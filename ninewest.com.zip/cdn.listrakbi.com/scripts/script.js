/*! Listrak LLC Business Intelligence (c) 2023 */
/*! Build Date 12/31/2023 12:43:34 AM */
/*! Version 1.0 - Mon, 18 Dec 2023 22:37:14 GMT */
function _Utilities() {
    this.Protocol = null;
    this.Context = {
        CTID: "sOwGMAximH7A",
        CartTemplateID: "sOwGMAximH7A",
        IsUsingSecureCookies: !1
    };
    this.AsyncManager = new AsyncManager;
    this.Identity = new Identity;
    this.testmodes = ["ltkjstestmode", "ltkdebugmode", "ltkvalidation"];
    var u = !1,
        i = null,
        r = function(n) {
            var t = "ltkCallback" + (Math.ceil(Math.random() * 8999) + 1e3);
            return window[t] = function() {
                try {
                    n.apply(this, arguments)
                } catch (i) {
                    _ltk_util.submitException(i, "Callback")
                }
                try {
                    window[t] = undefined;
                    delete window[t]
                } catch (i) {}
            }, t
        },
        c = function(n) {
            n.Protocol = "https:" == document.location.protocol ? "https://" : "http://"
        }(this);
    _Utilities.prototype.ready = function(n, t) {
        this.AsyncManager.StartAsyncCall("_ltk_utilReady-" + Math.random().toString(36).substr(2), n, t, ["jQuery", "_ltk", "sessionLoad"])
    };
    var t = "0123456789ABCDEFGHIJKLMNOPQRSTUV".split(""),
        f = {
            "0": 0,
            "1": 1,
            "2": 2,
            "3": 3,
            "4": 4,
            "5": 5,
            "6": 6,
            "7": 7,
            "8": 8,
            "9": 9,
            A: 10,
            B: 11,
            C: 12,
            D: 13,
            E: 14,
            F: 15,
            G: 16,
            H: 17,
            I: 18,
            J: 19,
            K: 20,
            L: 21,
            M: 22,
            N: 23,
            O: 24,
            P: 25,
            Q: 26,
            R: 27,
            S: 28,
            T: 29,
            U: 30,
            V: 31
        },
        e = function(n) {
            for (var u = "", o = n.length, f = 0, r = 0, t, i, e; f < o;) {
                if (t = n[f++], t <= 127) {
                    u += String.fromCharCode(t);
                    continue
                } else t > 191 && t <= 223 ? (i = t & 31, r = 1) : t <= 239 ? (i = t & 15, r = 2) : t <= 247 && (i = t & 7, r = 3);
                for (e = 0; e < r; ++e) t = n[f++], i <<= 6, i += t & 63;
                i <= 65535 && (u += String.fromCharCode(i))
            }
            return u
        },
        n = function(n, t) {
            return f[n.charAt(t)]
        },
        o = function(t) {
            var r, u, f, i;
            if (t = t.replace(/=/g, ""), r = [], u = t.match(/.{1,8}/g), !u) return r;
            for (f = 0; f < u.length; f++) i = u[f], r.push((n(i, 0) << 3 | n(i, 1) >>> 2) & 255), i.length > 2 && r.push((n(i, 1) << 6 | n(i, 2) << 1 | n(i, 3) >>> 4) & 255), i.length > 4 && r.push((n(i, 3) << 4 | n(i, 4) >>> 1) & 255), i.length > 5 && r.push((n(i, 4) << 7 | n(i, 5) << 2 | n(i, 6) >>> 3) & 255), i.length > 7 && r.push((n(i, 6) << 5 | n(i, 7)) & 255);
            return r
        },
        s = function(n) {
            for (var i = [], t, r = 0; r < n.length; r++) t = n.charCodeAt(r), t < 128 ? i.push(t) : t < 2048 ? (i.push(192 | t >> 6), i.push(128 | t & 63)) : t < 55296 || t >= 57344 ? (i.push(224 | t >> 12), i.push(128 | t >> 6 & 63), i.push(128 | t & 63)) : (t = 65536 + ((t & 1023) << 10 | n.charCodeAt(++index) & 1023), i.push(240 | t >> 18), i.push(128 | t >> 12 & 63), i.push(128 | t >> 6 & 63), i.push(128 | t & 63));
            return i
        },
        h = function(n) {
            for (var f = [], r = "", u, i; n.length;) f.push(n.splice(0, 5));
            for (u = 0; u < f.length; u++) i = f[u], r += t[i[0] >>> 3], r += t[(i[0] << 2 | i[1] >>> 6) & 31], i.length > 1 && (r += t[i[1] >>> 1 & 31], r += t[(i[1] << 4 | i[2] >>> 4) & 31]), i.length > 2 && (r += t[(i[2] << 1 | i[3] >>> 7) & 31]), i.length > 3 && (r += t[i[3] >>> 2 & 31], r += t[(i[3] << 3 | i[4] >>> 5) & 31]), i.length > 4 && (r += t[i[4] & 31]);
            return r
        };
    _Utilities.prototype.isValidCookieDomain = function() {
        if (!u) {
            if (window.location.host.toLowerCase().indexOf("localhost") > -1) i = null;
            else {
                var n = window.location.host.match(/([\.]*[^\.]+\.(co\.uk|com|net|biz|org|co\.nz|info|jp|edu|mx|com\.br|es|ca|pro|co|au|de|com\.au|fr|eu|com\.ar|us|cl|io|store|tv|fashion|world|coop|at|ch|myshopify\.com)$)|(^localhost$)/gi);
                i = n ? n[0].indexOf(".") != 0 ? "." + n[0] : n[0] : undefined
            }
            u = !0
        }
        return i !== undefined
    };
    _Utilities.prototype.getCookieDomain = function() {
        return this.isValidCookieDomain() ? i : window.location.host
    };
    _Utilities.prototype.getCookie = function(n) {
        return (n = _ltk_util.trim(n), document.cookie.length > 0 && (c_start = document.cookie.indexOf(n + "="), c_start != -1)) ? (c_start = c_start + n.length + 1, c_end = document.cookie.indexOf(";", c_start), c_end == -1 && (c_end = document.cookie.length), decodeURIComponent(document.cookie.substring(c_start, c_end))) : ""
    };
    _Utilities.prototype.setCookie = function(n, t, i, r, u, f) {
        var e = [_ltk_util.trim(n) + "=" + encodeURIComponent(t)],
            o, h, c;
        typeof i != "undefined" && i != null && (o = i, i instanceof Date || (o = new Date, o.setDate(o.getDate() + i)), e.push("expires=" + o.toGMTString()));
        typeof r != "undefined" && r != null && e.push("domain=" + r);
        typeof u != "undefined" && u != null && e.push("path=" + u);
        var s = this.Context.IsUsingSecureCookies,
            l = window.location.protocol === "https:",
            a = typeof f != "undefined" && f;
        (s && l || !s && a) && e.push("secure");
        h = e.join("; ");
        document.cookie = h;
        c = new _ltk_util.CustomEvent("ltk-cookie-updated", {});
        window.dispatchEvent(c)
    };
    _Utilities.prototype.deleteCookie = function(n, t, i, r) {
        _ltk_util.setCookie(n, "deleted", new Date(1970, 1, 1, 0, 0, 0), t, i, r)
    };
    _Utilities.prototype.cookiesEnabled = function() {
        var n = new Date,
            t;
        return n.setSeconds(n.getSeconds() + 180), _ltk_util.setCookie("checkCookies", "enabled", n, null, "/", null), t = _ltk_util.getCookie("checkCookies") == "enabled", t && _ltk_util.deleteCookie("checkCookies", null, "/", null), t
    };
    _Utilities.prototype.getJSONWithCallback = function(n, t) {
        var f = n,
            u, i, e;
        n.indexOf("callback=?") != -1 ? f = n.replace("callback=?", "callback=" + r(t)) : n.indexOf("callback=") == -1 && (u = n.indexOf("?"), f = u != -1 ? n.substring(0, u + 1) + "callback=" + r(t) + "&" + n.substring(u + 1) : n + "?callback=" + r(t));
        i = document.createElement("script");
        i.src = f;
        i.type = "text/javascript";
        i.async = !0;
        e = document.getElementsByTagName("script")[0];
        e.parentNode.insertBefore(i, e)
    };
    _Utilities.prototype.fire = function(n, t) {
        var i = new Image;
        i.height = 1;
        i.width = 1;
        i.src = n;
        t && (i.onload = t)
    };
    _Utilities.prototype.submitException = function(n, t) {
        if (n != null) {
            var i = _ltk_util.generateUUID(),
                r = "//s1.listrakbi.com/t/EX.ashx?ctid=" + _ltk_util.Context.CTID + "&uid=" + i + "&n=" + encodeURIComponent(n.name) + "&m=" + encodeURIComponent(n.message) + "&" + (t == null ? "" : "i=" + encodeURIComponent(t) + "&") + "h=" + encodeURIComponent(document.location.href);
            _ltk_util.fire(r, function() {
                if (_ltk.Testing) {
                    var i = {
                        Name: n.name,
                        Message: n.message,
                        Info: t
                    };
                    _ltk.Testing.Validate("Exception", {
                        Exception: i
                    })
                }
            })
        }
    };
    _Utilities.prototype.querySelectorAll = function() {
        function n(n, t) {
            var r = n.documentElement.firstChild,
                i = n.createElement("STYLE");
            return r.appendChild(i), n.arrayOfSelectorNodes = [], i.styleSheet.cssText = t + "{x:expression(document.arrayOfSelectorNodes.push(this))}", window.scrollBy(1, 0), r.removeChild(i), window.scrollBy(-1, 0), n.arrayOfSelectorNodes
        }

        function t(n, t) {
            return n.querySelectorAll(t)
        }
        return document.querySelectorAll ? t : n
    }();
    _Utilities.prototype.trim = function(n) {
        return typeof n == "string" ? String.prototype.trim ? n.trim() : n.replace(/^\s+|\s+$/g, "") : n
    };
    _Utilities.prototype.extend = function(n, t) {
        for (var i in t) t.hasOwnProperty(i) && (n[i] = t[i]);
        return n
    };
    _Utilities.prototype.getQuerystringValue = function(n) {
        n = n.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var i = "[\\?&]" + n + "=([^&#]*)",
            r = new RegExp(i),
            t = r.exec(window.location.href);
        return t == null ? "" : decodeURIComponent(t[1])
    };
    _Utilities.prototype.clearParameterValues = function(n, t) {
        var i, r, u, f, e;
        if (!n || n[0] !== "?" || !t) return n;
        for (i = n.split("&"), i.length && (i[0] = i[0].slice(1)), n = "", r = 0; r < i.length; ++r) {
            for (u = i[r], f = 0; f < t.length; ++f)
                if (e = t[f] + "=", u.indexOf(e) === 0) {
                    u = e;
                    break
                }
            n += (n ? "&" : "?") + u
        }
        return n
    };
    _Utilities.prototype.generateUUID = function() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(n) {
            var t = Math.random() * 16 | 0,
                i = n == "x" ? t : t & 3 | 8;
            return i.toString(16)
        }).toUpperCase()
    };
    _Utilities.prototype.consoleLog = function(n) {
        _ltk_util.isTestMode() && console.log(n)
    };
    _Utilities.prototype.isTestMode = function(n) {
        var i = function(n) {
                if (_ltk_util.getQuerystringValue(n) == 1) return !0;
                var i = !1,
                    t = _ltk_util.getCookie("ltkTestMode");
                return t && (t = t.split(","), i = t.indexOf(n) !== -1), i
            },
            t;
        if (n) return i(n);
        for (t = 0; t < _ltk_util.testmodes.length; t++)
            if (i(_ltk_util.testmodes[t])) return !0;
        return !1
    };
    _Utilities.prototype.encode = function(n) {
        return h(s(n))
    };
    _Utilities.prototype.decode = function(n) {
        return e(o(n))
    };
    _Utilities.prototype.getSubKey = function() {
        var n = this.getQuerystringValue("ltkSubKey");
        return this.decode(n)
    }
}

function AsyncManager() {
    this.Calls = [];
    AsyncManager.prototype.StartAsyncCall = function(n, t, i, r, u) {
        var f, e;
        try {
            return f = new AsyncCall(n, t, i, r, this), this.Calls.push(f), t === undefined ? f.InProgress = !0 : (u !== undefined && (e = function(n) {
                setTimeout(function() {
                    n.InProgress || (n.InProgress = !0, n.Delegate.call(n.DelegateObject || this), n.Complete())
                }, u)
            }, e(f)), this.CheckWait(f)), f
        } catch (o) {
            return _ltk_util.submitException(o, "AsyncManager.StartAsyncCall"), null
        }
    };
    AsyncManager.prototype.CallComplete = function(n) {
        try {
            for (var t = 0; t < this.Calls.length; t++)
                if (this.Calls[t].Name == n) {
                    this.Calls[t].InProgress = !1;
                    this.Calls[t].IsComplete = !0;
                    this.Calls.splice(t, 1);
                    break
                }
            this.CheckAllWaits()
        } catch (i) {
            return _ltk_util.submitException(i, "AsyncManager.CallComplete"), null
        }
    };
    AsyncManager.prototype.IsCallQueued = function(n) {
        for (var t = 0; t < this.Calls.length; t++)
            if (this.Calls[t].Name == n) return !0;
        return !1
    };
    AsyncManager.prototype.CheckWait = function(n) {
        var i, t, r;
        if (!n.InProgress) {
            for (i = !1, t = 0; t < n.CallsToWaitFor.length; t++)
                if (this.IsCallQueued(n.CallsToWaitFor[t])) {
                    i = !0;
                    break
                }
            i || (n.InProgress = !0, r = function(n) {
                setTimeout(function() {
                    n.Delegate.call(n.DelegateObject || this);
                    n.Complete()
                }, 0)
            }, r(n))
        }
    };
    AsyncManager.prototype.CheckAllWaits = function() {
        for (var n = 0; n < this.Calls.length; n++) this.CheckWait(this.Calls[n])
    }
}

function AsyncCall(n, t, i, r, u) {
    this.Name = n;
    this.Delegate = t;
    this.DelegateObject = i;
    this.CallsToWaitFor = r;
    this.InProgress = !1;
    this.IsComplete = !1;
    AsyncCall.prototype.Complete = function() {
        u.CallComplete(this.Name)
    }
}

function Identity() {
    function i(n, t) {
        n.handlers.push(t);
        var i = n.value;
        i && setTimeout(function() {
            t(i)
        }, 0)
    }

    function t() {
        var n = {
            handlers: [],
            value: ""
        };
        return function(t) {
            return setTimeout(function() {
                typeof t == "function" ? i(n, t) : typeof t == "string" && r(n, t)
            }, 0), t
        }
    }

    function r(n, t) {
        if (t = _ltk_util.trim((t || "").toString()), t && t != n.value) {
            n.value = t;
            for (var i = 0; i < n.handlers.length; i++)(function(n) {
                setTimeout(function() {
                    n(t)
                }, 0)
            })(n.handlers[i])
        }
    }
    var n = this;
    return n.ContactPID = t(), n.Email = t(), n.MobilePhone = t(), n.WebPushSubscriptionHash = t(), n
}

function LTK() {
    this.Session = new _Session;
    this.SCA = {};
    typeof SessionTracker != "undefined" && (this.SCA = new SessionTracker);
    this.Order = new _Order;
    this.Items = [];
    this.Products = [];
    this.Customer = new _Customer;
    this.Client = new _Client;
    this.TRKT = new _TRKT;
    this.Subscriber = new _LTKSubscriber;
    this.Signup = new _LTKSignup;
    this.Assembler = new _Assembler;
    this.Assembler.Name = "Conversion data";
    this.Click = new _LTKClick;
    this.Exception = {
        Submit: _ltk_util.submitException
    };
    this.TransactionIDs = [];
    LTK.prototype.Submit = function(n) {
        try {
            this.TRKT.T = this.GetCookie("_trkt");
            this.TRKT.Event = "t";
            this.Order.SetSessionID();
            this.PostData(n)
        } catch (t) {
            this.Exception.Submit(t, "Submit and Post Data")
        }
    };
    LTK.prototype.PostData = function(n) {
        var t = this.Order,
            i = this.TRKT,
            r = this.Customer,
            u = this.Items,
            f = this.Products;
        _ltk_util.AsyncManager.StartAsyncCall("submitConversion", function() {
            try {
                this.Assembler.QueryHeader = "ctid=" + this.Client.CTID + (this.Client.DebugMode ? "&debugmode=true" : "") + "&uid=" + this.uuidCompact() + "&gsid=" + _ltk.Session.GlobalID;
                this.Assembler.ContainsPII = !0;
                t.OrderNumber != null && (this.Assembler.QueryHeader += "&on=" + t.OrderNumber);
                this.Assembler.AddObject(t, "Order");
                this.Assembler.AddObject(i, "Tracking");
                this.Assembler.AddObject(r, "Customer");
                this.Assembler.AddArrayObject(u, "Items");
                this.Assembler.AddArrayObject(f, "Products");
                this.Assembler.Flush()
            } catch (n) {
                this.Exception.Submit(n, "Posting Data")
            }
        }, this, [_ltk.Session.GlobalIDAsyncCallName]);
        n === !0 && (this.Order = new _Order, this.TRKT = new _TRKT, this.Customer = new _Customer, this.Items = [], this.Products = [])
    };
    LTK.prototype.RandomString = function(n) {
        for (var t = "", i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", r = 0; r < n; r++) t += i.charAt(Math.floor(Math.random() * i.length));
        return t
    };
    LTK.prototype.uuidCompact = function() {
        var n = _ltk_util.generateUUID();
        try {
            this.TransactionIDs.push(n)
        } catch (t) {}
        return n
    };
    LTK.prototype.generateUUID = _ltk_util.generateUUID;
    LTK.prototype.GetCookie = function(n) {
        var t = "(?:; )?" + n + "=([^;]*);?",
            i = new RegExp(t);
        return i.test(document.cookie) ? decodeURIComponent(RegExp.$1) : null
    }
}

function _Order() {
    this._type = "o";
    this.UID = null;
    this.OrderNumber = null;
    this.OrderTotal = null;
    this.TaxTotal = null;
    this.ShippingTotal = null;
    this.HandlingTotal = null;
    this.ItemTotal = null;
    this.Currency = null;
    this.Meta1 = null;
    this.Meta2 = null;
    this.Meta3 = null;
    this.Meta4 = null;
    this.Meta5 = null;
    this.SessionID = null;
    this.Source = null;
    this._varmap = {
        _type: "_t",
        UID: "uid",
        OrderTotal: "ot",
        TaxTotal: "tt",
        ShippingTotal: "st",
        HandlingTotal: "ht",
        ItemTotal: "it",
        Currency: "c",
        Meta1: "m1",
        Meta2: "m2",
        Meta3: "m3",
        Meta4: "m4",
        Meta5: "m5",
        SessionID: "s",
        Source: "sr"
    };
    _Order.prototype.SetSessionID = function() {
        try {
            this.OrderNumber != null && (this.SessionID = _ltk.SCA.sessionID)
        } catch (n) {
            _ltk.Exception.Submit(n, "OrderSetSession")
        }
    };
    _Order.prototype.SetCustomer = function(n, t, i, r) {
        _ltk.Customer.Email = _ltk_util.Identity.Email(n);
        _ltk.Customer.FirstName = t;
        _ltk.Customer.LastName = i;
        _ltk.Customer.MobilePhone = _ltk_util.Identity.MobilePhone(r)
    };
    _Order.prototype.Submit = function(n) {
        if (document.dispatchEvent) {
            var t = new _ltk_util.CustomEvent("ltkCheckout", {
                detail: {
                    orderNumber: this.OrderNumber,
                    orderTotal: this.OrderTotal,
                    currency: this.Currency,
                    items: _ltk.Items
                }
            });
            document.dispatchEvent(t)
        }
        _ltk_util.deleteCookie("offers-" + _ltk.Client.CTID, _ltk_util.getCookieDomain(), "/");
        _ltk.Submit(n)
    };
    _Order.prototype.AddItem = function(n, t, i) {
        try {
            var r = new this.Item(n, t, i);
            _ltk.Items.push(r)
        } catch (u) {
            _ltk.Exception.Submit(u, "Add Item")
        }
    };
    _Order.prototype.AddItemEx = function(n) {
        try {
            _ltk.Items.push(n)
        } catch (t) {
            _ltk.Exception.Submit(t, "Add Item Ex")
        }
    };
    _Order.prototype.Item = function(n, t, i) {
        this._type = "i";
        this.UID = null;
        this.ID = n;
        this.Name = null;
        this.Quantity = t;
        this.Price = i;
        this.RowID = null;
        this.Meta1 = null;
        this.Meta2 = null;
        this.Meta3 = null;
        this.Meta4 = null;
        this.Meta5 = null;
        this._varmap = {
            _type: "_t",
            UID: "uid",
            ID: "id",
            Name: "n",
            Quantity: "q",
            Price: "p",
            RowID: "ri",
            Meta1: "m1",
            Meta2: "m2",
            Meta3: "m3",
            Meta4: "m4",
            Meta5: "m5"
        }
    }
}

function _TRKT() {
    this._type = "tt";
    this.UID = null;
    this.T = null;
    this.Event = null;
    this._varmap = {
        _type: "_t",
        UID: "uid",
        T: "t",
        Event: "e"
    }
}

function _Product(n, t, i, r, u, f, e, o) {
    this._type = "p";
    this.UID = null;
    this.ID = n;
    this.Name = t;
    this.Price = i;
    this.ImageUrl = r;
    this.ItemUrl = u;
    this.Description = f;
    this.Meta1 = null;
    this.Meta2 = null;
    this.Meta3 = null;
    this.Meta4 = null;
    this.Meta5 = null;
    this.MasterSku = typeof e == "undefined" ? null : e;
    this.ReviewProductID = typeof o == "undefined" ? null : o;
    this.Discontinued = null;
    this._varmap = {
        _type: "_t",
        UID: "uid",
        ID: "id",
        Name: "n",
        Price: "p",
        ImageUrl: "imu",
        ItemUrl: "itu",
        Description: "d",
        Meta1: "m1",
        Meta2: "m2",
        Meta3: "m3",
        Meta4: "m4",
        Meta5: "m5",
        MasterSku: "ms",
        ReviewProductID: "rpi",
        Discontinued: "ds"
    };
    _Product.prototype.Add = function() {
        try {
            _ltk.Products.push(this)
        } catch (n) {
            _ltk.Exception.Submit(n, "Add Product")
        }
    }
}

function _Customer() {
    this._type = "c";
    this.UID = null;
    this.Email = null;
    this.FirstName = null;
    this.LastName = null;
    this.MobilePhone = null;
    this.Meta1 = null;
    this.Meta2 = null;
    this.Meta3 = null;
    this.Meta4 = null;
    this.Meta5 = null;
    this._varmap = {
        _type: "_t",
        UID: "uid",
        Email: "e",
        FirstName: "fn",
        LastName: "ln",
        MobilePhone: "mp",
        Meta1: "m1",
        Meta2: "m2",
        Meta3: "m3",
        Meta4: "m4",
        Meta5: "m5"
    }
}

function _Client() {
    this.CTID = null;
    this.DebugMode = !1
}

function _Assembler() {
    this.QueryHeader = null;
    this.QueryMode = 0;
    this.EndPointArray = ["s1.listrakbi.com/t", "s2.listrakbi.com/t"];
    this.EndPointPath = "/T.ashx";
    this.EndPointIndex = 0;
    this.EnumIndex = 0;
    this.MaxLength = 950;
    this.Query = "";
    this.Name = "Assembler";
    this.Data = null;
    this.RequestMode = "img";
    this.ContainsPII = !1;
    this._protocol = "https:" == document.location.protocol ? "https://" : "http://";
    _Assembler.prototype.Reset = function() {
        this.Query = "";
        this.QueryMode == 0 && (this.EnumIndex = 0)
    };
    _Assembler.prototype.Append = function(n, t, i) {
        var r = this.BuildQuery(n, t, i),
            u = this.Query + r;
        u.length > this.MaxLength && (this.Flush(), r = this.BuildQuery(n, t, i));
        this.Query += r;
        (this.QueryMode == 0 || n._isIndexable) && this.EnumIndex++
    };
    _Assembler.prototype.Flush = function(n) {
        var i, t;
        if (this.Query != "") {
            i = this.Name + " Submitted";
            t = this.Data;
            t != null && _ltk.Testing.Validate(i, t);
            var r = function(r) {
                    t != null && _ltk.Testing.Validate(i, t);
                    typeof n == "function" && n(r)
                },
                u = this._protocol + this.EndPointArray[this.EndPointIndex] + this.EndPointPath + "?" + this.QueryHeader + this.Query,
                e = this.RequestMode,
                f = function() {
                    if (e == "script") _ltk_util.getScript(u, n || function() {});
                    else {
                        var t = new Image;
                        t.height = 1;
                        t.width = 1;
                        t.onload = r;
                        t.src = u
                    }
                };
            this.ContainsPII ? _ltk_util.ready(function() {
                _ltk.Session.getPersonalizedStatus() ? f() : r()
            }, this) : f();
            this.IncrementEndPointIndex();
            this.Reset()
        }
    };
    _Assembler.prototype.IncrementEndPointIndex = function() {
        this.EndPointIndex++;
        this.EndPointIndex == this.EndPointArray.length && (this.EndPointIndex = 0)
    };
    _Assembler.prototype.BuildQuery = function(n, t, i) {
        var f = -1,
            u = "";
        for (var r in n) r != "_varmap" && typeof n[r] != "function" && (f++, typeof n[r] != "undefined" && n[r] != null && typeof n._varmap[r] != "undefined" && n[r] != "") && (typeof t != "undefined" && (this.Data == null && (this.Data = {}), typeof this.Data[t] == "undefined" && (this.Data[t] = {}), typeof i != "undefined" ? (typeof this.Data[t][i] == "undefined" && (this.Data[t][i] = {}), this.Data[t][i][r] = n[r]) : this.Data[t][r] = n[r]), u += "&" + n._varmap[r] + (this.QueryMode == 0 || n._isIndexable ? "_" + this.EnumIndex : "") + "=" + encodeURIComponent(n[r]));
        return u
    };
    _Assembler.prototype.AddObject = function(n, t, i) {
        typeof n != "undefined" && n != null && this.HasValue(n) && typeof n._varmap != "undefined" && this.Append(n, t, i)
    };
    _Assembler.prototype.AddArrayObject = function(n, t) {
        if (typeof n != "undefined" && n != null)
            for (var i in n) this.AddObject(n[i], t, i)
    };
    _Assembler.prototype.HasValue = function(n) {
        var i, t;
        if (typeof n == "undefined" || n == null || typeof n._varmap == "undefined" || n._varmap == null) return !1;
        i = !1;
        for (t in n) t != "_varmap" && typeof n[t] != "function" && t != "_type" && typeof n[t] != "undefined" && n[t] != null && typeof n._varmap[t] != "undefined" && (i = !0);
        return i
    }
}

function _LTKClick() {
    this._endpoint = "s1.listrakbi.com/t";
    this._protocol = "https:" == document.location.protocol ? "https://" : "http://";
    this._roothost = null;
    _LTKClick.prototype.SetCookie = function(n, t, i, r, u, f) {
        _ltk_util.setCookie(n, t, i, r, u, f)
    };
    _LTKClick.prototype.Submit = function() {
        try {
            var i = new RegExp(/([\.]*[^\.]+\.(co\.uk|com|net|biz|org|co\.nz|info|jp|edu|mx|com\.br|es|ca|pro|co|au|de|com\.au|fr|eu|com\.ar|us|cl|io|store|tv|fashion|world|coop|at|ch|myshopify\.com)$)|(^localhost$)/gi),
                r = new RegExp(/[?&]*trk_[^=&]+=/gi),
                n = !0,
                t = document.location.host.match(i),
                u = document.location.search.match(r);
            t ? (this._roothost = t[0], this._roothost.indexOf(".") != 0 && (this._roothost = "." + this._roothost)) : n = !1;
            n && u && _ltk_util.ready(function() {
                _ltk.Session.getPersonalizedStatus() && (this.SetCookie("_trkt", "0", 365, this._roothost, "/", null), this.ScriptPostData(this._protocol + this._endpoint + "/CT.ashx?" + (_ltk.Client.CTID == null ? "" : "ctid=" + _ltk.Client.CTID + "&") + (_ltk.Client.DebugMode ? "debugmode=true&" : "") + "uid=" + _ltk.uuidCompact() + "&_t_0=cp&e_0=c&q_0=" + encodeURIComponent(document.location.search) + "&_version=1"))
            }, this)
        } catch (f) {
            _ltk.Exception.Submit(f, "Submit Click")
        }
    };
    _LTKClick.prototype.ScriptPostData = function(n) {
        var t = document.createElement("script");
        t.setAttribute("src", n);
        t.setAttribute("type", "text/javascript");
        document.body.appendChild(t)
    };
    _LTKClick.prototype.CallBack = function(n) {
        this.SetCookie("_trkt", n.token, 365, this._roothost, "/", null)
    }
}

function _LTKSubscriber() {
    this.List = null;
    this.Settings = null;
    this.Email = null;
    this.UpdatedEmail = null;
    this.ModalUID = null;
    this.Profile = new _Profile;
    this._endpoint = "s1.listrakbi.com/t";
    this._protocol = "https:" == document.location.protocol ? "https://" : "http://";
    var n = function(n, t, i, r, u, f, e, o) {
        var a, v, l, c, s, y, h, p;
        for (document.dispatchEvent && (a = new _ltk_util.CustomEvent(n ? "ltkUnsubscribe" : "ltkSubscribe", {
                detail: {
                    list: r,
                    email: t,
                    profile: u.Items
                }
            }), document.dispatchEvent(a)), v = (_ltk.uuidCompact || _ltk_util.generateUUID)(), l = "ctid=" + _ltk_util.Context.CTID + "&uid=" + v + "&gsid=" + o + "&_t_0=" + (n === !0 ? "u" : "s") + (t == null ? "" : "&e_0=" + encodeURIComponent(t)) + (i == null ? "" : "&u_0=" + encodeURIComponent(i)) + (r == null ? "" : "&l_0=" + encodeURIComponent(r)) + (f == null ? "" : "&s_0=" + encodeURIComponent(f)) + (e == null ? "" : "&m_0=" + encodeURIComponent(e)), c = 0; c < u.Items.length; c++) s = u.Items[c], s.AttributeID != null && s.Value != null && (l += "&" + encodeURIComponent(s.AttributeID) + "_0=" + encodeURIComponent(s.Value));
        y = "//s1.listrakbi.com/t/S.ashx?" + l;
        h = new Image;
        h.width = 1;
        h.height = 1;
        h.src = y;
        _ltk.Testing && (p = _ltk_util.extend({}, this), h.onload = function() {
            _ltk.Testing.Validate("Subscriber", {
                Subscriber: p
            })
        })
    };
    _LTKSubscriber.prototype.Submit = function(t) {
        var r, i, u, f;
        try {
            if (r = arguments.length > 1 && arguments[1] == "unsubscribe", typeof _ltk.Session != "undefined") {
                var e = this.Email,
                    o = this.UpdatedEmail,
                    s = this.List,
                    h = this.Profile,
                    c = this.Settings,
                    l = this.ModalUID;
                _ltk_util.ready(function() {
                    try {
                        n(r, e, o, s, h, c, l, _ltk.Session.GlobalID)
                    } catch (t) {
                        _ltk_util.submitException(t, "Subscriber Submit Delegate")
                    }
                }, this)
            } else n(r, this.Email, this.UpdatedEmail, this.List, this.Profile, this.Settings, this.ModalUID, "");
            i = _ltk_util.getCookie("ltk-subscribed");
            i ? (i = i.split(","), u = i.indexOf(this.List), r && u !== -1 && i.splice(u, 1), r || u != -1 || i.push(this.List)) : r || (i = [], i.push(this.List));
            i.length > 0 ? (f = new Date, f.setMonth(f.getMonth() + 120), _ltk_util.setCookie("ltk-subscribed", i, f, _ltk_util.getCookieDomain(), "/")) : _ltk_util.deleteCookie("ltk-subscribed", _ltk_util.getCookieDomain(), "/");
            (_ltk.isValidEmail(this.Email) || _ltk.isValidEmail(this.UpdatedEmail)) && _ltk_util.Identity.Email(this.UpdatedEmail || this.Email);
            (_ltk.isValidSMSNumber(this.Email) || _ltk.isValidSMSNumber(this.UpdatedEmail)) && _ltk_util.Identity.MobilePhone(this.UpdatedEmail || this.Email);
            t === !0 && (this.List = null, this.Email = null, this.UpdatedEmail = null, this.Profile = new _Profile)
        } catch (a) {
            _ltk_util.submitException(a, "Subscriber Submit")
        }
    };
    _LTKSubscriber.prototype.Unsubscribe = function(n) {
        this.Submit(n, "unsubscribe")
    }
}

function _Profile() {
    this.Items = [];
    _Profile.prototype.Add = function(n, t) {
        var i = new _ProfileItem;
        i.AttributeID = n;
        i.Value = t;
        this.Items.push(i)
    }
}

function _ProfileItem() {
    this.AttributeID = null;
    this.Value = null
}

function _LTKSignup() {
    function h(n, t, i) {
        _ltk_util.AsyncManager.StartAsyncCall("appendSubmitEvent", function() {
            var r = f(t);
            v(r, i, function() {
                _ltk.Signup.SetValue(n, "ltkSaved", !0);
                _ltk.Signup.Subscribe(n)
            })
        }, this, ["jQuery"])
    }

    function f(n) {
        var t, i = n.indexOf(":") > -1 ? n.replace(":", "\\:") : n,
            r = document.querySelector(i);
        return window.jQuery ? (t = jQuery(r), t.length === 0 && (t = jQuery("[id='" + n + "']")), t.length === 0 && (t = jQuery("[name='" + n + "']")), t.length === 0 && (t = jQuery(i)), t) : r
    }

    function c(n, t) {
        return n.is("input[type='checkbox']") ? n.is(":checked") ? "on" : "off" : y(n, t) ? n.is(":checked") ? "on" : "off" : tt(n, t) ? n.find(":selected").text() : n.val()
    }

    function y(n, t) {
        return n.is("input[type='radio']") && t.radio == "checked"
    }

    function tt(n, t) {
        return n.is("select") && t.dropdown == "text"
    }

    function it(n) {
        if (!n) return !1;
        var r = n.ltkSaved ? n.ltkSaved : !1,
            i = n.ltkEmail ? n.ltkEmail : n.ltkUnsubscribe ? n.ltkUnsubscribe : "",
            u = n.ltkOptIn ? n.ltkOptIn == "on" : !0,
            f = n.ltkOptOut ? n.ltkOptOut == "on" : !1,
            t = !1,
            e = n.ltkChannel;
        switch (e) {
            case "sms":
                t = _ltk.isValidSMSNumber(i);
                break;
            default:
                t = _ltk.isValidEmail(i)
        }
        return r && t && u && !f
    }

    function rt(n, t) {
        var i = typeof t == "undefined" ? {} : t;
        return i.key || (i.key = n), i.dropdown || (i.dropdown = "value"), i.radio || (i.radio = "checked"), i
    }

    function ut(n) {
        return new Date(Date.parse(n + " 1, 2016")).getMonth() + 1
    }

    function ft(n, t, i) {
        if (typeof n == "string" && (n = ut(n)), typeof n == "number") return t = typeof t == "number" ? t : 1, i = typeof i == "number" ? i : (new Date).getFullYear(), n + "/" + t + "/" + i
    }

    function et(n, t) {
        _ltk_util.setCookie(n, t, null, _ltk_util.getCookieDomain(), "/")
    }

    function ot(n) {
        return _ltk_util.getCookie(n)
    }

    function st(n) {
        _ltk_util.deleteCookie(n, _ltk_util.getCookieDomain(), "/")
    }

    function ht(n, t) {
        var i = JSON.stringify(t);
        et("ltkSubscriber-" + n, window.btoa(i))
    }

    function l(n) {
        var t = ot("ltkSubscriber-" + n),
            i;
        return t ? (i = window.atob(t), JSON.parse(i)) : {}
    }

    function ct(n) {
        st("ltkSubscriber-" + n)
    }

    function p() {
        var i = {
                lists: {}
            },
            r = "ltkSubscriber-",
            u = document.cookie.split("; "),
            f, n, e, o, t, s;
        for (f in u)(n = u[f], typeof n == "string") && (e = n.indexOf("="), o = n.substring(0, e), n.indexOf(r) == 0 && (t = o.replace(r, ""), s = l(t), i.lists[t] = s));
        return i
    }

    function w(t, i) {
        typeof i != "undefined" && n(t, "ltkForceOverride", i)
    }

    function r(n, t) {
        var i = f(t);
        v(i, "click", function() {
            o(n)
        })
    }

    function t(n, t, i) {
        g(n, t, i)
    }

    function n(n, t, i) {
        s(n, t, i)
    }

    function i(n, i, r) {
        e(n, r);
        t(n, i, {
            key: "ltkEmail"
        })
    }

    function u(n, i, r) {
        e(n, r);
        t(n, i, {
            key: "ltkUnsubscribe"
        })
    }

    function lt(t, i, r) {
        e(t, r);
        n(t, "ltkEmail", i)
    }

    function e(t, i) {
        (typeof i == "undefined" || i == "") && (i = "trigger");
        n(t, "ltkTrigger", i)
    }

    function o(t) {
        n(t, "ltkSaved", !0)
    }

    function a(n, i, r, u, f) {
        var e = "ltkDate-" + i;
        t(n, r, {
            key: e,
            date: "month",
            dropdown: "text"
        });
        u && t(n, u, {
            key: e,
            date: "day",
            dropdown: "text"
        });
        f && t(n, f, {
            key: e,
            date: "year",
            dropdown: "text"
        })
    }

    function at(n) {
        var t = l(n);
        d(n, t)
    }

    function b(n, t, i, r, u) {
        return n == null || typeof n == "undefined" ? (_ltk_util.consoleLog("subscriber_code param cannot be null or undefined"), !1) : t == null || typeof t == "undefined" && i != _ltk.Signup.TYPE.CHECKOUT ? (_ltk_util.consoleLog("id param cannot be null or undefined"), !1) : i == null || typeof i == "undefined" ? (_ltk_util.consoleLog("type param cannot be null. Please use one of the types in the _ltk.Signup.TYPE enumerator."), !1) : (i == _ltk.Signup.TYPE.CLICK || i == _ltk.Signup.TYPE.DEFAULT) && (r == null || typeof r == "undefined") ? (_ltk_util.consoleLog("Function parameter 'button' cannot be null or undefined if using CLICK or DEFAULT enumerator."), !1) : u != "sms" && u != "email" ? (_ltk_util.consoleLog('channel param is not set to a valid value. Please use either "sms" or "email".'), !1) : !0
    }

    function k(t) {
        var u, i, r;
        t === "checkout" && _ltk.Order.OrderNumber && (n("Checkout", "ltkEmail", _ltk.Customer.Email), n("Checkout", "FirstName", _ltk.Customer.FirstName), n("Checkout", "LastName", _ltk.Customer.LastName), n("Checkout", "ltkSaved", "true"));
        u = p();
        lists = u.lists;
        for (i in lists) r = lists[i], r.ltkTrigger == t && d(i, r)
    }

    function d(n, t) {
        var i, r;
        if (it(t)) {
            _ltk_util.consoleLog(t);
            var f = t.ltkUnsubscribe ? !0 : !1,
                u = !1,
                e = t.ltkForceOverride ? t.ltkForceOverride : !1;
            _ltk.Subscriber.List = this.List;
            _ltk.Subscriber.Email = this.Email;
            _ltk.Subscriber.SourceUID = this.SourceUID;
            this.Profile = new _Profile;
            try {
                _ltk.Subscriber.List = n;
                for (i in t)(r = t[i], (e || r != "") && i != "ltkSaved" && i != "ltkTrigger") && (i == "ltkEmail" || i == "ltkUnsubscribe" ? _ltk.Subscriber.Email = r : i == "ltkUpdatedEmail" ? _ltk.Subscriber.UpdatedEmail = r : i.indexOf("ltkDate-") == 0 ? (i = i.replace("ltkDate-", ""), _ltk.Subscriber.Profile.Add(i, ft(r.month, r.day, r.year))) : _ltk.Subscriber.Profile.Add(i, r));
                _ltk.Subscriber.Profile.Add("ltkSource", "on");
                f ? (_ltk_util.consoleLog("_ltk.Signup.Submit(reset, unsubscribe);"), _ltk.Subscriber.Unsubscribe()) : (_ltk_util.consoleLog("_ltk.Signup.Submit(true);"), _ltk.Subscriber.Submit(!0));
                u = !0
            } catch (o) {
                _ltk.Exception.Submit(o, "SubmitSubscriber-" + n)
            }
            u && ct(n)
        }
    }

    function s(n, t, i, r) {
        var u = l(n);
        r ? (u[t] || (u[t] = {}), u[t][r] = i) : u[t] = i;
        ht(n, u)
    }

    function v(n, t, i) {
        if (n)
            if (n.addEventListener) n.addEventListener(t, i, !1);
            else if (n.attachEvent) n.attachEvent("on" + t, i);
        else if (jQuery.on) n.on(t, i);
        else jQuery.bind ? n.bind(t, i) : _ltk.Exception.Submit("Cannot attach to event: " + t, "SubscriberAppendEvent-" + t)
    }
    var g, nt;
    this.List = null;
    this.Email = null;
    this.SourceUID = null;
    this.Profile = new _Profile;
    _LTKSignup.prototype.GetSavedSubscriberData = function() {
        return p()
    };
    _LTKSignup.prototype.GetSubscriptionKeys = function() {
        var u = _ltk.Signup.GetSavedSubscriberData(),
            i = u.lists,
            n, r, t;
        _ltk_util.consoleLog("Field names to map in Listrak Platform:");
        for (n in i) {
            _ltk_util.consoleLog("Subscription point: " + n);
            r = i[n];
            for (t in r) t.indexOf("ltk") != 0 && _ltk_util.consoleLog("   Field name: " + t);
            _ltk_util.consoleLog("   Field name: ltkSource")
        }
    };
    this.TYPE = {
        DEFAULT: "load",
        CHECKOUT: "checkout",
        CLICK: "click",
        CUSTOM: "trigger"
    };
    _LTKSignup.prototype.EnableCheckout = function() {
        i("Checkout", "ltkEmail", "checkout");
        o("Checkout")
    };
    _LTKSignup.prototype.New = function(t, u, f, e, s) {
        if ((s === undefined || s === "") && (s = "email"), s = s.toLowerCase(), !b(t, u, f, e, s)) return _ltk.Exception.Submit("LTKSignup.New error: One or more invalid parameters, please check debug console output for details");
        _ltk.SCA && _ltk.SCA.CaptureEmail(u);
        n(t, "ltkChannel", s);
        switch (f) {
            case this.TYPE.DEFAULT:
                i(t, u, "load");
                r(t, e);
                break;
            case this.TYPE.CHECKOUT:
                i(t, u, "checkout");
                o(t);
                break;
            case this.TYPE.CLICK:
                i(t, u, "load");
                h(t, e, "click");
                break;
            case this.TYPE.CUSTOM:
                i(t, u, f);
                break;
            default:
                _ltk.Exception.Submit("type enum not recognized!")
        }
    };
    _LTKSignup.prototype.Remove = function(t, i, f, e, o) {
        if ((o === undefined || o === "") && (o = "email"), o = o.toLowerCase(), !b(t, i, f, e, o)) return _ltk.Exception.Submit("LTKSignup.Remove error: One or more invalid parameters, please check debug console output for details");
        n(t, "ltkChannel", o);
        switch (f) {
            case this.TYPE.DEFAULT:
                u(t, i, "load");
                r(t, e);
                break;
            case this.TYPE.CLICK:
                u(t, i, "load");
                h(t, e, "click");
                break;
            case this.TYPE.CUSTOM:
                u(t, i, f);
                break;
            default:
                _ltk.Exception.Submit("type enum not recognized!")
        }
    };
    _LTKSignup.prototype.SubscribeFromTrigger = function(n) {
        k(n)
    };
    _LTKSignup.prototype.SetSubmitEvent = function(n, t, i) {
        h(n, t, i)
    };
    _LTKSignup.prototype.SetUnsubscribeEmailWithButtonClick = function(n, t, i) {
        u(n, id, "load");
        r(n, i)
    };
    _LTKSignup.prototype.SetEmailValue = function(n, t) {
        lt(n, t, "load")
    };
    _LTKSignup.prototype.SetUpdateEmail = function(n, i) {
        t(n, i, {
            key: "ltkUpdateEmail"
        })
    };
    _LTKSignup.prototype.SetOptIn = function(n, i) {
        t(n, i, {
            key: "ltkOptIn"
        })
    };
    _LTKSignup.prototype.SetOptOut = function(n, i) {
        t(n, i, {
            key: "ltkOptOut"
        })
    };
    _LTKSignup.prototype.SetDateFields = function(n, t, i, r, u) {
        a(n, t, i, r, u)
    };
    _LTKSignup.prototype.SetBirthdayFields = function(n, t, i, r) {
        a(n, "birthday", t, i, r)
    };
    _LTKSignup.prototype.SetAnniversaryFields = function(n, t, i, r) {
        a(n, "anniversary", t, i, r)
    };
    _LTKSignup.prototype.SetForceOverride = function(n, t) {
        w(n, t)
    };
    _LTKSignup.prototype.SetTrigger = function(n, t) {
        e(n, t)
    };
    _LTKSignup.prototype.SetValueFromQueryString = function(t, i) {
        var r = _ltk_util.getQuerystringValue(i);
        n(t, i, r)
    };
    _LTKSignup.prototype.SetField = function(n, i, r) {
        t(n, i, r)
    };
    _LTKSignup.prototype.SetFieldWithKey = function(n, i, r) {
        t(n, i, {
            key: r
        })
    };
    _LTKSignup.prototype.SetValue = function(t, i, r) {
        n(t, i, r)
    };
    _LTKSignup.prototype.Subscribe = function(n, t) {
        w(n, t);
        at(n)
    };
    v(document, "ltkCheckout", function() {
        k("checkout")
    });
    g = new function() {
        function n(n) {
            var l, u, r;
            if (typeof n != "undefined") {
                var i = jQuery(this),
                    e = n.data,
                    o = e.list,
                    v = e.id,
                    t = e.options,
                    h = t.key;
                if (y(i, t))
                    for (l = i.length == 1 ? f(v) : i, u = 0; u < l.length; u++) {
                        var a = jQuery(l[u]),
                            r = c(a, t),
                            p = h + "-" + a.val();
                        s(o, p, r)
                    } else t.date ? (r = c(i, t), s(o, h, r, t.date)) : (r = c(i, t), s(o, h, r))
            }
        }
        return function(t, i, r) {
            if (typeof i != "undefined" && i != "") {
                r = rt(i, r);
                try {
                    _ltk_util.AsyncManager.StartAsyncCall("setupCaptureSubscriberValue-" + i, function() {
                        try {
                            var e = {
                                    list: t,
                                    id: i,
                                    options: r
                                },
                                u = f(i);
                            u.length && (u.change.length > 1 ? u.change(e, n) : u.bind("change", e, n), n.apply(u, [{
                                data: e
                            }]))
                        } catch (o) {
                            _ltk.Exception.Submit(o, "CaptureSubscriberValue-" + i)
                        }
                    }, this, ["jQuery"])
                } catch (u) {
                    _ltk.Exception.Submit(u, "Init CaptureSubscriberValue-" + i)
                }
            }
        }
    };
    document.dispatchEvent && (nt = new _ltk_util.CustomEvent("ltkSignupLoad", {
        detail: "ltkSignupLoad"
    }), document.dispatchEvent(nt));
    _LTKSignup.prototype.SetEmail = function(n, t) {
        i(n, t, "load")
    };
    _LTKSignup.prototype.SetEmailWithManualTrigger = function(n, t) {
        i(n, t, "trigger")
    };
    _LTKSignup.prototype.SetEmailWithCheckoutTrigger = function(n, t) {
        i(n, t, "checkout");
        o(n)
    };
    _LTKSignup.prototype.SetEmailWithButtonClick = function(n, t, u) {
        i(n, t, "load");
        r(n, u)
    };
    _LTKSignup.prototype.SetCheckoutEmailWithButtonClick = function(n, t, u) {
        i(n, t, "checkout");
        r(n, u)
    };
    _LTKSignup.prototype.SetUnsubscribeEmail = function(n, t) {
        u(n, t, "load")
    };
    _LTKSignup.prototype.SetUnsubscribeEmailWithManualTrigger = function(n, t) {
        u(n, t, "trigger")
    };
    _LTKSignup.prototype.SetButtonClick = function(n, t) {
        r(n, t)
    }
}

function isWatermark(n) {
    return !_ltkwmt || _ltkwmt.length == 0 ? !1 : _ltkwmt.indexOf(n) >= 0 ? !0 : !1
}

function _Session() {
    var n = this,
        r, t, i, u;
    return n.AsyncCallName = "sessionLoad", n.GlobalID = null, n.GlobalIDAsyncCallName = "getGlobalSessionID", n.CartID = null, n.CartIDAsyncCallName = "scaGetTemplate", n.ContactPID = null, r = !1, n.setCartID = function(t, i) {
        n.CartID = t;
        r = !!i
    }, t = null, i = null, n.setPersonalizedStatus = function(r) {
        t === null ? i = r : (_ltk_util.fire("https://s1.listrakbi.com/sOwGMAximH7A/session/setPersonalizedStatus?status=" + !!r), _ltk_util.setCookie("TRUSR", r ? "1" : "0", 365, _ltk_util.getCookieDomain(), "/", null), t = t && r, r || (n.GlobalID = null, _ltk_util.deleteCookie("GSIDsOwGMAximH7A", _ltk_util.getCookieDomain(), "/", null), n.CartID = null, _ltk.SCA.sessionID = undefined, _ltk_util.deleteCookie("STSID" + _ltk_util.Context.CartTemplateID, _ltk_util.getCookieDomain(), "/", null), _ltk_util.deleteCookie("_trkt", _ltk.Click._roothost, "/", null), _ltk_util.deleteCookie("_cpid", _ltk_util.getCookieDomain(), "/", null), _ltk_util.storageAvailable("sessionStorage") && (sessionStorage.removeItem("_ltk.Activity.session"), sessionStorage.removeItem("ltk-sessionViewed")), _ltk_util.storageAvailable("localStorage") && localStorage.removeItem("ltk-recentlyViewed"), _ltk_util.deleteCookie("_vuid")))
    }, n.getPersonalizedStatus = function() {
        if (t === null) throw new Error("Invalid personalization usage - please wrap logic with call to _ltk_util.ready.");
        return t
    }, u = function(n) {
        var u = _ltk_util.AsyncManager.StartAsyncCall(n.GlobalIDAsyncCallName),
            f = _ltk_util.AsyncManager.StartAsyncCall(n.CartIDAsyncCallName),
            e = _ltk_util.AsyncManager.StartAsyncCall(n.AsyncCallName);
        try {
            var o = _ltk_util.getCookie("GSIDsOwGMAximH7A"),
                s = _ltk_util.getCookie("STSID" + _ltk_util.Context.CartTemplateID),
                h = function(n) {
                    switch (n) {
                        case "1":
                            return !0;
                        case "0":
                            return !1;
                        default:
                            return null
                    }
                }(_ltk_util.getCookie("TRUSR"));
            _ltk_util.getJSONWithCallback("https://s1.listrakbi.com/sOwGMAximH7A/session/getIds?callback=?&gsid=" + o + "&_sid=" + s + "&_tid=" + _ltk_util.Context.CartTemplateID + "&ps=" + h + "&dps=true", function(u) {
                var f, e, o;
                try {
                    t = u.personalized;
                    i !== null && n.setPersonalizedStatus(i);
                    u.personalized && (n.GlobalID = u.globalId, _ltk_util.setCookie("GSIDsOwGMAximH7A", n.GlobalID, u.globalExpiry, _ltk_util.getCookieDomain(), "/", null), r || (n.CartID = u.cartId), _ltk.SCA.sessionID = n.CartID, _ltk_util.setCookie("STSID" + _ltk_util.Context.CartTemplateID, n.CartID, 365, _ltk_util.getCookieDomain(), "/", null), f = document.location.href.match(/[?&]trk_contact=([^&]*)/i), f != null && f.length > 1 ? (e = new Date, e.setMonth(e.getMonth() + 120), _ltk_util.setCookie("_cpid", f[1], e, _ltk_util.getCookieDomain(), "/", null), n.ContactPID = _ltk_util.Identity.ContactPID(f[1])) : (o = _ltk_util.getCookie("_cpid"), o && (n.ContactPID = o)))
                } catch (s) {
                    _ltk_util.submitException(s, "GetGSID Callback")
                }
                _ltk_util.AsyncManager.CallComplete(n.GlobalIDAsyncCallName);
                _ltk_util.AsyncManager.CallComplete(n.CartIDAsyncCallName);
                _ltk_util.AsyncManager.CallComplete(n.AsyncCallName)
            })
        } catch (c) {
            _ltk_util.submitException(c, "GetGSID");
            u.Complete();
            f.Complete();
            e.Complete()
        }
    }(n), n
}

function MerchandiseBlock() {
    this.LastAPIUrl = null;
    this.MerchandiseBlockUID = null;
    this.Email = null;
    this.DefaultFields = ["Sku", "Title", "Price", "ImageUrl", "LinkUrl", "RecipeUID", "ProductUID"]
}

function OnescriptAuthClassRegistry() {
    var n = this;
    n.ltk = _ltk;
    n.ltkUtil = _ltk_util
}

function initializeOnescriptAuthIntegration() {
    _ltk.OnescriptAuth = {
        getToken: function() {
            return "eyJhbGciOiJSU0EtT0FFUCIsImVuYyI6IkEyNTZDQkMtSFM1MTIiLCJraWQiOiJPbmVTY3JpcHRBdXRoIiwidHlwIjoiSldUIn0.Xzo5z66ygiw_Z9qGP6Sni2oGLZfcFRy53rraxrLnOjrxy4OLpe6I1O3zwg6Qnmepyc08SqbxswkThoRtk9YiBNHTrl6vy5ZKzrdXs0t4PXGpsXrEbrfupDZZ3_-QXf6DsXQQrbYXkVHiHPcrHbPIiJoVlw7q2pDdpAXDZrW_oknr25hdZOF9Gb1O2Qx2etYvZVggqMUisLYwOCPksoDOau9wmbasyJLtydkHSa9crv6hBilMVaUSdBOqeWZ0Teoc1ZP17edUV5Z6P7X4TuJ9eLyibqsXfMI3P5DrFhAjJ0yWMbb4bnlViNqbhK-osO0qyq_N8Bk7_bxPFqeecaXTWA.ZqsbNCHzXYmjOkt-ko8QDQ.aJUlhklZl_AfZ09De_rjwVX2GM5zzzlzgYTkk_j1kBRNdsO094KRAHTfbkWj0mi5A7Z-BrfRVcMpuw65estmm8Bz3cJoG_Dz9dmirwScHZyKj2tnxEIPFElwUs3nJu7iu5-cTOR4jcW3a0NoAy-5KYfVXAk7w7_UaJ_r2Ab_agC0kGjKZtL43Y21t3CpCJDUsu9RpY0RxHIjFdpncJtgh5OXPtHJ4sT3k7dUVE_czRP_24vDUHNDh6CSA750yns2c-k1soGp9tPOFS4beK3XrAS7-qvLkHThDdJOxpradfxK7Pr8nRXK88pnd68tRfOOXRFSC1ZGMWsZqGCXfuAThA.FQrCzRQ3foF4MBbHXebsxeRNJHcsCVjdXldJ7twwfD8"
        }
    }
}

function CustomEventsClassRegistry() {
    var n = this;
    n.ltk = _ltk;
    n.ltkUtil = _ltk_util;
    n.httpClient = new CustomEventsHttpClient;
    n.eventsApi = new CustomEventsApi("https://custom-events.listrakbi.com/v1", "False", n)
}

function initializeCustomEventsIntegration() {
    _ltk.CustomEvents = {
        submit: customEventsClassRegistry.eventsApi.submit
    }
}

function CustomEventsApi(n, t, i) {
    function e(n) {
        return JSON.stringify(n)
    }

    function o(n) {
        r.consoleLog(`CustomEvents: Success  ${n}`)
    }

    function s(n) {
        var i = "CustomEvents: Error submitting data to endpoint.";
        r.consoleLog(t === "True" ? `${i} Error: ${n}` : i)
    }
    var u = this,
        f = i.httpClient,
        r = i.ltkUtil;
    u.submit = function(t) {
        var i = n + "/eventsIntegration",
            r = e(t);
        f.executePostRequest(i, r, o, s)
    }
}

function CustomEventsHttpClient() {
    function i(n, i, r) {
        var u = new XMLHttpRequest;
        return u.open("GET", n, !0), u.onreadystatechange = function() {
            t(u, i, r)
        }, u
    }

    function r(n, i, r) {
        var u = new XMLHttpRequest;
        return u.open("POST", n, !0), u.setRequestHeader("Content-Type", "application/json"), u.setRequestHeader("Authorization", "eyJhbGciOiJSU0EtT0FFUCIsImVuYyI6IkEyNTZDQkMtSFM1MTIiLCJraWQiOiJPbmVTY3JpcHRBdXRoIiwidHlwIjoiSldUIn0.BSjoc5e6Z4duF2VMHplv3Ct2rkAq0xqzgE8IBrhQheMdhy3KWjKS34YjgMatUAAK7qZt0oY1bD23zHQ5VAvBQxf3xvFhjbx8HkV4Nw2yvFavGBLR4Pif3ueUWdMP1MAxZ12__CIKb-tZ3cFUYXq39_3JdJgjhwOT_jiK1a8sypgFeKi1RoF8A8g8WQQQdq3AnalxAypHbV565G1s6qdBoBMnS0qsiYEgwUODvo8UU50wjaVdYWx5l_dTu1n0qD9fwCiP180fneIJWxinMeFad0YHBF7un2WC1EKlnubygYEBo20pyY5XbLaPqiy1uOwAVUalTok2UbUlZbkQBM-cZQ.e6dRomrb6dBCeeFaHF34-A.V-12GO_SJBLgx_8ijEmt5Nu5s-6iCwaYhJDO8M-qZBID041iGOCddhqExmZlQTtxmhCRpSqHOCGL7vCmgFMVqMB1b2UXoGDd3nKeK48sg0vwNcOyGcOZTMdmLZWopyag-VW6Cc8VG0zFs1pGvlOZL-s0fCXLyMPdzNZAZ7SeTvYhPas8QffMMns3U6MR06DV4TxUF0xXiwxh2xK8BjjoAOq0QuIfaK93NztwAjiZjDg.PU__vzxrykt_DxqdHb2aemKr4zDhKmwbbqrZXO3z72s"), u.onreadystatechange = function() {
            t(u, i, r)
        }, u
    }

    function t(n, t, i) {
        n.readyState === 4 && u(n, t, i)
    }

    function u(n, t, i) {
        n.status === 200 && typeof t == "function" ? t(n.responseText) : n.status >= 400 && typeof i == "function" && i(n.statusText)
    }
    var n = this;
    n.executeGetRequest = function(n, t, r) {
        var u = i(n, t, r);
        u.send()
    };
    n.executePostRequest = function(n, t, i, u) {
        var f = r(n, i, u);
        f.send(t)
    }
}

function tapToJoinHandler() {
    var n = this,
        t = {
            ios: "IOS",
            android: "ANDROID"
        };
    n.hasShortCode = !1;
    n.hasKeyword = !1;
    n.handleSMSRedirect = function(t) {
        t.preventDefault();
        var i = n.createLink(t.currentTarget);
        n.hasShortCode && n.hasKeyword ? document.location.assign(i) : _ltk_util.consoleLog("No short code and/or keyword found.")
    };
    n.createLink = function(i) {
        var r = n.getShortCodeFromElement(i),
            u = n.createKeywordWithRef(i),
            f = r.length >= 11 ? "+" : "",
            e = n.identifyMobileOS() === t.ios ? "&" : "?";
        return "sms://" + f + r + "/" + e + "body=" + u
    };
    n.getShortCodeFromElement = function(t) {
        var i = "";
        return i = t.href ? t.href.replace(/\D/g, "") : t.dataset.smsShortCode, n.hasShortCode = i.length > 0, i
    };
    n.identifyMobileOS = function() {
        return !navigator.userAgent.toLowerCase().match(/(iphone|ipod|ipad)/) ? t.android : t.ios
    };
    n.createKeywordWithRef = function(t) {
        var i = t.dataset.smsKeyword.trim(),
            r = _ltk.Session.GlobalID !== null ? n.encodeGUID(_ltk.Session.GlobalID) : "";
        return n.hasKeyword = i.length > 0, encodeURIComponent(i + "⁣" + r)
    };
    n.encodeGUID = function(n) {
        var t = "",
            r = ["​", "‌", "‍", "‎", "‪", "‬", "‭", "⁢"],
            u = (n.replace(/-/g, "") + "0").match(/.../g),
            f, i;
        if (u === null || u.length === 0) return t;
        for (f = 0; f < u.length; f++) i = parseInt(u[f], 16), t += r[(i & 7) >> 0], t += r[(i & 56) >> 3], t += r[(i & 448) >> 6], t += r[(i & 3584) >> 9];
        return t
    }
}
var _protocol, _ltk_util, match, _ltkwmt, _ltk, OnescriptAuthClassRegistry, customEventsClassRegistry, customEvent;
typeof _ltk == "object" && typeof _ltk.Client == "object" && typeof _ltk.Client.CTID == "string" && _ltk.Exception.Submit({
    name: "DuplicateScriptWarning",
    message: "_ltk (CTID=" + _ltk.Client.CTID + ") is already defined for this page"
}, "OneScript Start");
_protocol = "https:" == document.location.protocol ? "https://" : "http://",
    function() {
        if (!window.jQuery) {
            var n = document.createElement("script");
            n.src = _protocol + "ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js";
            n.onload = n.onreadystatechange = function() {
                window.jQuery && typeof n != "undefined" && (!n.readyState || /loaded|complete/.test(n.readyState)) && (jQuery.noConflict(), n.onload = n.readystatechange = null, n = undefined)
            };
            document.documentElement.children[0].appendChild(n)
        }
    }();
LTK.prototype.Testing = function() {
    function i(n) {
        n = n.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var i = "[\\?&]" + n + "=([^&#]*)",
            r = new RegExp(i),
            t = r.exec(window.location.href);
        return t == null ? "" : t[1]
    }

    function f(n, t) {
        r[n] = t
    }

    function e(n, t) {
        var i = Number(n);
        return i ? i >= t ? t : i : n == "last" ? t : n == "" || n == "first" ? 1 : !1
    }

    function h() {
        var n, t;
        document.getElementById("ltkJvtBtn") == null && (n = '<div class=ltk-fab id=ltkJvtBtn name=ltk-jvt-toggle><svg style="fill:#fff;opacity:1;transition:opacity 120ms"viewBox="0 0 130.5 128"xmlns=http://www.w3.org/2000/svg><path d="M128.3 47.6c-9.1-6.4-24.9-9.4-39.5-10.7C108.6 23.3 117 25 117 25 107 13 99.3 9.4 99.3 9.4c-11.3.9-26 10.8-37.2 19.9C66.6 5.1 74.5.7 74.5.7c-13-1.9-23.8 1-23.8 1-4.5 4.6-7.6 12.2-9.7 20.6L29.2 10.7c-10.9 6.8-17.9 17.4-17.9 17.4L23.4 40C5.8 44.1 1.7 49.7 1.7 49.7c-3.2 12.7-1 23.4-1 23.4 5-6.6 17.5-10.3 29.3-12.4C9.2 85.6 9.6 97.4 9.6 97.4c7.8 12 15.9 17.4 15.9 17.4-.1-7.9 5.3-18.1 11.9-27.4 2.9 27.7 11.1 38.6 11.1 38.6 12.1 3.3 24 1.7 24 1.7-9.7-10.9-12.5-37.3-13.3-52.6l42.6 41.9c12.5-8.6 17.7-17.6 17.7-17.6L77.4 58c42.3 1.8 52.6 13.1 52.6 13.1 1.7-13.9-1.7-23.5-1.7-23.5z"/><\/svg><\/div>', n += "<style>.ltk-fab{width:52px;height:52px;border-radius:50%;background-color:#7cb342;box-shadow:0 8px 15px 0 rgba(23,25,28,.28),0 4px 20px 0 rgba(23,25,28,.12);transition:all 120ms ease-in-out;font-size:1em;text-align:center;position:fixed;right:50px;bottom:50px;padding:0.5em}.ltk-fab svg{fill:#fff;opacity:1;transition:opacity 120ms}.ltk-fab:hover{box-shadow:0 14px 14px 0 rgba(23,25,28,.28),0 4px 20px 0 rgba(23,25,28,.12)}.ltk-fab:hover svg{opacity:0.7}#ltkJvtBtn{z-index:100010!important;position:fixed;bottom:2vw;left:2vw}#ltkJvtOverlay{z-index:100001!important;background-color:rgba(0,0,0,0.6);position:fixed;width:100%;height:100%;top:0;bottom:0;-webkit-transition:all 50ms ease-in;transition:all 50ms ease-in}#ltkJvtContainer{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen-Sans','Ubuntu','Cantarell','Helvetica Neue',sans-serif;font-size:16px;line-height:1.4;z-index:100010!important;position:fixed;top:50%;left:50%;margin-left:0;-webkit-transform:translate(-50%,-50%);-moz-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);transform:translate(-50%,-50%);width:90vw;max-width:600px;height:560px;overflow:auto;background-color:#eceff2;border-radius:2px}.jvt-display{border:red}#ltkJvtContainer *{box-sizing:border-box;backface-visibility:hidden!important}#ltkJvtContainer .ltk-clearfix::before,#ltkJvtContainer .ltk-clearfix::after{content:\"\";display:table}#ltkJvtContainer .ltk-clearfix::after{clear:both}#ltkJvtContainer .ltk-clearfix{zoom:1}#ltkJvtContainer .jvt-tab-group{display:inline-block;padding:0.5em 1em}.jvt-close{position:absolute;top:0.5em;right:0.5em;z-index:10;display:block;width:1.5em;height:1.5em;padding:0.25em;border-radius:50%;background-color:#c23c3c}.jvt-close:hover{background-color:#952929}.jvt-close svg{fill:#fff;width:100%;height:100%;vertical-align:top;-webkit-transition:all 0.11s linear;transition:all 0.11s linear}.ltk-jvt-main{display:-ms-flexbox;display:flex;flex-direction:column;flex-wrap:nowrap;flex-flow:row nowrap;align-content:flex-start;justify-content:flex-start;align-items:stretch;align-content:stretch}.ltk-jvt-main .jvt-tabs{flex:0 0 25%}.ltk-jvt-main .jvt-info{flex:0 0 75%;padding:2em 3em;background-color:#fff}.ltk-jvt-main .jvt-tabs ul{padding:2em 0 0}.ltk-jvt-main .jvt-tabs li{list-style:none;color:#546e7a;font-size:0.9em;line-height:1.7;display:block;width:100%;padding:0.75em 1em;cursor:pointer;transition:all 120ms ease-in-out}.ltk-jvt-main .jvt-tabs li:hover,.ltk-jvt-main .jvt-tabs li.active{background-color:#fff}.ltk-jvt-main .jvt-tabs li.active{font-weight:700}.ltk-jvt-main .jvt-tabs li:not(:first-of-type){border-top:1px solid #e3e5e6}.jvt-tabs li.exception{background:#c23c3c;color:#fff}.jvt-tabs li.exception:hover,.jvt-tabs li.exception.active{background-color:#952929}.jvt-group{display:none;visibility:hidden}.jvt-group.active{display:block;visibility:visible}.jvt-group{}.jvt-data span{content:\"\";display:table;clear:both;margin:0 0 0.25em 0}#ltkJvtContainer dl{margin:0 0 0.5em}#ltkJvtContainer dl:last-of-type{margin-bottom:2em}#ltkJvtContainer dt,#ltkJvtContainer dd{float:left;text-align:left;font-size:0.8em}#ltkJvtContainer dt{color:#959595}#ltkJvtContainer dd{margin-left:0.5em}#ltkJvtContainer h3,#ltkJvtContainer h4,#ltkJvtContainer h5{margin:0;padding:0;text-align:left;color:#263238;font-weight:400}#ltkJvtContainer h3{font-size:0.8em;font-weight:300;line-height:1.5;letter-spacing:0.1em;color:#fff;display:block;width:100%;background-color:#263238;padding:2em 1.5em;}#ltkJvtContainer h4{font-size:1.5em;padding:0.5em 0 1em}#ltkJvtContainer h5{font-size:0.8em;padding:10px 0 0}#ltkJvtContainer p{margin:15px 0 20px;line-height:1.4}#ltkJvtContainer .ltk-full{width:100%!important;float:none!important}#ltkJvtContainer .buttons{width:100%;position:relative}@media only screen and (max-width:602px){#ltkJvtContainer{width:100%}}<\/style>", t = document.createElement("span"), t.innerHTML = n, document.body.appendChild(t), document.getElementById("ltkJvtBtn").onclick = function() {
            document.getElementById("ltkJvtBtn").style.display = "none";
            c()
        })
    }

    function c() {
        function e() {
            for (var t, r, u, f, i = document.getElementsByClassName("jvt-tab"), n = 0; n < i.length; n++) i[n].classList.remove("active");
            for (t = document.getElementsByClassName("jvt-group"), n = 0; n < t.length; n++) t[n].classList.remove("active");
            r = this.id;
            u = r.substr(7);
            this.classList.add("active");
            f = document.getElementById("jvt-content-" + u);
            f.classList.add("active")
        }
        var i, r, f;
        for (n = '<div id="ltkJvtOverlay" class="ltk-jvt-overlay jvt-display"><\/div>', n += '<div id="ltkJvtContainer" class="ltk-jvt-container" name="v0.5">', n += '<a class=jvt-close id=jvt-close title=Close><svg enable-background="new 0 0 512 512"height=0px version=1.1 viewBox="0 0 512 512"width=0px x=0px xml:space=preserve xmlns=http://www.w3.org/2000/svg xmlns:xlink=http://www.w3.org/1999/xlink y=0px><polygon id=x-mark-icon points="438.393,374.595 319.757,255.977 438.378,137.348 374.595,73.607 255.995,192.225 137.375,73.622 73.607,137.352 192.246,255.983 73.622,374.625 137.352,438.393 256.002,319.734 374.652,438.378 "/><\/svg><\/a>', n += '<main class="ltk-jvt-main">', n += "<aside class=jvt-tabs>", n += '<h3 class="">JavaScript Validation Tool<\/h3>', n += "<ul>", l(t, 0, 0), n += "<\/ul>", n += "<\/aside>", n += '<div class="jvt-info">', u(t, 0, 0), n += "<\/div>", n += "<\/main><\/div>", i = document.createElement("div"), i.className = "popUpWrapper", i.id = "ltkJvtPopupWrapper", i.innerHTML = n, document.body.appendChild(i), r = document.getElementsByClassName("jvt-tab"), r[0].classList.add("active"), document.getElementById("jvt-content-1").classList.add("active"), f = 0; f < r.length; f++) r[f].addEventListener("click", e, !1);
        window.addEventListener("click", function(n) {
            if (document.getElementById("ltkJvtContainer") != null && document.getElementById("ltkJvtBtn") != null && document.getElementById("jvt-close").contains(n.target)) {
                document.getElementById("ltkJvtBtn").style.display = "block";
                var t = document.getElementById("ltkJvtPopupWrapper");
                t.parentNode.removeChild(t)
            }
        });
        window.addEventListener("click", function(n) {
            if (document.getElementById("ltkJvtContainer") != null && document.getElementById("ltkJvtBtn") != null && !document.getElementById("ltkJvtContainer").contains(n.target) && !document.getElementById("ltkJvtBtn").contains(n.target)) {
                document.getElementById("ltkJvtBtn").style.display = "block";
                var t = document.getElementById("ltkJvtPopupWrapper");
                t.parentNode.removeChild(t)
            }
        })
    }

    function l(t, i, r) {
        for (var u in t) t[u] !== null && typeof t[u] == "object" && i == 0 && (r == null ? r = 1 : r++, n += u == "Exception" ? '<li id="jvtTab-' + r + '" class="jvt-tab exception">' + u + "<\/li>" : '<li id="jvtTab-' + r + '" class="jvt-tab">' + u + "<\/li>")
    }

    function u(t, i, r) {
        function e(n, t, i) {
            var r = '<section id="jvt-content-' + n + '" class="jvt-group">';
            return r += '<article class="">', r += "<h4 class=jvt-header>" + i + "<\/h4>", r + "<dl class=jvt-data>"
        }

        function o() {
            return "<\/dl><\/article><\/section>"
        }

        function s(n) {
            return !isNaN(parseFloat(n)) && isFinite(n)
        }
        for (var f in t) t[f] !== null && typeof t[f] == "object" ? (i == 0 && (r == null ? r = 1 : r++, r > 1 && (n += o()), n += e(r, f, f + " Details")), i == 1 && s(f) && (n += '<h5 class="jvt-header">Item ' + (parseInt(f) + 1) + "<\/h5>"), u(t[f], i + 1, r)) : t.hasOwnProperty(f) && (n += "<span><dt>" + f + ": <\/dt><dd>" + t[f] + "<\/dd><\/span>")
    }

    function a(n) {
        t = _ltk_util.extend(t, n);
        console.log("---- Queue ----");
        console.log(t)
    }
    var r = {},
        o = function(n, t) {
            var o = n ? n : decodeURI(i("ltkpopupshow"));
            if (o) {
                var h = t ? t : i("ltkpage") ? i("ltkpage") : 1,
                    r = _ltk.Modal.modals.filter(function(n) {
                        return n.ModalName == o
                    })[0],
                    s = 2,
                    u = e(h, s);
                if (console.log(r), console.log(u), !r || !u) {
                    console.log("Please check your parameters:");
                    r || console.log("The Pop-up name is not valid.");
                    u || console.log("The page requested is not valid.");
                    return
                }
                f("Popup", !0);
                r.FollowUpDelay = -1;
                u == 1 ? r.show() : u == s && (r.updateDisplayFormCss(), r.Confirmation.open())
            }
        },
        t = {},
        n, s = function(n, t) {
            _ltk_util.isTestMode("ltkvalidation") && (console.log("Validating: " + n), a(t), h())
        };
    return {
        Flag: r,
        Popup: o,
        Validate: s
    }
}();
_ltk_util = new _Utilities,
    function() {
        _ltk_util.CustomEvent = function(n, t) {
            t = t || {
                bubbles: !1,
                cancelable: !1,
                detail: undefined
            };
            var i = document.createEvent("CustomEvent");
            return i.initCustomEvent(n, t.bubbles, t.cancelable, t.detail), i
        };
        _ltk_util.CustomEvent.prototype = window.Event.prototype
    }(),
    function() {
        var u = _ltk_util.testmodes,
            n = _ltk_util.getCookie("ltkTestMode"),
            t, i;
        for (n && (n = n.split(",")), t = [], i = 0; i < u.length; i++) {
            var r = u[i],
                f = _ltk_util.getQuerystringValue(r),
                e = n.indexOf(r);
            f !== "0" && (f || e > -1) && t.push(r)
        }
        t.length > 0 ? _ltk_util.setCookie("ltkTestMode", t, null, _ltk_util.getCookieDomain(), "/") : _ltk_util.deleteCookie("ltkTestMode", _ltk_util.getCookieDomain(), "/")
    }();
var jQueryLoadCall = _ltk_util.AsyncManager.StartAsyncCall("jQuery"),
    _jQueryLoadInterval = setInterval(function() {
        window.jQuery && (clearInterval(_jQueryLoadInterval), _ltk_util.AsyncManager.CallComplete("jQuery"))
    }, 100),
    ltkLoadCall = _ltk_util.AsyncManager.StartAsyncCall("_ltk"),
    _ltkLoadInterval = setInterval(function() {
        window._ltk && (clearInterval(_ltkLoadInterval), _ltk_util.AsyncManager.CallComplete("_ltk"))
    }, 100);
typeof LTK != "undefined" && (LTK.prototype.cookie = function(n, t, i) {
    var u, r, f, e;
    return arguments.length > 1 && String(t) !== "[object Object]" ? (i = _ltk_util.extend({}, i), (t === null || t === undefined) && (i.expires = -1), typeof i.expires == "number" && (u = i.expires, r = i.expires = new Date, r.setDate(r.getDate() + u)), t = String(t), document.cookie = [encodeURIComponent(n), "=", i.raw ? t : encodeURIComponent(t), i.expires ? "; expires=" + i.expires.toUTCString() : "", i.path ? "; path=" + i.path : "", i.domain ? "; domain=" + i.domain : "", i.secure ? "; secure" : ""].join("")) : (i = t || {}, e = i.raw ? function(n) {
        return n
    } : decodeURIComponent, (f = new RegExp("(?:^|; )" + encodeURIComponent(n) + "=([^;]*)").exec(document.cookie)) ? e(f[1]) : null)
}, LTK.prototype.isValidEmail = function(n) {
    for (var i = [], r = !1, i = ["user@example.com", "email@example.com", "customer@example.com", "user@domain.com", "email@domain.com", "customer@domain.com"], t = 0; t < i.length; t++) i[t] === n && (r = !0);
    return !/^[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test(n) || r ? !1 : !0
}, LTK.prototype.isValidSMSNumber = function(n) {
    return n !== null ? /^1?[0-9]{10}$/.test(n.replace(/\D/g, "")) : !1
}, LTK.prototype.browser || (ua = navigator.userAgent.toLowerCase(), match = /(chrome)[ \/]([\w.]+)/.exec(ua) || /(webkit)[ \/]([\w.]+)/.exec(ua) || /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(ua) || /(msie) ([\w.]+)/.exec(ua) || ua.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(ua) || [], matched = {
    browser: match[1] || "",
    version: match[2] || "0"
}, browser = {}, matched.browser && (browser[matched.browser] = !0, browser.version = matched.version), browser.chrome ? browser.webkit = !0 : browser.webkit && (browser.safari = !0), LTK.prototype.browser = browser, typeof _ltk != "undefined" && (_ltk.browser = browser)));
Array.prototype.indexOf || (Array.prototype.indexOf = function(n, t) {
    var i, r = t ? t : 0,
        u;
    if (!this) throw new TypeError;
    if (u = this.length, u === 0 || r >= u) return -1;
    for (r < 0 && (r = u - Math.abs(r)), i = r; i < u; i++)
        if (this[i] === n) return i;
    return -1
});
Array.prototype.filter || (Array.prototype.filter = function(n, t) {
    for (var r = [], u, i = 0, f = this.length; i < f; i++) i in this && n.call(t, u = this[i], i, this) && r.push(u);
    return r
});
typeof JSON != "object" && (JSON = {}),
    function() {
        "use strict";

        function i(n) {
            return n < 10 ? "0" + n : n
        }

        function o(n) {
            return u.lastIndex = 0, u.test(n) ? '"' + n.replace(u, function(n) {
                var t = s[n];
                return typeof t == "string" ? t : "\\u" + ("0000" + n.charCodeAt(0).toString(16)).slice(-4)
            }) + '"' : '"' + n + '"'
        }

        function e(i, r) {
            var s, l, h, a, v = n,
                c, u = r[i];
            u && typeof u == "object" && typeof u.toJSON == "function" && (u = u.toJSON(i));
            typeof t == "function" && (u = t.call(r, i, u));
            switch (typeof u) {
                case "string":
                    return o(u);
                case "number":
                    return isFinite(u) ? String(u) : "null";
                case "boolean":
                case "null":
                    return String(u);
                case "object":
                    if (!u) return "null";
                    if (n += f, c = [], Object.prototype.toString.apply(u) === "[object Array]") {
                        for (a = u.length, s = 0; s < a; s += 1) c[s] = e(s, u) || "null";
                        return h = c.length === 0 ? "[]" : n ? "[\n" + n + c.join(",\n" + n) + "\n" + v + "]" : "[" + c.join(",") + "]", n = v, h
                    }
                    if (t && typeof t == "object")
                        for (a = t.length, s = 0; s < a; s += 1) typeof t[s] == "string" && (l = t[s], h = e(l, u), h && c.push(o(l) + (n ? ": " : ":") + h));
                    else
                        for (l in u) Object.prototype.hasOwnProperty.call(u, l) && (h = e(l, u), h && c.push(o(l) + (n ? ": " : ":") + h));
                    return h = c.length === 0 ? "{}" : n ? "{\n" + n + c.join(",\n" + n) + "\n" + v + "}" : "{" + c.join(",") + "}", n = v, h
            }
        }
        typeof Date.prototype.toJSON != "function" && (Date.prototype.toJSON = function() {
            return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + i(this.getUTCMonth() + 1) + "-" + i(this.getUTCDate()) + "T" + i(this.getUTCHours()) + ":" + i(this.getUTCMinutes()) + ":" + i(this.getUTCSeconds()) + "Z" : null
        }, String.prototype.toJSON = Number.prototype.toJSON = Boolean.prototype.toJSON = function() {
            return this.valueOf()
        });
        var r, u, n, f, s, t;
        typeof JSON.stringify != "function" && (u = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, s = {
            "\b": "\\b",
            "\t": "\\t",
            "\n": "\\n",
            "\f": "\\f",
            "\r": "\\r",
            '"': '\\"',
            "\\": "\\\\"
        }, JSON.stringify = function(i, r, u) {
            var o;
            if (n = "", f = "", typeof u == "number")
                for (o = 0; o < u; o += 1) f += " ";
            else typeof u == "string" && (f = u);
            if (t = r, r && typeof r != "function" && (typeof r != "object" || typeof r.length != "number")) throw new Error("JSON.stringify");
            return e("", {
                "": i
            })
        });
        typeof JSON.parse != "function" && (r = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, JSON.parse = function(n, t) {
            function u(n, i) {
                var f, e, r = n[i];
                if (r && typeof r == "object")
                    for (f in r) Object.prototype.hasOwnProperty.call(r, f) && (e = u(r, f), e !== undefined ? r[f] = e : delete r[f]);
                return t.call(n, i, r)
            }
            var i;
            if (n = String(n), r.lastIndex = 0, r.test(n) && (n = n.replace(r, function(n) {
                    return "\\u" + ("0000" + n.charCodeAt(0).toString(16)).slice(-4)
                })), /^[\],:{}\s]*$/.test(n.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]").replace(/(?:^|:|,)(?:\s*\[)+/g, ""))) return i = eval("(" + n + ")"), typeof t == "function" ? u({
                "": i
            }, "") : i;
            throw new SyntaxError("JSON.parse");
        })
    }();
_Utilities.prototype.domready = function(n) {
    "use strict";
    var r = function(n) {
            o(n);
            c()
        },
        t = n.document,
        e = !1,
        f = [],
        o = function(n) {
            typeof n == "function" && f.push(n)
        },
        h = function() {
            while (f.length) f.shift()();
            o = function(n) {
                n()
            }
        },
        i = function() {
            t.addEventListener ? t.removeEventListener("DOMContentLoaded", i, !1) : t.detachEvent("onreadystatechange", i);
            u()
        },
        u = function() {
            if (!r.isReady) {
                if (!t.body) return setTimeout(u, 1);
                r.isReady = !0;
                h()
            }
        },
        c = function() {
            var r = !1;
            if (!e)
                if (e = !0, (t.attachEvent ? t.readyState === "complete" : t.readyState !== "loading") && u(), t.addEventListener) t.addEventListener("DOMContentLoaded", i, !1), n.addEventListener("load", i, !1);
                else if (t.attachEvent) {
                t.attachEvent("onreadystatechange", i);
                n.attachEvent("onload", i);
                try {
                    r = n.frameElement == null
                } catch (f) {}
                t.documentElement.doScroll && r && s()
            }
        },
        s = function() {
            if (!r.isReady) {
                try {
                    t.documentElement.doScroll("left")
                } catch (n) {
                    setTimeout(s, 1);
                    return
                }
                u()
            }
        };
    return r.isReady = !1, r
}(window);
_Utilities.prototype.getScript = function(n, t) {
    var i = document.createElement("script"),
        r, u;
    i.async = !1;
    r = document.getElementsByTagName("head")[0];
    u = !1;
    i.onload = i.onerror = i.onreadystatechange = function(n) {
        u || this.readyState && this.readyState != "loaded" && this.readyState != "complete" || (u = !0, t(n), i.onload = i.onerror = i.onreadystatechange = null, r.removeChild(i))
    };
    i.src = n;
    r.appendChild(i)
};
_Utilities.prototype.storageAvailable = function(n) {
    try {
        var i = window[n],
            t = "__storage_test__";
        return i.setItem(t, t), i.removeItem(t), !0
    } catch (r) {
        return !1
    }
};
typeof exports != "undefined" && (exports._ltk_util = _ltk_util);
LTK.prototype.moduleList = ["SCA", "PCO", "CUSTOMERMETRICS", "PPE", "MODALPOPUP", "LCG", "BIS", "REV", "REC", "BNA", "TRA", "PDA", "RAF", "BKA", "PSP", "LIA", "RACT", "LTY", "INF"];
typeof exports != "undefined" && (exports._LTKClick = _LTKClick);
_ltkwmt = "",
    function() {
        function c() {
            this.SessionID = null;
            this.TrackingToken = null;
            this.ContactPID = null;
            this._varmap = {
                SessionID: "sid",
                TrackingToken: "trkt",
                ContactPID: "cpid"
            }
        }

        function l() {
            this._type = "at";
            this._isIndexable = !0;
            this.Type = null;
            this.Key = null;
            this.Data = null;
            this._varmap = {
                _type: "_t",
                Type: "t",
                Key: "k",
                Data: "d"
            }
        }

        function n(n, t, i) {
            var r = new l;
            r.Type = n;
            r.Key = t;
            typeof i == "object" && i != null && (r.Data = JSON.stringify(i));
            this.push(r)
        }

        function e() {
            _ltk_util.deleteCookie(i, _ltk_util.getCookieDomain(), "/", null);
            _ltk_util.deleteCookie(r, _ltk_util.getCookieDomain(), "/", null)
        }

        function o(n, t, i) {
            if (e(), _ltk_util.storageAvailable(i)) {
                var r = u(n),
                    f = -1;
                r || (r = []);
                f = r.indexOf(t.toString());
                f >= 0 && r.splice(f, 1);
                r.length == 25 && r.shift();
                r.push(t);
                window[i].setItem(n, r.join(","))
            }
        }

        function u(n) {
            var t, r, i;
            if (e(), t = (_ltk_util.storageAvailable("sessionStorage") ? sessionStorage.getItem(n) || "" : "") || (_ltk_util.storageAvailable("localStorage") ? localStorage.getItem(n) || "" : ""), t) {
                for (t = t.split(","), r = [], i = 0; i < t.length; ++i) t[i].length <= 100 && r.push(t[i]);
                t = r
            }
            return t
        }

        function t(n, t) {
            if ("True".toLowerCase() != "true" || n.length < 1) {
                setTimeout(t || function() {}, 0);
                return
            }
            _ltk_util.ready(function() {
                _ltk.Session.getPersonalizedStatus() && (f.add(n), h(function(i) {
                    _ltk_util.AsyncManager.StartAsyncCall("submitActivity", function() {
                        var r = null,
                            u = null;
                        try {
                            u = new c;
                            u.TrackingToken = _ltk.GetCookie("_trkt");
                            u.ContactPID = _ltk.Session.ContactPID;
                            u.SessionID = _ltk.SCA.SessionID;
                            u.SessionID == null && (u.SessionID = _ltk.GetCookie("STSIDsOwGMAximH7A"));
                            r = new _Assembler;
                            r.Name = "Activity";
                            r.RequestMode = "script";
                            r.ContainsPII = !0;
                            r.QueryMode = 1;
                            r.EndPointArray = [];
                            r.EndPointArray.push("at1.listrakbi.com");
                            r.EndPointPath = "/activity/sOwGMAximH7A";
                            r.QueryHeader = "vuid=" + i + "&uid=" + _ltk.uuidCompact() + "&gsid=" + _ltk.Session.GlobalID;
                            r.AddObject(u, "Identity");
                            r.AddArrayObject(n, "Activity");
                            r.Flush(t)
                        } catch (f) {
                            _ltk.Exception.Submit(f, "Submit")
                        }
                    }, this, ["clickSubmit"])
                }))
            }, this)
        }

        function s() {
            this.AddContentBrowse = function(i, r) {
                var u, f;
                typeof i == "string" && (i = _ltk_util.trim(i), i.length > 0 && (u = [], n.call(u, "ContentBrowse", i, r), document.dispatchEvent && (f = new _ltk_util.CustomEvent("ltkContentBrowse", {
                    detail: {
                        data: r,
                        url: i
                    }
                }), document.dispatchEvent(f)), t(u)))
            };
            this.AddProductBrowse = function(u, f) {
                var e, s;
                typeof u == "string" && (u = _ltk_util.trim(u), u.length > 0 && (e = [], n.call(e, "ProductBrowse", u, f), document.dispatchEvent && (s = new _ltk_util.CustomEvent("ltkProductBrowse", {
                    detail: {
                        data: f,
                        sku: u
                    }
                }), document.dispatchEvent(s)), _ltk_util.ready(function() {
                    _ltk.Session.getPersonalizedStatus() && (o(i, u, "localStorage"), o(r, u, "sessionStorage"))
                }), t(e)))
            };
            this.AddProductAddedToCart = function(i, r) {
                var u, f;
                typeof i == "string" && (i = _ltk_util.trim(i), i.length > 0 && (u = [], n.call(u, "ProductAddedToCart", i, r), document.dispatchEvent && (f = new _ltk_util.CustomEvent("ltkProductAddedToCart", {
                    detail: {
                        data: r,
                        sku: i
                    }
                }), document.dispatchEvent(f)), t(u)))
            };
            this.AddPageBrowse = function(i, r) {
                var u, f;
                typeof i == "object" && typeof r == "undefined" && (r = i, i = null);
                (typeof i == "undefined" || i == null) && (i = window.location.href);
                typeof i == "string" && (i = _ltk_util.trim(i), i.length > 0 && (u = [], n.call(u, "PageBrowse", i, r), document.dispatchEvent && (f = new _ltk_util.CustomEvent("ltkPageBrowse", {
                    detail: {
                        data: r,
                        page: i
                    }
                }), document.dispatchEvent(f)), t(u)))
            };
            this.Batch = function() {
                return new s
            };
            this.Submit = function(n) {
                (n || function() {})()
            };
            this.GetRecentlyViewedSkus = function() {
                return u(i)
            };
            this.GetSessionViewedSkus = function() {
                return u(r)
            };
            this.Session = f.get
        }
        var i = "ltk-recentlyViewed",
            r = "ltk-sessionViewed",
            h = new function() {
                function u() {
                    for (r = r || _ltk_util.getCookie("_vuid"); r && i.length;)(function(n) {
                        setTimeout(function() {
                            n(r)
                        }, 0)
                    })(i.shift());
                    return i.length == 0
                }
                var i = [],
                    r;
                return function(r) {
                    if (i.push(r), !u() && i.length == 1) {
                        _ltk_util.getScript(_ltk_util.Protocol + "at1.listrakbi.com/activity/sOwGMAximH7A", u);
                        var f = [];
                        n.call(f, "Identification", 3);
                        n.call(f, "Identification", 4);
                        n.call(f, "Identification", 5);
                        t(f)
                    }
                }
            },
            f = new function() {
                var n = this,
                    t = "_ltk.Activity.session",
                    i = 25;
                return n.add = function(r) {
                    var e, u, f;
                    if (_ltk_util.storageAvailable("sessionStorage")) {
                        for (r instanceof Array || (r = arguments), e = n.get({
                                last: i - r.length
                            }), u = 0; u < r.length; u++) f = r[u], e.push({
                            Type: f.Type,
                            Key: f.Key,
                            Data: f.Data,
                            Date: new Date
                        });
                        sessionStorage.setItem(t, JSON.stringify(e))
                    }
                }, n.get = function(n) {
                    var r, f, i, u;
                    if (!_ltk_util.storageAvailable("sessionStorage")) return [];
                    r = [];
                    try {
                        r = JSON.parse(sessionStorage.getItem(t)) || []
                    } catch (e) {}
                    for (i = 0; i < r.length; i++) u = r[i], r[i] = {
                        Type: u.Type,
                        Key: u.Key,
                        Data: u.Data,
                        Date: new Date(u.Date)
                    };
                    for (f = [], i = 0; i < r.length; i++) u = r[i], (n === undefined || n.last && i >= r.length - n.last || n.since && u.Date > new Date(n.since)) && f.push(u);
                    return f
                }, n
            };
        LTK.prototype.Activity = new s;
        _ltk_util.Identity.Email(function(i) {
            var r = [],
                u;
            n.call(r, "Identification", "1:" + i);
            u = _ltk_util.CustomEvent("ltkEmailIdentityEvent", {
                detail: {
                    email: i
                }
            });
            document.dispatchEvent(u);
            t(r)
        });
        _ltk_util.Identity.MobilePhone(function(n) {
            var t = _ltk_util.CustomEvent("ltkPhoneIdentityEvent", {
                detail: {
                    phone: n
                }
            });
            document.dispatchEvent(t)
        });
        _ltk_util.Identity.ContactPID(function(i) {
            var r = [],
                u;
            n.call(r, "Identification", "2:" + i);
            u = _ltk_util.CustomEvent("ltkContactPidIdentityEvent", {
                detail: {
                    contactPid: i
                }
            });
            document.dispatchEvent(u);
            t(r)
        });
        _ltk_util.Identity.WebPushSubscriptionHash(function(n) {
            var t = _ltk_util.CustomEvent("ltkWebPushIdentityEvent", {
                detail: {
                    webPushSubscriptionHash: n
                }
            });
            document.dispatchEvent(t)
        })
    }(),
    function() {
        function n() {
            this.Alert = []
        }

        function t() {
            this._type = "al";
            this._isIndexable = !0;
            this.Email = "";
            this.Sku = "";
            this.PhoneNumber = "";
            this.AlertCode = "";
            this._varmap = {
                _type: "_t",
                Email: "e",
                Sku: "s",
                PhoneNumber: "pn",
                AlertCode: "ac"
            }
        }
        n.prototype.AddAlert = function(n, t, i) {
            this.AddAlertWithIdentifiers({
                Identifiers: {
                    Email: n
                },
                Sku: t,
                AlertCode: i
            })
        };
        n.prototype.AddAlertWithIdentifiers = function(n) {
            const i = new t;
            let r = !1;
            n.Sku !== undefined && n.Sku !== null && n.AlertCode !== undefined && n.AlertCode !== null && n.Identifiers !== undefined && n.Identifiers !== null && (n.Identifiers.Email !== undefined && n.Identifiers.Email !== null && _ltk.isValidEmail(n.Identifiers.Email) && (i.Email = _ltk_util.Identity.Email(n.Identifiers.Email), r = !0), n.Identifiers.PhoneNumber !== undefined && n.Identifiers.PhoneNumber !== null && _ltk.isValidSMSNumber(n.Identifiers.PhoneNumber) && (i.PhoneNumber = _ltk_util.Identity.MobilePhone(n.Identifiers.PhoneNumber), r = !0), r) && (i.Sku = n.Sku, i.AlertCode = n.AlertCode, this.Alert.push(i))
        };
        n.prototype.AddAlertEmail = function(n) {
            const t = {
                AlertCode: n.AlertCode,
                Sku: n.Sku,
                Identifiers: {
                    Email: n.Email
                }
            };
            this.AddAlertWithIdentifiers(t)
        };
        n.prototype.AddAlertPhoneNumber = function(n) {
            const t = {
                AlertCode: n.AlertCode,
                Sku: n.Sku,
                Identifiers: {
                    PhoneNumber: n.PhoneNumber
                }
            };
            this.AddAlertWithIdentifiers(t)
        };
        n.prototype.Submit = function() {
            try {
                _ltk_util.ready(function() {
                    try {
                        this.Assembler = new _Assembler;
                        this.Assembler.Name = "Alert data";
                        this.Assembler.QueryMode = 1;
                        this.Assembler.EndPointArray = [];
                        this.Assembler.EndPointArray.push("al1.listrakbi.com");
                        this.Assembler.EndPointPath = "/Handlers/Set.ashx";
                        this.Assembler.QueryHeader = "ctid=sOwGMAximH7A&uid=" + _ltk.uuidCompact() + "&gsid=" + _ltk.Session.GlobalID;
                        this.Assembler.AddArrayObject(this.Alert, "Alert");
                        this.Assembler.Flush();
                        this.Alert.length = 0
                    } catch (n) {
                        _ltk.Exception.Submit(n, "Alert Submit")
                    }
                }, this)
            } catch (n) {
                _ltk.Exception.Submit(n, "Init Alert Submit")
            }
        };
        LTK.prototype.Alerts = new n
    }();
MerchandiseBlock.prototype.RecInit = function(n) {
    _ltk_util.ready(function() {
        var i = _ltk_util.getCookie("_ltk_recs_trk"),
            r = _ltk_util.getCookie("ltk_recs_trk"),
            t;
        _ltk.Session.getPersonalizedStatus() || (i = _ltk_util.clearParameterValues(i, ["globalSessionUID", "sessionUID", "trackingUID", "email"]), r = _ltk_util.clearParameterValues(r, ["globalSessionUID", "sessionUID", "trackingUID", "email"]));
        t = null;
        i ? (t = new Image, t.src = _protocol + "recs.listrakbi.com/ltk.gif" + i + "&rnd=" + Math.random()) : r && (t = new Image, t.src = _protocol + "recs.listrakbi.com/ltk.gif" + r + "&rnd=" + Math.random());
        this.SetCookie(null, -1);
        typeof n == "function" && n(t)
    }, this)
};
MerchandiseBlock.prototype.SetCookie = function(n, t) {
    _ltk_util.setCookie("_ltk_recs_trk", n, t, _ltk_util.getCookieDomain(), "/", !1);
    _ltk_util.setCookie("ltk_recs_trk", n, t, "listrakbi.com", "/", !1)
};
MerchandiseBlock.prototype.GetRecommendations = function(n, t, i) {
    function f(n, t) {
        e += e.length == 0 ? "?" : "&";
        e += n + "=" + t
    }
    var e, u, r, o;
    if (this.MerchandiseBlockUID = n, e = "", arguments.length == 2 && (i = arguments[1]), this.isValid(n)) {
        for (r in t)
            if (t.hasOwnProperty(r)) switch (r) {
                case "activities":
                    if (typeof t[r] == "string" && this.isValid(t[r])) f("sku", t[r]);
                    else if (t[r] instanceof Array && typeof t[r][0] == "string")
                        for (u = 0; u < t[r].length; u++) this.isValid(t[r][u]) && f("sku", t[r][u]);
                    else if (typeof t[r] == "object" && this.isValid(t[r].Sku) && this.isValid(t[r].Type) && this.isValid(t[r].Date)) f("activity.sku", t[r].Sku), f("activity.type", t[r].Type), f("activity.date", t[r].Date);
                    else if (t[r] instanceof Array && typeof t[r][0] == "object")
                        for (u = 0; u < t[r].length; u++) this.isValid(t[r][u].Sku) && this.isValid(t[r][u].Type) && this.isValid(t[r][u].Date) && (f("activity.sku", t[r][u].Sku), f("activity.type", t[r][u].Type), f("activity.date", t[r][u].Date));
                    break;
                case "additionalFields":
                    if (typeof t[r] == "string" && this.isValid(t[r])) f("field", t[r]);
                    else if (t[r] instanceof Array && typeof t[r][0] == "string")
                        for (u = 0; u < t[r].length; u++) this.isValid(t[r][u]) && f("field", t[r][u]);
                    break;
                case "optionalConditions":
                    if (typeof t[r] == "object")
                        for (u in t[r]) f(u, t[r][u])
            }
        for (r = 0; r < this.DefaultFields.length; r++) this.isValid(this.DefaultFields[r]) && f("field", this.DefaultFields[r]);
        o = _protocol + "recs.listrakbi.com/json/" + n + e;
        _ltk_util.AsyncManager.StartAsyncCall("getRecommendations", function() {
            this.GetRecommendationsFromEndpoint(o, function(t) {
                for (var r = 0; r < t.length; r++) t[r].MerchandiseBlockUID = n;
                _ltk.MerchandiseBlock.SetTracking(t, i)
            })
        }, this, [_ltk.Session.GlobalIDAsyncCallName])
    }
};
MerchandiseBlock.prototype.GetRecommendationsFromEndpoint = function(n, t) {
    n += this.CreateImpressionQueryString();
    this.LastAPIUrl = n;
    _ltk_util.getJSONWithCallback(n, t)
};
MerchandiseBlock.prototype.isValid = function(n) {
    return n && n.length > 0
};
MerchandiseBlock.prototype.SetTracking = function(n, t) {
    var i = {},
        e = function(n) {
            for (var t, u = function(n) {
                    var t = n.currentTarget || n.srcElement,
                        r = null,
                        f = t.getAttribute("data-ltk-tag"),
                        e = t.parentNode.getAttribute("data-ltk-sku"),
                        o = t.getAttribute("data-ltk-sku"),
                        u;
                    _ltk.MerchandiseBlock.isValid(e) ? r = _ltk_util.trim(e) : _ltk.MerchandiseBlock.isValid(o) && (r = _ltk_util.trim(o));
                    _ltk.MerchandiseBlock.isValid(r) && i[r] && (u = i[r], _ltk.MerchandiseBlock.isValid(f) && (u.LinkTag = f), _ltk.MerchandiseBlock.isValid(t.href) && i[r].LinkUrl != t.href && (u.LinkUrl = t.href), _ltk.MerchandiseBlock.CreateQueryString(u, i))
                }, r = 0; r < n.length; r++) t = n[r], t.addEventListener ? t.addEventListener("click", u, !1) : t.attachEvent && t.attachEvent("onclick", u)
        },
        u, r, f;
    if (t(n), u = _ltk_util.querySelectorAll(document, "[data-ltk-sku]"), _ltk.MerchandiseBlock.isValid(u)) {
        for (r = 0; r < n.length; r++) f = n[r], i[_ltk_util.trim(f.Sku)] = f;
        e(u)
    }
};
MerchandiseBlock.prototype.CreateQueryString = function(n, t) {
    var i = "?linkUrl=" + n.LinkUrl,
        r, u;
    i = i.trim();
    for (r in t) u = t[r], i += "&recommended=" + u.ProductUID;
    i += "&merchandiseBlockUID=" + n.MerchandiseBlockUID;
    i += "&productUID=" + n.ProductUID;
    i += "&recipeUID=" + n.RecipeUID;
    this.isValid(n.LinkTag) && (i += "&linkTag=" + n.LinkTag);
    i += this.CreateImpressionQueryString();
    _ltk.MerchandiseBlock.SetCookie(i, 365)
};
MerchandiseBlock.prototype.CreateImpressionQueryString = function() {
    var n = "";
    return this.isValid(_ltk.Session.GlobalID) && (n += "&globalSessionUID=" + _ltk.Session.GlobalID), this.isValid(_ltk.SCA.sessionID) && (n += "&sessionUID=" + _ltk.SCA.sessionID), this.isValid(_ltk_util.getCookie("_trkt")) && (n += "&trackingUID=" + _ltk_util.getCookie("_trkt")), this.isValid(this.Email) && (n += "&email=" + this.Email), n
};
LTK.prototype.MerchandiseBlock = new MerchandiseBlock;
(typeof _ltk == "undefined" || window._ltk instanceof Array) && (_ltk = function() {
    var n = new LTK;
    return n.push = window._ltk, n
}(), _ltk.Client.CTID = "sOwGMAximH7A", _ltk.MerchandiseBlock && _ltk.MerchandiseBlock.RecInit());
OnescriptAuthClassRegistry = new OnescriptAuthClassRegistry;
_ltk_util.AsyncManager.StartAsyncCall("", initializeOnescriptAuthIntegration, this, ["jQuery"]);
customEventsClassRegistry = new CustomEventsClassRegistry;
_ltk_util.AsyncManager.StartAsyncCall("", initializeCustomEventsIntegration, this, ["jQuery"]);
typeof exports != "undefined" && (exports.EventsApi = CustomEventsApi),
    function() {
        function i(n) {
            function h(n, t) {
                var i = t.match(e),
                    f, s, h, c;
                if (i === null) return !1;
                var o = i[1],
                    l = i[2],
                    u = i[3];
                if (!n.hasAttribute(o)) return !1;
                f = n.getAttribute(o);
                switch (l) {
                    case r.contains:
                        return s = new RegExp(u), s.test(f);
                    case r.prefixed:
                        return h = new RegExp(r.prefixed + u), h.test(f);
                    case r.suffixed:
                        return c = new RegExp(u + r.suffixed), c.test(f);
                    default:
                        return n.getAttribute(o) === u
                }
            }

            function c(n) {
                return u.exec(n) ? t.id : f.exec(n) ? t.class : e.exec(n) ? t.attr : t.all
            }

            function l(n, t) {
                var i = n.id === t,
                    r = n.classList.contains(t),
                    u = n.name === t,
                    f = n.dataset.ltkField === t,
                    e = n.type === t;
                return i || r || u || f || e
            }

            function a(n) {
                var t = [];
                return u.exec(n) && t.push(p(n)), t
            }

            function v(n) {
                var t = [],
                    i;
                return f.exec(n) && (i = n.substring(1), t = document.getElementsByClassName(i)), t
            }

            function y(n) {
                var t = [];
                return s.exec(n) && (t = document.querySelectorAll(n)), t
            }

            function p(n) {
                var t = n.substring(1);
                return document.getElementById(t)
            }

            function w(n) {
                var t = [],
                    f = document.getElementById(n),
                    r, i, u;
                if (f && t.push(f), !Array.isArray(t) || !t.length)
                    for (r = document.querySelectorAll("[name='" + n + "']"), i = 0; i < r.length; i++) u = r[i], u instanceof HTMLElement && t.push(u);
                return t
            }
            var i = this,
                o = n.ltkUtil,
                u = /^#/,
                f = /^\.[^.\s]*$/,
                s = /\s|(\[)(.*)(\])/,
                e = /^[[]([\w-]*)([*$~^])?=['"](.*)['"][\]]$/,
                t = {
                    id: "id",
                    "class": "class",
                    attr: "attr",
                    all: "all"
                },
                r = {
                    exact: "=",
                    contains: "*",
                    prefixed: "^",
                    suffixed: "$"
                };
            Object.freeze(t);
            Object.freeze(r);
            i.getElementFromSelectorString = function(n) {
                var r;
                try {
                    var u = a(n),
                        f = [].slice.call(v(n)),
                        e = [].slice.call(y(n)),
                        t = [].concat(u, f, e);
                    return Array.isArray(t) && t.length || (r = [].slice.call(w(n)), t = r), i.filterToInputElements(t)
                } catch (s) {
                    return o.consoleLog(s), []
                }
            };
            i.filterToInputElements = function(n) {
                for (var i, r = [], t = 0; t < n.length; t++) i = n[t], i.tagName === "INPUT" && r.push(i);
                return r
            };
            i.waitForFieldToExist = function(n, t) {
                var u = c(n),
                    r = new MutationObserver(function(f) {
                        f.forEach(function(f) {
                            var e, o;
                            if (f.addedNodes)
                                for (e = 0; e < f.addedNodes.length; e++) o = f.addedNodes[e], i.elementMatchesOnCorrectSelector(o, n, u) && (r.disconnect(), t(o))
                        })
                    });
                r.observe(document.body, {
                    childList: !0,
                    subtree: !0,
                    attributes: !1,
                    characterData: !1
                })
            };
            i.elementMatchesOnCorrectSelector = function(n, i, r) {
                if (n.tagName === null || n.tagName !== "INPUT") return !1;
                switch (r) {
                    case t.id:
                        return n.id === i.replace("#", "");
                    case t.class:
                        return n.classList.contains(i.replace(".", ""));
                    case t.attr:
                        return h(n, i);
                    default:
                        return l(n, i)
                }
            }
        }

        function s() {
            function i(n, i, r) {
                var u = new XMLHttpRequest;
                return u.open("GET", n, !0), u.onreadystatechange = function() {
                    t(u, i, r)
                }, u
            }

            function r(n, i, r) {
                var u = new XMLHttpRequest;
                return u.open("POST", n, !0), u.setRequestHeader("Content-Type", "application/json"), u.withCredentials = !0, u.onreadystatechange = function() {
                    t(u, i, r)
                }, u
            }

            function t(n, t, i) {
                n.readyState === 4 && u(n, t, i)
            }

            function u(n, t, i) {
                n.status === 200 && typeof t == "function" ? t(n.responseText) : n.status >= 400 && typeof i == "function" && i(n.responseText)
            }
            var n = this;
            n.executeGetRequest = function(n, t, r) {
                var u = i(n, t, r);
                u.send()
            };
            n.executePostRequest = function(n, t, i, u) {
                var f = r(n, i, u);
                f.send(t)
            }
        }

        function h(n, t) {
            function r(n) {
                n.globalSessionUid = f.Session.GlobalID;
                n.sessionUid = f.SCA.sessionID;
                n.referrer = document.referrer;
                n.trackingId = e.Context.CTID
            }

            function u(t, i) {
                var r = JSON.stringify(t);
                s.executePostRequest(n + i, r, o, o)
            }

            function o(n) {
                e.consoleLog(n)
            }
            var i = this,
                f = t.ltk,
                e = t.ltkUtil,
                s = t.httpClient;
            i.emailIdentification = function(n) {
                var t = {
                    Email: n
                };
                r(t);
                u(t, "/EmailIdentification")
            };
            i.phoneIdentification = function(n) {
                var t = {
                    PhoneNumber: n
                };
                r(t);
                u(t, "/PhoneIdentification")
            };
            i.contactPidIdentification = function(n) {
                var t = {
                    ContactPid: n
                };
                r(t);
                u(t, "/ContactPidIdentification")
            };
            i.sha256Identification = function(n) {
                var t = {
                    Sha256Id: n
                };
                r(t);
                u(t, "/Sha256Identification")
            };
            i.webPushIdentification = function(n) {
                var t = {
                    WebPushSubscriptionHash: n
                };
                r(t);
                u(t, "/WebPushIdentification")
            };
            i.externalContactIdIdentification = function(n) {
                var t = {
                    ExternalContactId: n
                };
                r(t);
                u(t, "/ExternalContactIdIdentification")
            }
        }

        function c(n, t, i, r) {
            function o(n) {
                n.globalSessionUid = c.Session.GlobalID;
                n.sessionUid = e.sessionId;
                n.referrer = document.referrer;
                n.trackingId = f.Context.CTID
            }

            function s(t, r) {
                if (i) {
                    var u = JSON.stringify(t);
                    l.executePostRequest(n + r, u, h, h)
                }
            }

            function a() {
                var n = new Image;
                n.height = 1;
                n.width = 1;
                n.src = t + "/" + f.Context.CTID + "/bls/clearcartid?sid=" + e.sessionId
            }

            function h(n) {
                f.consoleLog(n)
            }
            var u = this,
                c = r.ltk,
                f = r.ltkUtil,
                l = r.httpClient,
                e = r.cart;
            u.cartUpdate = function() {
                var n = e.cartActivityEvent();
                o(n);
                s(n, "/CartUpdate")
            };
            u.cartPurchase = function(n) {
                var t = {
                    OrderNumber: n
                };
                o(t);
                s(t, "/CartPurchase");
                a()
            };
            u.cartClear = function() {
                var n = {};
                o(n);
                s(n, "/CartClear")
            }
        }

        function l(n, t, i) {
            function e(n) {
                n.globalSessionUid = u.Session.GlobalID;
                n.sessionUid = u.SCA.sessionID;
                n.referrer = document.referrer;
                n.trackingId = f.Context.CTID
            }

            function o(i, r) {
                if (t) {
                    var u = JSON.stringify(i);
                    h.executePostRequest(n + r, u, s, s)
                }
            }

            function s(n) {
                f.consoleLog(n)
            }
            var r = this,
                u = i.ltk,
                f = i.ltkUtil,
                h = i.httpClient;
            r.pageBrowse = function(n) {
                var t = {
                    Url: n
                };
                e(t);
                o(t, "/PageBrowse")
            };
            r.productBrowse = function(n) {
                var t = {
                    Sku: n
                };
                e(t);
                o(t, "/ProductBrowse")
            }
        }

        function r(n) {
            function h(n) {
                var t = n.replace(/[^0-9]/g, "");
                return t.length >= 7 && t.length <= 15
            }

            function e(n) {
                return n instanceof HTMLInputElement
            }
            var t = this,
                o = n.ltk,
                u = n.ltkUtil,
                i = n.browserElementGetter,
                r = null,
                f = 750,
                s = [".ltk-phone-field", '[data-ltk-field="phone"]', '[type="tel"]'];
            u.ready(function() {
                t.init(s)
            }, this);
            t.init = function(n) {
                for (var i = 0; i < n.length; i++) t.captureNonSubmittedPhoneNumber(n[i])
            };
            t.captureNonSubmittedEmail = function(n, r) {
                if (n) {
                    r && t.asyncCaptureNonSubmittedEmail(n);
                    var u = [];
                    return e(n) ? u.push(n) : (u = i.getElementFromSelectorString(n), u = i.filterToInputElements(u)), u.length > 0 && u[0] ? (t.attachInputListener(u, t.emailFieldCheckAndSubmit), u) : void 0
                }
            };
            t.asyncCaptureNonSubmittedEmail = function(n) {
                n && i.waitForFieldToExist(n, t.captureNonSubmittedEmail)
            };
            t.captureNonSubmittedPhoneNumber = function(n, r) {
                if (n) {
                    r && t.asyncCaptureNonSubmittedPhoneNumber(n);
                    var u = [];
                    return e(n) ? u.push(n) : (u = i.getElementFromSelectorString(n), u = i.filterToInputElements(u)), u.length > 0 && u[0] ? (t.attachInputListener(u, t.phoneFieldCheckAndSubmit), t.attachOnChangeListener(u, t.phoneFieldCheckAndSubmit), u) : void 0
                }
            };
            t.asyncCaptureNonSubmittedPhoneNumber = function(n) {
                n && i.waitForFieldToExist(n, t.captureNonSubmittedPhoneNumber)
            };
            t.emailFieldCheckAndSubmit = function(n) {
                r && clearTimeout(r);
                r = setTimeout(function() {
                    var i = n.target.value;
                    i.length > 0 && o.isValidEmail(i) && t.submitEmailIdentity(i)
                }, f)
            };
            t.phoneFieldCheckAndSubmit = function(n) {
                r && clearTimeout(r);
                r = setTimeout(function() {
                    var i = n.target.value;
                    h(i) && t.submitPhoneIdentity(i)
                }, f)
            };
            t.submitEmailIdentity = function(n) {
                u.Identity.Email(n)
            };
            t.submitPhoneIdentity = function(n) {
                u.Identity.MobilePhone(n)
            };
            t.attachInputListener = function(n, i) {
                t.attachListenerEvent(n, "input", i)
            };
            t.attachOnChangeListener = function(n, i) {
                t.attachListenerEvent(n, "change", i)
            };
            t.attachListenerEvent = function(n, t, i) {
                n.forEach(function(n) {
                    n.addEventListener(t, i)
                })
            }
        }

        function u(n) {
            function o(n) {
                i.ready(function() {
                    t.Session.getPersonalizedStatus() && f.pageBrowse(n.detail.page)
                }, this)
            }

            function s(n) {
                i.ready(function() {
                    t.Session.getPersonalizedStatus() && f.productBrowse(n.detail.sku)
                }, this)
            }

            function h(n) {
                i.ready(function() {
                    t.Session.getPersonalizedStatus() && u.contactPidIdentification(n.detail.contactPid)
                }, this)
            }

            function c(n) {
                i.ready(function() {
                    t.Session.getPersonalizedStatus() && u.emailIdentification(n.detail.email)
                }, this)
            }

            function l(n) {
                i.ready(function() {
                    t.Session.getPersonalizedStatus() && u.phoneIdentification(n.detail.phone)
                }, this)
            }

            function a(n) {
                i.ready(function() {
                    t.Session.getPersonalizedStatus() && u.webPushIdentification(n.detail.webPushSubscriptionHash)
                })
            }

            function r(n, t) {
                document.addEventListener(n, t, !1)
            }
            var e = this,
                t = n.ltk,
                i = n.ltkUtil,
                u = n.identityActivityEventApi,
                f = n.browseAbandonActivityEventApi;
            e.setupEventListeners = function() {
                r("ltkPageBrowse", o);
                r("ltkProductBrowse", s);
                r("ltkContactPidIdentityEvent", h);
                r("ltkEmailIdentityEvent", c);
                r("ltkPhoneIdentityEvent", l);
                r("ltkWebPushIdentityEvent", a)
            }
        }

        function f(n) {
            var i = this,
                u = n.ltk,
                r = n.ltkUtil;
            i.items = [];
            i.sessionId = null;
            i.tid = r.Context.CartTemplateID;
            i.clearCart = !1;
            i.firstName = null;
            i.lastName = null;
            i.email = null;
            i.stage = null;
            i.total = null;
            i.meta1 = null;
            i.meta2 = null;
            i.meta3 = null;
            i.meta4 = null;
            i.meta5 = null;
            i.orderNumber = null;
            i.token = null;
            i.cartLink = null;
            i.source = null;
            i.trkt = r.getCookie("_trkt");
            i._varmap = {
                email: "e",
                firstName: "fn",
                lastName: "ln",
                meta1: "sm1",
                meta2: "sm2",
                meta3: "sm3",
                meta4: "sm4",
                meta5: "sm5",
                stage: "st",
                orderNumber: "on",
                total: "tt",
                token: "tk",
                source: "sr",
                cartLink: "cl",
                NewCustomer: "nc",
                clearCart: "cc"
            };
            i.matchAndMapValueToProperty = function(n, t) {
                typeof i[n] != "undefined" ? (n.toLowerCase() !== "email" || u.isValidEmail(t)) && (i[n] = t) : r.consoleLog("Key of " + n + "with value of " + t + " is not a valid property.")
            };
            i.addNewItemToCart = function(n, r, u, f, e, o) {
                var s = new t(n, r, u, f);
                s.ImageUrl = e ? e : null;
                s.LinkUrl = o ? o : null;
                i.items.push(s)
            };
            i.clearCartItems = function() {
                i.items = []
            };
            i.cartActivityEvent = function() {
                for (var t = {
                        firstName: i.firstName,
                        lastName: i.lastName,
                        email: i.email,
                        stage: i.stage,
                        total: parseFloat(i.total),
                        meta1: i.meta1,
                        meta2: i.meta2,
                        meta3: i.meta3,
                        meta4: i.meta4,
                        meta5: i.meta5,
                        token: i.token,
                        url: i.cartLink,
                        source: i.source,
                        items: []
                    }, n = 0; n < i.items.length; n++) t.items.push(i.items[n].cartItemForActivityEvent());
                return t
            }
        }

        function t(n, t, i, r) {
            var u = this;
            u.Sku = n;
            u.Quantity = t;
            u.Price = i;
            u.Name = r;
            u.ImageUrl = null;
            u.LinkUrl = null;
            u.Size = null;
            u.Meta1 = null;
            u.Meta2 = null;
            u.Meta3 = null;
            u.Meta4 = null;
            u.Meta5 = null;
            u._isIndexable = !0;
            u._varmap = {
                Sku: "s",
                Quantity: "q",
                Price: "p",
                Name: "n",
                ImageUrl: "iu",
                LinkUrl: "lu",
                Size: "sz",
                Meta1: "m1",
                Meta2: "m2",
                Meta3: "m3",
                Meta4: "m4",
                Meta5: "m5"
            };
            u.cartItemForActivityEvent = function() {
                return {
                    sku: u.Sku ? u.Sku.toString() : null,
                    quantity: parseInt(u.Quantity),
                    price: parseFloat(u.Price),
                    name: u.Name ? u.Name.toString() : null,
                    imageUrl: u.ImageUrl ? u.ImageUrl.toString() : null,
                    linkUrl: u.LinkUrl ? u.LinkUrl.toString() : null,
                    size: u.Size ? u.Size.toString() : null,
                    meta1: u.Meta1 ? u.Meta1.toString() : null,
                    meta2: u.Meta2 ? u.Meta2.toString() : null,
                    meta3: u.Meta3 ? u.Meta3.toString() : null,
                    meta4: u.Meta4 ? u.Meta4.toString() : null,
                    meta5: u.Meta5 ? u.Meta5.toString() : null
                }
            }
        }

        function e(n) {
            function o(n) {
                f.cartPurchase(n);
                i.setCookie("STSID" + t.tid, "", -1, i.getCookieDomain());
                t.clearCartItems()
            }
            var r = this,
                u = n.ltk,
                i = n.ltkUtil,
                e = n.inputEventInterface,
                f = n.shoppingCartActivityEventApi,
                t = n.cart;
            r.setSessionId = function(n) {
                u.Session.setCartID(n, !0)
            };
            r.setCustomer = function(n, r, f) {
                t.email = n ? n : t.email;
                t.firstName = r ? r : t.firstName;
                t.lastName = f ? f : t.lastName;
                i.ready(function() {
                    t.email && u.isValidEmail(t.email) && u.Session.getPersonalizedStatus() && e.submitEmailIdentity(t.email)
                }, this)
            };
            r.addCartItem = function(n, i, r, u) {
                t.addNewItemToCart(n, i, r, u, null, null)
            };
            r.addCartItemWithLinks = function(n, i, r, u, f, e) {
                t.addNewItemToCart(n, i, r, u, f, e)
            };
            r.addCustomCartItem = function(n) {
                t.items.push(n)
            };
            r.updateCart = function(n, r) {
                i.ready(function() {
                    u.Session.getPersonalizedStatus() && (t.matchAndMapValueToProperty(n, r), n.toLowerCase() === "email" && u.isValidEmail(r) && e.submitEmailIdentity(r))
                }, this)
            };
            r.clearCart = function() {
                i.ready(function() {
                    f.cartClear();
                    t.clearCartItems();
                    var n = i.CustomEvent("ltkClearCart", {});
                    document.dispatchEvent(n)
                }, this)
            };
            r.submitCart = function() {
                i.ready(function() {
                    var n, r;
                    t.sessionId && (n = i.getCookie("_trkt"), t.token = n ? n : t.token, t.orderNumber ? o(t.orderNumber) : (r = i.CustomEvent("ltkAddToCart", {
                        detail: {
                            items: t.items
                        }
                    }), document.dispatchEvent(r), t.items.length > 0 && (f.cartUpdate(), t.clearCartItems())))
                })
            };
            document.addEventListener("ltkCheckout", function(n) {
                i.ready(function() {
                    o(n.detail.orderNumber)
                })
            }, !1)
        }

        function a(n, t) {
            var e = this,
                i = t.ltk,
                u = t.ltkUtil,
                f = t.cart,
                r = new _Assembler;
            r.Name = "SCA Data";
            e.updateCart = function(t, r) {
                try {
                    u.ready(function() {
                        try {
                            if (i.Session.getPersonalizedStatus() && (t !== "email" || i.isValidEmail(r))) {
                                var f = new Image;
                                f.src = _protocol + n + "/" + u.Context.CTID + "/cart/fieldUpdate?gsid=" + i.Session.GlobalID + "&_sid=" + i.SCA.sessionID + "&_uid=" + i.uuidCompact() + "&_tid=" + i.SCA.tid + "&" + t + "=" + encodeURIComponent(r) + "&_t=" + (new Date).valueOf();
                                i.Testing && (f.onload = function() {
                                    var n = {
                                        "Session Update": {}
                                    };
                                    n["Session Update"][t] = r;
                                    i.Testing.Validate("Session Update", n)
                                })
                            }
                        } catch (e) {
                            i.Exception.Submit(e, "Update")
                        }
                    }, this);
                    t === "email" && i.isValidEmail(r) && u.Identity.Email(r)
                } catch (f) {
                    i.Exception.Submit(f, "Init Update")
                }
            };
            e.clearCart = function() {
                u.ready(function() {
                    i.SCA.clearCart = !0;
                    e.submitCart()
                }, this)
            };
            e.submitCart = function() {
                try {
                    u.ready(function() {
                        try {
                            if (typeof f.sessionId == "undefined") return;
                            r = new _Assembler;
                            r.Name = "SCA data";
                            r.QueryMode = 1;
                            r.EndPointArray = [];
                            r.EndPointArray.push(n);
                            r.EndPointPath = "/" + u.Context.CTID + "/cart/update";
                            r.QueryHeader = "gsid=" + i.Session.GlobalID + "&_sid=" + f.sessionId + "&_tid=" + f.tid + "&_uid=" + i.uuidCompact();
                            r.ContainsPII = !0;
                            r.AddObject(f, "SCA");
                            f.orderNumber === null && r.AddArrayObject(f.items, "SCAItems");
                            r.Flush();
                            i.SCA.clearCart = !1
                        } catch (t) {
                            i.Exception.Submit("Submit")
                        }
                    }, this)
                } catch (t) {
                    i.Exception.Submit(t, "Init Submit")
                }
            }
        }

        function o(n) {
            var t = this,
                f = n.ltk,
                i = n.ltkUtil,
                r = n.identityActivityEventApi,
                u = ["ekey", "eKey", "SHA256", "_ltkSha256", "ltkSha256", "_ltkSHA256", "ltkSHA256"],
                e = ["e_ltk"];
            i.ready(function() {
                t.init()
            }, this);
            t.init = function() {
                f.Session.getPersonalizedStatus() && (t.identifySha256(), t.identifyExternalId())
            };
            t.identifySha256 = function() {
                var n = t.getSha256Identifier();
                n && r.sha256Identification(n)
            };
            t.getSha256Identifier = function() {
                for (var t, r = null, n = 0; n < u.length; n++)
                    if (t = i.getQuerystringValue(u[n]), t !== "") {
                        r = t;
                        break
                    }
                return r
            };
            t.identifyExternalId = function() {
                var n = t.getExternalId();
                n && r.externalContactIdIdentification(n)
            };
            t.getExternalId = function() {
                var n = null;
                return e.forEach(t => {
                    n || (n = i.getQuerystringValue(t))
                }), n
            }
        }

        function v() {
            var n = this;
            n.ltk = _ltk;
            n.ltkUtil = _ltk_util;
            n.initialize = function() {
                n.cart = new f(n);
                n.httpClient = new s;
                n.browserElementGetter = new i(n);
                n.inputEventInterface = new r(n);
                n.identityActivityEventApi = new h("https://bl.listrakbi.com/api/ActivityEvents", n);
                n.shoppingCartActivityEventApi = new c("https://bl.listrakbi.com/api/ActivityEvents", "https://s1.listrakbi.com", !0, n);
                n.shoppingCartAbandonmentInterface = new e(n);
                n.shoppingCartAbandonmentLegacy = new a("sca1.listrakbi.com", n);
                n.browseAbandonActivityEventApi = new l("https://bl.listrakbi.com/api/ActivityEvents", !0, n);
                n.browseAbandonmentInterface = new u(n);
                n.browseAbandonmentInterface.setupEventListeners();
                n.thirdPartyIdentificationInterface = new o(n)
            }
        }
        typeof exports != "undefined" && (exports.ElementInterface = i);
        typeof exports != "undefined" && (exports.InputEventInterface = r);
        typeof exports != "undefined" && (exports.BrowseAbandonmentInterface = u);
        typeof exports != "undefined" && (exports.Cart = f);
        typeof exports != "undefined" && (exports.SCAItem = t);
        typeof exports != "undefined" && (exports.ShoppingCartAbandonmentInterface = e);
        typeof exports != "undefined" && (exports.ThirdPartyIdentificationInterface = o);
        var n = new v;
        n.initialize();
        _ltk.SCA = {
            get CartLink() {
                return n.cart.cartLink
            },
            set CartLink(t) {
                n.cart.cartLink = t
            },
            get Email() {
                return n.cart.email
            },
            set Email(t) {
                n.cart.email = t
            },
            get FirstName() {
                return n.cart.firstName
            },
            set FirstName(t) {
                n.cart.firstName = t
            },
            get items() {
                return n.cart.items
            },
            set items(t) {
                n.cart.items = t
            },
            get LastName() {
                return n.cart.lastName
            },
            set LastName(t) {
                n.cart.lastName = t
            },
            get Meta1() {
                return n.cart.meta1
            },
            set Meta1(t) {
                n.cart.meta1 = t
            },
            get Meta2() {
                return n.cart.meta2
            },
            set Meta2(t) {
                n.cart.meta2 = t
            },
            get Meta3() {
                return n.cart.meta3
            },
            set Meta3(t) {
                n.cart.meta3 = t
            },
            get Meta4() {
                return n.cart.meta4
            },
            set Meta4(t) {
                n.cart.meta4 = t
            },
            get Meta5() {
                return n.cart.meta5
            },
            set Meta5(t) {
                n.cart.meta5 = t
            },
            get OrderNumber() {
                return n.cart.orderNumber
            },
            set OrderNumber(t) {
                n.cart.orderNumber = t
            },
            get Source() {
                return n.cart.source
            },
            set Source(t) {
                n.cart.source = t
            },
            get Stage() {
                return n.cart.stage
            },
            set Stage(t) {
                n.cart.stage = t
            },
            get Token() {
                return n.cart.token
            },
            set Token(t) {
                n.cart.token = t
            },
            get Total() {
                return n.cart.total
            },
            set Total(t) {
                n.cart.total = t
            },
            get sessionID() {
                return n.cart.sessionId
            },
            set sessionID(t) {
                n.cart.sessionId = t
            },
            get tid() {
                return n.cart.tid
            },
            set tid(t) {
                n.cart.tid = t
            },
            get trkt() {
                return n.cart.trkt
            },
            set trkt(t) {
                n.cart.trkt = t
            },
            get clearCart() {
                return n.cart.clearCart
            },
            set clearCart(t) {
                n.cart.clearCart = t
            },
            Load: function() {},
            SetSessionID: n.shoppingCartAbandonmentInterface.setSessionId,
            SetCustomer: n.shoppingCartAbandonmentInterface.setCustomer,
            CaptureEmail: n.inputEventInterface.captureNonSubmittedEmail,
            AsyncCaptureEmail: n.inputEventInterface.asyncCaptureNonSubmittedEmail,
            CapturePhoneNumber: n.inputEventInterface.captureNonSubmittedPhoneNumber,
            AsyncCapturePhoneNumber: n.inputEventInterface.asyncCaptureNonSubmittedPhoneNumber,
            AddItem: n.shoppingCartAbandonmentInterface.addCartItem,
            AddItemWithLinks: n.shoppingCartAbandonmentInterface.addCartItemWithLinks,
            AddItemEx: n.shoppingCartAbandonmentInterface.addCustomCartItem,
            Update: function(t, i) {
                n.shoppingCartAbandonmentLegacy.updateCart(t, i);
                n.shoppingCartAbandonmentInterface.updateCart(t, i)
            },
            ClearCart: function() {
                n.shoppingCartAbandonmentLegacy.clearCart();
                n.shoppingCartAbandonmentInterface.clearCart()
            },
            getCookie: n.ltkUtil.getCookie,
            setCookie: n.ltkUtil.setCookie,
            Submit: function() {
                n.shoppingCartAbandonmentLegacy.submitCart();
                n.shoppingCartAbandonmentInterface.submitCart()
            },
            Reset: n.cart.clearCartItems
        };
        window.SCAItem = t
    }();
LTK.prototype.Recommender = new function() {
        function h(n) {
            var u, t;
            n = n.replace(/\@\@/g, "@('@')");
            n = n.replace(/\@include\((.*?)\)/g, function(n, t) {
                return document.getElementById(t).innerHTML
            });
            var i = [],
                r = [i],
                s = {
                    "{": "}",
                    "(": ")"
                },
                f = 0,
                e = "",
                o = "";
            for (t = 0; t < n.length; t++) u = n[t], i.push(u), f == 0 ? (o = s[e = u]) && n[t - 1] == "@" && (f = 1, i.pop(), i.pop(), r.push(i = ["');"]), u == "(" && i.push("print(")) : f > 0 && (u == e && f++, u == o && f--, f == 0 && (i.pop(), u == ")" && i.push(")"), i.push("; print('"), r.push(i = [])));
            for (t = 0; t < r.length; t++) r[t] = r[t].join(""), t % 2 == 0 && (r[t] = r[t].replace(/\\/g, "\\\\").replace(/'/g, "\\'").replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\@([a-zA-Z0-9\.]+)/gi, "'); print($1); print('"));
            return n = "var __html = ''; function print(s) { __html += s; }; print('" + r.join("") + "'); return __html;", new Function("Recommendation", n)
        }

        function c(n, f) {
            function p(n) {
                var t = "_ltk.Recommender.lastActivityDate";
                if (n) sessionStorage.setItem(t, n.getTime());
                else return new Date(parseInt(sessionStorage.getItem(t) || 0))
            }
            for (var c, a, v, l, y, e = [], h = _ltk.Activity.Session({
                    since: p()
                }), o = 0; o < h.length; o++) c = h[o], ["ProductBrowse"].indexOf(c.Type) != -1 && (e.push("&activity.type="), e.push(encodeURIComponent(c.Type)), e.push("&activity.sku="), e.push(encodeURIComponent(c.Key)), e.push("&activity.date="), e.push(encodeURIComponent((new Date).getTime() - c.Date.getTime())));
            for (o = 0; o < i.length; o++) a = i[o], e.push("&activity.sku="), e.push(encodeURIComponent(a));
            for (o = 0; o < t.length; o++) v = t[o], e.push("&field="), e.push(encodeURIComponent(v));
            for (l in r) y = r[l], e.push("&"), e.push(encodeURIComponent(l)), e.push("="), e.push(encodeURIComponent(y));
            _ltk_util.AsyncManager.StartAsyncCall("recommend-" + n, function() {
                var t = new XMLHttpRequest;
                t.withCredentials === undefined && (t = new XDomainRequest);
                t.open("POST", s + "/json/" + n + "?globalSessionUID=" + _ltk.Session.GlobalID);
                t.withCredentials !== undefined && t.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                t.onload = function() {
                    var r, i;
                    h.length && (r = h[h.length - 1], p(r.Date));
                    i = JSON.parse(t.responseText);
                    i.MerchandiseBlockUID = n,
                        function(n, t) {
                            if (t == u.length) {
                                f(n);
                                return
                            }
                            var i = arguments.callee,
                                r = u[t];
                            r(n, function(n) {
                                i(n, t + 1)
                            })
                        }(i, 0)
                };
                t.send(e.join(""))
            }, this, [_ltk.Session.GlobalIDAsyncCallName])
        }

        function l(n) {
            for (var r, i = [], n = h(n), t = 0; t < this.length; t++) i.push(n(this[t]));
            for (r = document.createElement("div"), t = 0; t < i.length; t++) r.innerHTML = i[t], r.children.length != 1 && (i[t] = r.outerHTML);
            return i.join("")
        }
        var n = this,
            r = {},
            o = null,
            s = "//recs.listrakbi.com",
            t = ["ProductUID", "RecipeUID", "Sku", "Title", "Price", "ImageUrl", "LinkUrl"],
            u = [],
            f = [],
            i = [],
            e;
        return n.AddField = function() {
            for (var i, n = 0; n < arguments.length; n++) i = arguments[n], t.indexOf(i) == -1 && t.push(i)
        }, n.AddFilter = function(n) {
            u.push(n)
        }, n.AddSku = function() {
            for (var t, n = 0; n < arguments.length; n++) t = arguments[n], i.indexOf(t) == -1 && i.push(t)
        }, n.Render = function(n, t) {
            if (document.querySelector) {
                if (arguments.length == 0 && (n = document.body), t = typeof t == "function" ? t : function() {}, typeof n == "function") {
                    f.push(n);
                    return
                }(typeof n == "string" && (n = document.querySelector(n)), n) && _ltk_util.domready(function() {
                    var i = [],
                        o, u, s, h, r;
                    if (n.getAttribute("data-ltk-merchandiseblock")) i.push(n);
                    else
                        for (o = n.querySelectorAll("[data-ltk-merchandiseblock]"), u = 0; u < o.length; u++) i.push(o[u]);
                    for (s = i, i = {}; s.length > 0;) h = s.pop(), r = h.getAttribute("data-ltk-merchandiseblock"), i[r] = i[r] || [], i[r].push(h);
                    for (r in i) c(r, function(n) {
                        for (var s, h, b, r, p = i[n.MerchandiseBlockUID], a = 0; a < p.length; a++) {
                            var u = p[a],
                                v = parseInt(u.getAttribute("data-ltk-skip")) || 0,
                                k = parseInt(u.getAttribute("data-ltk-take")) || n.length - v,
                                o = u.querySelector("script") || u.querySelector("template"),
                                d = o.innerHTML,
                                y = [];
                            for (s = v; s < Math.min(n.length, v + k); s++) n[s] && y.push(n[s]);
                            for (h = document.createElement(o.parentNode.tagName), h.innerHTML = l.call(y, d), r = 0; r < h.children.length; r++) {
                                var c = h.children[r],
                                    g = y[r],
                                    w = e.click(g, n);
                                c.addEventListener ? c.addEventListener("click", w, !1) : c.attachEvent && c.attachEvent("onclick", w)
                            }
                            while (b = h.children[0]) o.parentNode.insertBefore(b, o);
                            for (o.parentNode.removeChild(o), t.call(u), r = 0; r < f.length; r++) f[r].call(u)
                        }
                    })
                })
            }
        }, n.SetData = function(n, t) {
            r[n] = t
        }, n.SetEmailAddress = function(n) {
            o = n
        }, e = new function() {
            function i(n, i, r) {
                for (var h, u, s, e, c = n.target || n.srcElement, l = [], f = 0; f < r.length; f++) r[f] && l.push(r[f].ProductUID);
                h = {
                    globalSessionUID: _ltk.Session.GlobalID,
                    sessionUID: _ltk.SCA.sessionID,
                    trackingUID: _ltk_util.getCookie("_trkt"),
                    email: o,
                    linkUrl: c.href || i.LinkUrl,
                    linkTag: c.getAttribute("data-ltk-tag"),
                    merchandiseBlockUID: r.MerchandiseBlockUID,
                    recipeUID: i.RecipeUID,
                    productUID: i.ProductUID,
                    recommended: l
                };
                u = [];
                for (s in h)
                    if (e = h[s], e instanceof Array)
                        for (f = 0; f < e.length; f++) u.push("&"), u.push(s), u.push("="), u.push(encodeURIComponent(e[f]));
                    else e && (u.push("&"), u.push(s), u.push("="), u.push(encodeURIComponent(e)));
                u[0] = "?";
                u = u.join("");
                t(u)
            }

            function t(n) {
                var t = "_ltk_recs_trk";
                if (arguments.length) _ltk_util.setCookie(t, n, 365, _ltk_util.getCookieDomain(), "/", !1);
                else return _ltk_util.getCookie(t)
            }
            var n = this;
            return n.click = function(n, t) {
                return function(r) {
                    i(r, n, t)
                }
            }, n.init = function() {
                _ltk_util.ready(function() {
                    var n = t(),
                        i;
                    _ltk.Session.getPersonalizedStatus() || (n = _ltk_util.clearParameterValues(n, ["globalSessionUID", "sessionUID", "trackingUID", "email"]));
                    n && (i = new Image, i.src = s + "/ltk.gif" + n + "&ts=" + (new Date).getTime(), t(""))
                }, this)
            }, n
        }, e.init(), n
    },
    function() {
        function i() {
            if (t) {
                _ltk_util.consoleLog("getCartData() fired");
                t = !1;
                var n = window.location.origin + "/cart.js";
                jQuery.getJSON(n, function(n) {
                    f(n.token);
                    e(n);
                    t = !0
                })
            }
        }

        function f(n) {
            _ltk_util.storageAvailable("sessionStorage") && sessionStorage.setItem("_ltk.Cart.token", n)
        }

        function e(n) {
            var r = n.items,
                u = {},
                i;
            if (r.length > 0) {
                for (i = 0; i < r.length; i++) {
                    var t = r[i],
                        f = _ltk.Shopify.GetSkuProperty(t.id, t.sku),
                        e = t.title,
                        o = t.quantity,
                        s = t.final_price / 100,
                        h = t.image,
                        c = t.url;
                    _ltk.SCA.AddItemWithLinks(f, o, s, e, h, c);
                    i <= 9 && (u[t.variant_id] = t.quantity)
                }
                _ltk.SCA.Meta1 = n.token;
                _ltk.SCA.CartLink = encodeURI(JSON.stringify(u).replace(/:/gi, "-")).replace(/,/gi, "%2C");
                _ltk.SCA.Submit()
            } else _ltk.SCA.ClearCart()
        }

        function o(n) {
            var i = n.pop ? n : [n],
                t = !1;
            return i.forEach(function(n) {
                window.location.pathname.indexOf(n) > -1 && (t = !0)
            }), t
        }

        function s(t, i, r) {
            n(t, r, i)
        }

        function n(n, t, i) {
            n == "*" || o(n) ? t && t() : i && i()
        }

        function h() {
            u("trackingConsentAccepted", () => _ltk.Session.setPersonalizedStatus(!0));
            u("trackingConsentDeclined", () => _ltk.Session.setPersonalizedStatus(!1));
            c();
            n("/products/", function() {
                var n = window.location.origin + window.location.pathname + ".js";
                jQuery.getJSON(n, function(n) {
                    var t = n.id.toString();
                    _ltk.Activity.AddProductBrowse(t)
                })
            });
            n("*", function() {
                var t, n, i;
                for (l(), t = document.querySelectorAll("input[type='email']"), n = 0; n < t.length; n++) i = t[n], _ltk.SCA.CaptureEmail(i.id)
            });
            n("/cart", function() {
                var n = _ltk_util.getQuerystringValue("ltkcart"),
                    t, r;
                n ? (t = decodeURI(n.replace(/-/gi, ":")).replace(/%2C/gi, ","), r = {
                    updates: JSON.parse(t)
                }, jQuery.ajax({
                    type: "POST",
                    url: "/cart/update.js",
                    data: r,
                    complete: function() {
                        location.search = ""
                    }
                })) : i()
            });
            s("/checkouts/", function() {
                jQuery(document).ajaxSuccess(function(n, t, r) {
                    r.url && r.url.indexOf("/cart") > -1 && r.url.indexOf("cart.js") === -1 && (_ltk_util.consoleLog(r.url), i())
                })
            })
        }

        function c() {
            typeof Shopify == "object" && typeof Shopify.loadFeatures == "function" && Shopify.loadFeatures([{
                name: "consent-tracking-api",
                version: "0.1"
            }, ], n => {
                !n && Shopify.customerPrivacy && _ltk_util.ready(function() {
                    _ltk.Session.getPersonalizedStatus() != Shopify.customerPrivacy.userCanBeTracked() && _ltk.Session.setPersonalizedStatus(Shopify.customerPrivacy.userCanBeTracked())
                })
            })
        }

        function u(n, t) {
            document.addEventListener && document.addEventListener(n, function() {
                t()
            })
        }

        function l() {
            if (typeof ltkCustObj != "undefined") {
                var n = _ltk_util.getCookie("ltkLoggedIn");
                (n == "" || _ltk_util.decode(n) != ltkCustObj.email) && a()
            } else _ltk_util.deleteCookie("ltkLoggedIn")
        }

        function a() {
            _ltk_util.setCookie("ltkLoggedIn", _ltk_util.encode(ltkCustObj.email));
            _ltk.SCA.SetCustomer(ltkCustObj.email, ltkCustObj.firstname, ltkCustObj.lastname);
            _ltk.SCA.Submit()
        }
        var t = !0,
            r;
        _ltk.Shopify = {
            GetSkuProperty: function(n, t) {
                return "sku".toLowerCase() == "sku" ? t || n : n
            },
            GetCartData: function() {
                i()
            }
        };
        r = new function() {
            function t(n) {
                setTimeout(function() {
                    try {
                        n()
                    } catch (t) {
                        _ltk.Exception.Submit(t, "Unhandled exception in shopify.js: " + t)
                    }
                }, 0)
            }

            function i(n) {
                setTimeout(n, 0)
            }
            var n = /debug/.test(function() {});
            return n ? i : t
        };
        _ltk_util.AsyncManager.StartAsyncCall("shopifyInit", function() {
            r(function() {
                h()
            })
        }, this, ["jQuery"])
    }();
_ltk.Modal = {};
_ltk_util.AsyncManager.StartAsyncCall("modalInit", function() {
    (function() {
        var u = [],
            r = jQuery(document),
            i = navigator.userAgent.toLowerCase(),
            f = jQuery(window),
            t = [],
            n = {
                ieQuirks: null,
                msie: /msie/.test(i) && !/opera/.test(i),
                opera: /opera/.test(i)
            };
        n.ie6 = n.msie && /msie 6./.test(i) && typeof XMLHttpRequest != "object";
        n.ie7 = n.msie && /msie 7.0/.test(i);
        _ltk.Modal.simpleModal = function(n, t) {
            return _ltk.Modal.simpleModal.impl.init(n, t)
        };
        _ltk.Modal.simpleModal.close = function() {
            _ltk.Modal.simpleModal.impl.close()
        };
        _ltk.Modal.simpleModal.focus = function(n) {
            _ltk.Modal.simpleModal.impl.focus(n)
        };
        _ltk.Modal.simpleModal.setContainerDimensions = function() {
            _ltk.Modal.simpleModal.impl.setContainerDimensions()
        };
        _ltk.Modal.simpleModal.setPosition = function() {
            _ltk.Modal.simpleModal.impl.setPosition()
        };
        _ltk.Modal.simpleModal.update = function(n, t) {
            _ltk.Modal.simpleModal.impl.update(n, t)
        };
        _ltk.Modal.simpleModal.defaults = {
            appendTo: "body",
            focus: !0,
            opacity: 50,
            overlayId: "simpleltkmodal-overlay",
            overlayCss: {},
            containerId: "simpleltkmodal-container",
            containerCss: {},
            dataId: "simpleltkmodal-data",
            dataCss: {},
            minHeight: null,
            minWidth: null,
            maxHeight: null,
            maxWidth: null,
            autoResize: !1,
            autoPosition: !0,
            zIndex: 1e3,
            close: !0,
            closeHTML: '<a class="modalCloseImg" title="Close"><\/a>',
            closeClass: "simpleltkmodal-close",
            closeClass2: "ltk-bee-popup-close",
            escClose: !0,
            overlayClose: !1,
            fixed: !0,
            position: null,
            persist: !1,
            modal: !0,
            onOpen: null,
            onShow: null,
            onClose: null,
            isLegacy: !0
        };
        _ltk.Modal.simpleModal.impl = {
            d: {},
            init: function(t, i) {
                var r = this;
                if (r.d.data) return !1;
                if (n.ieQuirks = n.msie && document.compatMode == "BackCompat", r.o = jQuery.extend({}, _ltk.Modal.simpleModal.defaults, i), r.zIndex = r.o.zIndex, r.occb = !1, typeof t == "object") t = t instanceof jQuery ? t : jQuery(t), r.d.placeholder = !1, t.parent().parent().length > 0 && (t.before(jQuery("<span><\/span>").attr("id", "simpleltkmodal-placeholder").css({
                    display: "none"
                })), r.d.placeholder = !0, r.display = t.css("display"), r.o.persist || (r.d.orig = t.clone(!0)));
                else if (typeof t == "string" || typeof t == "number") t = jQuery("<div><\/div>").html(t);
                else return alert("SimpleLtkModal Error: Unsupported data type: " + typeof t), r;
                return r.create(t), t = null, r.open(), jQuery.isFunction(r.o.onShow) && r.o.onShow.apply(r, [r.d]), r
            },
            create: function(i) {
                var r = this,
                    f, e;
                r.getDimensions();
                r.o.modal && n.ie6 && (r.d.iframe = jQuery('<iframe src="javascript:false;"><\/iframe>').css(jQuery.extend(r.o.iframeCss, {
                    display: "none",
                    opacity: 0,
                    position: "fixed",
                    height: t[0],
                    width: t[1],
                    zIndex: r.o.zIndex,
                    top: 0,
                    left: 0
                })).appendTo(r.o.appendTo));
                f = r.o.isLegacy ? jQuery.extend(r.o.overlayCss, {
                    display: "none",
                    opacity: r.o.opacity / 100,
                    height: r.o.modal ? u[0] : 0,
                    width: r.o.modal ? u[1] : 0,
                    position: "fixed",
                    left: 0,
                    top: 0,
                    zIndex: r.o.zIndex + 1
                }) : {
                    display: "none",
                    zIndex: r.o.zIndex + 1
                };
                r.d.overlay = jQuery("<div><\/div>").attr("id", r.o.overlayId).attr("aria-hidden", "true").addClass("simpleltkmodal-overlay").css(f).appendTo(r.o.appendTo);
                e = r.o.isLegacy ? jQuery.extend({
                    position: r.o.fixed ? "fixed" : "absolute"
                }, r.o.containerCss, {
                    display: "none",
                    zIndex: r.o.zIndex + 2
                }) : {
                    display: "none",
                    zIndex: r.o.zIndex + 2
                };
                r.d.container = jQuery("<div><\/div>").attr("id", r.o.containerId).attr("role", "dialog").attr("aria-modal", "true").attr("aria-label", "Modal Dialog").addClass("simpleltkmodal-container").css(e).append(r.o.close && r.o.closeHTML ? jQuery(r.o.closeHTML).addClass(r.o.closeClass) : "").appendTo(r.o.appendTo);
                r.d.wrap = jQuery("<div><\/div>").attr("tabIndex", -1).addClass("simpleltkmodal-wrap").css({
                    height: "100%",
                    outline: 0,
                    width: "100%"
                }).appendTo(r.d.container);
                r.d.data = i.attr("id", i.attr("id") || r.o.dataId).addClass("simpleltkmodal-data").css(jQuery.extend(r.o.dataCss, {
                    display: "none"
                })).appendTo("body");
                i = null;
                r.setContainerDimensions();
                r.d.data.appendTo(r.d.wrap);
                (n.ie6 || n.ieQuirks) && r.fixIE()
            },
            bindEvents: function() {
                var n = this;
                jQuery("." + n.o.closeClass).bind("click.simpleltkmodal", function(t) {
                    t.preventDefault();
                    n.close()
                });
                jQuery("." + n.o.closeClass2).bind("click.simpleltkmodal", function(t) {
                    t.preventDefault();
                    n.close()
                });
                jQuery('a[title="nothanks"]').bind("click.simpleltkmodal", function(t) {
                    t.preventDefault();
                    n.close()
                });
                jQuery('a:contains("No thanks")').bind("click.simpleltkmodal", function(t) {
                    t.preventDefault();
                    n.close()
                });
                n.o.modal && n.o.close && n.o.overlayClose && n.d.overlay.bind("click.simpleltkmodal", function(t) {
                    t.preventDefault();
                    n.close()
                });
                r.bind("keydown.simpleltkmodal", function(t) {
                    n.o.modal && t.keyCode === 9 ? n.watchTab(t) : n.o.close && n.o.escClose && t.keyCode === 27 && (t.preventDefault(), n.close())
                })
            },
            unbindEvents: function() {
                jQuery("." + this.o.closeClass).unbind("click.simpleltkmodal");
                jQuery("." + this.o.closeClass2).unbind("click.simpleltkmodal");
                jQuery('a[title="nothanks"]').unbind("click.simpleltkmodal");
                jQuery('a:contains("No thanks")').unbind("click.simpleltkmodal");
                r.unbind("keydown.simpleltkmodal");
                f.unbind(".simpleltkmodal");
                this.d.overlay.unbind("click.simpleltkmodal")
            },
            fixIE: function() {
                var t = this,
                    n = t.o.position;
                jQuery.each([t.d.iframe || null, t.o.modal ? t.d.overlay : null, t.d.container.css("position") === "fixed" ? t.d.container : null], function(t, i) {
                    var a, v, s, h;
                    if (i) {
                        var e = "document.body.clientHeight",
                            o = "document.body.clientWidth",
                            y = "document.body.scrollHeight",
                            c = "document.body.scrollLeft",
                            l = "document.body.scrollTop",
                            p = "document.body.scrollWidth",
                            w = "document.documentElement.clientHeight",
                            b = "document.documentElement.clientWidth",
                            u = "document.documentElement.scrollLeft",
                            f = "document.documentElement.scrollTop",
                            r = i[0].style;
                        r.position = "absolute";
                        t < 2 ? (r.removeExpression("height"), r.removeExpression("width"), r.setExpression("height", "" + y + " > " + e + " ? " + y + " : " + e + ' + "px"'), r.setExpression("width", "" + p + " > " + o + " ? " + p + " : " + o + ' + "px"')) : (n && n.constructor === Array ? (s = n[0] ? typeof n[0] == "number" ? n[0].toString() : n[0].replace(/px/, "") : i.css("top").replace(/px/, ""), a = s.indexOf("%") === -1 ? s + " + (t = " + f + " ? " + f + " : " + l + ') + "px"' : parseInt(s.replace(/%/, "")) + " * ((" + w + " || " + e + ") / 100) + (t = " + f + " ? " + f + " : " + l + ') + "px"', n[1] && (h = typeof n[1] == "number" ? n[1].toString() : n[1].replace(/px/, ""), v = h.indexOf("%") === -1 ? h + " + (t = " + u + " ? " + u + " : " + c + ') + "px"' : parseInt(h.replace(/%/, "")) + " * ((" + b + " || " + o + ") / 100) + (t = " + u + " ? " + u + " : " + c + ') + "px"')) : (a = "(" + w + " || " + e + ") / 2 - (this.offsetHeight / 2) + (t = " + f + " ? " + f + " : " + l + ') + "px"', v = "(" + b + " || " + o + ") / 2 - (this.offsetWidth / 2) + (t = " + u + " ? " + u + " : " + c + ') + "px"'), r.removeExpression("top"), r.removeExpression("left"), r.setExpression("top", a), r.setExpression("left", v))
                    }
                })
            },
            focus: function(n) {
                var t = this,
                    r = n && jQuery.inArray(n, ["first", "last"]) !== -1 ? n : "first",
                    i = jQuery(":input:enabled:visible:" + r, t.d.wrap);
                setTimeout(function() {
                    i.length > 0 ? i.focus() : t.d.wrap.focus()
                }, 10)
            },
            getDimensions: function() {
                var i = this,
                    n = typeof innerHeight == "undefined" ? f.height() : window.innerHeight;
                u = [r.height(), r.width()];
                t = [n, f.width()]
            },
            getVal: function(n, i) {
                return n ? typeof n == "number" ? n : n === "auto" ? 0 : n.indexOf("%") > 0 ? parseInt(n.replace(/%/, "")) / 100 * (i === "h" ? t[0] : t[1]) : parseInt(n.replace(/px/, "")) : null
            },
            update: function(n, t) {
                var i = this;
                if (!i.d.data) return !1;
                i.d.origHeight = i.getVal(n, "h");
                i.d.origWidth = i.getVal(t, "w");
                i.d.data.hide();
                n && i.d.container.css("height", n);
                t && i.d.container.css("width", t);
                i.setContainerDimensions();
                i.d.data.show();
                i.o.focus && i.focus();
                i.unbindEvents();
                i.bindEvents()
            },
            setContainerDimensions: function() {
                var i = this,
                    v = n.ie6 || n.ie7,
                    r = i.d.origHeight ? i.d.origHeight : n.opera ? i.d.container.height() : i.getVal(v ? i.d.container[0].currentStyle.height : i.d.container.css("height"), "h"),
                    u = i.d.origWidth ? i.d.origWidth : n.opera ? i.d.container.width() : i.getVal(v ? i.d.container[0].currentStyle.width : i.d.container.css("width"), "w"),
                    o = i.d.data.outerHeight(!0),
                    s = i.d.data.outerWidth(!0),
                    f;
                i.d.origHeight = i.d.origHeight || r;
                i.d.origWidth = i.d.origWidth || u;
                var l = i.o.maxHeight ? i.getVal(i.o.maxHeight, "h") : null,
                    a = i.o.maxWidth ? i.getVal(i.o.maxWidth, "w") : null,
                    h = l && l < t[0] ? l : t[0],
                    c = a && a < t[1] ? a : t[1],
                    e = i.o.minHeight ? i.getVal(i.o.minHeight, "h") : "auto";
                r = r ? i.o.autoResize && r > h ? h : r < e ? e : r : o ? o > h ? h : i.o.minHeight && e !== "auto" && o < e ? e : o : e;
                f = i.o.minWidth ? i.getVal(i.o.minWidth, "w") : "auto";
                u = u ? i.o.autoResize && u > c ? c : u < f ? f : u : s ? s > c ? c : i.o.minWidth && f !== "auto" && s < f ? f : s : f;
                i.o.isLegacy && i.d.container.css({
                    height: r,
                    width: u
                });
                i.d.wrap.css({
                    overflow: o > r || s > u ? "auto" : "visible"
                });
                i.o.autoPosition && i.setPosition()
            },
            setPosition: function() {
                var n = this;
                n.o.isLegacy && n.d.container.css({
                    left: "50%",
                    top: "20%",
                    "margin-left": n.d.container.outerWidth(!1) / -2
                })
            },
            watchTab: function(n) {
                var t = this,
                    i;
                jQuery(n.target).parents(".simpleltkmodal-container").length > 0 ? (t.inputs = jQuery(":input:enabled:visible:first, :input:enabled:visible:last", t.d.data[0]), (!n.shiftKey && n.target === t.inputs[t.inputs.length - 1] || n.shiftKey && n.target === t.inputs[0] || t.inputs.length === 0) && (n.preventDefault(), i = n.shiftKey ? "last" : "first", t.focus(i))) : (n.preventDefault(), t.focus())
            },
            open: function() {
                var n = this;
                n.d.iframe && n.d.iframe.show();
                jQuery.isFunction(n.o.onOpen) ? n.o.onOpen.apply(n, [n.d]) : (n.d.overlay.show(), n.d.container.show(), n.d.data.show());
                n.o.focus && n.focus();
                n.bindEvents()
            },
            close: function() {
                var n = this,
                    t;
                if (!n.d.data) return !1;
                n.unbindEvents();
                jQuery.isFunction(n.o.onClose) && !n.occb ? (n.occb = !0, n.o.onClose.apply(n, [n.d])) : (n.d.placeholder ? (t = jQuery("#simpleltkmodal-placeholder"), n.o.persist ? t.replaceWith(n.d.data.removeClass("simpleltkmodal-data").css("display", n.display)) : n.d.data.hide().remove()) : n.d.data.hide().remove(), n.d.container.hide().remove(), n.d.overlay.hide(), n.d.iframe && n.d.iframe.hide().remove(), n.d.overlay.remove(), n.d = {})
            }
        }
    })()
}, this, ["jQuery"]);
_ltk_util.AsyncManager.StartAsyncCall("popupInit", function() {
    function t() {
        this.windowBind = function(n, t) {
            this.addEventListener(window, n, t)
        };
        this.addEventListener = function(n, t, i) {
            n.addEventListener ? n.addEventListener(t, i, !1) : n.attachEvent && n.attachEvent("on" + t, i)
        };
        this.removeEventListener = function(n, t, i) {
            n.removeEventListener ? n.removeEventListener(t, i) : n.detachEvent && n.detachEvent("on" + t, i)
        };
        this.getWindowVisibleWidth = function() {
            return window.innerWidth ? window.innerWidth : document.documentElement.clientWidth
        };
        this.getWindowVisibleHeight = function() {
            return window.innerHeight ? window.innerHeight : document.documentElement.clientHeight
        };
        this.getDocumentTotalHeight = function() {
            return Math.max(document.body.scrollHeight, document.documentElement.scrollHeight, document.body.offsetHeight, document.documentElement.offsetHeight, document.body.clientHeight, document.documentElement.clientHeight)
        };
        this.getMouseEventY = function(n) {
            n = this.getEvent(n);
            var t = 0;
            return n.pageY ? t = n.pageY - window.pageYOffset : n.clientY && (t = n.clientY), t
        };
        this.getMouseEventX = function(n) {
            n = this.getEvent(n);
            var t = 0;
            return n.pageX ? t = n.pageX - window.pageXOffset : n.clientX && (t = n.clientX), t
        };
        this.stopPropagation = function(n) {
            var t = this.getEvent(n);
            t && t.stopPropagation()
        };
        this.getEvent = function(n) {
            return n ? n : window.event
        };
        this.getScrollVerticalPosition = function() {
            return typeof pageYOffset != "undefined" ? window.pageYOffset : (document.documentElement || document.body.parentNode || document.body).scrollTop
        };
        this.setCssText = function(n, t) {
            n.styleSheet ? n.styleSheet.cssText = t : n.appendChild(document.createTextNode(t))
        };
        this.getKeyCode = function(n) {
            return (n || window.event).keyCode
        };
        this.getHistory = function() {
            return window.history
        };
        this.getPageUrl = function() {
            return window.location.href
        };
        this.redirectTo = function(n) {
            window.location.replace(n)
        };
        this.getDocumentHead = function() {
            return document.head ? document.head : document.getElementsByTagName("head")[0]
        };
        this.getReferrerDomain = function() {
            return document.referrer
        };
        this.querySelectorAll = function() {
            function n(n, t) {
                var r = n.documentElement.firstChild,
                    i = n.createElement("STYLE");
                return r.appendChild(i), n.arrayOfSelectorNodes = [], i.styleSheet.cssText = t + "{x:expression(document.arrayOfSelectorNodes.push(this))}", window.scrollBy(1, 0), r.removeChild(i), window.scrollBy(-1, 0), n.arrayOfSelectorNodes
            }

            function t(n, t) {
                return n.querySelectorAll(t)
            }
            return document.querySelectorAll ? t : n
        }()
    }

    function i(n, t, i) {
        this.SUPPRESSION_COOKIE_PREFIX = "ltkpopup-suppression-";
        this.DEPTH_COOKIE_NAME = "ltkpopup-session-depth";
        this.followupDelayFrequency = {
            DAYS: 0,
            WEEKS: 1,
            MONTHS: 2,
            YEARS: 3
        };
        this.testing = !1;
        this.designPreviewPopupName = "";
        this.showConfirmationPage = !1;
        this.url = "";
        this.deviceType = "Desktop";
        this.depth = 1;
        this.initialize = function() {
            this.initializeTesting();
            this.initializeDesignPreviewPopupName();
            this.initializePreviewPopupPage();
            this.initializeUrl();
            this.initializeDeviceType();
            this.initializeDepth()
        };
        this.initializeTesting = function() {
            this.testing = t.getQuerystringValue("ltkpopuptestmode") === "1"
        };
        this.initializeDesignPreviewPopupName = function() {
            this.designPreviewPopupName = t.getQuerystringValue("ltkpopupshow")
        };
        this.initializePreviewPopupPage = function() {
            this.showConfirmationPage = t.getQuerystringValue("ltkpage") === "last"
        };
        this.initializeUrl = function() {
            this.url = i.getPageUrl().toLowerCase()
        };
        this.initializeDeviceType = function() {
            var n = i.getWindowVisibleWidth();
            n < 769 && (this.deviceType = "Mobile")
        };
        this.initializeDepth = function() {
            var r = t.getCookie(this.DEPTH_COOKIE_NAME),
                u = i.getHistory().length,
                n;
            r && (n = r.split("-", 2), this.depth = parseInt(n[0]), n[1] < u && ++this.depth);
            t.setCookie(this.DEPTH_COOKIE_NAME, this.depth + "-" + u, null, t.getCookieDomain(), "/", !1)
        };
        this.isSuppressed = function(n) {
            return t.getCookie(this.SUPPRESSION_COOKIE_PREFIX + n) !== ""
        };
        this.suppress = function(n, i) {
            var r = new Date,
                u = i ? this.neverShowAgain(r) : this.getFollowUpDate(n, r);
            t.setCookie(this.SUPPRESSION_COOKIE_PREFIX + n.popupUID, "1", u, t.getCookieDomain(), "/", !1)
        };
        this.getFollowUpDate = function(n, t) {
            var i = t,
                r;
            if (this.isSetToShowAgain(n) && this.isDelayingByPositiveValue(n)) {
                r = n.settings.engagement.followUpDelay;
                switch (n.settings.engagement.followUpTimeframe) {
                    case this.followupDelayFrequency.DAYS:
                        i.setDate(i.getDate() + r);
                        break;
                    case this.followupDelayFrequency.WEEKS:
                        i.setDate(i.getDate() + r * 7);
                        break;
                    case this.followupDelayFrequency.MONTHS:
                        i.setMonth(i.getMonth() + r);
                        break;
                    case this.followupDelayFrequency.YEARS:
                        i.setFullYear(i.getFullYear() + r);
                        break;
                    default:
                        i = this.neverShowAgain(i)
                }
            } else i = this.neverShowAgain(i);
            return i
        };
        this.isSetToShowAgain = function(n) {
            return n.settings.engagement.followUp
        };
        this.isDelayingByPositiveValue = function(n) {
            return n.settings.engagement.followUpDelay > 0
        };
        this.neverShowAgain = function(n) {
            return n.setFullYear(n.getFullYear() + 10), n
        };
        this.isListrakEmailClick = function() {
            return t.getQuerystringValue("trk_msg") !== "" && n.moduleList.indexOf(t.getQuerystringValue("trk_module").toUpperCase()) === -1
        };
        this.isSubscribed = function(n) {
            var i = t.getCookie("ltk-subscribed").split(",");
            return i.indexOf(n) !== -1
        }
    }

    function r(n) {
        function t(n, t) {
            for (var r, i = 0; i < t.length; i++)
                if (r = n.toLowerCase(), t[i].test(r)) return !0;
            return !1
        }

        function i(n, t) {
            for (var i = 0; i < t.length; i++)
                if (t[i].test(n)) return !0;
            return !1
        }
        this.browserInterface = n;
        this.searchTrafficTypes = {
            ALL: 0,
            PAID: 1,
            ORGANIC: 2
        };
        this.referrerTemplates = [{
            referrerDomains: [/www\.google\.com/],
            queryStrings: [/[?&]gclid=/, /[?&]utm_source=google(&|$)/]
        }];
        this.isReferrerValid = function(n) {
            if (!n.settings.referrerRule) return !0;
            switch (n.settings.referrerRule.type) {
                case this.searchTrafficTypes.ALL:
                    return n.settings.referrerRule.show;
                case this.searchTrafficTypes.PAID:
                    return n.settings.referrerRule.show ? this.referrerIsPaid() : !this.referrerIsPaid();
                case this.searchTrafficTypes.ORGANIC:
                    return n.settings.referrerRule.show ? this.referrerIsOrganic() : !this.referrerIsOrganic();
                default:
                    return !0
            }
        };
        this.referrerIsPaid = function() {
            return this.parseReferrerType() === this.searchTrafficTypes.PAID
        };
        this.referrerIsOrganic = function() {
            return this.parseReferrerType() === this.searchTrafficTypes.ORGANIC
        };
        this.parseReferrerType = function() {
            for (var u = this.browserInterface.getReferrerDomain(), f = this.browserInterface.getPageUrl(), r = null, n = 0; n < this.referrerTemplates.length; n++)
                if (t(u, this.referrerTemplates[n].referrerDomains) && (r = this.searchTrafficTypes.ORGANIC, i(f, this.referrerTemplates[n].queryStrings))) return this.searchTrafficTypes.PAID;
            return r
        }
    }

    function u(n, t) {
        this.session = n;
        this.referrerFilter = t;
        this.types = {
            ENTRY: 1,
            EXIT: 2,
            MANUAL: 3,
            BUTTON: 4,
            SCROLL: 5
        };
        this.popups = {};
        this.popups[this.types.ENTRY] = null;
        this.popups[this.types.EXIT] = null;
        this.popups[this.types.MANUAL] = [];
        this.popups[this.types.BUTTON] = null;
        this.popups[this.types.SCROLL] = null;
        this.designPreviewPopup = null;
        this.urlMatchTypes = {
            EQUALS: 0,
            CONTAINS: 1,
            NOT_CONTAINS: 2
        };
        this.hasEntry = function() {
            return this.getEntry() !== null
        };
        this.getEntry = function() {
            return this.popups[this.types.ENTRY]
        };
        this.hasExit = function() {
            return this.getExit() !== null
        };
        this.getExit = function() {
            return this.popups[this.types.EXIT]
        };
        this.getPopupWithName = function(n, t) {
            for (var r, i = 0; i < n.length; i++)
                if (r = n[i], r.popupName.toLowerCase() === t.toLowerCase()) return r;
            return null
        };
        this.hasManualWithName = function(n) {
            return this.getManualWithName(n) !== null
        };
        this.getManualWithName = function(n) {
            for (var i, t = 0; t < this.popups[this.types.MANUAL].length; t++)
                if (i = this.popups[this.types.MANUAL][t], i.popupName === n) return i;
            return null
        };
        this.hasButton = function() {
            return this.getButton() !== null
        };
        this.getButton = function() {
            return this.popups[this.types.BUTTON]
        };
        this.hasScroll = function() {
            return this.getScroll() !== null
        };
        this.getScroll = function() {
            return this.popups[this.types.SCROLL]
        };
        this.isButton = function(n) {
            return n.type === this.types.BUTTON
        };
        this.registerPopups = function(n) {
            var t, i;
            if (this.session.designPreviewPopupName !== "") this.designPreviewPopup = this.getPopupWithName(n, this.session.designPreviewPopupName);
            else if (!!n)
                for (t = 0; t < n.length; t++) i = n[t], this.isEligible(i) && this.setEligible(i)
        };
        this.isEligible = function(n) {
            return this.isManual(n) ? !0 : this.isInvalidForTestMode(n) ? !1 : this.isSuppressed(n) ? !1 : this.isUrlInvalid(n) ? !1 : this.isDeviceInvalid(n) ? !1 : this.isSessionDepthInadequate(n) ? !1 : this.referrerFilter.isReferrerValid(n) ? this.isListrakEmailClick(n) ? (this.session.suppress(n, !0), !1) : !this.session.isSubscribed(n.settings.subscriptionPoint) : !1
        };
        this.isManual = function(n) {
            return n.type === this.types.MANUAL
        };
        this.isInvalidForTestMode = function(n) {
            return this.session.testing && n.isActive || this.session.testing && !n.isActive && !n.settings.isTestMode || !this.session.testing && !n.isActive
        };
        this.isSuppressed = function(n) {
            return !this.isButton(n) && this.session.isSuppressed(n.popupUID)
        };
        this.isUrlInvalid = function(n) {
            var r, u, t, i;
            if (n.settings.urlRules.length === 0) return !1;
            for (r = !1, u = !1, t = 0; t < n.settings.urlRules.length; ++t)
                if (i = n.settings.urlRules[t], i.show && (r = !0), this.doesRuleMatch(i)) {
                    if (!i.show) return !0;
                    u = !0
                }
            return r && !u
        };
        this.doesRuleMatch = function(n) {
            var t = n.url.toLowerCase(),
                i = this.removeTestModeQueryParameter(this.session.url);
            return n.urlMatchRule === this.urlMatchTypes.EQUALS && t === i || n.urlMatchRule === this.urlMatchTypes.CONTAINS && i.indexOf(t) !== -1 || n.urlMatchRule === this.urlMatchTypes.NOT_CONTAINS && i.indexOf(t) === -1
        };
        this.removeTestModeQueryParameter = function(n) {
            return n.replace(/\?ltkpopuptestmode=1$/, "").replace(/ltkpopuptestmode=1&/, "").replace(/&ltkpopuptestmode=1$/, "")
        };
        this.isDeviceInvalid = function(n) {
            return n.settings.targetingRules.showWhenDevice.length > 0 && n.settings.targetingRules.showWhenDevice.indexOf(this.session.deviceType) === -1
        };
        this.isSessionDepthInadequate = function(n) {
            return n.settings.engagement.showWhenPageSession > this.session.depth
        };
        this.isListrakEmailClick = function(n) {
            return !n.settings.engagement.showIfFromListrakEmail && this.session.isListrakEmailClick()
        };
        this.setEligible = function(n) {
            this.isManual(n) ? this.popups[n.type].push(n) : this.wasPopupModifiedAfterExisting(n) && (this.popups[n.type] = n)
        };
        this.wasPopupModifiedAfterExisting = function(n) {
            var t = this.popups[n.type];
            return t === null || t.lastModified < n.lastModified
        }
    }

    function f(n, t, i) {
        var r = this;
        r.initialize = function() {
            window.setTimeout(t, i * 1e3)
        }
    }

    function e(n, t) {
        var i = this;
        i.isDepthMet = !1;
        i.isExitEligible = !1;
        i.lastY = null;
        i.initialize = function() {
            n.addEventListener(document, "mousemove", i.mouseMoveListener);
            n.addEventListener(document, "mouseout", i.mouseExitListener)
        };
        i.mouseMoveListener = function(t) {
            var r = n.getMouseEventY(t);
            i.setIsDepthMet(r);
            i.isDepthMet && i.setLastY(r)
        };
        i.setIsDepthMet = function(n) {
            !i.isDepthMet && n > i.eligibleBindHeight() && (i.isDepthMet = !0)
        };
        i.setLastY = function(n) {
            i.lastY ? (i.setIsExitEligible(n), i.lastY = n) : n >= 0 && (i.lastY = n)
        };
        i.setIsExitEligible = function(n) {
            i.isUpwardMovementInEligibleBindHeight(n) && (i.isExitEligible = !0)
        };
        i.isUpwardMovementInEligibleBindHeight = function(n) {
            return i.lastY < i.eligibleBindHeight() && n < i.lastY
        };
        i.eligibleBindHeight = function() {
            return n.getWindowVisibleHeight() * .1
        };
        i.mouseExitListener = function(r) {
            if (i.isExitEligible) {
                var u = n.getMouseEventY(r),
                    f = n.getMouseEventX(r),
                    e = n.getWindowVisibleWidth();
                u <= 5 && f < e && t()
            }
        }
    }

    function o(n, t, i) {
        var r = this;
        r.initialize = function() {
            var r = document.getElementById(i);
            r && n.addEventListener(r, "click", t)
        }
    }

    function s(n, t, i) {
        var r = this;
        r.isFullTrigger = i === 1;
        r.initialize = function() {
            r.pageHeightAtLeastTwiceWindowHeight() && n.windowBind("scroll", r.scrollListener)
        };
        r.scrollListener = function() {
            var n = r.getCurrentDepthPercentage();
            n >= 50 && !r.isFullTrigger ? t() : (n >= 99 || r.isExceedingPixelBuffer()) && r.isFullTrigger && t()
        };
        r.pageHeightAtLeastTwiceWindowHeight = function() {
            return n.getDocumentTotalHeight() / n.getWindowVisibleHeight() >= 2
        };
        r.getCurrentDepthPercentage = function() {
            return r.getScrollPositionPercentageAsDecimal() * 100
        };
        r.getScrollPositionPercentageAsDecimal = function() {
            var t = r.getMaxTopOfPageOffset();
            return n.getScrollVerticalPosition() / t
        };
        r.getMaxTopOfPageOffset = function() {
            return n.getDocumentTotalHeight() - n.getWindowVisibleHeight()
        };
        r.isExceedingPixelBuffer = function() {
            return r.getMaxTopOfPageOffset() - n.getScrollVerticalPosition() <= 500
        }
    }

    function h(n, t, i, r, u, f, e, o) {
        var s = this;
        s.styleBlock = null;
        s.formBlock = null;
        s.contentBlock = null;
        s.options = null;
        s.isConfirmation = !1;
        s.tapToJoinClassName = "ltkpopup-tap-to-join";
        s.open = function(t) {
            return s.isConfirmation = t, s.createStyleBlock(), s.createFormBlock(), s.createContentBlock(), s.configureOptions(), n(s.contentBlock, s.options) !== !1
        };
        s.createStyleBlock = function() {
            s.styleBlock = document.createElement("style");
            s.styleBlock.type = "text/css";
            f.setCssText(s.styleBlock, t.settings.formCSS)
        };
        s.createFormBlock = function() {
            s.formBlock = document.createElement("div");
            s.formBlock.id = "ltkpopup-form";
            s.formBlock.innerHTML = s.isConfirmation ? t.settings.confirmationHTML : t.settings.formHTML
        };
        s.createContentBlock = function() {
            s.contentBlock = document.createElement("div");
            s.contentBlock.id = "ltkpopup-formcontent";
            s.contentBlock.appendChild(s.styleBlock);
            s.contentBlock.appendChild(s.formBlock);
            t.settings.animation === null || s.isConfirmation || s.contentBlock.classList.add("signup", "ltk-animated", "ltk-" + t.settings.animation)
        };
        s.configureOptions = function() {
            s.options = {
                overlayCss: {
                    backgroundColor: "#000"
                },
                overlayId: "ltkpopup-overlay",
                containerId: "ltkpopup-container",
                dataId: "ltkpopup-data",
                overlayClose: t.settings.overlayClose,
                onShow: s.modalShowHandler,
                onClose: s.modalCloseHandler
            }
        };
        s.modalShowHandler = function() {
            s.isConfirmation || (i(t), s.addEventListener(s.formBlock.getElementsByTagName("input"), "keyup", s.inputKeyUpHandler), s.addEventListener(f.querySelectorAll(s.formBlock, ".ltkpopup-subscribe, .ltkmodal-subscribe"), "click", s.onSubscribing));
            s.registerTapToJoinEvent();
            s.addEventListener(f.querySelectorAll(s.formBlock, ".ltkpopup-close, .ltkmodal-close"), "click", s.close);
            s.addOverlayCloseEventListeners()
        };
        s.addEventListener = function(n, t, i) {
            for (var r = 0; r < n.length; ++r) f.addEventListener(n[r], t, i)
        };
        s.inputKeyUpHandler = function(n) {
            return f.getKeyCode(n) === 13 ? (s.onSubscribing(), !1) : !0
        };
        s.onSubscribing = function() {
            if (e.fieldsAreValid(s.contentBlock)) {
                var n = s.getFormFields();
                u(t, n)
            }
        };
        s.getFormFields = function() {
            for (var t = [], i = f.querySelectorAll(s.formBlock, "input, select"), n = 0; n < i.length; n++) s.processFormField(i[n], t);
            return t
        };
        s.processFormField = function(n, t) {
            if (n.name) switch (n.type) {
                case "radio":
                    t.push(s.formatRadioField(n));
                    break;
                case "checkbox":
                    t.push(s.formatCheckboxField(n));
                    break;
                default:
                    t.push(s.formatOtherField(n))
            }
        };
        s.formatRadioField = function(n) {
            return {
                name: n.name + "." + n.value,
                value: n.checked ? "on" : "off"
            }
        };
        s.formatCheckboxField = function(n) {
            return {
                name: n.name,
                value: n.checked ? "on" : "off"
            }
        };
        s.formatOtherField = function(n) {
            return {
                name: n.name,
                value: n.value
            }
        };
        s.addOverlayCloseEventListeners = function() {
            var n = f.querySelectorAll(s.contentBlock, "#ltkpopup-wrapper, #ltkmodal-wrapper");
            t.settings.overlayClose && n.length && (f.addEventListener(window, "click", s.close), f.addEventListener(n[0], "click", s.stopPropagation))
        };
        s.registerTapToJoinEvent = function() {
            if (o.deviceType === "Mobile") {
                var t = "." + s.tapToJoinClassName,
                    n = f.querySelectorAll(s.formBlock, t);
                s.addEventListener(n, "click", _ltk.TapToJoin);
                s.addEventListener(n, "click", s.close)
            }
        };
        s.stopPropagation = function(n) {
            f.stopPropagation(n)
        };
        s.modalCloseHandler = function() {
            r();
            s.close()
        };
        s.close = function() {
            f.removeEventListener(window, "click", s.close);
            n.close()
        }
    }

    function c(n) {
        var t = this;
        t.contentBlock = null;
        t.currentInputFieldElement = null;
        t.fieldsAreValid = function(i) {
            if (t.contentBlock = i, t.browserDoesNotSupportValidation()) return !0;
            var r = n.querySelectorAll(t.contentBlock, "input, select");
            return t.validateFields(r)
        };
        t.validateFields = function(n) {
            for (var r = !0, i = 0; i < n.length; i++) t.currentInputFieldElement = n[i], n[i].checkValidity() ? t.setInputFieldValid(n[i]) : (r = !1, t.setInputFieldInvalid(n[i]));
            return r
        };
        t.browserDoesNotSupportValidation = function() {
            return typeof document.createElement("input").checkValidity != "function"
        };
        t.setInputFieldValid = function() {
            t.removeInputNotValidClass(t.currentInputFieldElement);
            var n = t.findErrorDivElement(t.currentInputFieldElement);
            n && (n.innerHTML = "")
        };
        t.removeInputNotValidClass = function() {
            t.currentInputFieldElement.className = t.currentInputFieldElement.className.replace(/\bltkinputnotvalid\b/g, "")
        };
        t.setInputFieldInvalid = function() {
            t.addInputNotValidClass(t.currentInputFieldElement);
            var n = t.findErrorDivElement(t.currentInputFieldElement);
            n && t.insertErrorMessage(n, t.currentInputFieldElement.validationMessage)
        };
        t.addInputNotValidClass = function() {
            var n = t.currentInputFieldElement.className.split(" ");
            n.indexOf("ltkinputnotvalid") === -1 && (t.currentInputFieldElement.className += " ltkinputnotvalid")
        };
        t.findErrorDivElement = function() {
            var i = t.currentInputFieldElement.getAttribute("name");
            return n.querySelectorAll(t.contentBlock, "div[data-ltk-error-for='" + i + "'], div[data-ltkpopup-error-for='" + i + "']")[0]
        };
        t.insertErrorMessage = function(n, t) {
            n.innerHTML = n.getAttribute("data-ltkpopup-message") || n.getAttribute("data-ltk-message") || t
        }
    }

    function l(n) {
        var t = this;
        t.popup = n;
        t.containerId = "ltkPopupButtonTriggerContainer";
        t.buttonId = "ltkPopupTriggerButton";
        t.align = "right";
        t.fontSize = "16px";
        t.padding = "10px 16px";
        t.borderRadius = "6px";
        t.zIndexValueJustBlowModalOverlay = "99999";
        t.initialize = function() {
            var n = t.popup.settings.buttonSettings;
            n != null && (t.setStyles(n), t.createButton(n))
        };
        t.destroy = function() {
            var n = document.getElementById(t.containerId);
            n && n.parentNode && n.parentNode.removeChild(n)
        };
        t.setStyles = function(n) {
            n.alignment === 0 ? t.align = "left" : n.alignment === 1 && (t.align = "center");
            n.size === 0 ? (t.fontSize = "14px", t.padding = "5px 10px") : n.size === 2 && (t.fontSize = "18px", t.padding = "15px 24px");
            n.shape === 0 ? t.borderRadius = "0px" : n.shape === 2 && (t.borderRadius = "200px")
        };
        t.createButton = function(n) {
            var r = document.createElement("div"),
                i;
            r.id = t.containerId;
            r.style.position = "fixed";
            r.style.bottom = "0";
            r.style.left = "0";
            r.style.width = "100%";
            r.style.background = "transparent";
            r.style.textAlign = t.align;
            r.style.zIndex = t.zIndexValueJustBlowModalOverlay;
            r.style.pointerEvents = "none";
            i = document.createElement("button");
            i.id = t.buttonId;
            i.style.background = n.color;
            i.style.color = n.textColor;
            i.style.fontSize = t.fontSize;
            i.style.padding = t.padding;
            i.style.borderRadius = t.borderRadius;
            i.style.margin = "18px";
            i.style.border = "0";
            i.style.outline = "none";
            i.style.webkitAppearance = "button";
            i.style.pointerEvents = "auto";
            i.innerText = n.text;
            r.appendChild(i);
            document.body.appendChild(r)
        }
    }

    function a(n, t, i, r) {
        var u = this;
        this.popupUID = n;
        this.ltk = t;
        this.ltkUtil = i;
        this.MetricType = {
            IMPRESSION: "impression",
            SUBMIT: "submit",
            CANCEL: "cancel"
        };
        this.impressionUID = "0";
        this.postImpression = function() {
            this.submitMetric(this.MetricType.IMPRESSION)
        };
        this.postCancel = function() {
            this.submitMetric(this.MetricType.CANCEL)
        };
        this.postSubmit = function() {
            this.submitMetric(this.MetricType.SUBMIT)
        };
        this.submitMetric = function(n) {
            var t = "?t=" + n + "&ctid=" + u.ltkUtil.Context.CTID + "&globalSessionUID=" + u.ltk.Session.GlobalID + "&mid=" + this.popupUID;
            n === u.MetricType.IMPRESSION ? u.ltkUtil.getJSONWithCallback("https://" + r + "/ModalImpression.ashx" + t, function(n) {
                n && n.status === "success" && (u.impressionUID = n.iuid)
            }) : u.ltkUtil.fire("https://" + r + "/ModalAction.ashx" + t + "&iuid=" + u.impressionUID)
        }
    }

    function v(n) {
        this.postSubmission = function(t, i, r) {
            for (var u, f = 0; f < r.length; f++) u = r[f], u.name === "ltkpopup-email" || u.name === "email" ? (n.Subscriber.Email = u.value, n.Subscriber.ModalUID = t, n.SCA && n.SCA.sessionID && (n.SCA.SetCustomer(u.value, "", ""), n.SCA.Submit())) : n.Subscriber.Profile.Add(u.name, u.value);
            n.Subscriber.List = i;
            n.Subscriber.Submit()
        }
    }

    function y(n, t, i, r, u, f, e, o, s, h, c, l, a, v, y, p, w, b) {
        var k = this;
        k.browserInterface = null;
        k.session = null;
        k.registry = null;
        k.display = null;
        k.buttonDisplay = null;
        k.hasAnyPopupBeenShown = !1;
        k.metrics = null;
        k.submission = null;
        k.isSubscribed = !1;
        k.lastDisplayedConfiguration = null;
        k.referrerFilter = null;
        k.initialize = function() {
            k.browserInterface = new f;
            k.loadAnimationStyles();
            k.session = new e(n, t, k.browserInterface);
            k.session.initialize();
            k.referrerFilter = new o(k.browserInterface);
            k.registry = new s(k.session, k.referrerFilter);
            k.registry.registerPopups(u);
            k.submission = new b(n);
            k.registry.designPreviewPopup === null ? k.initializeEventTriggers() : k.showPopup(k.registry.designPreviewPopup, k.session.showConfirmationPage)
        };
        k.loadAnimationStyles = function() {
            var t = "https://" + r + "/css/animate.min.css",
                n;
            k.browserInterface.querySelectorAll(k.browserInterface.getDocumentHead(), 'link[href="' + t + '"]').length < 1 && (n = document.createElement("link"), n.href = t, n.rel = "stylesheet", k.browserInterface.getDocumentHead().appendChild(n))
        };
        k.initializeEventTriggers = function() {
            k.registry.hasEntry() && k.initializeEntryTrigger();
            k.registry.hasExit() && k.initializeExitTrigger();
            k.registry.hasButton() && k.initializeButtonTrigger();
            k.registry.hasScroll() && k.initializeScrollTrigger()
        };
        k.initializeEntryTrigger = function() {
            var n = k.registry.getEntry(),
                t = k.createTriggerHandler(n),
                i = new h(k.browserInterface, t, n.settings.initialDelay);
            i.initialize()
        };
        k.initializeExitTrigger = function() {
            var n = k.registry.getExit(),
                t = k.createTriggerHandler(n),
                i = new c(k.browserInterface, t);
            i.initialize()
        };
        k.initializeButtonTrigger = function() {
            var n = k.registry.getButton(),
                t, i;
            k.buttonDisplay = new y(n);
            k.buttonDisplay.initialize();
            t = k.createTriggerHandler(n);
            i = new l(k.browserInterface, t, k.buttonDisplay.buttonId);
            i.initialize()
        };
        k.initializeScrollTrigger = function() {
            var n = k.registry.getScroll(),
                t = k.createTriggerHandler(n),
                i = new a(k.browserInterface, t, n.settings.scrollDepth);
            i.initialize()
        };
        k.createTriggerHandler = function(n) {
            return function(t) {
                k.registry.isButton(n) ? (k.showPopup(n), k.browserInterface.stopPropagation(t)) : k.showTriggeredNonButtonPopup(n);
                k.hasAnyPopupBeenShown = !0
            }
        };
        k.showTriggeredNonButtonPopup = function(n) {
            k.hasAnyPopupBeenShown || k.showPopup(n)
        };
        k.showPopup = function(t, i) {
            k.session.suppress(t, !1);
            k.display = new v(n.Modal.simpleModal, t, k.openHandler, k.closeHandler, k.subscribeHandler, k.browserInterface, new p(k.browserInterface), k.session);
            k.display.open(i)
        };
        k.openHandler = function(r) {
            k.lastDisplayedConfiguration = r;
            k.metrics = new w(r.popupUID, n, t, i);
            k.metrics.postImpression()
        };
        k.closeHandler = function() {
            k.isSubscribed || k.metrics.postCancel()
        };
        k.subscribeHandler = function(n, t) {
            k.session.suppress(n, !0);
            k.metrics.postSubmit();
            k.submission.postSubmission(n.popupUID, n.settings.subscriptionPoint, t);
            k.isSubscribed = !0;
            k.completePostSubmissionProcess(n)
        };
        k.completePostSubmissionProcess = function(i) {
            if (i.settings.urlRedirect) {
                var r = i.settings.urlRedirect;
                r.substring(0, 7) !== "http://" && r.substring(0, 8) !== "https://" && r.substring(0, 2) !== "//" && (r = "http://" + r);
                r = k.appendParamToRedirect(r, "ltkSubKey", t.encode(n.Subscriber.Email));
                k.browserInterface.redirectTo(r)
            } else k.showConfirmationPage();
            k.destroyButtonIfSubscriptionPointsMatch(i.settings.subscriptionPoint)
        };
        k.appendParamToRedirect = function(n, t, i) {
            var r = n.split("?"),
                u;
            return r = r.filter(function(n) {
                return n !== ""
            }), n = r[0], u = [], r.length > 1 && (u = r[1].split("&").filter(function(n) {
                return n.split("=")[0].toLowerCase() !== t.toLowerCase() && n !== ""
            })), u.push(t + "=" + i), n + "?" + u.join("&")
        };
        k.destroyButtonIfSubscriptionPointsMatch = function(n) {
            k.registry.hasButton() && n === k.registry.getButton().settings.subscriptionPoint && k.buttonDisplay.destroy()
        };
        k.showConfirmationPage = function() {
            k.close();
            k.display.open(!0)
        };
        k.close = function() {
            n.Modal.simpleModal.close()
        };
        k.openManualByName = function(n) {
            k.registry.hasManualWithName(n) && (k.showPopup(k.registry.getManualWithName(n)), k.browserInterface.stopPropagation())
        }
    }
    var n;
    typeof exports != "undefined" && (exports.BrowserInterface = t);
    typeof exports != "undefined" && (exports.PopupSession = i);
    typeof exports != "undefined" && (exports.ReferrerFilter = r);
    typeof exports != "undefined" && (exports.PopupRegistry = u);
    typeof exports != "undefined" && (exports.EntryTrigger = f, exports.ExitTrigger = e, exports.ButtonTrigger = o, exports.ScrollTrigger = s);
    typeof exports != "undefined" && (exports.PopupDisplay = h, exports.FormValidator = c, exports.ButtonDisplay = l);
    typeof exports != "undefined" && (exports.PopupMetrics = a);
    typeof exports != "undefined" && (exports.PopupSubmission = v);
    typeof exports != "undefined" && (exports.PopupManager = y);
    n = new y(_ltk, _ltk_util, "m1.listrakbi.com", "cdn.listrakbi.com", [{
        type: 1,
        category: 0,
        popupUID: "4f822ef8-2eb8-46ca-ba6d-e8d6a15b758d",
        popupName: "Entry Popup - Nine West",
        clientUID: "4812bcb7-32f3-4732-92d1-a34659911750",
        companyID: 0,
        isActive: !1,
        lastModified: "2022-03-15T04:21:00.753Z",
        settings: {
            scrollDepth: 0,
            isTestMode: !0,
            formHTML: '\n\t\t\t\t\t\t\t<!-- Pop-up Form -->\n<!-- ltkpopup-no-scroll: centers the popup on display by preventing the page from scrolling -->\n<!-- ltkpopup-ios-fix: keeps fixed position popups like bottom banners in place in iOS -->\n<div id="ltkpopup-wrapper" class="ltkpopup-signup ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n\t<!-- Custom Fonts can be placed below if applicable -->\n\t\n\t<link rel="stylesheet" href="https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/fontawesomev5.min.css">\n\n\t<!-- Main Popup Content Area -->\n\t<!-- Add class ltkpopup-no-padd for split popups -->\n\t<div id="ltkpopup-content" class="ltkpopup-signup ltkpopup-no-padd">\n\n\t\t<!-- Pull in the popup container -->\n\t\t<div class="ltkpopup-clearfix ltkpopup-split-content ">\n\n\t<div class="ltkpopup-contain-img" id="ltkpopup-img-contained">\n\t\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/NW_EMAIL_POPUP_IMG_600x840-min.jpg" alt="" class="ltkpopup-img-fluid" aria-hidden="true">\n\t<\/div>\n\n\t<div class="ltkpopup-contain-form">\n\n\t\t<div class="ltkpopup-form-control">\n\n\t\t\t<div class="ltkpopup-content-wrap">\n\t\t\t\t<h1 id="ltkpopup-headline" class="ltkpopup-headline">RECEIVE 15% OFF <span class="ltkpopup-subheadline">WHEN YOU SUBSCRIBE TODAY!<\/span><\/h1>\n<p id="ltkpopup-content-para" class="ltkpopup-content-para">Get the latest on new arrivals, trends, sales, and exclusive&nbsp;offers.<\/p>\n\n\t\t\t\t<div class="ltkpopup-form-contain" id="ltkpopup-form">\n\n\t\t\t\t\t<div class="ltkpopup-form-contain">\n\n\t<div class="ltkpopup-form-control">\n\n\t\t<!-- Email Input Required Error Message|Moved out of column for display purposes -->\n\t\t<div class="ltkpopup-error-message" aria-live="assertive" data-ltkpopup-error-for="ltkpopup-email" data-ltkpopup-message="Please enter a valid email address"><\/div>\n\t\t\n\t\t<label class="ltkpopup-visuallyhidden" for="ltkpopup-email">Email Address<\/label>\n<input autofocus required type="email" id="ltkpopup-email" class="ltkpopup-email" tabindex="0" name="ltkpopup-email" placeholder="Email Address (required)" autocomplete="email" pattern="^([a-zA-Z0-9._+!-]+[@](?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,})$" onchange="_ltk.SCA.Update(\'email\', this.value)" />\n\n\t<\/div>\n\n\t<div class="ltkpopup-form-control">\n\t\t\n\t\t<!-- Phone Input Required Error Message | Moved out of column for display purposes -->\n\t\t<div class="ltkpopup-error-message" aria-live="assertive" data-ltkpopup-error-for="ltkpopup-phone" data-ltkpopup-message="Please enter a valid phone number"><\/div>\n\n\t\t<label class="ltkpopup-visuallyhidden" for="ltkpopup-phone">Mobile Phone<\/label>\n<input type="tel" id="ltkpopup-phone" class="ltkpopup-email" tabindex="0" name="ltkpopup-phone" placeholder="Mobile Number (optional)" autocomplete="tel" data-inputmask="\'mask\': \'(###) ###-####\'" pattern="^\\D?(\\d{3})\\D?\\D?(\\d{3})\\D?(\\d{4})$" />\n\t\t\n\t<\/div>\n\n\t<!-- Emmet Snippets if applicable -->\n\t<!-- zip error dropdown checkbox radio sms-capture -->\n\n\t<!-- Button Container -->\n\t<div class="ltkpopup-button-container ltkpopup-flex ltkpopup-clearfix">\n\t\t<!-- Submit Button -->\n\t\t<button id="ltkpopup-submit" class="ltkpopup-subscribe" tabindex="0" type="submit"><span>SIGN UP NOW<\/span><\/button>\n\n\t\t<!-- Text Close Button -->\n\t\t<div class="ltkpopup-no-thanks ltkpopup-visuallyhidden" id="ltkpopup-text-btn">\n\t\t\t<!-- Do Not Delete. Add class ltkpopup-visuallyhidden -->\n\t\t\t<button tabindex="0" class="ltkpopup-close">maybe later<\/button>\n\t\t<\/div>\n\t<\/div>\n\n<\/div>\n\n\t\t\t\t<\/div>\n\n\t\t\t\t<p class="ltkpopup-content-para ltkpopup-disclaimer">By providing your number above, you agree to receive recurring autodialed marketing text msgs to the mobile number used at opt-in from Nine West on 69629. Consent is not a condition of purchase. Msg frequency may vary. Msg & data rates may apply. Reply HELP for help and STOP to cancel.<br><br>See <a href="http://ninewest.com/policies/terms-of-service" target="_blank">Terms and Conditions<\/a> &amp; <a href="http://ninewest.com/policies/privacy-policy" target="_blank">Privacy&nbspPolicy<\/a>.<\/p>\n\n\t\t\t<\/div>\n\t\t<\/div>\n\n\t<\/div>\n\n<\/div>\n\t\t\n\n\t\t<!-- Emmet Snippets if applicable -->\n\t\t<!-- zip error dropdown checkbox radio sms-capture -->\n\n\t\t<!-- Do Not Delete. Connects the Popup to Segmentation within the Listrak platform. Input name needs to match segmentation -->\n\t\t<div class="ltkpopup-source">\n\t\t\t<input type="hidden" class="text" name="Source.Popup" value="On" tabindex="-1" />\n\t\t<\/div>\n\n\t\t<!-- Close \'X\' Button -->\n\t\t<!-- Add class ltkpopup-circle-close to create a circle close button -->\n<div id="ltkpopup-close-button" class="ltkpopup-circle-close">\n\t<a class="ltkpopup-close" tabindex="0" role="button" aria-label="close">\n\t\t<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">\n\t\t\t<line x1="1" y1="1" x2="28" y2="28" />\n\t\t\t<line x1="28" y1="1" x2="1" y2="28" />\n\t\t<\/svg>\n\t<\/a>\n<\/div>\n\n\t<\/div>\n\t<!-- End ltkpopup-content -->\n\n<\/div>\n<!-- End ltkpopup-wrapper -->\n\n<script>\n\tvar emailVal;\n\tjQuery(\'#ltkpopup-submit\').on(\'click\', function () {\n\t\temailVal = jQuery(\'#ltkpopup-email\').val();\n\t\tphoneVal = jQuery(\'#ltkpopup-phone\').val();\n\t\tvar e = jQuery(":input");\n\t\tjQuery(e).each(function (e) {\n\t\t\tcheckInputValidity(this);\n\t\t\tif (jQuery(this).is(":invalid")) {\n\t\t\t\tthis.setAttribute("aria-describedby", this.id + "-error-message");\n\t\t\t} else {\n\t\t\t\tthis.removeAttribute("aria-describedby")\n\t\t\t}\n\t\t});\n\t\tsetTimeout(function () {\n\t\t\tif (document.querySelector(".ltkinputnotvalid") != null) {\n\t\t\t\tdocument.querySelector(".ltkinputnotvalid").focus();\n\t\t\t}\n\t\t}, 0);\n\t});\n<\/script>\n\n<script>\n\t// Browsers\n\tvar b = document.documentElement;\n\tb.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n\tvar $html = jQuery("html"),\n\t\tua = $html.data("useragent"),\n\t\tpf = $html.data("platform");\n\n\tfunction is(e) {\n\t\treturn ua.indexOf(e) > -1\n\t}\n\tvar browser = {\n\t\tisIE: is("msie") || is("trident/7.0"),\n\t\tisIE7: is("msie 7.0"),\n\t\tisIE8: is("msie 8.0"),\n\t\tisIE9: is("msie 9.0"),\n\t\tisIE10: is("msie 10"),\n\t\tisIE11: is("rv:11") && is("trident/7.0"),\n\t\tisEdge: is("edge"),\n\t\tisChrome: is("chrome") && !is("edge"),\n\t\tisSafari: is("safari") && !is("chrome") && !is("edge"),\n\t\tisFirefox: is("firefox") && !is("edge"),\n\t\tisAndroidChrome: is("android") && is("chrome"),\n\t\tisAndroidDefault: is("android") && !is("chrome"),\n\t\tisWin7: is("windows nt 6.1"),\n\t\tisWin8: is("windows nt 6.2"),\n\t\tisWindows: pf.indexOf("win32") > -1,\n\t\tisWebkit: is("webkit") && !is("edge"),\n\t\tisIPad: is("ipad"),\n\t\tisIPadChrome: is("ipad") && is("crios"),\n\t\tisIPhone: is("iphone"),\n\t\tisIPhoneChrome: is("iphone") && is("crios"),\n\t\tisAndroid: is("android"),\n\t\tisIOS: is("iphone") || is("ipad")\n\t};\n\tfor (var title in browser) {\n\t\tvar helperClass = title.slice(2).toLowerCase();\n\t\tbrowser[title] && jQuery("#ltkpopup-content").addClass(helperClass)\n\t}\n\n\t// Close Function\n\tjQuery(\'.ltkpopup-close\').focus(function () {\n\t\tjQuery(\'.ltkpopup-close\').keypress(function (e) {\n\t\t\tvar key = e.which;\n\t\t\tif (key == 13) {\n\t\t\t\tjQuery(\'#ltkpopup-overlay, #ltkpopup-container\').remove()\n\t\t\t}\n\t\t})\n\t});\n\n\t// Check Input Validity\n\tfunction checkInputValidity(inputEl) {\n\t\tjQuery(inputEl).removeClass("ltkinputnotvalid");\n\t\tvar ltkErrorMessage = jQuery("[data-ltkpopup-error-for=\'" + inputEl.id + "\'");\n\t\tjQuery(ltkErrorMessage).text("");\n\t\tinputEl.checkValidity();\n\t\tif (jQuery(inputEl).is(\':invalid\')) {\n\t\t\tjQuery(inputEl).addClass("ltkinputnotvalid");\n\t\t\tvar ltkErrorMessageText = jQuery(ltkErrorMessage).attr("data-ltkpopup-message");\n\t\t\tjQuery(ltkErrorMessage).text(ltkErrorMessageText);\n\t\t\treturn false;\n\t\t}\n\t\treturn true;\n\t}\n\n\n\n\tchangeFocus = function () {\n\t\tif (document.getElementById("ltkpopup-email") == undefined && document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined) {\n\t\t\tdocument.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n\t\t}\n\t}\n\n\t// Tab Trapping\n\tjQuery(document).ready(function () {\n\t\tsetTimeout(function () {\n\t\t\tfunction triggerFocus(element) {\n\t\t\t\tvar eventType = "onfocusin" in element ? "focusin" : "focus",\n\t\t\t\t\tbubbles = "onfocusin" in element,\n\t\t\t\t\tevent;\n\n\t\t\t\tif ("createEvent" in document) {\n\t\t\t\t\tevent = document.createEvent("Event");\n\t\t\t\t\tevent.initEvent(eventType, bubbles, true);\n\t\t\t\t} else if ("Event" in window) {\n\t\t\t\t\tevent = new Event(eventType, {\n\t\t\t\t\t\tbubbles: bubbles,\n\t\t\t\t\t\tcancelable: true\n\t\t\t\t\t});\n\t\t\t\t}\n\n\t\t\t\telement.focus();\n\t\t\t\telement.dispatchEvent(event);\n\t\t\t}\n\t\t\tif (document.getElementById("ltkpopup-email") != undefined) {\n\t\t\t\ttriggerFocus(document.getElementById("ltkpopup-email"));\n\t\t\t} else {\n\t\t\t\tchangeFocus();\n\t\t\t}\n\t\t}, 0);\n\t});\n\n\tfunction trapTabKey(e) {\n\t\tvar t = document.activeElement,\n\t\t\ts = focusableElems.indexOf(t);\n\t\tif (9 === e.keyCode) {\n\t\t\te.preventDefault();\n\t\t\tmoveTab(s, e.shiftKey)\n\t\t}\n\t}\n\n\tfunction moveTab(index, shift) {\n\t\tvar nextTab = null;\n\t\tvar nextIndex = index;\n\t\tif (shift) {\n\t\t\tif (focusableElems[index] == firstTabStop) {\n\t\t\t\tnextTab = lastTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index - 1;\n\t\t\t\tnextTab = focusableElem[nextIndex];\n\t\t\t}\n\t\t} else {\n\t\t\tif (focusableElems[index] == lastTabStop) {\n\t\t\t\tnextTab = firstTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index + 1;\n\t\t\t\tnextTab = focusableElems[nextIndex];\n\t\t\t}\n\t\t}\n\n\t\tif (jQuery(nextTab).is(":visible")) {\n\t\t\tnextTab.focus();\n\t\t} else {\n\t\t\tmoveTab(nextIndex, shift);\n\t\t}\n\t}\n\twindow.onload = function () {\n\t\tvar e = document.getElementById("ltkpopup-img-contained");\n\t\te && (2 == window.getComputedStyle(e).getPropertyValue("order") && (e.className += " ltkpopup-img-right"))\n\t}, setTimeout(function () {\n\t\t//Do not delete - tab functionality will break\n\t\t_ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n\t\tchangeFocus();\n\t}, 50);\n\tvar focused = document.activeElement;\n\tjQuery(".ltkpopup-close").on("click", function () {\n\t\tfocused.focus()\n\t});\n\tvar focusBox = document.getElementById("ltkpopup-content"),\n\t\tfocusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n\t\tfocusableElem = focusBox.querySelectorAll(focusableElemStr),\n\t\tfocusableElems = Array.prototype.slice.call(focusableElem),\n\t\tfirstTabStop = focusableElems[0],\n\t\tlastTabStop = focusableElems[focusableElems.length - 1];\n\tfocusBox.addEventListener("keydown", trapTabKey);\n\n\t\n\t$("body").bind("DOMSubtreeModified", function() {\n    \tif($(\'#smile-ui-container\')){\n\t\t\t$(\'#smile-ui-container\').css(\'z-index\',\'999\');\n\t\t}\n\t});\n<\/script>\n<script>\n    jQuery(document).ready(function () {\n\n        if (jQuery("[data-inputmask]").length) {\n            \n                // Input masking for number validation - Get Jquery Input Mask from CDN and load it\n                jQuery.getScript(\n                    "https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.1/jquery.inputmask.bundle.js",\n                    function () {\n                        jQuery("[data-inputmask]").each(function() {\n                             // Mask phone number input after script is loaded\n                            jQuery(this).inputmask({greedy: false, showMaskOnHover: false, definitions: {\n                            \'#\': { validator: "[0-9]", cardinality: 1\n                            }\n                            }\n                            });\n                        });\n                    });\n        }\n    });\n<\/script>\n<script>\n\tvar datepickerField = document.querySelector("#ltkpopup-datepicker");\n\tif (datepickerField != null) {\n\t\tvar jQueryUIcss = document.createElement("link");\n\t\tjQueryUIcss.href = "https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css";\n\t\tjQueryUIcss.rel = "stylesheet";\n\t\tjQueryUIcss.addEventListener("load", function () {\n\t\t\tvar jQueryUI = document.createElement("script");\n\t\t\tjQueryUI.src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js";\n\t\t\tjQueryUI.addEventListener("load", function () {\n\t\t\t\tdatepickerField.setAttribute("readonly", "");\n\t\t\t\tjQuery(datepickerField).datepicker({\n\t\t\t\t\tchangeMonth: true,\n\t\t\t\t\tchangeYear: false,\n\t\t\t\t\tyearRange: \'-0:+0\',\n\t\t\t\t\t// use for different date format and hidden bday field\n\t\t\t\t\tdateFormat: "mm/dd",\n\t\t\t\t\taltField: "#ltkpopup-hidden-bday",\n\t\t\t\t\taltFormat: "mm/dd/1900"\n\t\t\t\t});\n\n\t\t\t\tjQuery(datepickerField).focus(function () {\n\t\t\t\t\tjQuery(\'#ui-datepicker-div\').appendTo(this.parentNode);\n\t\t\t\t});\n\t\t\t});\n\t\t\tdocument.getElementById("ltkpopup-content").appendChild(jQueryUI);\n\t\t});\n\t\tdocument.getElementById("ltkpopup-content").appendChild(jQueryUIcss);\n\t}\n<\/script>\n\t\t\t\t\t\t',
            formCSS: '#ltkpopup-wrapper .ltkpopup-clearfix::before,#ltkpopup-wrapper .ltkpopup-clearfix::after{content:"";display:table}#ltkpopup-wrapper .ltkpopup-clearfix::after{clear:both}#ltkpopup-wrapper .ltkpopup-clearfix{zoom:1}.ios-only{position:fixed}.ltkpopup-visuallyhidden{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);border:0}.ltkpopup-visuallyhidden.focusable:active,.ltkpopup-visuallyhidden.focusable:focus{position:static;width:auto;height:auto;margin:0;overflow:visible;clip:auto}.ltkpopup-img-fluid{width:100%;height:auto}.ltkpopup-full-width{width:100% !important;max-width:100% !important}.ltkpopup-content-wrap{max-width:450px;margin:0 auto}#ltkpopup-thanks{text-align:center}#ltkpopup-thanks input{display:inline-block}#smile-ui-container,#keyboard-nav-34,#keyboard-nav-37{z-index:99990 !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-wrapper .mobileHide{display:none}}#ltkpopup-content .ltk-grid{margin:0 auto;width:100%}#ltkpopup-content .ltk-row{padding-bottom:20px}#ltkpopup-content .ltk-row:last-of-type{padding-bottom:0px}#ltkpopup-content .ltk-col-1{width:100%}#ltkpopup-content .ltk-col-1-2{width:50%}#ltkpopup-content .ltk-col-2-3{width:66.66%}#ltkpopup-content .ltk-col-1-3{width:33.33%}#ltkpopup-content [class*=\'ltk-col-\']{float:left}#ltkpopup-content [class*=\'ltk-col-\']{padding-right:0}#ltkpopup-content [class*=\'ltk-col-\']:last-of-type{padding-right:0;padding-left:10px}#ltkpopup-content .ltk-col-1-3{padding-right:14px}#ltkpopup-content .ltk-col-1-3+.ltk-col-1-3{padding-right:6px;padding-left:6px}#ltkpopup-content .ltk-col-1-3:last-of-type{padding-right:0;padding-left:0}#ltkpopup-content .ltk-col-1,#ltkpopup-content .ltk-col-1:last-of-type{padding-right:0;padding-top:0;padding-left:0}#ltkpopup-overlay{z-index:100001 !important;position:fixed !important;top:0 !important;bottom:0 !important;width:100% !important;height:100% !important;background-color:#000 !important;opacity:.5 !important;-webkit-transition:all .25s ease-in;transition:all .25s ease-in}#ltkpopup-container{z-index:100010 !important;position:fixed !important;width:710px !important;height:auto !important;max-height:100%;top:50% !important;left:50% !important;margin-left:0 !important;-webkit-transform:translate(-50%, -50%) !important;-moz-transform:translate(-50%, -50%) !important;-ms-transform:translate(-50%, -50%) !important;transform:translate(-50%, -50%) !important;overflow-x:hidden;overflow-y:auto;-webkit-box-shadow:0 5px 15px rgba(0,0,0,0.5);-moz-box-shadow:0 5px 15px rgba(0,0,0,0.5);box-shadow:0 5px 15px rgba(0,0,0,0.5)}#ltkpopup-wrapper{position:relative;margin:0 auto;width:100% !important}#ltkpopup-container .simpleltkmodal-wrap{overflow:visible !important}#ltkpopup-wrapper *{box-sizing:border-box;backface-visibility:hidden !important}#ltkpopup-wrapper{background:transparent;font-size:12px;font-family:Arial,Helvetica,sans-serif;-webkit-font-smoothing:subpixel-antialiased}#ltkpopup-wrapper .no-wrap{white-space:nowrap}#ltkpopup-content{padding:3em;font-size:12px;text-align:left;color:#000;line-height:1.4;background:#fff}.ltkpopup-fullscreen{position:relative;max-width:710px;height:auto !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-container{width:100% !important;height:100% !important}#ltkpopup-wrapper{width:320px !important}#ltkpopup-content{float:none;width:100%;padding:40px 20px 30px 20px}}#ltkpopup-content .ltkpopup-split-content{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-webkit-box-align:center;-moz-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img{max-width:300px;-webkit-box-flex:0 0 300px;-moz-box-flex:0 0 300px;-webkit-flex:0 0 300px;-ms-flex:0 0 300px;flex:0 0 300px;line-height:0;order:2;-ms-flex-order:2}#ltkpopup-content .ltkpopup-split-content.ltkpopup-image-bottom .ltkpopup-contain-img-full{line-height:0}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form{max-width:410px;-webkit-box-flex:0 0 410px;-moz-box-flex:0 0 410px;-webkit-flex:0 0 410px;-ms-flex:0 0 410px;flex:0 0 410px;-ms-flex:0 0 410px;padding:10px 10px 10px;order:1;-ms-flex-order:1}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form .ltkpopup-no-thanks{float:none;text-align:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-full-width{padding-top:30px}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below{flex-wrap:wrap}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form{max-width:100%;-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full{-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%;order:2;line-height:0}#ltkpopup-content.ie6 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie7 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie8 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie9 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie10 .ltkpopup-split-content .ltkpopup-contain-img{width:300px;float:right}#ltkpopup-content.ie6 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie7 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie8 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie9 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie10 .ltkpopup-split-content .ltkpopup-contain-form{width:410px;float:left;padding-top:70px}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below{flex-wrap:wrap}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form{width:100%}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full{width:100%}#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-form{position:relative;left:-2px}#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-img.ltkpopup-img-right img,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-img.ltkpopup-img-right img,#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-form-right,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-form-right{position:relative;right:-2px;left:auto}#ltkpopup-content.safari,#ltkpopup-content.ipad{overflow-x:hidden;overflow-y:hidden}#ltkpopup-content.ie .ltkpopup-split-content,#ltkpopup-content.ie11 .ltkpopup-split-content{padding-bottom:2px}#ltkpopup-content.ie .ltkpopup-split-content .ltkpopup-img-fluid,#ltkpopup-content.ie11 .ltkpopup-split-content .ltkpopup-img-fluid{position:relative;bottom:-1px}#ltkpopup-content.ltkpopup-no-padd{padding:0 !important}#ltkpopup-content.ltkpopup-no-padd .ltkpopup-no-padd{padding:0 !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-formcontent,#ltkpopup-form,#ltkpopup-wrapper{width:100% !important;height:100% !important;background-color:#fff}#ltkpopup-content{width:100%}#ltkpopup-content .ltkpopup-split-content{width:100%;height:100%;-webkit-align-items:center;-moz-align-items:center;-ms-align-items:center;align-items:center;-webkit-justify-content:center;-moz-justify-content:center;-ms-justify-content:center;justify-content:center;-ms-flex-pack:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img-full,#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img{display:none}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form{width:100%;flex:0 0 100%;-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%;padding:40px 20px 10px}#ltkpopup-content.ltkpopup-confirm .ltkpopup-split-content .ltkpopup-contain-form{padding:40px 20px}}#ltkpopup-close-button{position:absolute;left:7px;top:7px;margin:0px;z-index:10}#ltkpopup-close-button a{display:block;width:12px;height:12px;cursor:pointer}#ltkpopup-close-button a svg{width:100%;height:100%;position:relative;display:block;overflow:visible;stroke:#333;stroke-width:6px;-webkit-transition:all .25s linear;transition:all .25s linear}#ltkpopup-close-button a:hover svg{stroke:#858585}#ltkpopup-close-button a:focus svg{stroke:#858585}#ltkpopup-close-button.ltkpopup-circle-close{right:7px;top:7px}#ltkpopup-close-button.ltkpopup-circle-close a{width:22px;height:22px;background:#fff;border-radius:50%;padding:4px;border:2px solid #333}#ltkpopup-close-button.ltkpopup-circle-close a:hover,#ltkpopup-close-button.ltkpopup-circle-close a:focus{border-color:#858585}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-close-button{right:7px;top:7px}#ltkpopup-close-button a{width:12px;height:12px}}#ltkpopup-content h1,#ltkpopup-content h2,#ltkpopup-content h3,#ltkpopup-content h4,#ltkpopup-content h5,#ltkpopup-content .ltkpopup-headline,#ltkpopup-content .ltkpopup-subheadline{margin:0;padding:0;text-align:center;font-family:Arial,Helvetica,sans-serif !important}#ltkpopup-content h1,#ltkpopup-content .ltkpopup-headline{font-weight:700;font-size:26px;line-height:30px;color:#000;letter-spacing:1px;margin-bottom:10px;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content h2,#ltkpopup-content .ltkpopup-subheadline{font-weight:400;font-size:14px;line-height:25px;color:#000;display:block;margin-top:10px;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content p,#ltkpopup-content .ltkpopup-content-para{margin:0 0 5px;font-size:12px;line-height:19px;font-family:Arial,Helvetica,sans-serif;text-align:center;letter-spacing:.5px}#ltkpopup-content p.ltkpopup-disclaimer,#ltkpopup-content p.ltkpopup-sms-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer{font-size:8px;line-height:16px;text-align:center;margin:30px 10px 0;letter-spacing:0}#ltkpopup-content p.ltkpopup-disclaimer a,#ltkpopup-content p.ltkpopup-sms-disclaimer a,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a{color:inherit;text-decoration:underline;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content p.ltkpopup-disclaimer a:hover,#ltkpopup-content p.ltkpopup-disclaimer a:focus,#ltkpopup-content p.ltkpopup-sms-disclaimer a:hover,#ltkpopup-content p.ltkpopup-sms-disclaimer a:focus,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:hover,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:focus,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:hover,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:focus{text-decoration:none}#ltkpopup-content p.ltkpopup-disclaimer span,#ltkpopup-content p.ltkpopup-sms-disclaimer span,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer span,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer span{font-weight:700}#ltkpopup-content.ltkpopup-confirm p,#ltkpopup-content.ltkpopup-confirm .ltkpopup-content-para{margin:10px auto}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content h1,#ltkpopup-content .ltkpopup-headline{font-size:26px;line-height:30px}#ltkpopup-content h2,#ltkpopup-content .ltkpopup-subheadline{font-size:14px;line-height:25px}#ltkpopup-content p,#ltkpopup-content .ltkpopup-content-para{font-size:12px;line-height:19px}#ltkpopup-content p.ltkpopup-disclaimer,#ltkpopup-content p.ltkpopup-sms-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer{font-size:8px;line-height:16px}}#ltkpopup-content input[type="text"],#ltkpopup-content input[type="email"],#ltkpopup-content input[type="number"],#ltkpopup-content input[type="tel"]{display:block;width:100%;height:32px;padding:0 1em;margin:0 auto;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:400;text-align:left;color:#000;line-height:normal;background-color:transparent;border:1px solid #000;border-radius:0px !important;box-shadow:inset 0 0 0 1000px #fff;-webkit-transition:all 0.11s linear;transition:all 0.11s linear;-webkit-appearance:none;-moz-appearance:none;appearance:none}#ltkpopup-content input[type="text"]:focus,#ltkpopup-content input[type="email"]:focus,#ltkpopup-content input[type="number"]:focus,#ltkpopup-content input[type="tel"]:focus{outline:none;border:2px solid #000}#ltkpopup-content input[type="text"]:last-of-type{margin:10px auto 0}#ltkpopup-content .ltkpopup-form-control{position:relative}#ltkpopup-content .ltkpopup-form-contain{max-width:320px;margin:0 auto}#ltkpopup-content input::-webkit-input-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input::-moz-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input:-ms-input-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input::-ms-clear{display:none;width:0;height:0;opacity:0}#ltkpopup-content .ltk-floating-input{width:250px;float:left}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content input[type="text"],#ltkpopup-content input[type="email"],#ltkpopup-content input[type="number"],#ltkpopup-content input[type="tel"]{float:none;width:100%;font-size:15px}#ltkpopup-content .ltk-floating-input{width:100%;padding-bottom:15px}}#ltkpopup-content input[type="radio"]{position:absolute;overflow:hidden;clip:rect(0 0 0 0);height:1px;width:1px;margin:-1px;padding:0;border:0}#ltkpopup-content .radio-wrapper{padding:10px 0;text-align:left}#ltkpopup-content .ltk-radio{position:relative;float:left;width:50%}#ltkpopup-content .ltk-radio label{position:relative;display:block;padding:0px 4px;cursor:pointer}#ltkpopup-content .ltk-radio label::before{position:absolute;display:block;float:left;padding:0 3px 0 0;font-family:FontAwesome;font-size:12px;color:#fff;content:"\\f111";border-radius:0px}#ltkpopup-content .ltk-radio label span{display:block;padding:0 0 0 22px}#ltkpopup-content .ltk-radio input:checked ~ label::before{color:#fff;content:"\\f192"}#ltkpopup-content .ltk-radio input:hover+label::before{color:#000}#ltkpopup-content .ltk-radio input:focus+label::before{color:#fff}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkmodal-wrapper .radio-wrapper{padding:5px 0}}#ltkpopup-content input[type="checkbox"]{position:absolute;overflow:hidden;clip:rect(0 0 0 0);height:1px;width:1px;margin:-1px;padding:0;border:0}#ltkpopup-content fieldset#ltkpopup-options{border:none;margin:5px auto 10px;padding:0;width:100%;max-width:150px}#ltkpopup-content .ltkpopup-legend,#ltkpopup-content .ltkpopup-legend-styling{font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:12px;line-height:19px;text-align:center;color:#000;white-space:normal;margin:0 auto}#ltkpopup-content .ltkpopup-legend .ltklegend-regular,#ltkpopup-content .ltkpopup-legend-styling .ltklegend-regular{font-weight:400;text-transform:none;font-size:8px;line-height:16px;color:#000;display:block}#ltkpopup-content .ltkpopup-column{width:50%;display:block;float:left}#ltkpopup-content .ltkpopup-checkbox{float:left;width:100%}#ltkpopup-content .ltkpopup-checkbox label{display:block;position:relative;padding:0px 0px 3px;cursor:pointer;font-size:14px;margin-top:9px;margin-bottom:0;font-weight:400}#ltkpopup-content .ltkpopup-checkbox label:before{position:absolute !important;display:block;float:left;text-align:center;content:"";width:14px;height:14px;border:1px solid #000}#ltkpopup-content .ltkpopup-checkbox label span{display:block;padding:0px 0 0 24px;line-height:17px}#ltkpopup-content .ltkpopup-checkbox input:checked+label::before{font-family:FontAwesome;content:"\\f00c";color:#000;font-size:14px;line-height:14px}#ltkpopup-content .ltkpopup-checkbox input:focus+label::before,#ltkpopup-content .ltkpopup-checkbox input:hover+label::before{border-color:#000}#ltkpopup-content .ltkpopup-checkbox input:checked:hover+label::before{opacity:.7}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content fieldset#ltkpopup-options{display:block;margin-top:15px}}#ltkpopup-content .dropdown{position:relative;width:100%;height:32px;margin:10px 0;padding:0;font-size:12px;font-weight:400;text-overflow:ellipsis;border-radius:0 !important;cursor:pointer}#ltkpopup-content .dropdown select{width:100%;height:100%;padding:0 10px;z-index:1;font-family:Arial,Helvetica,sans-serif;font-size:12px;font-weight:400;color:#000;text-indent:0 !important;background:#fff;border:1px solid #000;border-radius:0;cursor:pointer;-webkit-appearance:none !important;-moz-appearance:none !important;appearance:none !important}#ltkpopup-content .dropdown select:focus{border-color:#000;outline:none}#ltkpopup-content .dropdown::before{position:absolute;display:block;right:10px;top:50%;margin-top:-10px;z-index:2;font-family:FontAwesome;font-size:14px;content:"\\f0d7";color:#000;pointer-events:none;-webkit-transition:all .25s linear;transition:all .25s linear}#ltkpopup-content .dropdown select::-ms-expand{display:none !important}#ltkpopup-content input.ltkinputnotvalid,#ltkpopup-content div.dropdown.ltk-select-notvalid,#ltkpopup-content div.dropdown select.ltkinputnotvalid{border-color:red}#ltkpopup-content input.ltkinputnotvalid:focus,#ltkpopup-content div.dropdown.ltk-select-notvalid:focus,#ltkpopup-content div.dropdown select.ltkinputnotvalid:focus{border-color:red}#ltkpopup-content input.ltkinputnotvalid::-webkit-input-placeholder{color:red}#ltkpopup-content input.ltkinputnotvalid::-moz-placeholder{color:red}#ltkpopup-content input.ltkinputnotvalid:-ms-input-placeholder{color:red}#ltkpopup-content .ltkpopup-error-message{display:block;height:14px;text-align:center;line-height:14px;width:100%;font-size:10px;color:red;font-weight:700}#ltkpopup-content .ltkpopup-error-message:empty{visibility:hidden}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-error-message{line-height:14px;font-size:10px}}#ltkpopup-content .ltkpopup-button-container{position:relative;width:100%;overflow:hidden}#ltkpopup-content .ltkpopup-button-container.ltkpopup-flex{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;flex-wrap:wrap;-ms-flex-wrap:wrap;-webkit-box-align:center;-moz-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center;margin-top:15px;text-align:center}#ltkpopup-content .ltkpopup-subscribe,#ltkpopup-content .ltkpopup-close-button,#ltkpopup-content .ltkpopup-faux-subscribe{display:inline-block;position:relative;width:100%;max-width:320px;margin:auto;padding:7px;vertical-align:middle;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:400;color:#fff;height:32px;text-decoration:none;background-color:#000;border:1px solid #000;border-radius:0 !important;box-shadow:none !important;cursor:pointer;outline:none;-webkit-appearance:none !important;-moz-appearance:none !important;appearance:none !important;-webkit-transition:all .25s linear;transition:all .25s linear;transition:.25s;overflow:hidden}#ltkpopup-content .ltkpopup-subscribe span,#ltkpopup-content .ltkpopup-close-button span,#ltkpopup-content .ltkpopup-faux-subscribe span{position:relative;z-index:1}#ltkpopup-content .ltkpopup-subscribe:hover,#ltkpopup-content .ltkpopup-close-button:hover,#ltkpopup-content .ltkpopup-faux-subscribe:hover{color:#fff;background-color:#858585;border-color:#858585}#ltkpopup-content .ltkpopup-subscribe:focus,#ltkpopup-content .ltkpopup-close-button:focus,#ltkpopup-content .ltkpopup-faux-subscribe:focus{color:#fff;background-color:#858585;border-color:#858585;transition:0s}#ltkpopup-content .ltkpopup-close-button{float:none;margin:10px auto 0px;line-height:normal}#ltkpopup-content .ltkpopup-no-thanks{float:none;width:100%;text-align:center}#ltkpopup-content .ltkpopup-no-thanks a,#ltkpopup-content .ltkpopup-no-thanks button{background:none;border:none;display:inline-block;padding:10px;font-size:12px;font-weight:400;color:#000;text-decoration:underline;-webkit-transition:all .25s linear;transition:all .25s linear;cursor:pointer;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content .ltkpopup-no-thanks a:hover,#ltkpopup-content .ltkpopup-no-thanks a:focus,#ltkpopup-content .ltkpopup-no-thanks button:hover,#ltkpopup-content .ltkpopup-no-thanks button:focus{text-decoration:none}#ltkpopup-content .ltkpopup-float-fields{width:350px;margin:0 auto}#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button{width:100px;float:left}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-subscribe,#ltkpopup-content .ltkpopup-close-button,#ltkpopup-content .ltkpopup-faux-subscribe{font-size:16px;margin-top:5px}#ltkpopup-content .ltkpopup-no-thanks a,#ltkpopup-content .ltkpopup-no-thanks button{font-size:12px}#ltkpopup-content .ltkpopup-float-fields{width:100%}#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button{width:100%}}',
            confirmationHTML: '\n\t\t\t\t\t\t\t<!-- Pop-up Confirm / Appears after user submits Popup Form -->\n<div id="ltkpopup-wrapper" class="confirm ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n\t<!-- Custom Fonts can be placed below if applicable -->\n\t\n\t<link rel="stylesheet" href="https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/fontawesomev5.min.css">\n\n\t<!-- Main Popup Content Area -->\n\t<!-- Add class ltkpopup-no-padd for split popups -->\n\t<div id="ltkpopup-content" class="ltkpopup-confirm ltkpopup-no-padd">\n\n\t\t<!-- Pull in the popup container -->\n\t\t<div class="ltkpopup-clearfix ltkpopup-split-content ">\n\n\t<div class="ltkpopup-contain-img" id="ltkpopup-img-contained">\n\t\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/NW_EMAIL_POPUP_IMG_600x840-min.jpg" alt="" class="ltkpopup-img-fluid" aria-hidden="true">\n\t<\/div>\n\n\t<div class="ltkpopup-contain-form">\n\n\t\t<div class="ltkpopup-form-control">\n\n\t\t\t<div class="ltkpopup-content-wrap">\n\n\t\t\t\t<h1 id="ltkpopup-headline" class="ltkpopup-headline">THANK YOU<\/h1>\n<h2 id="ltkpopup-subheadline" class="ltkpopup-subheadline">You have been subscribed.<\/h2>\n<p id="ltkpopup-content-para" class="ltkpopup-content-para">To apply your 15% off coupon now, click below.<\/p>\n\n\t\t\t\t<div class="ltkpopup-button-container" id="ltkpopup-thanks">\n    <a tabindex="0" class="ltkpopup-close-button ltkpopup-close" href="https://ninewest.com/discount/WELCOME15">APPLY COUPON<\/a>\n<\/div>\n\n\t\t\t<\/div>\n\t\t<\/div>\n\t\t\n\t<\/div>\n\n<\/div>\n\t\t\n\n\t\t<!-- End Content Information -->\n\n\t\t<!-- Close \'X\' Button -->\n\t\t<!-- Add class ltkpopup-circle-close to create a circle close button -->\n<div id="ltkpopup-close-button" class="ltkpopup-circle-close">\n\t<a class="ltkpopup-close" tabindex="0" role="button" aria-label="close">\n\t\t<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">\n\t\t\t<line x1="1" y1="1" x2="28" y2="28" />\n\t\t\t<line x1="28" y1="1" x2="1" y2="28" />\n\t\t<\/svg>\n\t<\/a>\n<\/div>\n\t<\/div>\n<\/div>\n\n\n<script>\n\tvar reg = /^\\D?(\\d{3})\\D?\\D?(\\d{3})\\D?(\\d{4})$/;\n\tif (typeof phoneVal != "undefined" && phoneVal != "" && phoneVal.match(reg)) {\n\t\t_ltk.Subscriber.Email = phoneVal;\n\t\t_ltk.Subscriber.List = \'DesktopSMS\';\n\t\t_ltk.Subscriber.Profile.Add(\'Email\', emailVal);\n\t\t_ltk.Subscriber.Submit(true);\n\t}\n<\/script>\n<script>\n\t// Browsers\n\tvar b = document.documentElement;\n\tb.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n\tvar $html = jQuery("html"),\n\t\tua = $html.data("useragent"),\n\t\tpf = $html.data("platform");\n\n\tfunction is(e) {\n\t\treturn ua.indexOf(e) > -1\n\t}\n\tvar browser = {\n\t\tisIE: is("msie") || is("trident/7.0"),\n\t\tisIE7: is("msie 7.0"),\n\t\tisIE8: is("msie 8.0"),\n\t\tisIE9: is("msie 9.0"),\n\t\tisIE10: is("msie 10"),\n\t\tisIE11: is("rv:11") && is("trident/7.0"),\n\t\tisEdge: is("edge"),\n\t\tisChrome: is("chrome") && !is("edge"),\n\t\tisSafari: is("safari") && !is("chrome") && !is("edge"),\n\t\tisFirefox: is("firefox") && !is("edge"),\n\t\tisAndroidChrome: is("android") && is("chrome"),\n\t\tisAndroidDefault: is("android") && !is("chrome"),\n\t\tisWin7: is("windows nt 6.1"),\n\t\tisWin8: is("windows nt 6.2"),\n\t\tisWindows: pf.indexOf("win32") > -1,\n\t\tisWebkit: is("webkit") && !is("edge"),\n\t\tisIPad: is("ipad"),\n\t\tisIPadChrome: is("ipad") && is("crios"),\n\t\tisIPhone: is("iphone"),\n\t\tisIPhoneChrome: is("iphone") && is("crios"),\n\t\tisAndroid: is("android"),\n\t\tisIOS: is("iphone") || is("ipad")\n\t};\n\tfor (var title in browser) {\n\t\tvar helperClass = title.slice(2).toLowerCase();\n\t\tbrowser[title] && jQuery("#ltkpopup-content").addClass(helperClass)\n\t}\n\n\t// Close Function\n\tjQuery(\'.ltkpopup-close\').focus(function () {\n\t\tjQuery(\'.ltkpopup-close\').keypress(function (e) {\n\t\t\tvar key = e.which;\n\t\t\tif (key == 13) {\n\t\t\t\tjQuery(\'#ltkpopup-overlay, #ltkpopup-container\').remove()\n\t\t\t}\n\t\t})\n\t});\n\n\t// Check Input Validity\n\tfunction checkInputValidity(inputEl) {\n\t\tjQuery(inputEl).removeClass("ltkinputnotvalid");\n\t\tvar ltkErrorMessage = jQuery("[data-ltkpopup-error-for=\'" + inputEl.id + "\'");\n\t\tjQuery(ltkErrorMessage).text("");\n\t\tinputEl.checkValidity();\n\t\tif (jQuery(inputEl).is(\':invalid\')) {\n\t\t\tjQuery(inputEl).addClass("ltkinputnotvalid");\n\t\t\tvar ltkErrorMessageText = jQuery(ltkErrorMessage).attr("data-ltkpopup-message");\n\t\t\tjQuery(ltkErrorMessage).text(ltkErrorMessageText);\n\t\t\treturn false;\n\t\t}\n\t\treturn true;\n\t}\n\n\n\n\tchangeFocus = function () {\n\t\tif (document.getElementById("ltkpopup-email") == undefined && document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined) {\n\t\t\tdocument.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n\t\t}\n\t}\n\n\t// Tab Trapping\n\tjQuery(document).ready(function () {\n\t\tsetTimeout(function () {\n\t\t\tfunction triggerFocus(element) {\n\t\t\t\tvar eventType = "onfocusin" in element ? "focusin" : "focus",\n\t\t\t\t\tbubbles = "onfocusin" in element,\n\t\t\t\t\tevent;\n\n\t\t\t\tif ("createEvent" in document) {\n\t\t\t\t\tevent = document.createEvent("Event");\n\t\t\t\t\tevent.initEvent(eventType, bubbles, true);\n\t\t\t\t} else if ("Event" in window) {\n\t\t\t\t\tevent = new Event(eventType, {\n\t\t\t\t\t\tbubbles: bubbles,\n\t\t\t\t\t\tcancelable: true\n\t\t\t\t\t});\n\t\t\t\t}\n\n\t\t\t\telement.focus();\n\t\t\t\telement.dispatchEvent(event);\n\t\t\t}\n\t\t\tif (document.getElementById("ltkpopup-email") != undefined) {\n\t\t\t\ttriggerFocus(document.getElementById("ltkpopup-email"));\n\t\t\t} else {\n\t\t\t\tchangeFocus();\n\t\t\t}\n\t\t}, 0);\n\t});\n\n\tfunction trapTabKey(e) {\n\t\tvar t = document.activeElement,\n\t\t\ts = focusableElems.indexOf(t);\n\t\tif (9 === e.keyCode) {\n\t\t\te.preventDefault();\n\t\t\tmoveTab(s, e.shiftKey)\n\t\t}\n\t}\n\n\tfunction moveTab(index, shift) {\n\t\tvar nextTab = null;\n\t\tvar nextIndex = index;\n\t\tif (shift) {\n\t\t\tif (focusableElems[index] == firstTabStop) {\n\t\t\t\tnextTab = lastTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index - 1;\n\t\t\t\tnextTab = focusableElem[nextIndex];\n\t\t\t}\n\t\t} else {\n\t\t\tif (focusableElems[index] == lastTabStop) {\n\t\t\t\tnextTab = firstTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index + 1;\n\t\t\t\tnextTab = focusableElems[nextIndex];\n\t\t\t}\n\t\t}\n\n\t\tif (jQuery(nextTab).is(":visible")) {\n\t\t\tnextTab.focus();\n\t\t} else {\n\t\t\tmoveTab(nextIndex, shift);\n\t\t}\n\t}\n\twindow.onload = function () {\n\t\tvar e = document.getElementById("ltkpopup-img-contained");\n\t\te && (2 == window.getComputedStyle(e).getPropertyValue("order") && (e.className += " ltkpopup-img-right"))\n\t}, setTimeout(function () {\n\t\t//Do not delete - tab functionality will break\n\t\t_ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n\t\tchangeFocus();\n\t}, 50);\n\tvar focused = document.activeElement;\n\tjQuery(".ltkpopup-close").on("click", function () {\n\t\tfocused.focus()\n\t});\n\tvar focusBox = document.getElementById("ltkpopup-content"),\n\t\tfocusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n\t\tfocusableElem = focusBox.querySelectorAll(focusableElemStr),\n\t\tfocusableElems = Array.prototype.slice.call(focusableElem),\n\t\tfirstTabStop = focusableElems[0],\n\t\tlastTabStop = focusableElems[focusableElems.length - 1];\n\tfocusBox.addEventListener("keydown", trapTabKey);\n\n\t\n\t$("body").bind("DOMSubtreeModified", function() {\n    \tif($(\'#smile-ui-container\')){\n\t\t\t$(\'#smile-ui-container\').css(\'z-index\',\'999\');\n\t\t}\n\t});\n<\/script>\n\t\t\t\t\t\t',
            animation: null,
            urlRedirect: null,
            initialDelay: 2,
            buttonSettings: {
                size: 1,
                shape: 1,
                alignment: 2,
                text: "Subscribe",
                color: "#00BDE5",
                textColor: "#FFFFFF"
            },
            urlRules: [{
                urlMatchRule: 1,
                show: !1,
                url: "/account/"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "/cart"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "/checkouts/"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "/preference-center"
            }],
            targetingRules: {
                showWhenDevice: ["Desktop", "Mobile"]
            },
            subscriptionPoint: "Popup",
            engagement: {
                followUpTimeframe: 0,
                showWhenPageSession: 1,
                followUp: !0,
                followUpDelay: 30,
                showIfFromListrakEmail: !1
            },
            overlayClose: !0,
            referrerRule: null
        }
    }, {
        type: 2,
        category: 0,
        popupUID: "ce946375-a0a5-48e2-af7f-4045e242e22d",
        popupName: "Exit Popup - Nine West",
        clientUID: "4812bcb7-32f3-4732-92d1-a34659911750",
        companyID: 0,
        isActive: !1,
        lastModified: "2022-03-15T04:31:41.891Z",
        settings: {
            scrollDepth: 0,
            isTestMode: !0,
            formHTML: '\n\t\t\t\t\t\t\t<!-- Pop-up Form -->\n<!-- ltkpopup-no-scroll: centers the popup on display by preventing the page from scrolling -->\n<!-- ltkpopup-ios-fix: keeps fixed position popups like bottom banners in place in iOS -->\n<div id="ltkpopup-wrapper" class="ltkpopup-signup ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n\t<!-- Custom Fonts can be placed below if applicable -->\n\t\n\t<link rel="stylesheet" href="https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/fontawesomev5.min.css">\n\n\t<!-- Main Popup Content Area -->\n\t<!-- Add class ltkpopup-no-padd for split popups -->\n\t<div id="ltkpopup-content" class="ltkpopup-signup ltkpopup-no-padd">\n\n\t\t<!-- Pull in the popup container -->\n\t\t<div class="ltkpopup-clearfix ltkpopup-split-content ">\n\n\t<div class="ltkpopup-contain-img" id="ltkpopup-img-contained">\n\t\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/NW_Exit_EMAIL_POPUP_IMG_600x840-min.jpg" alt="" class="ltkpopup-img-fluid" aria-hidden="true">\n\t<\/div>\n\n\t<div class="ltkpopup-contain-form">\n\n\t\t<div class="ltkpopup-form-control">\n\n\t\t\t<div class="ltkpopup-content-wrap">\n\t\t\t\t<h2 class="ltkpopup-subheadline">DON\'T LEAVE EMPTY&nbsp;HANDED!<\/h2>\n<h1 id="ltkpopup-headline" class="ltkpopup-headline">ENTER YOUR EMAIL<br> AND RECEIVE AN<br> EXTRA 15%&nbsp;OFF<\/h1>\n\n\t\t\t\t<div class="ltkpopup-form-contain" id="ltkpopup-form">\n\n\t\t\t\t\t<div class="ltkpopup-form-contain">\n\n\t<div class="ltkpopup-form-control">\n\n\t\t<!-- Email Input Required Error Message|Moved out of column for display purposes -->\n\t\t<div class="ltkpopup-error-message" aria-live="assertive" data-ltkpopup-error-for="ltkpopup-email" data-ltkpopup-message="Please enter a valid email address"><\/div>\n\t\t\n\t\t<label class="ltkpopup-visuallyhidden" for="ltkpopup-email">Email Address<\/label>\n<input autofocus required type="email" id="ltkpopup-email" class="ltkpopup-email" tabindex="0" name="ltkpopup-email" placeholder="Email Address (required)" autocomplete="email" pattern="^([a-zA-Z0-9._+!-]+[@](?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,})$" onchange="_ltk.SCA.Update(\'email\', this.value)" />\n\n\t<\/div>\n\n\n\t<!-- Emmet Snippets if applicable -->\n\t<!-- zip error dropdown checkbox radio sms-capture -->\n\n\t<!-- Button Container -->\n\t<div class="ltkpopup-button-container ltkpopup-flex ltkpopup-clearfix">\n\t\t<!-- Submit Button -->\n\t\t<button id="ltkpopup-submit" class="ltkpopup-subscribe" tabindex="0" type="submit"><span>GET YOUR 15% OFF NOW<\/span><\/button>\n\n\t\t<!-- Text Close Button -->\n\t\t<div class="ltkpopup-no-thanks ltkpopup-visuallyhidden" id="ltkpopup-text-btn">\n\t\t\t<!-- Do Not Delete. Add class ltkpopup-visuallyhidden -->\n\t\t\t<button tabindex="0" class="ltkpopup-close">maybe later<\/button>\n\t\t<\/div>\n\t<\/div>\n\n<\/div>\n\n\t\t\t\t<\/div>\n\n\n\t\t\t<\/div>\n\t\t<\/div>\n\n\t<\/div>\n\n<\/div>\n\t\t\n\n\t\t<!-- Emmet Snippets if applicable -->\n\t\t<!-- zip error dropdown checkbox radio sms-capture -->\n\n\t\t<!-- Do Not Delete. Connects the Popup to Segmentation within the Listrak platform. Input name needs to match segmentation -->\n\t\t<div class="ltkpopup-source">\n\t\t\t<input type="hidden" class="text" name="Source.Popup" value="On" tabindex="-1" />\n\t\t<\/div>\n\n\t\t<!-- Close \'X\' Button -->\n\t\t<!-- Add class ltkpopup-circle-close to create a circle close button -->\n<div id="ltkpopup-close-button" class="ltkpopup-circle-close">\n\t<a class="ltkpopup-close" tabindex="0" role="button" aria-label="close">\n\t\t<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">\n\t\t\t<line x1="1" y1="1" x2="28" y2="28" />\n\t\t\t<line x1="28" y1="1" x2="1" y2="28" />\n\t\t<\/svg>\n\t<\/a>\n<\/div>\n\n\t<\/div>\n\t<!-- End ltkpopup-content -->\n\n<\/div>\n<!-- End ltkpopup-wrapper -->\n\n<script>\n\tvar emailVal;\n\tjQuery(\'#ltkpopup-submit\').on(\'click\', function () {\n\t\temailVal = jQuery(\'#ltkpopup-email\').val();\n\t\tvar e = jQuery(":input");\n\t\tjQuery(e).each(function (e) {\n\t\t\tcheckInputValidity(this);\n\t\t\tif (jQuery(this).is(":invalid")) {\n\t\t\t\tthis.setAttribute("aria-describedby", this.id + "-error-message");\n\t\t\t} else {\n\t\t\t\tthis.removeAttribute("aria-describedby")\n\t\t\t}\n\t\t});\n\t\tsetTimeout(function () {\n\t\t\tif (document.querySelector(".ltkinputnotvalid") != null) {\n\t\t\t\tdocument.querySelector(".ltkinputnotvalid").focus();\n\t\t\t}\n\t\t}, 0);\n\t});\n<\/script>\n\n<script>\n\t// Browsers\n\tvar b = document.documentElement;\n\tb.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n\tvar $html = jQuery("html"),\n\t\tua = $html.data("useragent"),\n\t\tpf = $html.data("platform");\n\n\tfunction is(e) {\n\t\treturn ua.indexOf(e) > -1\n\t}\n\tvar browser = {\n\t\tisIE: is("msie") || is("trident/7.0"),\n\t\tisIE7: is("msie 7.0"),\n\t\tisIE8: is("msie 8.0"),\n\t\tisIE9: is("msie 9.0"),\n\t\tisIE10: is("msie 10"),\n\t\tisIE11: is("rv:11") && is("trident/7.0"),\n\t\tisEdge: is("edge"),\n\t\tisChrome: is("chrome") && !is("edge"),\n\t\tisSafari: is("safari") && !is("chrome") && !is("edge"),\n\t\tisFirefox: is("firefox") && !is("edge"),\n\t\tisAndroidChrome: is("android") && is("chrome"),\n\t\tisAndroidDefault: is("android") && !is("chrome"),\n\t\tisWin7: is("windows nt 6.1"),\n\t\tisWin8: is("windows nt 6.2"),\n\t\tisWindows: pf.indexOf("win32") > -1,\n\t\tisWebkit: is("webkit") && !is("edge"),\n\t\tisIPad: is("ipad"),\n\t\tisIPadChrome: is("ipad") && is("crios"),\n\t\tisIPhone: is("iphone"),\n\t\tisIPhoneChrome: is("iphone") && is("crios"),\n\t\tisAndroid: is("android"),\n\t\tisIOS: is("iphone") || is("ipad")\n\t};\n\tfor (var title in browser) {\n\t\tvar helperClass = title.slice(2).toLowerCase();\n\t\tbrowser[title] && jQuery("#ltkpopup-content").addClass(helperClass)\n\t}\n\n\t// Close Function\n\tjQuery(\'.ltkpopup-close\').focus(function () {\n\t\tjQuery(\'.ltkpopup-close\').keypress(function (e) {\n\t\t\tvar key = e.which;\n\t\t\tif (key == 13) {\n\t\t\t\tjQuery(\'#ltkpopup-overlay, #ltkpopup-container\').remove()\n\t\t\t}\n\t\t})\n\t});\n\n\t// Check Input Validity\n\tfunction checkInputValidity(inputEl) {\n\t\tjQuery(inputEl).removeClass("ltkinputnotvalid");\n\t\tvar ltkErrorMessage = jQuery("[data-ltkpopup-error-for=\'" + inputEl.id + "\'");\n\t\tjQuery(ltkErrorMessage).text("");\n\t\tinputEl.checkValidity();\n\t\tif (jQuery(inputEl).is(\':invalid\')) {\n\t\t\tjQuery(inputEl).addClass("ltkinputnotvalid");\n\t\t\tvar ltkErrorMessageText = jQuery(ltkErrorMessage).attr("data-ltkpopup-message");\n\t\t\tjQuery(ltkErrorMessage).text(ltkErrorMessageText);\n\t\t\treturn false;\n\t\t}\n\t\treturn true;\n\t}\n\n\n\n\tchangeFocus = function () {\n\t\tif (document.getElementById("ltkpopup-email") == undefined && document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined) {\n\t\t\tdocument.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n\t\t}\n\t}\n\n\t// Tab Trapping\n\tjQuery(document).ready(function () {\n\t\tsetTimeout(function () {\n\t\t\tfunction triggerFocus(element) {\n\t\t\t\tvar eventType = "onfocusin" in element ? "focusin" : "focus",\n\t\t\t\t\tbubbles = "onfocusin" in element,\n\t\t\t\t\tevent;\n\n\t\t\t\tif ("createEvent" in document) {\n\t\t\t\t\tevent = document.createEvent("Event");\n\t\t\t\t\tevent.initEvent(eventType, bubbles, true);\n\t\t\t\t} else if ("Event" in window) {\n\t\t\t\t\tevent = new Event(eventType, {\n\t\t\t\t\t\tbubbles: bubbles,\n\t\t\t\t\t\tcancelable: true\n\t\t\t\t\t});\n\t\t\t\t}\n\n\t\t\t\telement.focus();\n\t\t\t\telement.dispatchEvent(event);\n\t\t\t}\n\t\t\tif (document.getElementById("ltkpopup-email") != undefined) {\n\t\t\t\ttriggerFocus(document.getElementById("ltkpopup-email"));\n\t\t\t} else {\n\t\t\t\tchangeFocus();\n\t\t\t}\n\t\t}, 0);\n\t});\n\n\tfunction trapTabKey(e) {\n\t\tvar t = document.activeElement,\n\t\t\ts = focusableElems.indexOf(t);\n\t\tif (9 === e.keyCode) {\n\t\t\te.preventDefault();\n\t\t\tmoveTab(s, e.shiftKey)\n\t\t}\n\t}\n\n\tfunction moveTab(index, shift) {\n\t\tvar nextTab = null;\n\t\tvar nextIndex = index;\n\t\tif (shift) {\n\t\t\tif (focusableElems[index] == firstTabStop) {\n\t\t\t\tnextTab = lastTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index - 1;\n\t\t\t\tnextTab = focusableElem[nextIndex];\n\t\t\t}\n\t\t} else {\n\t\t\tif (focusableElems[index] == lastTabStop) {\n\t\t\t\tnextTab = firstTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index + 1;\n\t\t\t\tnextTab = focusableElems[nextIndex];\n\t\t\t}\n\t\t}\n\n\t\tif (jQuery(nextTab).is(":visible")) {\n\t\t\tnextTab.focus();\n\t\t} else {\n\t\t\tmoveTab(nextIndex, shift);\n\t\t}\n\t}\n\twindow.onload = function () {\n\t\tvar e = document.getElementById("ltkpopup-img-contained");\n\t\te && (2 == window.getComputedStyle(e).getPropertyValue("order") && (e.className += " ltkpopup-img-right"))\n\t}, setTimeout(function () {\n\t\t//Do not delete - tab functionality will break\n\t\t_ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n\t\tchangeFocus();\n\t}, 50);\n\tvar focused = document.activeElement;\n\tjQuery(".ltkpopup-close").on("click", function () {\n\t\tfocused.focus()\n\t});\n\tvar focusBox = document.getElementById("ltkpopup-content"),\n\t\tfocusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n\t\tfocusableElem = focusBox.querySelectorAll(focusableElemStr),\n\t\tfocusableElems = Array.prototype.slice.call(focusableElem),\n\t\tfirstTabStop = focusableElems[0],\n\t\tlastTabStop = focusableElems[focusableElems.length - 1];\n\tfocusBox.addEventListener("keydown", trapTabKey);\n\n\t\n\t$("body").bind("DOMSubtreeModified", function() {\n    \tif($(\'#smile-ui-container\')){\n\t\t\t$(\'#smile-ui-container\').css(\'z-index\',\'999\');\n\t\t}\n\t});\n<\/script>\n<script>\n    jQuery(document).ready(function () {\n\n        if (jQuery("[data-inputmask]").length) {\n            \n                // Input masking for number validation - Get Jquery Input Mask from CDN and load it\n                jQuery.getScript(\n                    "https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.1/jquery.inputmask.bundle.js",\n                    function () {\n                        jQuery("[data-inputmask]").each(function() {\n                             // Mask phone number input after script is loaded\n                            jQuery(this).inputmask({greedy: false, showMaskOnHover: false, definitions: {\n                            \'#\': { validator: "[0-9]", cardinality: 1\n                            }\n                            }\n                            });\n                        });\n                    });\n        }\n    });\n<\/script>\n<script>\n\tvar datepickerField = document.querySelector("#ltkpopup-datepicker");\n\tif (datepickerField != null) {\n\t\tvar jQueryUIcss = document.createElement("link");\n\t\tjQueryUIcss.href = "https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css";\n\t\tjQueryUIcss.rel = "stylesheet";\n\t\tjQueryUIcss.addEventListener("load", function () {\n\t\t\tvar jQueryUI = document.createElement("script");\n\t\t\tjQueryUI.src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js";\n\t\t\tjQueryUI.addEventListener("load", function () {\n\t\t\t\tdatepickerField.setAttribute("readonly", "");\n\t\t\t\tjQuery(datepickerField).datepicker({\n\t\t\t\t\tchangeMonth: true,\n\t\t\t\t\tchangeYear: false,\n\t\t\t\t\tyearRange: \'-0:+0\',\n\t\t\t\t\t// use for different date format and hidden bday field\n\t\t\t\t\tdateFormat: "mm/dd",\n\t\t\t\t\taltField: "#ltkpopup-hidden-bday",\n\t\t\t\t\taltFormat: "mm/dd/1900"\n\t\t\t\t});\n\n\t\t\t\tjQuery(datepickerField).focus(function () {\n\t\t\t\t\tjQuery(\'#ui-datepicker-div\').appendTo(this.parentNode);\n\t\t\t\t});\n\t\t\t});\n\t\t\tdocument.getElementById("ltkpopup-content").appendChild(jQueryUI);\n\t\t});\n\t\tdocument.getElementById("ltkpopup-content").appendChild(jQueryUIcss);\n\t}\n<\/script>\n\t\t\t\t\t\t',
            formCSS: '#ltkpopup-wrapper .ltkpopup-clearfix::before,#ltkpopup-wrapper .ltkpopup-clearfix::after{content:"";display:table}#ltkpopup-wrapper .ltkpopup-clearfix::after{clear:both}#ltkpopup-wrapper .ltkpopup-clearfix{zoom:1}.ios-only{position:fixed}.ltkpopup-visuallyhidden{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);border:0}.ltkpopup-visuallyhidden.focusable:active,.ltkpopup-visuallyhidden.focusable:focus{position:static;width:auto;height:auto;margin:0;overflow:visible;clip:auto}.ltkpopup-img-fluid{width:100%;height:auto}.ltkpopup-full-width{width:100% !important;max-width:100% !important}.ltkpopup-content-wrap{max-width:450px;margin:0 auto}#ltkpopup-thanks{text-align:center}#ltkpopup-thanks input{display:inline-block}#smile-ui-container,#keyboard-nav-34,#keyboard-nav-37{z-index:99990 !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-wrapper .mobileHide{display:none}}#ltkpopup-content .ltk-grid{margin:0 auto;width:100%}#ltkpopup-content .ltk-row{padding-bottom:20px}#ltkpopup-content .ltk-row:last-of-type{padding-bottom:0px}#ltkpopup-content .ltk-col-1{width:100%}#ltkpopup-content .ltk-col-1-2{width:50%}#ltkpopup-content .ltk-col-2-3{width:66.66%}#ltkpopup-content .ltk-col-1-3{width:33.33%}#ltkpopup-content [class*=\'ltk-col-\']{float:left}#ltkpopup-content [class*=\'ltk-col-\']{padding-right:0}#ltkpopup-content [class*=\'ltk-col-\']:last-of-type{padding-right:0;padding-left:10px}#ltkpopup-content .ltk-col-1-3{padding-right:14px}#ltkpopup-content .ltk-col-1-3+.ltk-col-1-3{padding-right:6px;padding-left:6px}#ltkpopup-content .ltk-col-1-3:last-of-type{padding-right:0;padding-left:0}#ltkpopup-content .ltk-col-1,#ltkpopup-content .ltk-col-1:last-of-type{padding-right:0;padding-top:0;padding-left:0}#ltkpopup-overlay{z-index:100001 !important;position:fixed !important;top:0 !important;bottom:0 !important;width:100% !important;height:100% !important;background-color:#000 !important;opacity:.5 !important;-webkit-transition:all .25s ease-in;transition:all .25s ease-in}#ltkpopup-container{z-index:100010 !important;position:fixed !important;width:710px !important;height:auto !important;max-height:100%;top:50% !important;left:50% !important;margin-left:0 !important;-webkit-transform:translate(-50%, -50%) !important;-moz-transform:translate(-50%, -50%) !important;-ms-transform:translate(-50%, -50%) !important;transform:translate(-50%, -50%) !important;overflow-x:hidden;overflow-y:auto;-webkit-box-shadow:0 5px 15px rgba(0,0,0,0.5);-moz-box-shadow:0 5px 15px rgba(0,0,0,0.5);box-shadow:0 5px 15px rgba(0,0,0,0.5)}#ltkpopup-wrapper{position:relative;margin:0 auto;width:100% !important}#ltkpopup-container .simpleltkmodal-wrap{overflow:visible !important}#ltkpopup-wrapper *{box-sizing:border-box;backface-visibility:hidden !important}#ltkpopup-wrapper{background:transparent;font-size:12px;font-family:Arial,Helvetica,sans-serif;-webkit-font-smoothing:subpixel-antialiased}#ltkpopup-wrapper .no-wrap{white-space:nowrap}#ltkpopup-content{padding:3em;font-size:12px;text-align:left;color:#000;line-height:1.4;background:#fff}.ltkpopup-fullscreen{position:relative;max-width:710px;height:auto !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-container{width:320px !important}#ltkpopup-wrapper{width:320px !important}#ltkpopup-content{float:none;width:100%;padding:40px 20px 30px 20px}}#ltkpopup-content .ltkpopup-split-content{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-webkit-box-align:center;-moz-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img{max-width:300px;-webkit-box-flex:0 0 300px;-moz-box-flex:0 0 300px;-webkit-flex:0 0 300px;-ms-flex:0 0 300px;flex:0 0 300px;line-height:0;order:2;-ms-flex-order:2}#ltkpopup-content .ltkpopup-split-content.ltkpopup-image-bottom .ltkpopup-contain-img-full{line-height:0}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form{max-width:410px;-webkit-box-flex:0 0 410px;-moz-box-flex:0 0 410px;-webkit-flex:0 0 410px;-ms-flex:0 0 410px;flex:0 0 410px;-ms-flex:0 0 410px;padding:10px 10px 30px;order:1;-ms-flex-order:1}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form .ltkpopup-no-thanks{float:none;text-align:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-full-width{padding-top:30px}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below{flex-wrap:wrap}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form{max-width:100%;-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full{-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%;order:2;line-height:0}#ltkpopup-content.ie6 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie7 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie8 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie9 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie10 .ltkpopup-split-content .ltkpopup-contain-img{width:300px;float:right}#ltkpopup-content.ie6 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie7 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie8 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie9 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie10 .ltkpopup-split-content .ltkpopup-contain-form{width:410px;float:left;padding-top:70px}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below{flex-wrap:wrap}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form{width:100%}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full{width:100%}#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-form{position:relative;left:-2px}#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-img.ltkpopup-img-right img,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-img.ltkpopup-img-right img,#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-form-right,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-form-right{position:relative;right:-2px;left:auto}#ltkpopup-content.safari,#ltkpopup-content.ipad{overflow-x:hidden;overflow-y:hidden}#ltkpopup-content.ie .ltkpopup-split-content,#ltkpopup-content.ie11 .ltkpopup-split-content{padding-bottom:2px}#ltkpopup-content.ie .ltkpopup-split-content .ltkpopup-img-fluid,#ltkpopup-content.ie11 .ltkpopup-split-content .ltkpopup-img-fluid{position:relative;bottom:-1px}#ltkpopup-content.ltkpopup-no-padd{padding:0 !important}#ltkpopup-content.ltkpopup-no-padd .ltkpopup-no-padd{padding:0 !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img-full,#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img{display:none}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form{max-width:100%;flex:0 0 100%;-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%;padding:40px 20px}}#ltkpopup-close-button{position:absolute;left:7px;top:7px;margin:0px;z-index:10}#ltkpopup-close-button a{display:block;width:12px;height:12px;cursor:pointer}#ltkpopup-close-button a svg{width:100%;height:100%;position:relative;display:block;overflow:visible;stroke:#333;stroke-width:6px;-webkit-transition:all .25s linear;transition:all .25s linear}#ltkpopup-close-button a:hover svg{stroke:#858585}#ltkpopup-close-button a:focus svg{stroke:#858585}#ltkpopup-close-button.ltkpopup-circle-close{right:7px;top:7px}#ltkpopup-close-button.ltkpopup-circle-close a{width:22px;height:22px;background:#fff;border-radius:50%;padding:4px;border:2px solid #333}#ltkpopup-close-button.ltkpopup-circle-close a:hover,#ltkpopup-close-button.ltkpopup-circle-close a:focus{border-color:#858585}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-close-button{right:7px;top:7px}#ltkpopup-close-button a{width:12px;height:12px}}#ltkpopup-content h1,#ltkpopup-content h2,#ltkpopup-content h3,#ltkpopup-content h4,#ltkpopup-content h5,#ltkpopup-content .ltkpopup-headline,#ltkpopup-content .ltkpopup-subheadline{margin:0;padding:0;text-align:center;font-family:Arial,Helvetica,sans-serif !important}#ltkpopup-content h1,#ltkpopup-content .ltkpopup-headline{font-weight:700;font-size:22px;line-height:30px;color:#000;letter-spacing:1px;margin-bottom:10px}#ltkpopup-content h2,#ltkpopup-content .ltkpopup-subheadline{font-weight:400;font-size:18px;line-height:25px;color:#000;display:block;margin-bottom:20px}#ltkpopup-content p,#ltkpopup-content .ltkpopup-content-para{margin:0 0 5px;font-size:12px;line-height:19px;font-family:Arial,Helvetica,sans-serif;text-align:center;letter-spacing:.5px}#ltkpopup-content p.ltkpopup-disclaimer,#ltkpopup-content p.ltkpopup-sms-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer{font-size:8px;line-height:26px;text-align:center;margin:10px 10px 0;letter-spacing:0}#ltkpopup-content p.ltkpopup-disclaimer a,#ltkpopup-content p.ltkpopup-sms-disclaimer a,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a{color:inherit;text-decoration:underline;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content p.ltkpopup-disclaimer a:hover,#ltkpopup-content p.ltkpopup-disclaimer a:focus,#ltkpopup-content p.ltkpopup-sms-disclaimer a:hover,#ltkpopup-content p.ltkpopup-sms-disclaimer a:focus,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:hover,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:focus,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:hover,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:focus{text-decoration:none}#ltkpopup-content p.ltkpopup-disclaimer span,#ltkpopup-content p.ltkpopup-sms-disclaimer span,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer span,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer span{font-weight:700}#ltkpopup-content.ltkpopup-confirm p,#ltkpopup-content.ltkpopup-confirm .ltkpopup-content-para{margin:10px auto}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content h1,#ltkpopup-content .ltkpopup-headline{font-size:22px;line-height:30px}#ltkpopup-content h2,#ltkpopup-content .ltkpopup-subheadline{font-size:18px;line-height:25px}#ltkpopup-content p,#ltkpopup-content .ltkpopup-content-para{font-size:12px;line-height:19px}#ltkpopup-content p.ltkpopup-disclaimer,#ltkpopup-content p.ltkpopup-sms-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer{font-size:8px;line-height:16px}}#ltkpopup-content input[type="text"],#ltkpopup-content input[type="email"],#ltkpopup-content input[type="number"],#ltkpopup-content input[type="tel"]{display:block;width:100%;height:32px;padding:0 1em;margin:0 auto;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:400;text-align:left;color:#000;line-height:normal;background-color:transparent;border:1px solid #000;border-radius:0px !important;box-shadow:inset 0 0 0 1000px #fff;-webkit-transition:all 0.11s linear;transition:all 0.11s linear;-webkit-appearance:none;-moz-appearance:none;appearance:none}#ltkpopup-content input[type="text"]:focus,#ltkpopup-content input[type="email"]:focus,#ltkpopup-content input[type="number"]:focus,#ltkpopup-content input[type="tel"]:focus{outline:none;border:2px solid #000}#ltkpopup-content input[type="text"]:last-of-type{margin:10px auto 0}#ltkpopup-content .ltkpopup-form-control{position:relative}#ltkpopup-content .ltkpopup-form-contain{max-width:320px;margin:0 auto}#ltkpopup-content input::-webkit-input-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input::-moz-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input:-ms-input-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input::-ms-clear{display:none;width:0;height:0;opacity:0}#ltkpopup-content .ltk-floating-input{width:250px;float:left}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content input[type="text"],#ltkpopup-content input[type="email"],#ltkpopup-content input[type="number"],#ltkpopup-content input[type="tel"]{float:none;width:100%;font-size:15px}#ltkpopup-content .ltk-floating-input{width:100%;padding-bottom:15px}}#ltkpopup-content input[type="radio"]{position:absolute;overflow:hidden;clip:rect(0 0 0 0);height:1px;width:1px;margin:-1px;padding:0;border:0}#ltkpopup-content .radio-wrapper{padding:10px 0;text-align:left}#ltkpopup-content .ltk-radio{position:relative;float:left;width:50%}#ltkpopup-content .ltk-radio label{position:relative;display:block;padding:0px 4px;cursor:pointer}#ltkpopup-content .ltk-radio label::before{position:absolute;display:block;float:left;padding:0 3px 0 0;font-family:FontAwesome;font-size:12px;color:#fff;content:"\\f111";border-radius:0px}#ltkpopup-content .ltk-radio label span{display:block;padding:0 0 0 22px}#ltkpopup-content .ltk-radio input:checked ~ label::before{color:#fff;content:"\\f192"}#ltkpopup-content .ltk-radio input:hover+label::before{color:#000}#ltkpopup-content .ltk-radio input:focus+label::before{color:#fff}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkmodal-wrapper .radio-wrapper{padding:5px 0}}#ltkpopup-content input[type="checkbox"]{position:absolute;overflow:hidden;clip:rect(0 0 0 0);height:1px;width:1px;margin:-1px;padding:0;border:0}#ltkpopup-content fieldset#ltkpopup-options{border:none;margin:5px auto 10px;padding:0;width:100%;max-width:150px}#ltkpopup-content .ltkpopup-legend,#ltkpopup-content .ltkpopup-legend-styling{font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:12px;line-height:19px;text-align:center;color:#000;white-space:normal;margin:0 auto}#ltkpopup-content .ltkpopup-legend .ltklegend-regular,#ltkpopup-content .ltkpopup-legend-styling .ltklegend-regular{font-weight:400;text-transform:none;font-size:8px;line-height:26px;color:#000;display:block}#ltkpopup-content .ltkpopup-column{width:50%;display:block;float:left}#ltkpopup-content .ltkpopup-checkbox{float:left;width:100%}#ltkpopup-content .ltkpopup-checkbox label{display:block;position:relative;padding:0px 0px 3px;cursor:pointer;font-size:14px;margin-top:9px;margin-bottom:0;font-weight:400}#ltkpopup-content .ltkpopup-checkbox label:before{position:absolute !important;display:block;float:left;text-align:center;content:"";width:14px;height:14px;border:1px solid #000}#ltkpopup-content .ltkpopup-checkbox label span{display:block;padding:0px 0 0 24px;line-height:17px}#ltkpopup-content .ltkpopup-checkbox input:checked+label::before{font-family:FontAwesome;content:"\\f00c";color:#000;font-size:14px;line-height:14px}#ltkpopup-content .ltkpopup-checkbox input:focus+label::before,#ltkpopup-content .ltkpopup-checkbox input:hover+label::before{border-color:#000}#ltkpopup-content .ltkpopup-checkbox input:checked:hover+label::before{opacity:.7}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content fieldset#ltkpopup-options{display:block;margin-top:15px}}#ltkpopup-content .dropdown{position:relative;width:100%;height:32px;margin:10px 0;padding:0;font-size:12px;font-weight:400;text-overflow:ellipsis;border-radius:0 !important;cursor:pointer}#ltkpopup-content .dropdown select{width:100%;height:100%;padding:0 10px;z-index:1;font-family:Arial,Helvetica,sans-serif;font-size:12px;font-weight:400;color:#000;text-indent:0 !important;background:#fff;border:1px solid #000;border-radius:0;cursor:pointer;-webkit-appearance:none !important;-moz-appearance:none !important;appearance:none !important}#ltkpopup-content .dropdown select:focus{border-color:#000;outline:none}#ltkpopup-content .dropdown::before{position:absolute;display:block;right:10px;top:50%;margin-top:-10px;z-index:2;font-family:FontAwesome;font-size:14px;content:"\\f0d7";color:#000;pointer-events:none;-webkit-transition:all .25s linear;transition:all .25s linear}#ltkpopup-content .dropdown select::-ms-expand{display:none !important}#ltkpopup-content input.ltkinputnotvalid,#ltkpopup-content div.dropdown.ltk-select-notvalid,#ltkpopup-content div.dropdown select.ltkinputnotvalid{border-color:red}#ltkpopup-content input.ltkinputnotvalid:focus,#ltkpopup-content div.dropdown.ltk-select-notvalid:focus,#ltkpopup-content div.dropdown select.ltkinputnotvalid:focus{border-color:red}#ltkpopup-content input.ltkinputnotvalid::-webkit-input-placeholder{color:red}#ltkpopup-content input.ltkinputnotvalid::-moz-placeholder{color:red}#ltkpopup-content input.ltkinputnotvalid:-ms-input-placeholder{color:red}#ltkpopup-content .ltkpopup-error-message{display:block;height:14px;text-align:center;line-height:14px;width:100%;font-size:10px;color:red;font-weight:700}#ltkpopup-content .ltkpopup-error-message:empty{visibility:hidden}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-error-message{line-height:14px;font-size:10px}}#ltkpopup-content .ltkpopup-button-container{position:relative;width:100%;overflow:hidden}#ltkpopup-content .ltkpopup-button-container.ltkpopup-flex{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;flex-wrap:wrap;-ms-flex-wrap:wrap;-webkit-box-align:center;-moz-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center;margin-top:20px;text-align:center}#ltkpopup-content .ltkpopup-subscribe,#ltkpopup-content .ltkpopup-close-button,#ltkpopup-content .ltkpopup-faux-subscribe{display:inline-block;position:relative;width:100%;max-width:320px;margin:auto;padding:7px;vertical-align:middle;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:400;color:#fff;height:32px;text-decoration:none;background-color:#000;border:1px solid #000;border-radius:0 !important;box-shadow:none !important;cursor:pointer;outline:none;-webkit-appearance:none !important;-moz-appearance:none !important;appearance:none !important;-webkit-transition:all .25s linear;transition:all .25s linear;transition:.25s;overflow:hidden}#ltkpopup-content .ltkpopup-subscribe span,#ltkpopup-content .ltkpopup-close-button span,#ltkpopup-content .ltkpopup-faux-subscribe span{position:relative;z-index:1}#ltkpopup-content .ltkpopup-subscribe:hover,#ltkpopup-content .ltkpopup-close-button:hover,#ltkpopup-content .ltkpopup-faux-subscribe:hover{color:#fff;background-color:#858585;border-color:#858585}#ltkpopup-content .ltkpopup-subscribe:focus,#ltkpopup-content .ltkpopup-close-button:focus,#ltkpopup-content .ltkpopup-faux-subscribe:focus{color:#fff;background-color:#858585;border-color:#858585;transition:0s}#ltkpopup-content .ltkpopup-close-button{float:none;margin:10px auto 0px;line-height:normal}#ltkpopup-content .ltkpopup-no-thanks{float:none;width:100%;text-align:center}#ltkpopup-content .ltkpopup-no-thanks a,#ltkpopup-content .ltkpopup-no-thanks button{background:none;border:none;display:inline-block;padding:10px;font-size:12px;font-weight:400;color:#000;text-decoration:underline;-webkit-transition:all .25s linear;transition:all .25s linear;cursor:pointer;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content .ltkpopup-no-thanks a:hover,#ltkpopup-content .ltkpopup-no-thanks a:focus,#ltkpopup-content .ltkpopup-no-thanks button:hover,#ltkpopup-content .ltkpopup-no-thanks button:focus{text-decoration:none}#ltkpopup-content .ltkpopup-float-fields{width:350px;margin:0 auto}#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button{width:100px;float:left}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-subscribe,#ltkpopup-content .ltkpopup-close-button,#ltkpopup-content .ltkpopup-faux-subscribe{font-size:16px;margin-top:5px}#ltkpopup-content .ltkpopup-no-thanks a,#ltkpopup-content .ltkpopup-no-thanks button{font-size:12px}#ltkpopup-content .ltkpopup-float-fields{width:100%}#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button{width:100%}}',
            confirmationHTML: '\n\t\t\t\t\t\t\t<!-- Pop-up Confirm / Appears after user submits Popup Form -->\n<div id="ltkpopup-wrapper" class="confirm ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n\t<!-- Custom Fonts can be placed below if applicable -->\n\t\n\t<link rel="stylesheet" href="https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/fontawesomev5.min.css">\n\n\t<!-- Main Popup Content Area -->\n\t<!-- Add class ltkpopup-no-padd for split popups -->\n\t<div id="ltkpopup-content" class="ltkpopup-confirm ltkpopup-no-padd">\n\n\t\t<!-- Pull in the popup container -->\n\t\t<div class="ltkpopup-clearfix ltkpopup-split-content ">\n\n\t<div class="ltkpopup-contain-img" id="ltkpopup-img-contained">\n\t\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/NW_Exit_EMAIL_POPUP_IMG_600x840-min.jpg" alt="" class="ltkpopup-img-fluid" aria-hidden="true">\n\t<\/div>\n\n\t<div class="ltkpopup-contain-form">\n\n\t\t<div class="ltkpopup-form-control">\n\n\t\t\t<div class="ltkpopup-content-wrap">\n\n\t\t\t\t<h1 id="ltkpopup-headline" class="ltkpopup-headline">THANK YOU<\/h1>\n<h2 id="ltkpopup-subheadline" class="ltkpopup-subheadline">You have been subscribed.<\/h2>\n<p id="ltkpopup-content-para" class="ltkpopup-content-para">To apply your 15% off coupon now, click below.<\/p>\n\n\t\t\t\t<div class="ltkpopup-button-container" id="ltkpopup-thanks">\n    <a tabindex="0" class="ltkpopup-close-button ltkpopup-close" href="https://ninewest.com/discount/WELCOME15" target="_blank">APPLY COUPON<\/a>\n<\/div>\n\n\t\t\t<\/div>\n\t\t<\/div>\n\t\t\n\t<\/div>\n\n<\/div>\n\t\t\n\n\t\t<!-- End Content Information -->\n\n\t\t<!-- Close \'X\' Button -->\n\t\t<!-- Add class ltkpopup-circle-close to create a circle close button -->\n<div id="ltkpopup-close-button" class="ltkpopup-circle-close">\n\t<a class="ltkpopup-close" tabindex="0" role="button" aria-label="close">\n\t\t<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">\n\t\t\t<line x1="1" y1="1" x2="28" y2="28" />\n\t\t\t<line x1="28" y1="1" x2="1" y2="28" />\n\t\t<\/svg>\n\t<\/a>\n<\/div>\n\t<\/div>\n<\/div>\n\n\n\n<script>\n\t// Browsers\n\tvar b = document.documentElement;\n\tb.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n\tvar $html = jQuery("html"),\n\t\tua = $html.data("useragent"),\n\t\tpf = $html.data("platform");\n\n\tfunction is(e) {\n\t\treturn ua.indexOf(e) > -1\n\t}\n\tvar browser = {\n\t\tisIE: is("msie") || is("trident/7.0"),\n\t\tisIE7: is("msie 7.0"),\n\t\tisIE8: is("msie 8.0"),\n\t\tisIE9: is("msie 9.0"),\n\t\tisIE10: is("msie 10"),\n\t\tisIE11: is("rv:11") && is("trident/7.0"),\n\t\tisEdge: is("edge"),\n\t\tisChrome: is("chrome") && !is("edge"),\n\t\tisSafari: is("safari") && !is("chrome") && !is("edge"),\n\t\tisFirefox: is("firefox") && !is("edge"),\n\t\tisAndroidChrome: is("android") && is("chrome"),\n\t\tisAndroidDefault: is("android") && !is("chrome"),\n\t\tisWin7: is("windows nt 6.1"),\n\t\tisWin8: is("windows nt 6.2"),\n\t\tisWindows: pf.indexOf("win32") > -1,\n\t\tisWebkit: is("webkit") && !is("edge"),\n\t\tisIPad: is("ipad"),\n\t\tisIPadChrome: is("ipad") && is("crios"),\n\t\tisIPhone: is("iphone"),\n\t\tisIPhoneChrome: is("iphone") && is("crios"),\n\t\tisAndroid: is("android"),\n\t\tisIOS: is("iphone") || is("ipad")\n\t};\n\tfor (var title in browser) {\n\t\tvar helperClass = title.slice(2).toLowerCase();\n\t\tbrowser[title] && jQuery("#ltkpopup-content").addClass(helperClass)\n\t}\n\n\t// Close Function\n\tjQuery(\'.ltkpopup-close\').focus(function () {\n\t\tjQuery(\'.ltkpopup-close\').keypress(function (e) {\n\t\t\tvar key = e.which;\n\t\t\tif (key == 13) {\n\t\t\t\tjQuery(\'#ltkpopup-overlay, #ltkpopup-container\').remove()\n\t\t\t}\n\t\t})\n\t});\n\n\t// Check Input Validity\n\tfunction checkInputValidity(inputEl) {\n\t\tjQuery(inputEl).removeClass("ltkinputnotvalid");\n\t\tvar ltkErrorMessage = jQuery("[data-ltkpopup-error-for=\'" + inputEl.id + "\'");\n\t\tjQuery(ltkErrorMessage).text("");\n\t\tinputEl.checkValidity();\n\t\tif (jQuery(inputEl).is(\':invalid\')) {\n\t\t\tjQuery(inputEl).addClass("ltkinputnotvalid");\n\t\t\tvar ltkErrorMessageText = jQuery(ltkErrorMessage).attr("data-ltkpopup-message");\n\t\t\tjQuery(ltkErrorMessage).text(ltkErrorMessageText);\n\t\t\treturn false;\n\t\t}\n\t\treturn true;\n\t}\n\n\n\n\tchangeFocus = function () {\n\t\tif (document.getElementById("ltkpopup-email") == undefined && document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined) {\n\t\t\tdocument.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n\t\t}\n\t}\n\n\t// Tab Trapping\n\tjQuery(document).ready(function () {\n\t\tsetTimeout(function () {\n\t\t\tfunction triggerFocus(element) {\n\t\t\t\tvar eventType = "onfocusin" in element ? "focusin" : "focus",\n\t\t\t\t\tbubbles = "onfocusin" in element,\n\t\t\t\t\tevent;\n\n\t\t\t\tif ("createEvent" in document) {\n\t\t\t\t\tevent = document.createEvent("Event");\n\t\t\t\t\tevent.initEvent(eventType, bubbles, true);\n\t\t\t\t} else if ("Event" in window) {\n\t\t\t\t\tevent = new Event(eventType, {\n\t\t\t\t\t\tbubbles: bubbles,\n\t\t\t\t\t\tcancelable: true\n\t\t\t\t\t});\n\t\t\t\t}\n\n\t\t\t\telement.focus();\n\t\t\t\telement.dispatchEvent(event);\n\t\t\t}\n\t\t\tif (document.getElementById("ltkpopup-email") != undefined) {\n\t\t\t\ttriggerFocus(document.getElementById("ltkpopup-email"));\n\t\t\t} else {\n\t\t\t\tchangeFocus();\n\t\t\t}\n\t\t}, 0);\n\t});\n\n\tfunction trapTabKey(e) {\n\t\tvar t = document.activeElement,\n\t\t\ts = focusableElems.indexOf(t);\n\t\tif (9 === e.keyCode) {\n\t\t\te.preventDefault();\n\t\t\tmoveTab(s, e.shiftKey)\n\t\t}\n\t}\n\n\tfunction moveTab(index, shift) {\n\t\tvar nextTab = null;\n\t\tvar nextIndex = index;\n\t\tif (shift) {\n\t\t\tif (focusableElems[index] == firstTabStop) {\n\t\t\t\tnextTab = lastTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index - 1;\n\t\t\t\tnextTab = focusableElem[nextIndex];\n\t\t\t}\n\t\t} else {\n\t\t\tif (focusableElems[index] == lastTabStop) {\n\t\t\t\tnextTab = firstTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index + 1;\n\t\t\t\tnextTab = focusableElems[nextIndex];\n\t\t\t}\n\t\t}\n\n\t\tif (jQuery(nextTab).is(":visible")) {\n\t\t\tnextTab.focus();\n\t\t} else {\n\t\t\tmoveTab(nextIndex, shift);\n\t\t}\n\t}\n\twindow.onload = function () {\n\t\tvar e = document.getElementById("ltkpopup-img-contained");\n\t\te && (2 == window.getComputedStyle(e).getPropertyValue("order") && (e.className += " ltkpopup-img-right"))\n\t}, setTimeout(function () {\n\t\t//Do not delete - tab functionality will break\n\t\t_ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n\t\tchangeFocus();\n\t}, 50);\n\tvar focused = document.activeElement;\n\tjQuery(".ltkpopup-close").on("click", function () {\n\t\tfocused.focus()\n\t});\n\tvar focusBox = document.getElementById("ltkpopup-content"),\n\t\tfocusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n\t\tfocusableElem = focusBox.querySelectorAll(focusableElemStr),\n\t\tfocusableElems = Array.prototype.slice.call(focusableElem),\n\t\tfirstTabStop = focusableElems[0],\n\t\tlastTabStop = focusableElems[focusableElems.length - 1];\n\tfocusBox.addEventListener("keydown", trapTabKey);\n\n\t\n\t$("body").bind("DOMSubtreeModified", function() {\n    \tif($(\'#smile-ui-container\')){\n\t\t\t$(\'#smile-ui-container\').css(\'z-index\',\'999\');\n\t\t}\n\t});\n<\/script>\n\t\t\t\t\t\t',
            animation: null,
            urlRedirect: null,
            initialDelay: 2,
            buttonSettings: {
                size: 1,
                shape: 1,
                alignment: 2,
                text: "Subscribe",
                color: "#00BDE5",
                textColor: "#FFFFFF"
            },
            urlRules: [{
                urlMatchRule: 1,
                show: !0,
                url: "/checkouts/"
            }],
            targetingRules: {
                showWhenDevice: ["Desktop"]
            },
            subscriptionPoint: "Popup",
            engagement: {
                followUpTimeframe: 0,
                showWhenPageSession: 1,
                followUp: !0,
                followUpDelay: 30,
                showIfFromListrakEmail: !1
            },
            overlayClose: !0,
            referrerRule: null
        }
    }, {
        type: 1,
        category: 0,
        popupUID: "cca8418a-1396-4b7a-a4b3-5a471f9c82e3",
        popupName: "Entry Popup - Nine West - No SMS",
        clientUID: "4812bcb7-32f3-4732-92d1-a34659911750",
        companyID: 0,
        isActive: !1,
        lastModified: "2022-02-22T21:15:16.363Z",
        settings: {
            scrollDepth: 0,
            isTestMode: !0,
            formHTML: '\n\t\t\t\t\t\t\t<!-- Pop-up Form -->\n<!-- ltkpopup-no-scroll: centers the popup on display by preventing the page from scrolling -->\n<!-- ltkpopup-ios-fix: keeps fixed position popups like bottom banners in place in iOS -->\n<div id="ltkpopup-wrapper" class="ltkpopup-signup ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n\t<!-- Custom Fonts can be placed below if applicable -->\n\n\t<link rel="stylesheet" href="https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/fontawesomev5.min.css">\n\n\t<!-- Main Popup Content Area -->\n\t<!-- Add class ltkpopup-no-padd for split popups -->\n\t<div id="ltkpopup-content" class="ltkpopup-signup ltkpopup-no-padd">\n\n\t\t<!-- Pull in the popup container -->\n\t\t<div class="ltkpopup-clearfix ltkpopup-split-content ">\n\n\t\t\t<div class="ltkpopup-contain-img" id="ltkpopup-img-contained">\n\t\t\t\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/NW_EMAIL_POPUP_IMG_600x840-min.jpg" alt="" class="ltkpopup-img-fluid" aria-hidden="true">\n\t\t\t<\/div>\n\n\t\t\t<div class="ltkpopup-contain-form">\n\n\t\t\t\t<div class="ltkpopup-form-control">\n\n\t\t\t\t\t<div class="ltkpopup-content-wrap">\n\t\t\t\t\t\t<h1 id="ltkpopup-headline" class="ltkpopup-headline">RECEIVE 15% OFF <span class="ltkpopup-subheadline">WHEN YOU SUBSCRIBE TODAY!<\/span><\/h1>\n\t\t\t\t\t\t<p id="ltkpopup-content-para" class="ltkpopup-content-para">Get the latest on new arrivals, trends, sales, and exclusive&nbsp;offers.<\/p>\n\n\t\t\t\t\t\t<div class="ltkpopup-form-contain" id="ltkpopup-form">\n\n\t\t\t\t\t\t\t<div class="ltkpopup-form-contain">\n\n\t\t\t\t\t\t\t\t<div class="ltkpopup-form-control">\n\n\t\t\t\t\t\t\t\t\t<!-- Email Input Required Error Message|Moved out of column for display purposes -->\n\t\t\t\t\t\t\t\t\t<div class="ltkpopup-error-message" aria-live="assertive" data-ltkpopup-error-for="ltkpopup-email" data-ltkpopup-message="Please enter a valid email address"><\/div>\n\n\t\t\t\t\t\t\t\t\t<label class="ltkpopup-visuallyhidden" for="ltkpopup-email">Email Address<\/label>\n\t\t\t\t\t\t\t\t\t<input autofocus required type="email" id="ltkpopup-email" class="ltkpopup-email" tabindex="0" name="ltkpopup-email" placeholder="Email Address (required)" autocomplete="email" pattern="^([a-zA-Z0-9._+!-]+[@](?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,})$" onchange="_ltk.SCA.Update(\'email\', this.value)" />\n\n\t\t\t\t\t\t\t\t<\/div>\n\n\t\t\t\t\t\t\t\t<!-- Emmet Snippets if applicable -->\n\t\t\t\t\t\t\t\t<!-- zip error dropdown checkbox radio sms-capture -->\n\n\t\t\t\t\t\t\t\t<!-- Button Container -->\n\t\t\t\t\t\t\t\t<div class="ltkpopup-button-container ltkpopup-flex ltkpopup-clearfix">\n\t\t\t\t\t\t\t\t\t<!-- Submit Button -->\n\t\t\t\t\t\t\t\t\t<button id="ltkpopup-submit" class="ltkpopup-subscribe" tabindex="0" type="submit"><span>SIGN UP NOW<\/span><\/button>\n\n\t\t\t\t\t\t\t\t\t<!-- Text Close Button -->\n\t\t\t\t\t\t\t\t\t<div class="ltkpopup-no-thanks ltkpopup-visuallyhidden" id="ltkpopup-text-btn">\n\t\t\t\t\t\t\t\t\t\t<!-- Do Not Delete. Add class ltkpopup-visuallyhidden -->\n\t\t\t\t\t\t\t\t\t\t<button tabindex="0" class="ltkpopup-close">maybe later<\/button>\n\t\t\t\t\t\t\t\t\t<\/div>\n\t\t\t\t\t\t\t\t<\/div>\n\n\t\t\t\t\t\t\t<\/div>\n\n\t\t\t\t\t\t<\/div>\n\n\t\t\t\t\t\t<p class="ltkpopup-content-para ltkpopup-disclaimer">See <a href="http://ninewest.com/policies/terms-of-service" target="_blank">Terms and Conditions<\/a> &amp; <a href="http://ninewest.com/policies/privacy-policy" target="_blank">Privacy&nbspPolicy<\/a>.<\/p>\n\n\t\t\t\t\t<\/div>\n\t\t\t\t<\/div>\n\n\t\t\t<\/div>\n\n\t\t<\/div>\n\n\n\t\t<!-- Emmet Snippets if applicable -->\n\t\t<!-- zip error dropdown checkbox radio sms-capture -->\n\n\t\t<!-- Do Not Delete. Connects the Popup to Segmentation within the Listrak platform. Input name needs to match segmentation -->\n\t\t<div class="ltkpopup-source">\n\t\t\t<input type="hidden" class="text" name="Source.Popup" value="On" tabindex="-1" />\n\t\t<\/div>\n\n\t\t<!-- Close \'X\' Button -->\n\t\t<!-- Add class ltkpopup-circle-close to create a circle close button -->\n\t\t<div id="ltkpopup-close-button" class="ltkpopup-circle-close">\n\t\t\t<a class="ltkpopup-close" tabindex="0" role="button" aria-label="close">\n\t\t\t\t<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">\n\t\t\t\t\t<line x1="1" y1="1" x2="28" y2="28" />\n\t\t\t\t\t<line x1="28" y1="1" x2="1" y2="28" />\n\t\t\t\t<\/svg>\n\t\t\t<\/a>\n\t\t<\/div>\n\n\t<\/div>\n\t<!-- End ltkpopup-content -->\n\n<\/div>\n<!-- End ltkpopup-wrapper -->\n\n<script>\n\tvar emailVal;\n\tjQuery(\'#ltkpopup-submit\').on(\'click\', function () {\n\t\temailVal = jQuery(\'#ltkpopup-email\').val();\n\t\tphoneVal = jQuery(\'#ltkpopup-phone\').val();\n\t\tvar e = jQuery(":input");\n\t\tjQuery(e).each(function (e) {\n\t\t\tcheckInputValidity(this);\n\t\t\tif (jQuery(this).is(":invalid")) {\n\t\t\t\tthis.setAttribute("aria-describedby", this.id + "-error-message");\n\t\t\t} else {\n\t\t\t\tthis.removeAttribute("aria-describedby")\n\t\t\t}\n\t\t});\n\t\tsetTimeout(function () {\n\t\t\tif (document.querySelector(".ltkinputnotvalid") != null) {\n\t\t\t\tdocument.querySelector(".ltkinputnotvalid").focus();\n\t\t\t}\n\t\t}, 0);\n\t});\n<\/script>\n\n<script>\n\t// Browsers\n\tvar b = document.documentElement;\n\tb.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n\tvar $html = jQuery("html"),\n\t\tua = $html.data("useragent"),\n\t\tpf = $html.data("platform");\n\n\tfunction is(e) {\n\t\treturn ua.indexOf(e) > -1\n\t}\n\tvar browser = {\n\t\tisIE: is("msie") || is("trident/7.0"),\n\t\tisIE7: is("msie 7.0"),\n\t\tisIE8: is("msie 8.0"),\n\t\tisIE9: is("msie 9.0"),\n\t\tisIE10: is("msie 10"),\n\t\tisIE11: is("rv:11") && is("trident/7.0"),\n\t\tisEdge: is("edge"),\n\t\tisChrome: is("chrome") && !is("edge"),\n\t\tisSafari: is("safari") && !is("chrome") && !is("edge"),\n\t\tisFirefox: is("firefox") && !is("edge"),\n\t\tisAndroidChrome: is("android") && is("chrome"),\n\t\tisAndroidDefault: is("android") && !is("chrome"),\n\t\tisWin7: is("windows nt 6.1"),\n\t\tisWin8: is("windows nt 6.2"),\n\t\tisWindows: pf.indexOf("win32") > -1,\n\t\tisWebkit: is("webkit") && !is("edge"),\n\t\tisIPad: is("ipad"),\n\t\tisIPadChrome: is("ipad") && is("crios"),\n\t\tisIPhone: is("iphone"),\n\t\tisIPhoneChrome: is("iphone") && is("crios"),\n\t\tisAndroid: is("android"),\n\t\tisIOS: is("iphone") || is("ipad")\n\t};\n\tfor (var title in browser) {\n\t\tvar helperClass = title.slice(2).toLowerCase();\n\t\tbrowser[title] && jQuery("#ltkpopup-content").addClass(helperClass)\n\t}\n\n\t// Close Function\n\tjQuery(\'.ltkpopup-close\').focus(function () {\n\t\tjQuery(\'.ltkpopup-close\').keypress(function (e) {\n\t\t\tvar key = e.which;\n\t\t\tif (key == 13) {\n\t\t\t\tjQuery(\'#ltkpopup-overlay, #ltkpopup-container\').remove()\n\t\t\t}\n\t\t})\n\t});\n\n\t// Check Input Validity\n\tfunction checkInputValidity(inputEl) {\n\t\tjQuery(inputEl).removeClass("ltkinputnotvalid");\n\t\tvar ltkErrorMessage = jQuery("[data-ltkpopup-error-for=\'" + inputEl.id + "\'");\n\t\tjQuery(ltkErrorMessage).text("");\n\t\tinputEl.checkValidity();\n\t\tif (jQuery(inputEl).is(\':invalid\')) {\n\t\t\tjQuery(inputEl).addClass("ltkinputnotvalid");\n\t\t\tvar ltkErrorMessageText = jQuery(ltkErrorMessage).attr("data-ltkpopup-message");\n\t\t\tjQuery(ltkErrorMessage).text(ltkErrorMessageText);\n\t\t\treturn false;\n\t\t}\n\t\treturn true;\n\t}\n\n\n\n\tchangeFocus = function () {\n\t\tif (document.getElementById("ltkpopup-email") == undefined && document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined) {\n\t\t\tdocument.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n\t\t}\n\t}\n\n\t// Tab Trapping\n\tjQuery(document).ready(function () {\n\t\tsetTimeout(function () {\n\t\t\tfunction triggerFocus(element) {\n\t\t\t\tvar eventType = "onfocusin" in element ? "focusin" : "focus",\n\t\t\t\t\tbubbles = "onfocusin" in element,\n\t\t\t\t\tevent;\n\n\t\t\t\tif ("createEvent" in document) {\n\t\t\t\t\tevent = document.createEvent("Event");\n\t\t\t\t\tevent.initEvent(eventType, bubbles, true);\n\t\t\t\t} else if ("Event" in window) {\n\t\t\t\t\tevent = new Event(eventType, {\n\t\t\t\t\t\tbubbles: bubbles,\n\t\t\t\t\t\tcancelable: true\n\t\t\t\t\t});\n\t\t\t\t}\n\n\t\t\t\telement.focus();\n\t\t\t\telement.dispatchEvent(event);\n\t\t\t}\n\t\t\tif (document.getElementById("ltkpopup-email") != undefined) {\n\t\t\t\ttriggerFocus(document.getElementById("ltkpopup-email"));\n\t\t\t} else {\n\t\t\t\tchangeFocus();\n\t\t\t}\n\t\t}, 0);\n\t});\n\n\tfunction trapTabKey(e) {\n\t\tvar t = document.activeElement,\n\t\t\ts = focusableElems.indexOf(t);\n\t\tif (9 === e.keyCode) {\n\t\t\te.preventDefault();\n\t\t\tmoveTab(s, e.shiftKey)\n\t\t}\n\t}\n\n\tfunction moveTab(index, shift) {\n\t\tvar nextTab = null;\n\t\tvar nextIndex = index;\n\t\tif (shift) {\n\t\t\tif (focusableElems[index] == firstTabStop) {\n\t\t\t\tnextTab = lastTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index - 1;\n\t\t\t\tnextTab = focusableElem[nextIndex];\n\t\t\t}\n\t\t} else {\n\t\t\tif (focusableElems[index] == lastTabStop) {\n\t\t\t\tnextTab = firstTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index + 1;\n\t\t\t\tnextTab = focusableElems[nextIndex];\n\t\t\t}\n\t\t}\n\n\t\tif (jQuery(nextTab).is(":visible")) {\n\t\t\tnextTab.focus();\n\t\t} else {\n\t\t\tmoveTab(nextIndex, shift);\n\t\t}\n\t}\n\twindow.onload = function () {\n\t\tvar e = document.getElementById("ltkpopup-img-contained");\n\t\te && (2 == window.getComputedStyle(e).getPropertyValue("order") && (e.className += " ltkpopup-img-right"))\n\t}, setTimeout(function () {\n\t\t//Do not delete - tab functionality will break\n\t\t_ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n\t\tchangeFocus();\n\t}, 50);\n\tvar focused = document.activeElement;\n\tjQuery(".ltkpopup-close").on("click", function () {\n\t\tfocused.focus()\n\t});\n\tvar focusBox = document.getElementById("ltkpopup-content"),\n\t\tfocusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n\t\tfocusableElem = focusBox.querySelectorAll(focusableElemStr),\n\t\tfocusableElems = Array.prototype.slice.call(focusableElem),\n\t\tfirstTabStop = focusableElems[0],\n\t\tlastTabStop = focusableElems[focusableElems.length - 1];\n\tfocusBox.addEventListener("keydown", trapTabKey);\n\n\n\t$("body").bind("DOMSubtreeModified", function () {\n\t\tif ($(\'#smile-ui-container\')) {\n\t\t\t$(\'#smile-ui-container\').css(\'z-index\', \'999\');\n\t\t}\n\t});\n<\/script>\n<script>\n\tjQuery(document).ready(function () {\n\n\t\tif (jQuery("[data-inputmask]").length) {\n\n\t\t\t// Input masking for number validation - Get Jquery Input Mask from CDN and load it\n\t\t\tjQuery.getScript(\n\t\t\t\t"https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.1/jquery.inputmask.bundle.js",\n\t\t\t\tfunction () {\n\t\t\t\t\tjQuery("[data-inputmask]").each(function () {\n\t\t\t\t\t\t// Mask phone number input after script is loaded\n\t\t\t\t\t\tjQuery(this).inputmask({\n\t\t\t\t\t\t\tgreedy: false,\n\t\t\t\t\t\t\tshowMaskOnHover: false,\n\t\t\t\t\t\t\tdefinitions: {\n\t\t\t\t\t\t\t\t\'#\': {\n\t\t\t\t\t\t\t\t\tvalidator: "[0-9]",\n\t\t\t\t\t\t\t\t\tcardinality: 1\n\t\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\t}\n\t\t\t\t\t\t});\n\t\t\t\t\t});\n\t\t\t\t});\n\t\t}\n\t});\n<\/script>\n<script>\n\tvar datepickerField = document.querySelector("#ltkpopup-datepicker");\n\tif (datepickerField != null) {\n\t\tvar jQueryUIcss = document.createElement("link");\n\t\tjQueryUIcss.href = "https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css";\n\t\tjQueryUIcss.rel = "stylesheet";\n\t\tjQueryUIcss.addEventListener("load", function () {\n\t\t\tvar jQueryUI = document.createElement("script");\n\t\t\tjQueryUI.src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js";\n\t\t\tjQueryUI.addEventListener("load", function () {\n\t\t\t\tdatepickerField.setAttribute("readonly", "");\n\t\t\t\tjQuery(datepickerField).datepicker({\n\t\t\t\t\tchangeMonth: true,\n\t\t\t\t\tchangeYear: false,\n\t\t\t\t\tyearRange: \'-0:+0\',\n\t\t\t\t\t// use for different date format and hidden bday field\n\t\t\t\t\tdateFormat: "mm/dd",\n\t\t\t\t\taltField: "#ltkpopup-hidden-bday",\n\t\t\t\t\taltFormat: "mm/dd/1900"\n\t\t\t\t});\n\n\t\t\t\tjQuery(datepickerField).focus(function () {\n\t\t\t\t\tjQuery(\'#ui-datepicker-div\').appendTo(this.parentNode);\n\t\t\t\t});\n\t\t\t});\n\t\t\tdocument.getElementById("ltkpopup-content").appendChild(jQueryUI);\n\t\t});\n\t\tdocument.getElementById("ltkpopup-content").appendChild(jQueryUIcss);\n\t}\n<\/script>\n\t\t\t\t\t\t',
            formCSS: '#ltkpopup-wrapper .ltkpopup-clearfix::before,#ltkpopup-wrapper .ltkpopup-clearfix::after{content:"";display:table}#ltkpopup-wrapper .ltkpopup-clearfix::after{clear:both}#ltkpopup-wrapper .ltkpopup-clearfix{zoom:1}.ios-only{position:fixed}.ltkpopup-visuallyhidden{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);border:0}.ltkpopup-visuallyhidden.focusable:active,.ltkpopup-visuallyhidden.focusable:focus{position:static;width:auto;height:auto;margin:0;overflow:visible;clip:auto}.ltkpopup-img-fluid{width:100%;height:auto}.ltkpopup-full-width{width:100% !important;max-width:100% !important}.ltkpopup-content-wrap{max-width:450px;margin:0 auto}#ltkpopup-thanks{text-align:center}#ltkpopup-thanks input{display:inline-block}#smile-ui-container,#keyboard-nav-34,#keyboard-nav-37{z-index:99990 !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-wrapper .mobileHide{display:none}}#ltkpopup-content .ltk-grid{margin:0 auto;width:100%}#ltkpopup-content .ltk-row{padding-bottom:20px}#ltkpopup-content .ltk-row:last-of-type{padding-bottom:0px}#ltkpopup-content .ltk-col-1{width:100%}#ltkpopup-content .ltk-col-1-2{width:50%}#ltkpopup-content .ltk-col-2-3{width:66.66%}#ltkpopup-content .ltk-col-1-3{width:33.33%}#ltkpopup-content [class*=\'ltk-col-\']{float:left}#ltkpopup-content [class*=\'ltk-col-\']{padding-right:0}#ltkpopup-content [class*=\'ltk-col-\']:last-of-type{padding-right:0;padding-left:10px}#ltkpopup-content .ltk-col-1-3{padding-right:14px}#ltkpopup-content .ltk-col-1-3+.ltk-col-1-3{padding-right:6px;padding-left:6px}#ltkpopup-content .ltk-col-1-3:last-of-type{padding-right:0;padding-left:0}#ltkpopup-content .ltk-col-1,#ltkpopup-content .ltk-col-1:last-of-type{padding-right:0;padding-top:0;padding-left:0}#ltkpopup-overlay{z-index:100001 !important;position:fixed !important;top:0 !important;bottom:0 !important;width:100% !important;height:100% !important;background-color:#000 !important;opacity:.5 !important;-webkit-transition:all .25s ease-in;transition:all .25s ease-in}#ltkpopup-container{z-index:100010 !important;position:fixed !important;width:710px !important;height:auto !important;max-height:100%;top:50% !important;left:50% !important;margin-left:0 !important;-webkit-transform:translate(-50%, -50%) !important;-moz-transform:translate(-50%, -50%) !important;-ms-transform:translate(-50%, -50%) !important;transform:translate(-50%, -50%) !important;overflow-x:hidden;overflow-y:auto;-webkit-box-shadow:0 5px 15px rgba(0,0,0,0.5);-moz-box-shadow:0 5px 15px rgba(0,0,0,0.5);box-shadow:0 5px 15px rgba(0,0,0,0.5)}#ltkpopup-wrapper{position:relative;margin:0 auto;width:100% !important}#ltkpopup-container .simpleltkmodal-wrap{overflow:visible !important}#ltkpopup-wrapper *{box-sizing:border-box;backface-visibility:hidden !important}#ltkpopup-wrapper{background:transparent;font-size:12px;font-family:Arial,Helvetica,sans-serif;-webkit-font-smoothing:subpixel-antialiased}#ltkpopup-wrapper .no-wrap{white-space:nowrap}#ltkpopup-content{padding:3em;font-size:12px;text-align:left;color:#000;line-height:1.4;background:#fff}.ltkpopup-fullscreen{position:relative;max-width:710px;height:auto !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-container{width:100% !important;height:100% !important}#ltkpopup-wrapper{width:320px !important}#ltkpopup-content{float:none;width:100%;padding:40px 20px 30px 20px}}#ltkpopup-content .ltkpopup-split-content{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-webkit-box-align:center;-moz-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img{max-width:300px;-webkit-box-flex:0 0 300px;-moz-box-flex:0 0 300px;-webkit-flex:0 0 300px;-ms-flex:0 0 300px;flex:0 0 300px;line-height:0;order:2;-ms-flex-order:2}#ltkpopup-content .ltkpopup-split-content.ltkpopup-image-bottom .ltkpopup-contain-img-full{line-height:0}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form{max-width:410px;-webkit-box-flex:0 0 410px;-moz-box-flex:0 0 410px;-webkit-flex:0 0 410px;-ms-flex:0 0 410px;flex:0 0 410px;-ms-flex:0 0 410px;padding:10px 10px 10px;order:1;-ms-flex-order:1}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form .ltkpopup-no-thanks{float:none;text-align:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-full-width{padding-top:30px}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below{flex-wrap:wrap}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form{max-width:100%;-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full{-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%;order:2;line-height:0}#ltkpopup-content.ie6 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie7 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie8 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie9 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie10 .ltkpopup-split-content .ltkpopup-contain-img{width:300px;float:right}#ltkpopup-content.ie6 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie7 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie8 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie9 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie10 .ltkpopup-split-content .ltkpopup-contain-form{width:410px;float:left;padding-top:70px}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below{flex-wrap:wrap}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form{width:100%}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full{width:100%}#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-form{position:relative;left:-2px}#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-img.ltkpopup-img-right img,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-img.ltkpopup-img-right img,#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-form-right,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-form-right{position:relative;right:-2px;left:auto}#ltkpopup-content.safari,#ltkpopup-content.ipad{overflow-x:hidden;overflow-y:hidden}#ltkpopup-content.ie .ltkpopup-split-content,#ltkpopup-content.ie11 .ltkpopup-split-content{padding-bottom:2px}#ltkpopup-content.ie .ltkpopup-split-content .ltkpopup-img-fluid,#ltkpopup-content.ie11 .ltkpopup-split-content .ltkpopup-img-fluid{position:relative;bottom:-1px}#ltkpopup-content.ltkpopup-no-padd{padding:0 !important}#ltkpopup-content.ltkpopup-no-padd .ltkpopup-no-padd{padding:0 !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-formcontent,#ltkpopup-form,#ltkpopup-wrapper{width:100% !important;height:100% !important;background-color:#fff}#ltkpopup-content{width:100%}#ltkpopup-content .ltkpopup-split-content{width:100%;height:100%;-webkit-align-items:center;-moz-align-items:center;-ms-align-items:center;align-items:center;-webkit-justify-content:center;-moz-justify-content:center;-ms-justify-content:center;justify-content:center;-ms-flex-pack:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img-full,#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img{display:none}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form{width:100%;flex:0 0 100%;-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%;padding:40px 20px 10px}#ltkpopup-content.ltkpopup-confirm .ltkpopup-split-content .ltkpopup-contain-form{padding:40px 20px}}#ltkpopup-close-button{position:absolute;left:7px;top:7px;margin:0px;z-index:10}#ltkpopup-close-button a{display:block;width:12px;height:12px;cursor:pointer}#ltkpopup-close-button a svg{width:100%;height:100%;position:relative;display:block;overflow:visible;stroke:#333;stroke-width:6px;-webkit-transition:all .25s linear;transition:all .25s linear}#ltkpopup-close-button a:hover svg{stroke:#858585}#ltkpopup-close-button a:focus svg{stroke:#858585}#ltkpopup-close-button.ltkpopup-circle-close{right:7px;top:7px}#ltkpopup-close-button.ltkpopup-circle-close a{width:22px;height:22px;background:#fff;border-radius:50%;padding:4px;border:2px solid #333}#ltkpopup-close-button.ltkpopup-circle-close a:hover,#ltkpopup-close-button.ltkpopup-circle-close a:focus{border-color:#858585}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-close-button{right:7px;top:7px}#ltkpopup-close-button a{width:12px;height:12px}}#ltkpopup-content h1,#ltkpopup-content h2,#ltkpopup-content h3,#ltkpopup-content h4,#ltkpopup-content h5,#ltkpopup-content .ltkpopup-headline,#ltkpopup-content .ltkpopup-subheadline{margin:0;padding:0;text-align:center;font-family:Arial,Helvetica,sans-serif !important}#ltkpopup-content h1,#ltkpopup-content .ltkpopup-headline{font-weight:700;font-size:26px;line-height:30px;color:#000;letter-spacing:1px;margin-bottom:10px;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content h2,#ltkpopup-content .ltkpopup-subheadline{font-weight:400;font-size:14px;line-height:25px;color:#000;display:block;margin-top:10px;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content p,#ltkpopup-content .ltkpopup-content-para{margin:0 0 5px;font-size:12px;line-height:19px;font-family:Arial,Helvetica,sans-serif;text-align:center;letter-spacing:.5px}#ltkpopup-content p.ltkpopup-disclaimer,#ltkpopup-content p.ltkpopup-sms-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer{font-size:8px;line-height:16px;text-align:center;margin:30px 10px 0;letter-spacing:0}#ltkpopup-content p.ltkpopup-disclaimer a,#ltkpopup-content p.ltkpopup-sms-disclaimer a,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a{color:inherit;text-decoration:underline;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content p.ltkpopup-disclaimer a:hover,#ltkpopup-content p.ltkpopup-disclaimer a:focus,#ltkpopup-content p.ltkpopup-sms-disclaimer a:hover,#ltkpopup-content p.ltkpopup-sms-disclaimer a:focus,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:hover,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:focus,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:hover,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:focus{text-decoration:none}#ltkpopup-content p.ltkpopup-disclaimer span,#ltkpopup-content p.ltkpopup-sms-disclaimer span,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer span,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer span{font-weight:700}#ltkpopup-content.ltkpopup-confirm p,#ltkpopup-content.ltkpopup-confirm .ltkpopup-content-para{margin:10px auto}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content h1,#ltkpopup-content .ltkpopup-headline{font-size:26px;line-height:30px}#ltkpopup-content h2,#ltkpopup-content .ltkpopup-subheadline{font-size:14px;line-height:25px}#ltkpopup-content p,#ltkpopup-content .ltkpopup-content-para{font-size:12px;line-height:19px}#ltkpopup-content p.ltkpopup-disclaimer,#ltkpopup-content p.ltkpopup-sms-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer{font-size:8px;line-height:16px}}#ltkpopup-content input[type="text"],#ltkpopup-content input[type="email"],#ltkpopup-content input[type="number"],#ltkpopup-content input[type="tel"]{display:block;width:100%;height:32px;padding:0 1em;margin:0 auto;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:400;text-align:left;color:#000;line-height:normal;background-color:transparent;border:1px solid #000;border-radius:0px !important;box-shadow:inset 0 0 0 1000px #fff;-webkit-transition:all 0.11s linear;transition:all 0.11s linear;-webkit-appearance:none;-moz-appearance:none;appearance:none}#ltkpopup-content input[type="text"]:focus,#ltkpopup-content input[type="email"]:focus,#ltkpopup-content input[type="number"]:focus,#ltkpopup-content input[type="tel"]:focus{outline:none;border:2px solid #000}#ltkpopup-content input[type="text"]:last-of-type{margin:10px auto 0}#ltkpopup-content .ltkpopup-form-control{position:relative}#ltkpopup-content .ltkpopup-form-contain{max-width:320px;margin:0 auto}#ltkpopup-content input::-webkit-input-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input::-moz-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input:-ms-input-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input::-ms-clear{display:none;width:0;height:0;opacity:0}#ltkpopup-content .ltk-floating-input{width:250px;float:left}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content input[type="text"],#ltkpopup-content input[type="email"],#ltkpopup-content input[type="number"],#ltkpopup-content input[type="tel"]{float:none;width:100%;font-size:15px}#ltkpopup-content .ltk-floating-input{width:100%;padding-bottom:15px}}#ltkpopup-content input[type="radio"]{position:absolute;overflow:hidden;clip:rect(0 0 0 0);height:1px;width:1px;margin:-1px;padding:0;border:0}#ltkpopup-content .radio-wrapper{padding:10px 0;text-align:left}#ltkpopup-content .ltk-radio{position:relative;float:left;width:50%}#ltkpopup-content .ltk-radio label{position:relative;display:block;padding:0px 4px;cursor:pointer}#ltkpopup-content .ltk-radio label::before{position:absolute;display:block;float:left;padding:0 3px 0 0;font-family:FontAwesome;font-size:12px;color:#fff;content:"\\f111";border-radius:0px}#ltkpopup-content .ltk-radio label span{display:block;padding:0 0 0 22px}#ltkpopup-content .ltk-radio input:checked ~ label::before{color:#fff;content:"\\f192"}#ltkpopup-content .ltk-radio input:hover+label::before{color:#000}#ltkpopup-content .ltk-radio input:focus+label::before{color:#fff}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkmodal-wrapper .radio-wrapper{padding:5px 0}}#ltkpopup-content input[type="checkbox"]{position:absolute;overflow:hidden;clip:rect(0 0 0 0);height:1px;width:1px;margin:-1px;padding:0;border:0}#ltkpopup-content fieldset#ltkpopup-options{border:none;margin:5px auto 10px;padding:0;width:100%;max-width:150px}#ltkpopup-content .ltkpopup-legend,#ltkpopup-content .ltkpopup-legend-styling{font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:12px;line-height:19px;text-align:center;color:#000;white-space:normal;margin:0 auto}#ltkpopup-content .ltkpopup-legend .ltklegend-regular,#ltkpopup-content .ltkpopup-legend-styling .ltklegend-regular{font-weight:400;text-transform:none;font-size:8px;line-height:16px;color:#000;display:block}#ltkpopup-content .ltkpopup-column{width:50%;display:block;float:left}#ltkpopup-content .ltkpopup-checkbox{float:left;width:100%}#ltkpopup-content .ltkpopup-checkbox label{display:block;position:relative;padding:0px 0px 3px;cursor:pointer;font-size:14px;margin-top:9px;margin-bottom:0;font-weight:400}#ltkpopup-content .ltkpopup-checkbox label:before{position:absolute !important;display:block;float:left;text-align:center;content:"";width:14px;height:14px;border:1px solid #000}#ltkpopup-content .ltkpopup-checkbox label span{display:block;padding:0px 0 0 24px;line-height:17px}#ltkpopup-content .ltkpopup-checkbox input:checked+label::before{font-family:FontAwesome;content:"\\f00c";color:#000;font-size:14px;line-height:14px}#ltkpopup-content .ltkpopup-checkbox input:focus+label::before,#ltkpopup-content .ltkpopup-checkbox input:hover+label::before{border-color:#000}#ltkpopup-content .ltkpopup-checkbox input:checked:hover+label::before{opacity:.7}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content fieldset#ltkpopup-options{display:block;margin-top:15px}}#ltkpopup-content .dropdown{position:relative;width:100%;height:32px;margin:10px 0;padding:0;font-size:12px;font-weight:400;text-overflow:ellipsis;border-radius:0 !important;cursor:pointer}#ltkpopup-content .dropdown select{width:100%;height:100%;padding:0 10px;z-index:1;font-family:Arial,Helvetica,sans-serif;font-size:12px;font-weight:400;color:#000;text-indent:0 !important;background:#fff;border:1px solid #000;border-radius:0;cursor:pointer;-webkit-appearance:none !important;-moz-appearance:none !important;appearance:none !important}#ltkpopup-content .dropdown select:focus{border-color:#000;outline:none}#ltkpopup-content .dropdown::before{position:absolute;display:block;right:10px;top:50%;margin-top:-10px;z-index:2;font-family:FontAwesome;font-size:14px;content:"\\f0d7";color:#000;pointer-events:none;-webkit-transition:all .25s linear;transition:all .25s linear}#ltkpopup-content .dropdown select::-ms-expand{display:none !important}#ltkpopup-content input.ltkinputnotvalid,#ltkpopup-content div.dropdown.ltk-select-notvalid,#ltkpopup-content div.dropdown select.ltkinputnotvalid{border-color:red}#ltkpopup-content input.ltkinputnotvalid:focus,#ltkpopup-content div.dropdown.ltk-select-notvalid:focus,#ltkpopup-content div.dropdown select.ltkinputnotvalid:focus{border-color:red}#ltkpopup-content input.ltkinputnotvalid::-webkit-input-placeholder{color:red}#ltkpopup-content input.ltkinputnotvalid::-moz-placeholder{color:red}#ltkpopup-content input.ltkinputnotvalid:-ms-input-placeholder{color:red}#ltkpopup-content .ltkpopup-error-message{display:block;height:14px;text-align:center;line-height:14px;width:100%;font-size:10px;color:red;font-weight:700}#ltkpopup-content .ltkpopup-error-message:empty{visibility:hidden}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-error-message{line-height:14px;font-size:10px}}#ltkpopup-content .ltkpopup-button-container{position:relative;width:100%;overflow:hidden}#ltkpopup-content .ltkpopup-button-container.ltkpopup-flex{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;flex-wrap:wrap;-ms-flex-wrap:wrap;-webkit-box-align:center;-moz-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center;margin-top:15px;text-align:center}#ltkpopup-content .ltkpopup-subscribe,#ltkpopup-content .ltkpopup-close-button,#ltkpopup-content .ltkpopup-faux-subscribe{display:inline-block;position:relative;width:100%;max-width:320px;margin:auto;padding:7px;vertical-align:middle;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:400;color:#fff;height:32px;text-decoration:none;background-color:#000;border:1px solid #000;border-radius:0 !important;box-shadow:none !important;cursor:pointer;outline:none;-webkit-appearance:none !important;-moz-appearance:none !important;appearance:none !important;-webkit-transition:all .25s linear;transition:all .25s linear;transition:.25s;overflow:hidden}#ltkpopup-content .ltkpopup-subscribe span,#ltkpopup-content .ltkpopup-close-button span,#ltkpopup-content .ltkpopup-faux-subscribe span{position:relative;z-index:1}#ltkpopup-content .ltkpopup-subscribe:hover,#ltkpopup-content .ltkpopup-close-button:hover,#ltkpopup-content .ltkpopup-faux-subscribe:hover{color:#fff;background-color:#858585;border-color:#858585}#ltkpopup-content .ltkpopup-subscribe:focus,#ltkpopup-content .ltkpopup-close-button:focus,#ltkpopup-content .ltkpopup-faux-subscribe:focus{color:#fff;background-color:#858585;border-color:#858585;transition:0s}#ltkpopup-content .ltkpopup-close-button{float:none;margin:10px auto 0px;line-height:normal}#ltkpopup-content .ltkpopup-no-thanks{float:none;width:100%;text-align:center}#ltkpopup-content .ltkpopup-no-thanks a,#ltkpopup-content .ltkpopup-no-thanks button{background:none;border:none;display:inline-block;padding:10px;font-size:12px;font-weight:400;color:#000;text-decoration:underline;-webkit-transition:all .25s linear;transition:all .25s linear;cursor:pointer;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content .ltkpopup-no-thanks a:hover,#ltkpopup-content .ltkpopup-no-thanks a:focus,#ltkpopup-content .ltkpopup-no-thanks button:hover,#ltkpopup-content .ltkpopup-no-thanks button:focus{text-decoration:none}#ltkpopup-content .ltkpopup-float-fields{width:350px;margin:0 auto}#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button{width:100px;float:left}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-subscribe,#ltkpopup-content .ltkpopup-close-button,#ltkpopup-content .ltkpopup-faux-subscribe{font-size:16px;margin-top:5px}#ltkpopup-content .ltkpopup-no-thanks a,#ltkpopup-content .ltkpopup-no-thanks button{font-size:12px}#ltkpopup-content .ltkpopup-float-fields{width:100%}#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button{width:100%}}',
            confirmationHTML: '\n\t\t\t\t\t\t\t<!-- Pop-up Confirm / Appears after user submits Popup Form -->\n<div id="ltkpopup-wrapper" class="confirm ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n\t<!-- Custom Fonts can be placed below if applicable -->\n\n\t<link rel="stylesheet" href="https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/fontawesomev5.min.css">\n\n\t<!-- Main Popup Content Area -->\n\t<!-- Add class ltkpopup-no-padd for split popups -->\n\t<div id="ltkpopup-content" class="ltkpopup-confirm ltkpopup-no-padd">\n\n\t\t<!-- Pull in the popup container -->\n\t\t<div class="ltkpopup-clearfix ltkpopup-split-content ">\n\n\t\t\t<div class="ltkpopup-contain-img" id="ltkpopup-img-contained">\n\t\t\t\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/NW_EMAIL_POPUP_IMG_600x840-min.jpg" alt="" class="ltkpopup-img-fluid" aria-hidden="true">\n\t\t\t<\/div>\n\n\t\t\t<div class="ltkpopup-contain-form">\n\n\t\t\t\t<div class="ltkpopup-form-control">\n\n\t\t\t\t\t<div class="ltkpopup-content-wrap">\n\n\t\t\t\t\t\t<h1 id="ltkpopup-headline" class="ltkpopup-headline">THANK YOU<\/h1>\n\t\t\t\t\t\t<h2 id="ltkpopup-subheadline" class="ltkpopup-subheadline">You have been subscribed.<\/h2>\n\t\t\t\t\t\t<p id="ltkpopup-content-para" class="ltkpopup-content-para">To apply your 15% off coupon now, click below.<\/p>\n\n\t\t\t\t\t\t<div class="ltkpopup-button-container" id="ltkpopup-thanks">\n\t\t\t\t\t\t\t<a tabindex="0" class="ltkpopup-close-button ltkpopup-close" href="https://ninewest.com/discount/WELCOME15">APPLY COUPON<\/a>\n\t\t\t\t\t\t<\/div>\n\n\t\t\t\t\t<\/div>\n\t\t\t\t<\/div>\n\n\t\t\t<\/div>\n\n\t\t<\/div>\n\n\n\t\t<!-- End Content Information -->\n\n\t\t<!-- Close \'X\' Button -->\n\t\t<!-- Add class ltkpopup-circle-close to create a circle close button -->\n\t\t<div id="ltkpopup-close-button" class="ltkpopup-circle-close">\n\t\t\t<a class="ltkpopup-close" tabindex="0" role="button" aria-label="close">\n\t\t\t\t<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">\n\t\t\t\t\t<line x1="1" y1="1" x2="28" y2="28" />\n\t\t\t\t\t<line x1="28" y1="1" x2="1" y2="28" />\n\t\t\t\t<\/svg>\n\t\t\t<\/a>\n\t\t<\/div>\n\t<\/div>\n<\/div>\n\n<script>\n\t// Browsers\n\tvar b = document.documentElement;\n\tb.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n\tvar $html = jQuery("html"),\n\t\tua = $html.data("useragent"),\n\t\tpf = $html.data("platform");\n\n\tfunction is(e) {\n\t\treturn ua.indexOf(e) > -1\n\t}\n\tvar browser = {\n\t\tisIE: is("msie") || is("trident/7.0"),\n\t\tisIE7: is("msie 7.0"),\n\t\tisIE8: is("msie 8.0"),\n\t\tisIE9: is("msie 9.0"),\n\t\tisIE10: is("msie 10"),\n\t\tisIE11: is("rv:11") && is("trident/7.0"),\n\t\tisEdge: is("edge"),\n\t\tisChrome: is("chrome") && !is("edge"),\n\t\tisSafari: is("safari") && !is("chrome") && !is("edge"),\n\t\tisFirefox: is("firefox") && !is("edge"),\n\t\tisAndroidChrome: is("android") && is("chrome"),\n\t\tisAndroidDefault: is("android") && !is("chrome"),\n\t\tisWin7: is("windows nt 6.1"),\n\t\tisWin8: is("windows nt 6.2"),\n\t\tisWindows: pf.indexOf("win32") > -1,\n\t\tisWebkit: is("webkit") && !is("edge"),\n\t\tisIPad: is("ipad"),\n\t\tisIPadChrome: is("ipad") && is("crios"),\n\t\tisIPhone: is("iphone"),\n\t\tisIPhoneChrome: is("iphone") && is("crios"),\n\t\tisAndroid: is("android"),\n\t\tisIOS: is("iphone") || is("ipad")\n\t};\n\tfor (var title in browser) {\n\t\tvar helperClass = title.slice(2).toLowerCase();\n\t\tbrowser[title] && jQuery("#ltkpopup-content").addClass(helperClass)\n\t}\n\n\t// Close Function\n\tjQuery(\'.ltkpopup-close\').focus(function () {\n\t\tjQuery(\'.ltkpopup-close\').keypress(function (e) {\n\t\t\tvar key = e.which;\n\t\t\tif (key == 13) {\n\t\t\t\tjQuery(\'#ltkpopup-overlay, #ltkpopup-container\').remove()\n\t\t\t}\n\t\t})\n\t});\n\n\t// Check Input Validity\n\tfunction checkInputValidity(inputEl) {\n\t\tjQuery(inputEl).removeClass("ltkinputnotvalid");\n\t\tvar ltkErrorMessage = jQuery("[data-ltkpopup-error-for=\'" + inputEl.id + "\'");\n\t\tjQuery(ltkErrorMessage).text("");\n\t\tinputEl.checkValidity();\n\t\tif (jQuery(inputEl).is(\':invalid\')) {\n\t\t\tjQuery(inputEl).addClass("ltkinputnotvalid");\n\t\t\tvar ltkErrorMessageText = jQuery(ltkErrorMessage).attr("data-ltkpopup-message");\n\t\t\tjQuery(ltkErrorMessage).text(ltkErrorMessageText);\n\t\t\treturn false;\n\t\t}\n\t\treturn true;\n\t}\n\n\n\n\tchangeFocus = function () {\n\t\tif (document.getElementById("ltkpopup-email") == undefined && document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined) {\n\t\t\tdocument.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n\t\t}\n\t}\n\n\t// Tab Trapping\n\tjQuery(document).ready(function () {\n\t\tsetTimeout(function () {\n\t\t\tfunction triggerFocus(element) {\n\t\t\t\tvar eventType = "onfocusin" in element ? "focusin" : "focus",\n\t\t\t\t\tbubbles = "onfocusin" in element,\n\t\t\t\t\tevent;\n\n\t\t\t\tif ("createEvent" in document) {\n\t\t\t\t\tevent = document.createEvent("Event");\n\t\t\t\t\tevent.initEvent(eventType, bubbles, true);\n\t\t\t\t} else if ("Event" in window) {\n\t\t\t\t\tevent = new Event(eventType, {\n\t\t\t\t\t\tbubbles: bubbles,\n\t\t\t\t\t\tcancelable: true\n\t\t\t\t\t});\n\t\t\t\t}\n\n\t\t\t\telement.focus();\n\t\t\t\telement.dispatchEvent(event);\n\t\t\t}\n\t\t\tif (document.getElementById("ltkpopup-email") != undefined) {\n\t\t\t\ttriggerFocus(document.getElementById("ltkpopup-email"));\n\t\t\t} else {\n\t\t\t\tchangeFocus();\n\t\t\t}\n\t\t}, 0);\n\t});\n\n\tfunction trapTabKey(e) {\n\t\tvar t = document.activeElement,\n\t\t\ts = focusableElems.indexOf(t);\n\t\tif (9 === e.keyCode) {\n\t\t\te.preventDefault();\n\t\t\tmoveTab(s, e.shiftKey)\n\t\t}\n\t}\n\n\tfunction moveTab(index, shift) {\n\t\tvar nextTab = null;\n\t\tvar nextIndex = index;\n\t\tif (shift) {\n\t\t\tif (focusableElems[index] == firstTabStop) {\n\t\t\t\tnextTab = lastTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index - 1;\n\t\t\t\tnextTab = focusableElem[nextIndex];\n\t\t\t}\n\t\t} else {\n\t\t\tif (focusableElems[index] == lastTabStop) {\n\t\t\t\tnextTab = firstTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index + 1;\n\t\t\t\tnextTab = focusableElems[nextIndex];\n\t\t\t}\n\t\t}\n\n\t\tif (jQuery(nextTab).is(":visible")) {\n\t\t\tnextTab.focus();\n\t\t} else {\n\t\t\tmoveTab(nextIndex, shift);\n\t\t}\n\t}\n\twindow.onload = function () {\n\t\tvar e = document.getElementById("ltkpopup-img-contained");\n\t\te && (2 == window.getComputedStyle(e).getPropertyValue("order") && (e.className += " ltkpopup-img-right"))\n\t}, setTimeout(function () {\n\t\t//Do not delete - tab functionality will break\n\t\t_ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n\t\tchangeFocus();\n\t}, 50);\n\tvar focused = document.activeElement;\n\tjQuery(".ltkpopup-close").on("click", function () {\n\t\tfocused.focus()\n\t});\n\tvar focusBox = document.getElementById("ltkpopup-content"),\n\t\tfocusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n\t\tfocusableElem = focusBox.querySelectorAll(focusableElemStr),\n\t\tfocusableElems = Array.prototype.slice.call(focusableElem),\n\t\tfirstTabStop = focusableElems[0],\n\t\tlastTabStop = focusableElems[focusableElems.length - 1];\n\tfocusBox.addEventListener("keydown", trapTabKey);\n\n\n\t$("body").bind("DOMSubtreeModified", function () {\n\t\tif ($(\'#smile-ui-container\')) {\n\t\t\t$(\'#smile-ui-container\').css(\'z-index\', \'999\');\n\t\t}\n\t});\n<\/script>\n\t\t\t\t\t\t',
            animation: null,
            urlRedirect: null,
            initialDelay: 2,
            buttonSettings: {
                size: 1,
                shape: 1,
                alignment: 2,
                text: "Subscribe",
                color: "#00BDE5",
                textColor: "#FFFFFF"
            },
            urlRules: [{
                urlMatchRule: 1,
                show: !1,
                url: "/account/"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "/cart"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "/checkouts/"
            }],
            targetingRules: {
                showWhenDevice: ["Desktop", "Mobile"]
            },
            subscriptionPoint: "Popup",
            engagement: {
                followUpTimeframe: 0,
                showWhenPageSession: 1,
                followUp: !0,
                followUpDelay: 30,
                showIfFromListrakEmail: !1
            },
            overlayClose: !0,
            referrerRule: null
        }
    }, {
        type: 1,
        category: 0,
        popupUID: "fdb5cefc-3916-49a4-9245-f1550c06653f",
        popupName: "NW- SS22 - Entry Popup",
        clientUID: "4812bcb7-32f3-4732-92d1-a34659911750",
        companyID: 0,
        isActive: !1,
        lastModified: "2022-11-16T14:42:33.633Z",
        settings: {
            scrollDepth: 0,
            isTestMode: !0,
            formHTML: '<!-- Pop-up Form -->\n<!-- ltkpopup-no-scroll: centers the popup on display by preventing the page from scrolling -->\n<!-- ltkpopup-ios-fix: keeps fixed position popups like bottom banners in place in iOS -->\n<div id="ltkpopup-wrapper" class="ltkpopup-signup ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n        <!-- Custom Fonts can be placed below if applicable -->\n        \n        <link rel="stylesheet" href="https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/fontawesomev5.min.css">\n\n\n        <!-- Main Popup Content Area -->\n        <!-- Add class ltkpopup-no-padd for split popups -->\n        <div id="ltkpopup-content" class="ltkpopup-signup ltkpopup-no-padd">\n\n\n                <!-- Pull in the popup container -->\n                <div class="ltkpopup-clearfix ltkpopup-split-content ">\n\n\n        <div class="ltkpopup-contain-img" id="ltkpopup-img-contained">\n                <img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F22/NW_EMAIL_POPUP_IMG_1440x840_SIGNUP.jpg" alt="" class="ltkpopup-img-fluid" aria-hidden="true">\n        <\/div>\n\n\n        <div class="ltkpopup-contain-form">\n\n\n                <div class="ltkpopup-form-control">\n\n\n                        <div class="ltkpopup-content-wrap">\n                                <h1 id="ltkpopup-headline" class="ltkpopup-headline">RECEIVE 15% OFF <span class="ltkpopup-subheadline">WHEN YOU SUBSCRIBE TODAY!<\/span><\/h1>\n<p id="ltkpopup-content-para" class="ltkpopup-content-para">Get the latest on new arrivals, trends, sales, and exclusive&nbsp;offers.<\/p>\n\n\n                                <div class="ltkpopup-form-contain" id="ltkpopup-form">\n\n\n                                        <div class="ltkpopup-form-contain">\n\n\n        <div class="ltkpopup-form-control">\n\n\n                <!-- Email Input Required Error Message|Moved out of column for display purposes -->\n                <div class="ltkpopup-error-message" aria-live="assertive" data-ltkpopup-error-for="ltkpopup-email" data-ltkpopup-message="Please enter a valid email address"><\/div>\n                \n                <label class="ltkpopup-visuallyhidden" for="ltkpopup-email">Email Address<\/label>\n<input autofocus required type="email" id="ltkpopup-email" class="ltkpopup-email" tabindex="0" name="ltkpopup-email" placeholder="Email Address (required)" autocomplete="email" pattern="^([a-zA-Z0-9._+!-]+[@](?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,})$" onchange="_ltk.SCA.Update(\'email\', this.value)" />\n\n\n        <\/div>\n\n\n        <div class="ltkpopup-form-control">\n                \n                <!-- Phone Input Required Error Message | Moved out of column for display purposes -->\n                <div class="ltkpopup-error-message" aria-live="assertive" data-ltkpopup-error-for="ltkpopup-phone" data-ltkpopup-message="Please enter a valid phone number"><\/div>\n\n\n                <label class="ltkpopup-visuallyhidden" for="ltkpopup-phone">Mobile Phone<\/label>\n<input type="tel" id="ltkpopup-phone" class="ltkpopup-email" tabindex="0" name="ltkpopup-phone" placeholder="Mobile Number (optional)" autocomplete="tel" data-inputmask="\'mask\': \'(###) ###-####\'" pattern="^\\D?(\\d{3})\\D?\\D?(\\d{3})\\D?(\\d{4})$" />\n                \n        <\/div>\n\n\n        <!-- Emmet Snippets if applicable -->\n        <!-- zip error dropdown checkbox radio sms-capture -->\n\n\n        <!-- Button Container -->\n        <div class="ltkpopup-button-container ltkpopup-flex ltkpopup-clearfix">\n                <!-- Submit Button -->\n                <button id="ltkpopup-submit" class="ltkpopup-subscribe" tabindex="0" type="submit"><span>SIGN UP NOW<\/span><\/button>\n\n\n                <!-- Text Close Button -->\n                <div class="ltkpopup-no-thanks ltkpopup-visuallyhidden" id="ltkpopup-text-btn">\n                        <!-- Do Not Delete. Add class ltkpopup-visuallyhidden -->\n                        <button tabindex="0" class="ltkpopup-close">maybe later<\/button>\n                <\/div>\n        <\/div>\n\n\n<\/div>\n\n\n                                <\/div>\n\n\n                                <p class="ltkpopup-content-para ltkpopup-disclaimer">By providing your number above, you agree to receive recurring autodialed marketing text msgs to the mobile number used at opt-in from Nine West on 69629. Consent is not a condition of purchase. Msg frequency may vary. Msg & data rates may apply. Reply HELP for help and STOP to cancel.<br><br>See <a href="http://ninewest.com/policies/terms-of-service" target="_blank">Terms and Conditions<\/a> &amp; <a href="http://ninewest.com/policies/privacy-policy" target="_blank">Privacy&nbspPolicy<\/a>.<\/p>\n\n\n                        <\/div>\n                <\/div>\n\n\n        <\/div>\n\n\n<\/div>\n                \n\n\n                <!-- Emmet Snippets if applicable -->\n                <!-- zip error dropdown checkbox radio sms-capture -->\n\n\n                <!-- Do Not Delete. Connects the Popup to Segmentation within the Listrak platform. Input name needs to match segmentation -->\n                <div class="ltkpopup-source">\n                        <input type="hidden" class="text" name="Source.Popup" value="On" tabindex="-1" />\n                <\/div>\n\n\n                <!-- Close \'X\' Button -->\n                <!-- Add class ltkpopup-circle-close to create a circle close button -->\n<div id="ltkpopup-close-button" class="ltkpopup-circle-close">\n        <a class="ltkpopup-close" tabindex="0" role="button" aria-label="close">\n                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">\n                        <line x1="1" y1="1" x2="28" y2="28" />\n                        <line x1="28" y1="1" x2="1" y2="28" />\n                <\/svg>\n        <\/a>\n<\/div>\n\n\n        <\/div>\n        <!-- End ltkpopup-content -->\n\n\n<\/div>\n<!-- End ltkpopup-wrapper -->\n\n\n<script>\n        var emailVal;\n        jQuery(\'#ltkpopup-submit\').on(\'click\', function () {\n                emailVal = jQuery(\'#ltkpopup-email\').val();\n                phoneVal = jQuery(\'#ltkpopup-phone\').val();\n                var e = jQuery(":input");\n                jQuery(e).each(function (e) {\n                        checkInputValidity(this);\n                        if (jQuery(this).is(":invalid")) {\n                                this.setAttribute("aria-describedby", this.id + "-error-message");\n                        } else {\n                                this.removeAttribute("aria-describedby")\n                        }\n                });\n                setTimeout(function () {\n                        if (document.querySelector(".ltkinputnotvalid") != null) {\n                                document.querySelector(".ltkinputnotvalid").focus();\n                        }\n                }, 0);\n        });\n<\/script>\n\n\n<script>\n        // Browsers\n        var b = document.documentElement;\n        b.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n        var $html = jQuery("html"),\n                ua = $html.data("useragent"),\n                pf = $html.data("platform");\n\n\n        function is(e) {\n                return ua.indexOf(e) > -1\n        }\n        var browser = {\n                isIE: is("msie") || is("trident/7.0"),\n                isIE7: is("msie 7.0"),\n                isIE8: is("msie 8.0"),\n                isIE9: is("msie 9.0"),\n                isIE10: is("msie 10"),\n                isIE11: is("rv:11") && is("trident/7.0"),\n                isEdge: is("edge"),\n                isChrome: is("chrome") && !is("edge"),\n                isSafari: is("safari") && !is("chrome") && !is("edge"),\n                isFirefox: is("firefox") && !is("edge"),\n                isAndroidChrome: is("android") && is("chrome"),\n                isAndroidDefault: is("android") && !is("chrome"),\n                isWin7: is("windows nt 6.1"),\n                isWin8: is("windows nt 6.2"),\n                isWindows: pf.indexOf("win32") > -1,\n                isWebkit: is("webkit") && !is("edge"),\n                isIPad: is("ipad"),\n                isIPadChrome: is("ipad") && is("crios"),\n                isIPhone: is("iphone"),\n                isIPhoneChrome: is("iphone") && is("crios"),\n                isAndroid: is("android"),\n                isIOS: is("iphone") || is("ipad")\n        };\n        for (var title in browser) {\n                var helperClass = title.slice(2).toLowerCase();\n                browser[title] && jQuery("#ltkpopup-content").addClass(helperClass)\n        }\n\n\n        // Close Function\n        jQuery(\'.ltkpopup-close\').focus(function () {\n                jQuery(\'.ltkpopup-close\').keypress(function (e) {\n                        var key = e.which;\n                        if (key == 13) {\n                                jQuery(\'#ltkpopup-overlay, #ltkpopup-container\').remove()\n                        }\n                })\n        });\n\n\n        // Check Input Validity\n        function checkInputValidity(inputEl) {\n                jQuery(inputEl).removeClass("ltkinputnotvalid");\n                var ltkErrorMessage = jQuery("[data-ltkpopup-error-for=\'" + inputEl.id + "\'");\n                jQuery(ltkErrorMessage).text("");\n                inputEl.checkValidity();\n                if (jQuery(inputEl).is(\':invalid\')) {\n                        jQuery(inputEl).addClass("ltkinputnotvalid");\n                        var ltkErrorMessageText = jQuery(ltkErrorMessage).attr("data-ltkpopup-message");\n                        jQuery(ltkErrorMessage).text(ltkErrorMessageText);\n                        return false;\n                }\n                return true;\n        }\n\n\n\n\n\n\n        changeFocus = function () {\n                if (document.getElementById("ltkpopup-email") == undefined && document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined) {\n                        document.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n                }\n        }\n\n\n        // Tab Trapping\n        jQuery(document).ready(function () {\n                setTimeout(function () {\n                        function triggerFocus(element) {\n                                var eventType = "onfocusin" in element ? "focusin" : "focus",\n                                        bubbles = "onfocusin" in element,\n                                        event;\n\n\n                                if ("createEvent" in document) {\n                                        event = document.createEvent("Event");\n                                        event.initEvent(eventType, bubbles, true);\n                                } else if ("Event" in window) {\n                                        event = new Event(eventType, {\n                                                bubbles: bubbles,\n                                                cancelable: true\n                                        });\n                                }\n\n\n                                element.focus();\n                                element.dispatchEvent(event);\n                        }\n                        if (document.getElementById("ltkpopup-email") != undefined) {\n                                triggerFocus(document.getElementById("ltkpopup-email"));\n                        } else {\n                                changeFocus();\n                        }\n                }, 0);\n        });\n\n\n        function trapTabKey(e) {\n                var t = document.activeElement,\n                        s = focusableElems.indexOf(t);\n                if (9 === e.keyCode) {\n                        e.preventDefault();\n                        moveTab(s, e.shiftKey)\n                }\n        }\n\n\n        function moveTab(index, shift) {\n                var nextTab = null;\n                var nextIndex = index;\n                if (shift) {\n                        if (focusableElems[index] == firstTabStop) {\n                                nextTab = lastTabStop;\n                        } else {\n                                nextIndex = index - 1;\n                                nextTab = focusableElem[nextIndex];\n                        }\n                } else {\n                        if (focusableElems[index] == lastTabStop) {\n                                nextTab = firstTabStop;\n                        } else {\n                                nextIndex = index + 1;\n                                nextTab = focusableElems[nextIndex];\n                        }\n                }\n\n\n                if (jQuery(nextTab).is(":visible")) {\n                        nextTab.focus();\n                } else {\n                        moveTab(nextIndex, shift);\n                }\n        }\n        window.onload = function () {\n                var e = document.getElementById("ltkpopup-img-contained");\n                e && (2 == window.getComputedStyle(e).getPropertyValue("order") && (e.className += " ltkpopup-img-right"))\n        }, setTimeout(function () {\n                //Do not delete - tab functionality will break\n                _ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n                changeFocus();\n        }, 50);\n        var focused = document.activeElement;\n        jQuery(".ltkpopup-close").on("click", function () {\n                focused.focus()\n        });\n        var focusBox = document.getElementById("ltkpopup-content"),\n                focusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n                focusableElem = focusBox.querySelectorAll(focusableElemStr),\n                focusableElems = Array.prototype.slice.call(focusableElem),\n                firstTabStop = focusableElems[0],\n                lastTabStop = focusableElems[focusableElems.length - 1];\n        focusBox.addEventListener("keydown", trapTabKey);\n\n\n        \n        $("body").bind("DOMSubtreeModified", function() {\n            if($(\'#smile-ui-container\')){\n                        $(\'#smile-ui-container\').css(\'z-index\',\'999\');\n                }\n        });\n<\/script>\n<script>\n    jQuery(document).ready(function () {\n\n\n        if (jQuery("[data-inputmask]").length) {\n            \n                // Input masking for number validation - Get Jquery Input Mask from CDN and load it\n                jQuery.getScript(\n                    "https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.1/jquery.inputmask.bundle.js",\n                    function () {\n                        jQuery("[data-inputmask]").each(function() {\n                             // Mask phone number input after script is loaded\n                            jQuery(this).inputmask({greedy: false, showMaskOnHover: false, definitions: {\n                            \'#\': { validator: "[0-9]", cardinality: 1\n                            }\n                            }\n                            });\n                        });\n                    });\n        }\n    });\n<\/script>\n<script>\n        var datepickerField = document.querySelector("#ltkpopup-datepicker");\n        if (datepickerField != null) {\n                var jQueryUIcss = document.createElement("link");\n                jQueryUIcss.href = "https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css";\n                jQueryUIcss.rel = "stylesheet";\n                jQueryUIcss.addEventListener("load", function () {\n                        var jQueryUI = document.createElement("script");\n                        jQueryUI.src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js";\n                        jQueryUI.addEventListener("load", function () {\n                                datepickerField.setAttribute("readonly", "");\n                                jQuery(datepickerField).datepicker({\n                                        changeMonth: true,\n                                        changeYear: false,\n                                        yearRange: \'-0:+0\',\n                                        // use for different date format and hidden bday field\n                                        dateFormat: "mm/dd",\n                                        altField: "#ltkpopup-hidden-bday",\n                                        altFormat: "mm/dd/1900"\n                                });\n\n\n                                jQuery(datepickerField).focus(function () {\n                                        jQuery(\'#ui-datepicker-div\').appendTo(this.parentNode);\n                                });\n                        });\n                        document.getElementById("ltkpopup-content").appendChild(jQueryUI);\n                });\n                document.getElementById("ltkpopup-content").appendChild(jQueryUIcss);\n        }\n<\/script>',
            formCSS: '#ltkpopup-wrapper .ltkpopup-clearfix::before,#ltkpopup-wrapper .ltkpopup-clearfix::after{content:"";display:table}#ltkpopup-wrapper .ltkpopup-clearfix::after{clear:both}#ltkpopup-wrapper .ltkpopup-clearfix{zoom:1}.ios-only{position:fixed}.ltkpopup-visuallyhidden{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);border:0}.ltkpopup-visuallyhidden.focusable:active,.ltkpopup-visuallyhidden.focusable:focus{position:static;width:auto;height:auto;margin:0;overflow:visible;clip:auto}.ltkpopup-img-fluid{width:100%;height:auto}.ltkpopup-full-width{width:100% !important;max-width:100% !important}.ltkpopup-content-wrap{max-width:450px;margin:0 auto}#ltkpopup-thanks{text-align:center}#ltkpopup-thanks input{display:inline-block}#smile-ui-container,#keyboard-nav-34,#keyboard-nav-37{z-index:99990 !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-wrapper .mobileHide{display:none}}#ltkpopup-content .ltk-grid{margin:0 auto;width:100%}#ltkpopup-content .ltk-row{padding-bottom:20px}#ltkpopup-content .ltk-row:last-of-type{padding-bottom:0px}#ltkpopup-content .ltk-col-1{width:100%}#ltkpopup-content .ltk-col-1-2{width:50%}#ltkpopup-content .ltk-col-2-3{width:66.66%}#ltkpopup-content .ltk-col-1-3{width:33.33%}#ltkpopup-content [class*=\'ltk-col-\']{float:left}#ltkpopup-content [class*=\'ltk-col-\']{padding-right:0}#ltkpopup-content [class*=\'ltk-col-\']:last-of-type{padding-right:0;padding-left:10px}#ltkpopup-content .ltk-col-1-3{padding-right:14px}#ltkpopup-content .ltk-col-1-3+.ltk-col-1-3{padding-right:6px;padding-left:6px}#ltkpopup-content .ltk-col-1-3:last-of-type{padding-right:0;padding-left:0}#ltkpopup-content .ltk-col-1,#ltkpopup-content .ltk-col-1:last-of-type{padding-right:0;padding-top:0;padding-left:0}#ltkpopup-overlay{z-index:100001 !important;position:fixed !important;top:0 !important;bottom:0 !important;width:100% !important;height:100% !important;background-color:#000 !important;opacity:.5 !important;-webkit-transition:all .25s ease-in;transition:all .25s ease-in}#ltkpopup-container{z-index:100010 !important;position:fixed !important;width:710px !important;height:auto !important;max-height:100%;top:50% !important;left:50% !important;margin-left:0 !important;-webkit-transform:translate(-50%, -50%) !important;-moz-transform:translate(-50%, -50%) !important;-ms-transform:translate(-50%, -50%) !important;transform:translate(-50%, -50%) !important;overflow-x:hidden;overflow-y:auto;-webkit-box-shadow:0 5px 15px rgba(0,0,0,0.5);-moz-box-shadow:0 5px 15px rgba(0,0,0,0.5);box-shadow:0 5px 15px rgba(0,0,0,0.5)}#ltkpopup-wrapper{position:relative;margin:0 auto;width:100% !important}#ltkpopup-container .simpleltkmodal-wrap{overflow:visible !important}#ltkpopup-wrapper *{box-sizing:border-box;backface-visibility:hidden !important}#ltkpopup-wrapper{background:transparent;font-size:12px;font-family:Arial,Helvetica,sans-serif;-webkit-font-smoothing:subpixel-antialiased}#ltkpopup-wrapper .no-wrap{white-space:nowrap}#ltkpopup-content{padding:3em;font-size:12px;text-align:left;color:#000;line-height:1.4;background:#f8f8fa}.ltkpopup-fullscreen{position:relative;max-width:710px;height:auto !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-container{width:100% !important;height:100% !important}#ltkpopup-wrapper{width:320px !important}#ltkpopup-content{float:none;width:100%;padding:40px 20px 30px 20px}}#ltkpopup-content .ltkpopup-split-content{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-webkit-box-align:center;-moz-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img{max-width:300px;-webkit-box-flex:0 0 300px;-moz-box-flex:0 0 300px;-webkit-flex:0 0 300px;-ms-flex:0 0 300px;flex:0 0 300px;line-height:0;order:2;-ms-flex-order:2}#ltkpopup-content .ltkpopup-split-content.ltkpopup-image-bottom .ltkpopup-contain-img-full{line-height:0}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form{max-width:410px;-webkit-box-flex:0 0 410px;-moz-box-flex:0 0 410px;-webkit-flex:0 0 410px;-ms-flex:0 0 410px;flex:0 0 410px;-ms-flex:0 0 410px;padding:10px 10px 10px;order:1;-ms-flex-order:1}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form .ltkpopup-no-thanks{float:none;text-align:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-full-width{padding-top:30px}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below{flex-wrap:wrap}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form{max-width:100%;-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full{-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%;order:2;line-height:0}#ltkpopup-content.ie6 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie7 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie8 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie9 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie10 .ltkpopup-split-content .ltkpopup-contain-img{width:300px;float:right}#ltkpopup-content.ie6 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie7 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie8 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie9 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie10 .ltkpopup-split-content .ltkpopup-contain-form{width:410px;float:left;padding-top:70px}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below{flex-wrap:wrap}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form{width:100%}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full{width:100%}#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-form{position:relative;left:-2px}#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-img.ltkpopup-img-right img,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-img.ltkpopup-img-right img,#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-form-right,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-form-right{position:relative;right:-2px;left:auto}#ltkpopup-content.safari,#ltkpopup-content.ipad{overflow-x:hidden;overflow-y:hidden}#ltkpopup-content.ie .ltkpopup-split-content,#ltkpopup-content.ie11 .ltkpopup-split-content{padding-bottom:2px}#ltkpopup-content.ie .ltkpopup-split-content .ltkpopup-img-fluid,#ltkpopup-content.ie11 .ltkpopup-split-content .ltkpopup-img-fluid{position:relative;bottom:-1px}#ltkpopup-content.ltkpopup-no-padd{padding:0 !important}#ltkpopup-content.ltkpopup-no-padd .ltkpopup-no-padd{padding:0 !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-formcontent,#ltkpopup-form,#ltkpopup-wrapper{width:100% !important;height:100% !important;background-color:#F8F8FA}#ltkpopup-content{width:100%}#ltkpopup-content .ltkpopup-split-content{width:100%;height:100%;-webkit-align-items:center;-moz-align-items:center;-ms-align-items:center;align-items:center;-webkit-justify-content:center;-moz-justify-content:center;-ms-justify-content:center;justify-content:center;-ms-flex-pack:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img-full,#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img{display:none}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form{width:100%;flex:0 0 100%;-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%;padding:40px 20px 10px}#ltkpopup-content.ltkpopup-confirm .ltkpopup-split-content .ltkpopup-contain-form{padding:40px 20px}}#ltkpopup-close-button{position:absolute;left:7px;top:7px;margin:0px;z-index:10}#ltkpopup-close-button a{display:block;width:12px;height:12px;cursor:pointer}#ltkpopup-close-button a svg{width:100%;height:100%;position:relative;display:block;overflow:visible;stroke:#333;stroke-width:6px;-webkit-transition:all .25s linear;transition:all .25s linear}#ltkpopup-close-button a:hover svg{stroke:#858585}#ltkpopup-close-button a:focus svg{stroke:#858585}#ltkpopup-close-button.ltkpopup-circle-close{right:7px;top:7px}#ltkpopup-close-button.ltkpopup-circle-close a{width:22px;height:22px;background:#FFF;border-radius:50%;padding:4px;border:2px solid #333}#ltkpopup-close-button.ltkpopup-circle-close a:hover,#ltkpopup-close-button.ltkpopup-circle-close a:focus{border-color:#858585}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-close-button{right:7px;top:7px}#ltkpopup-close-button a{width:12px;height:12px}}#ltkpopup-content h1,#ltkpopup-content h2,#ltkpopup-content h3,#ltkpopup-content h4,#ltkpopup-content h5,#ltkpopup-content .ltkpopup-headline,#ltkpopup-content .ltkpopup-subheadline{margin:0;padding:0;text-align:center;font-family:Arial,Helvetica,sans-serif !important}#ltkpopup-content h1,#ltkpopup-content .ltkpopup-headline{font-weight:700;font-size:26px;line-height:30px;color:#000;letter-spacing:1px;margin-bottom:10px;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content h2,#ltkpopup-content .ltkpopup-subheadline{font-weight:400;font-size:14px;line-height:25px;color:#000;display:block;margin-top:10px;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content p,#ltkpopup-content .ltkpopup-content-para{margin:0 0 5px;font-size:12px;line-height:19px;font-family:Arial,Helvetica,sans-serif;text-align:center;letter-spacing:.5px}#ltkpopup-content p.ltkpopup-disclaimer,#ltkpopup-content p.ltkpopup-sms-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer{font-size:8px;line-height:16px;text-align:center;margin:30px 10px 0;letter-spacing:0}#ltkpopup-content p.ltkpopup-disclaimer a,#ltkpopup-content p.ltkpopup-sms-disclaimer a,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a{color:inherit;text-decoration:underline;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content p.ltkpopup-disclaimer a:hover,#ltkpopup-content p.ltkpopup-disclaimer a:focus,#ltkpopup-content p.ltkpopup-sms-disclaimer a:hover,#ltkpopup-content p.ltkpopup-sms-disclaimer a:focus,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:hover,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:focus,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:hover,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:focus{text-decoration:none}#ltkpopup-content p.ltkpopup-disclaimer span,#ltkpopup-content p.ltkpopup-sms-disclaimer span,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer span,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer span{font-weight:700}#ltkpopup-content.ltkpopup-confirm p,#ltkpopup-content.ltkpopup-confirm .ltkpopup-content-para{margin:10px auto}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content h1,#ltkpopup-content .ltkpopup-headline{font-size:26px;line-height:30px}#ltkpopup-content h2,#ltkpopup-content .ltkpopup-subheadline{font-size:14px;line-height:25px}#ltkpopup-content p,#ltkpopup-content .ltkpopup-content-para{font-size:12px;line-height:19px}#ltkpopup-content p.ltkpopup-disclaimer,#ltkpopup-content p.ltkpopup-sms-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer{font-size:8px;line-height:16px}}#ltkpopup-content input[type="text"],#ltkpopup-content input[type="email"],#ltkpopup-content input[type="number"],#ltkpopup-content input[type="tel"]{display:block;width:100%;height:32px;padding:0 1em;margin:0 auto;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:400;text-align:left;color:#000;line-height:normal;background-color:transparent;border:1px solid #000;border-radius:0px !important;box-shadow:inset 0 0 0 1000px #FFF;-webkit-transition:all 0.11s linear;transition:all 0.11s linear;-webkit-appearance:none;-moz-appearance:none;appearance:none}#ltkpopup-content input[type="text"]:focus,#ltkpopup-content input[type="email"]:focus,#ltkpopup-content input[type="number"]:focus,#ltkpopup-content input[type="tel"]:focus{outline:none;border:2px solid #000}#ltkpopup-content input[type="text"]:last-of-type{margin:10px auto 0}#ltkpopup-content .ltkpopup-form-control{position:relative}#ltkpopup-content .ltkpopup-form-contain{max-width:320px;margin:0 auto}#ltkpopup-content input::-webkit-input-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input::-moz-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input:-ms-input-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input::-ms-clear{display:none;width:0;height:0;opacity:0}#ltkpopup-content .ltk-floating-input{width:250px;float:left}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content input[type="text"],#ltkpopup-content input[type="email"],#ltkpopup-content input[type="number"],#ltkpopup-content input[type="tel"]{float:none;width:100%;font-size:15px}#ltkpopup-content .ltk-floating-input{width:100%;padding-bottom:15px}}#ltkpopup-content input[type="radio"]{position:absolute;overflow:hidden;clip:rect(0 0 0 0);height:1px;width:1px;margin:-1px;padding:0;border:0}#ltkpopup-content .radio-wrapper{padding:10px 0;text-align:left}#ltkpopup-content .ltk-radio{position:relative;float:left;width:50%}#ltkpopup-content .ltk-radio label{position:relative;display:block;padding:0px 4px;cursor:pointer}#ltkpopup-content .ltk-radio label::before{position:absolute;display:block;float:left;padding:0 3px 0 0;font-family:FontAwesome;font-size:12px;color:#fff;content:"\\f111";border-radius:0px}#ltkpopup-content .ltk-radio label span{display:block;padding:0 0 0 22px}#ltkpopup-content .ltk-radio input:checked ~ label::before{color:#fff;content:"\\f192"}#ltkpopup-content .ltk-radio input:hover+label::before{color:#000}#ltkpopup-content .ltk-radio input:focus+label::before{color:#fff}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkmodal-wrapper .radio-wrapper{padding:5px 0}}#ltkpopup-content input[type="checkbox"]{position:absolute;overflow:hidden;clip:rect(0 0 0 0);height:1px;width:1px;margin:-1px;padding:0;border:0}#ltkpopup-content fieldset#ltkpopup-options{border:none;margin:5px auto 10px;padding:0;width:100%;max-width:150px}#ltkpopup-content .ltkpopup-legend,#ltkpopup-content .ltkpopup-legend-styling{font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:12px;line-height:19px;text-align:center;color:#000;white-space:normal;margin:0 auto}#ltkpopup-content .ltkpopup-legend .ltklegend-regular,#ltkpopup-content .ltkpopup-legend-styling .ltklegend-regular{font-weight:400;text-transform:none;font-size:8px;line-height:16px;color:#000;display:block}#ltkpopup-content .ltkpopup-column{width:50%;display:block;float:left}#ltkpopup-content .ltkpopup-checkbox{float:left;width:100%}#ltkpopup-content .ltkpopup-checkbox label{display:block;position:relative;padding:0px 0px 3px;cursor:pointer;font-size:14px;margin-top:9px;margin-bottom:0;font-weight:400}#ltkpopup-content .ltkpopup-checkbox label:before{position:absolute !important;display:block;float:left;text-align:center;content:"";width:14px;height:14px;border:1px solid #000}#ltkpopup-content .ltkpopup-checkbox label span{display:block;padding:0px 0 0 24px;line-height:17px}#ltkpopup-content .ltkpopup-checkbox input:checked+label::before{font-family:FontAwesome;content:"\\f00c";color:#000;font-size:14px;line-height:14px}#ltkpopup-content .ltkpopup-checkbox input:focus+label::before,#ltkpopup-content .ltkpopup-checkbox input:hover+label::before{border-color:#000}#ltkpopup-content .ltkpopup-checkbox input:checked:hover+label::before{opacity:.7}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content fieldset#ltkpopup-options{display:block;margin-top:15px}}#ltkpopup-content .dropdown{position:relative;width:100%;height:32px;margin:10px 0;padding:0;font-size:12px;font-weight:400;text-overflow:ellipsis;border-radius:0 !important;cursor:pointer}#ltkpopup-content .dropdown select{width:100%;height:100%;padding:0 10px;z-index:1;font-family:Arial,Helvetica,sans-serif;font-size:12px;font-weight:400;color:#000;text-indent:0 !important;background:#fff;border:1px solid #000;border-radius:0;cursor:pointer;-webkit-appearance:none !important;-moz-appearance:none !important;appearance:none !important}#ltkpopup-content .dropdown select:focus{border-color:#000;outline:none}#ltkpopup-content .dropdown::before{position:absolute;display:block;right:10px;top:50%;margin-top:-10px;z-index:2;font-family:FontAwesome;font-size:14px;content:"\\f0d7";color:#000;pointer-events:none;-webkit-transition:all .25s linear;transition:all .25s linear}#ltkpopup-content .dropdown select::-ms-expand{display:none !important}#ltkpopup-content input.ltkinputnotvalid,#ltkpopup-content div.dropdown.ltk-select-notvalid,#ltkpopup-content div.dropdown select.ltkinputnotvalid{border-color:red}#ltkpopup-content input.ltkinputnotvalid:focus,#ltkpopup-content div.dropdown.ltk-select-notvalid:focus,#ltkpopup-content div.dropdown select.ltkinputnotvalid:focus{border-color:red}#ltkpopup-content input.ltkinputnotvalid::-webkit-input-placeholder{color:red}#ltkpopup-content input.ltkinputnotvalid::-moz-placeholder{color:red}#ltkpopup-content input.ltkinputnotvalid:-ms-input-placeholder{color:red}#ltkpopup-content .ltkpopup-error-message{display:block;height:14px;text-align:center;line-height:14px;width:100%;font-size:10px;color:red;font-weight:700}#ltkpopup-content .ltkpopup-error-message:empty{visibility:hidden}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-error-message{line-height:14px;font-size:10px}}#ltkpopup-content .ltkpopup-button-container{position:relative;width:100%;overflow:hidden}#ltkpopup-content .ltkpopup-button-container.ltkpopup-flex{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;flex-wrap:wrap;-ms-flex-wrap:wrap;-webkit-box-align:center;-moz-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center;margin-top:15px;text-align:center}#ltkpopup-content .ltkpopup-subscribe,#ltkpopup-content .ltkpopup-close-button,#ltkpopup-content .ltkpopup-faux-subscribe{display:inline-block;position:relative;width:100%;max-width:320px;margin:auto;padding:7px;vertical-align:middle;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:400;color:#fff;height:32px;text-decoration:none;background-color:#000;border:1px solid #000;border-radius:0 !important;box-shadow:none !important;cursor:pointer;outline:none;-webkit-appearance:none !important;-moz-appearance:none !important;appearance:none !important;-webkit-transition:all .25s linear;transition:all .25s linear;transition:.25s;overflow:hidden}#ltkpopup-content .ltkpopup-subscribe span,#ltkpopup-content .ltkpopup-close-button span,#ltkpopup-content .ltkpopup-faux-subscribe span{position:relative;z-index:1}#ltkpopup-content .ltkpopup-subscribe:hover,#ltkpopup-content .ltkpopup-close-button:hover,#ltkpopup-content .ltkpopup-faux-subscribe:hover{color:#fff;background-color:#858585;border-color:#858585}#ltkpopup-content .ltkpopup-subscribe:focus,#ltkpopup-content .ltkpopup-close-button:focus,#ltkpopup-content .ltkpopup-faux-subscribe:focus{color:#fff;background-color:#858585;border-color:#858585;transition:0s}#ltkpopup-content .ltkpopup-close-button{float:none;margin:10px auto 0px;line-height:normal}#ltkpopup-content .ltkpopup-no-thanks{float:none;width:100%;text-align:center}#ltkpopup-content .ltkpopup-no-thanks a,#ltkpopup-content .ltkpopup-no-thanks button{background:none;border:none;display:inline-block;padding:10px;font-size:12px;font-weight:400;color:#000;text-decoration:underline;-webkit-transition:all .25s linear;transition:all .25s linear;cursor:pointer;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content .ltkpopup-no-thanks a:hover,#ltkpopup-content .ltkpopup-no-thanks a:focus,#ltkpopup-content .ltkpopup-no-thanks button:hover,#ltkpopup-content .ltkpopup-no-thanks button:focus{text-decoration:none}#ltkpopup-content .ltkpopup-float-fields{width:350px;margin:0 auto}#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button{width:100px;float:left}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-subscribe,#ltkpopup-content .ltkpopup-close-button,#ltkpopup-content .ltkpopup-faux-subscribe{font-size:16px;margin-top:5px}#ltkpopup-content .ltkpopup-no-thanks a,#ltkpopup-content .ltkpopup-no-thanks button{font-size:12px}#ltkpopup-content .ltkpopup-float-fields{width:100%}#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button{width:100%}}',
            confirmationHTML: '\n\t\t\t\t\t\t\t<!-- Pop-up Confirm / Appears after user submits Popup Form -->\n<div id="ltkpopup-wrapper" class="confirm ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n\t<!-- Custom Fonts can be placed below if applicable -->\n\t\n\t<link rel="stylesheet" href="https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/fontawesomev5.min.css">\n\n\t<!-- Main Popup Content Area -->\n\t<!-- Add class ltkpopup-no-padd for split popups -->\n\t<div id="ltkpopup-content" class="ltkpopup-confirm ltkpopup-no-padd">\n\n\t\t<!-- Pull in the popup container -->\n\t\t<div class="ltkpopup-clearfix ltkpopup-split-content ">\n\n\t<div class="ltkpopup-contain-img" id="ltkpopup-img-contained">\n\t\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/SS22/NW_EMAIL_POPUP_IMG_1440x840_SIGNUP_Final.jpg\n" alt="" class="ltkpopup-img-fluid" aria-hidden="true">\n\t<\/div>\n\n\t<div class="ltkpopup-contain-form">\n\n\t\t<div class="ltkpopup-form-control">\n\n\t\t\t<div class="ltkpopup-content-wrap">\n\n\t\t\t\t<h1 id="ltkpopup-headline" class="ltkpopup-headline">THANK YOU<\/h1>\n<h2 id="ltkpopup-subheadline" class="ltkpopup-subheadline">You have been subscribed.<\/h2>\n<p id="ltkpopup-content-para" class="ltkpopup-content-para">To apply your 15% off coupon now, click below.<\/p>\n\n\t\t\t\t<div class="ltkpopup-button-container" id="ltkpopup-thanks">\n    <a tabindex="0" class="ltkpopup-close-button ltkpopup-close" href="https://ninewest.com/discount/WELCOME15">APPLY COUPON<\/a>\n<\/div>\n\n\t\t\t<\/div>\n\t\t<\/div>\n\t\t\n\t<\/div>\n\n<\/div>\n\t\t\n\n\t\t<!-- End Content Information -->\n\n\t\t<!-- Close \'X\' Button -->\n\t\t<!-- Add class ltkpopup-circle-close to create a circle close button -->\n<div id="ltkpopup-close-button" class="ltkpopup-circle-close">\n\t<a class="ltkpopup-close" tabindex="0" role="button" aria-label="close">\n\t\t<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">\n\t\t\t<line x1="1" y1="1" x2="28" y2="28" />\n\t\t\t<line x1="28" y1="1" x2="1" y2="28" />\n\t\t<\/svg>\n\t<\/a>\n<\/div>\n\t<\/div>\n<\/div>\n\n\n<script>\n\tvar reg = /^\\D?(\\d{3})\\D?\\D?(\\d{3})\\D?(\\d{4})$/;\n\tif (typeof phoneVal != "undefined" && phoneVal != "" && phoneVal.match(reg)) {\n\t\t_ltk.Subscriber.Email = phoneVal;\n\t\t_ltk.Subscriber.List = \'DesktopSMS\';\n\t\t_ltk.Subscriber.Profile.Add(\'Email\', emailVal);\n\t\t_ltk.Subscriber.Submit(true);\n\t}\n<\/script>\n<script>\n\t// Browsers\n\tvar b = document.documentElement;\n\tb.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n\tvar $html = jQuery("html"),\n\t\tua = $html.data("useragent"),\n\t\tpf = $html.data("platform");\n\n\tfunction is(e) {\n\t\treturn ua.indexOf(e) > -1\n\t}\n\tvar browser = {\n\t\tisIE: is("msie") || is("trident/7.0"),\n\t\tisIE7: is("msie 7.0"),\n\t\tisIE8: is("msie 8.0"),\n\t\tisIE9: is("msie 9.0"),\n\t\tisIE10: is("msie 10"),\n\t\tisIE11: is("rv:11") && is("trident/7.0"),\n\t\tisEdge: is("edge"),\n\t\tisChrome: is("chrome") && !is("edge"),\n\t\tisSafari: is("safari") && !is("chrome") && !is("edge"),\n\t\tisFirefox: is("firefox") && !is("edge"),\n\t\tisAndroidChrome: is("android") && is("chrome"),\n\t\tisAndroidDefault: is("android") && !is("chrome"),\n\t\tisWin7: is("windows nt 6.1"),\n\t\tisWin8: is("windows nt 6.2"),\n\t\tisWindows: pf.indexOf("win32") > -1,\n\t\tisWebkit: is("webkit") && !is("edge"),\n\t\tisIPad: is("ipad"),\n\t\tisIPadChrome: is("ipad") && is("crios"),\n\t\tisIPhone: is("iphone"),\n\t\tisIPhoneChrome: is("iphone") && is("crios"),\n\t\tisAndroid: is("android"),\n\t\tisIOS: is("iphone") || is("ipad")\n\t};\n\tfor (var title in browser) {\n\t\tvar helperClass = title.slice(2).toLowerCase();\n\t\tbrowser[title] && jQuery("#ltkpopup-content").addClass(helperClass)\n\t}\n\n\t// Close Function\n\tjQuery(\'.ltkpopup-close\').focus(function () {\n\t\tjQuery(\'.ltkpopup-close\').keypress(function (e) {\n\t\t\tvar key = e.which;\n\t\t\tif (key == 13) {\n\t\t\t\tjQuery(\'#ltkpopup-overlay, #ltkpopup-container\').remove()\n\t\t\t}\n\t\t})\n\t});\n\n\t// Check Input Validity\n\tfunction checkInputValidity(inputEl) {\n\t\tjQuery(inputEl).removeClass("ltkinputnotvalid");\n\t\tvar ltkErrorMessage = jQuery("[data-ltkpopup-error-for=\'" + inputEl.id + "\'");\n\t\tjQuery(ltkErrorMessage).text("");\n\t\tinputEl.checkValidity();\n\t\tif (jQuery(inputEl).is(\':invalid\')) {\n\t\t\tjQuery(inputEl).addClass("ltkinputnotvalid");\n\t\t\tvar ltkErrorMessageText = jQuery(ltkErrorMessage).attr("data-ltkpopup-message");\n\t\t\tjQuery(ltkErrorMessage).text(ltkErrorMessageText);\n\t\t\treturn false;\n\t\t}\n\t\treturn true;\n\t}\n\n\n\n\tchangeFocus = function () {\n\t\tif (document.getElementById("ltkpopup-email") == undefined && document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined) {\n\t\t\tdocument.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n\t\t}\n\t}\n\n\t// Tab Trapping\n\tjQuery(document).ready(function () {\n\t\tsetTimeout(function () {\n\t\t\tfunction triggerFocus(element) {\n\t\t\t\tvar eventType = "onfocusin" in element ? "focusin" : "focus",\n\t\t\t\t\tbubbles = "onfocusin" in element,\n\t\t\t\t\tevent;\n\n\t\t\t\tif ("createEvent" in document) {\n\t\t\t\t\tevent = document.createEvent("Event");\n\t\t\t\t\tevent.initEvent(eventType, bubbles, true);\n\t\t\t\t} else if ("Event" in window) {\n\t\t\t\t\tevent = new Event(eventType, {\n\t\t\t\t\t\tbubbles: bubbles,\n\t\t\t\t\t\tcancelable: true\n\t\t\t\t\t});\n\t\t\t\t}\n\n\t\t\t\telement.focus();\n\t\t\t\telement.dispatchEvent(event);\n\t\t\t}\n\t\t\tif (document.getElementById("ltkpopup-email") != undefined) {\n\t\t\t\ttriggerFocus(document.getElementById("ltkpopup-email"));\n\t\t\t} else {\n\t\t\t\tchangeFocus();\n\t\t\t}\n\t\t}, 0);\n\t});\n\n\tfunction trapTabKey(e) {\n\t\tvar t = document.activeElement,\n\t\t\ts = focusableElems.indexOf(t);\n\t\tif (9 === e.keyCode) {\n\t\t\te.preventDefault();\n\t\t\tmoveTab(s, e.shiftKey)\n\t\t}\n\t}\n\n\tfunction moveTab(index, shift) {\n\t\tvar nextTab = null;\n\t\tvar nextIndex = index;\n\t\tif (shift) {\n\t\t\tif (focusableElems[index] == firstTabStop) {\n\t\t\t\tnextTab = lastTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index - 1;\n\t\t\t\tnextTab = focusableElem[nextIndex];\n\t\t\t}\n\t\t} else {\n\t\t\tif (focusableElems[index] == lastTabStop) {\n\t\t\t\tnextTab = firstTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index + 1;\n\t\t\t\tnextTab = focusableElems[nextIndex];\n\t\t\t}\n\t\t}\n\n\t\tif (jQuery(nextTab).is(":visible")) {\n\t\t\tnextTab.focus();\n\t\t} else {\n\t\t\tmoveTab(nextIndex, shift);\n\t\t}\n\t}\n\twindow.onload = function () {\n\t\tvar e = document.getElementById("ltkpopup-img-contained");\n\t\te && (2 == window.getComputedStyle(e).getPropertyValue("order") && (e.className += " ltkpopup-img-right"))\n\t}, setTimeout(function () {\n\t\t//Do not delete - tab functionality will break\n\t\t_ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n\t\tchangeFocus();\n\t}, 50);\n\tvar focused = document.activeElement;\n\tjQuery(".ltkpopup-close").on("click", function () {\n\t\tfocused.focus()\n\t});\n\tvar focusBox = document.getElementById("ltkpopup-content"),\n\t\tfocusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n\t\tfocusableElem = focusBox.querySelectorAll(focusableElemStr),\n\t\tfocusableElems = Array.prototype.slice.call(focusableElem),\n\t\tfirstTabStop = focusableElems[0],\n\t\tlastTabStop = focusableElems[focusableElems.length - 1];\n\tfocusBox.addEventListener("keydown", trapTabKey);\n\n\t\n\t$("body").bind("DOMSubtreeModified", function() {\n    \tif($(\'#smile-ui-container\')){\n\t\t\t$(\'#smile-ui-container\').css(\'z-index\',\'999\');\n\t\t}\n\t});\n<\/script>\n\t\t\t\t\t\t',
            animation: null,
            urlRedirect: null,
            initialDelay: 2,
            buttonSettings: {
                size: 1,
                shape: 1,
                alignment: 2,
                text: "Subscribe",
                color: "#00BDE5",
                textColor: "#FFFFFF"
            },
            urlRules: [{
                urlMatchRule: 1,
                show: !1,
                url: "/account/"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "/cart"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "/checkouts/"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "/preference-center"
            }],
            targetingRules: {
                showWhenDevice: ["Desktop", "Mobile"]
            },
            subscriptionPoint: "Popup",
            engagement: {
                followUpTimeframe: 0,
                showWhenPageSession: 1,
                followUp: !0,
                followUpDelay: 30,
                showIfFromListrakEmail: !1
            },
            overlayClose: !0,
            referrerRule: null
        }
    }, {
        type: 3,
        category: 0,
        popupUID: "9d8e495a-d839-43df-b2eb-a3aa81a12318",
        popupName: "NW - SS22 - Exit Pop Up",
        clientUID: "4812bcb7-32f3-4732-92d1-a34659911750",
        companyID: 0,
        isActive: !1,
        lastModified: "2022-11-16T14:41:55.941Z",
        settings: {
            scrollDepth: 0,
            isTestMode: !0,
            formHTML: '<!-- Pop-up Form -->\n<!-- ltkpopup-no-scroll: centers the popup on display by preventing the page from scrolling -->\n<!-- ltkpopup-ios-fix: keeps fixed position popups like bottom banners in place in iOS -->\n<div id="ltkpopup-wrapper" class="ltkpopup-signup ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n        <!-- Custom Fonts can be placed below if applicable -->\n        \n        <link rel="stylesheet" href="https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/fontawesomev5.min.css">\n\n\n        <!-- Main Popup Content Area -->\n        <!-- Add class ltkpopup-no-padd for split popups -->\n        <div id="ltkpopup-content" class="ltkpopup-signup ltkpopup-no-padd">\n\n\n                <!-- Pull in the popup container -->\n                <div class="ltkpopup-clearfix ltkpopup-split-content ">\n\n\n        <div class="ltkpopup-contain-img" id="ltkpopup-img-contained">\n                <img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F22/NW_EMAIL_POPUP_IMG_1440x840_EXIT.jpg" alt="" class="ltkpopup-img-fluid" aria-hidden="true">\n        <\/div>\n\n\n        <div class="ltkpopup-contain-form">\n\n\n                <div class="ltkpopup-form-control">\n\n\n                        <div class="ltkpopup-content-wrap">\n                                <h2 class="ltkpopup-subheadline">DON\'T LEAVE EMPTY&nbsp;HANDED!<\/h2>\n<h1 id="ltkpopup-headline" class="ltkpopup-headline">ENTER YOUR EMAIL<br> AND RECEIVE AN<br> EXTRA 15%&nbsp;OFF<\/h1>\n\n\n                                <div class="ltkpopup-form-contain" id="ltkpopup-form">\n\n\n                                        <div class="ltkpopup-form-contain">\n\n\n        <div class="ltkpopup-form-control">\n\n\n                <!-- Email Input Required Error Message|Moved out of column for display purposes -->\n                <div class="ltkpopup-error-message" aria-live="assertive" data-ltkpopup-error-for="ltkpopup-email" data-ltkpopup-message="Please enter a valid email address"><\/div>\n                \n                <label class="ltkpopup-visuallyhidden" for="ltkpopup-email">Email Address<\/label>\n<input autofocus required type="email" id="ltkpopup-email" class="ltkpopup-email" tabindex="0" name="ltkpopup-email" placeholder="Email Address (required)" autocomplete="email" pattern="^([a-zA-Z0-9._+!-]+[@](?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,})$" onchange="_ltk.SCA.Update(\'email\', this.value)" />\n\n\n        <\/div>\n\n\n\n\n        <!-- Emmet Snippets if applicable -->\n        <!-- zip error dropdown checkbox radio sms-capture -->\n\n\n        <!-- Button Container -->\n        <div class="ltkpopup-button-container ltkpopup-flex ltkpopup-clearfix">\n                <!-- Submit Button -->\n                <button id="ltkpopup-submit" class="ltkpopup-subscribe" tabindex="0" type="submit"><span>GET YOUR 15% OFF NOW<\/span><\/button>\n\n\n                <!-- Text Close Button -->\n                <div class="ltkpopup-no-thanks ltkpopup-visuallyhidden" id="ltkpopup-text-btn">\n                        <!-- Do Not Delete. Add class ltkpopup-visuallyhidden -->\n                        <button tabindex="0" class="ltkpopup-close">maybe later<\/button>\n                <\/div>\n        <\/div>\n\n\n<\/div>\n\n\n                                <\/div>\n\n\n\n\n                        <\/div>\n                <\/div>\n\n\n        <\/div>\n\n\n<\/div>\n                \n\n\n                <!-- Emmet Snippets if applicable -->\n                <!-- zip error dropdown checkbox radio sms-capture -->\n\n\n                <!-- Do Not Delete. Connects the Popup to Segmentation within the Listrak platform. Input name needs to match segmentation -->\n                <div class="ltkpopup-source">\n                        <input type="hidden" class="text" name="Source.Popup" value="On" tabindex="-1" />\n                <\/div>\n\n\n                <!-- Close \'X\' Button -->\n                <!-- Add class ltkpopup-circle-close to create a circle close button -->\n<div id="ltkpopup-close-button" class="ltkpopup-circle-close">\n        <a class="ltkpopup-close" tabindex="0" role="button" aria-label="close">\n                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">\n                        <line x1="1" y1="1" x2="28" y2="28" />\n                        <line x1="28" y1="1" x2="1" y2="28" />\n                <\/svg>\n        <\/a>\n<\/div>\n\n\n        <\/div>\n        <!-- End ltkpopup-content -->\n\n\n<\/div>\n<!-- End ltkpopup-wrapper -->\n\n\n<script>\n        var emailVal;\n        jQuery(\'#ltkpopup-submit\').on(\'click\', function () {\n                emailVal = jQuery(\'#ltkpopup-email\').val();\n                var e = jQuery(":input");\n                jQuery(e).each(function (e) {\n                        checkInputValidity(this);\n                        if (jQuery(this).is(":invalid")) {\n                                this.setAttribute("aria-describedby", this.id + "-error-message");\n                        } else {\n                                this.removeAttribute("aria-describedby")\n                        }\n                });\n                setTimeout(function () {\n                        if (document.querySelector(".ltkinputnotvalid") != null) {\n                                document.querySelector(".ltkinputnotvalid").focus();\n                        }\n                }, 0);\n        });\n<\/script>\n\n\n<script>\n        // Browsers\n        var b = document.documentElement;\n        b.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n        var $html = jQuery("html"),\n                ua = $html.data("useragent"),\n                pf = $html.data("platform");\n\n\n        function is(e) {\n                return ua.indexOf(e) > -1\n        }\n        var browser = {\n                isIE: is("msie") || is("trident/7.0"),\n                isIE7: is("msie 7.0"),\n                isIE8: is("msie 8.0"),\n                isIE9: is("msie 9.0"),\n                isIE10: is("msie 10"),\n                isIE11: is("rv:11") && is("trident/7.0"),\n                isEdge: is("edge"),\n                isChrome: is("chrome") && !is("edge"),\n                isSafari: is("safari") && !is("chrome") && !is("edge"),\n                isFirefox: is("firefox") && !is("edge"),\n                isAndroidChrome: is("android") && is("chrome"),\n                isAndroidDefault: is("android") && !is("chrome"),\n                isWin7: is("windows nt 6.1"),\n                isWin8: is("windows nt 6.2"),\n                isWindows: pf.indexOf("win32") > -1,\n                isWebkit: is("webkit") && !is("edge"),\n                isIPad: is("ipad"),\n                isIPadChrome: is("ipad") && is("crios"),\n                isIPhone: is("iphone"),\n                isIPhoneChrome: is("iphone") && is("crios"),\n                isAndroid: is("android"),\n                isIOS: is("iphone") || is("ipad")\n        };\n        for (var title in browser) {\n                var helperClass = title.slice(2).toLowerCase();\n                browser[title] && jQuery("#ltkpopup-content").addClass(helperClass)\n        }\n\n\n        // Close Function\n        jQuery(\'.ltkpopup-close\').focus(function () {\n                jQuery(\'.ltkpopup-close\').keypress(function (e) {\n                        var key = e.which;\n                        if (key == 13) {\n                                jQuery(\'#ltkpopup-overlay, #ltkpopup-container\').remove()\n                        }\n                })\n        });\n\n\n        // Check Input Validity\n        function checkInputValidity(inputEl) {\n                jQuery(inputEl).removeClass("ltkinputnotvalid");\n                var ltkErrorMessage = jQuery("[data-ltkpopup-error-for=\'" + inputEl.id + "\'");\n                jQuery(ltkErrorMessage).text("");\n                inputEl.checkValidity();\n                if (jQuery(inputEl).is(\':invalid\')) {\n                        jQuery(inputEl).addClass("ltkinputnotvalid");\n                        var ltkErrorMessageText = jQuery(ltkErrorMessage).attr("data-ltkpopup-message");\n                        jQuery(ltkErrorMessage).text(ltkErrorMessageText);\n                        return false;\n                }\n                return true;\n        }\n\n\n\n\n\n\n        changeFocus = function () {\n                if (document.getElementById("ltkpopup-email") == undefined && document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined) {\n                        document.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n                }\n        }\n\n\n        // Tab Trapping\n        jQuery(document).ready(function () {\n                setTimeout(function () {\n                        function triggerFocus(element) {\n                                var eventType = "onfocusin" in element ? "focusin" : "focus",\n                                        bubbles = "onfocusin" in element,\n                                        event;\n\n\n                                if ("createEvent" in document) {\n                                        event = document.createEvent("Event");\n                                        event.initEvent(eventType, bubbles, true);\n                                } else if ("Event" in window) {\n                                        event = new Event(eventType, {\n                                                bubbles: bubbles,\n                                                cancelable: true\n                                        });\n                                }\n\n\n                                element.focus();\n                                element.dispatchEvent(event);\n                        }\n                        if (document.getElementById("ltkpopup-email") != undefined) {\n                                triggerFocus(document.getElementById("ltkpopup-email"));\n                        } else {\n                                changeFocus();\n                        }\n                }, 0);\n        });\n\n\n        function trapTabKey(e) {\n                var t = document.activeElement,\n                        s = focusableElems.indexOf(t);\n                if (9 === e.keyCode) {\n                        e.preventDefault();\n                        moveTab(s, e.shiftKey)\n                }\n        }\n\n\n        function moveTab(index, shift) {\n                var nextTab = null;\n                var nextIndex = index;\n                if (shift) {\n                        if (focusableElems[index] == firstTabStop) {\n                                nextTab = lastTabStop;\n                        } else {\n                                nextIndex = index - 1;\n                                nextTab = focusableElem[nextIndex];\n                        }\n                } else {\n                        if (focusableElems[index] == lastTabStop) {\n                                nextTab = firstTabStop;\n                        } else {\n                                nextIndex = index + 1;\n                                nextTab = focusableElems[nextIndex];\n                        }\n                }\n\n\n                if (jQuery(nextTab).is(":visible")) {\n                        nextTab.focus();\n                } else {\n                        moveTab(nextIndex, shift);\n                }\n        }\n        window.onload = function () {\n                var e = document.getElementById("ltkpopup-img-contained");\n                e && (2 == window.getComputedStyle(e).getPropertyValue("order") && (e.className += " ltkpopup-img-right"))\n        }, setTimeout(function () {\n                //Do not delete - tab functionality will break\n                _ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n                changeFocus();\n        }, 50);\n        var focused = document.activeElement;\n        jQuery(".ltkpopup-close").on("click", function () {\n                focused.focus()\n        });\n        var focusBox = document.getElementById("ltkpopup-content"),\n                focusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n                focusableElem = focusBox.querySelectorAll(focusableElemStr),\n                focusableElems = Array.prototype.slice.call(focusableElem),\n                firstTabStop = focusableElems[0],\n                lastTabStop = focusableElems[focusableElems.length - 1];\n        focusBox.addEventListener("keydown", trapTabKey);\n\n\n        \n        $("body").bind("DOMSubtreeModified", function() {\n            if($(\'#smile-ui-container\')){\n                        $(\'#smile-ui-container\').css(\'z-index\',\'999\');\n                }\n        });\n<\/script>\n<script>\n    jQuery(document).ready(function () {\n\n\n        if (jQuery("[data-inputmask]").length) {\n            \n                // Input masking for number validation - Get Jquery Input Mask from CDN and load it\n                jQuery.getScript(\n                    "https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.1/jquery.inputmask.bundle.js",\n                    function () {\n                        jQuery("[data-inputmask]").each(function() {\n                             // Mask phone number input after script is loaded\n                            jQuery(this).inputmask({greedy: false, showMaskOnHover: false, definitions: {\n                            \'#\': { validator: "[0-9]", cardinality: 1\n                            }\n                            }\n                            });\n                        });\n                    });\n        }\n    });\n<\/script>\n<script>\n        var datepickerField = document.querySelector("#ltkpopup-datepicker");\n        if (datepickerField != null) {\n                var jQueryUIcss = document.createElement("link");\n                jQueryUIcss.href = "https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css";\n                jQueryUIcss.rel = "stylesheet";\n                jQueryUIcss.addEventListener("load", function () {\n                        var jQueryUI = document.createElement("script");\n                        jQueryUI.src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js";\n                        jQueryUI.addEventListener("load", function () {\n                                datepickerField.setAttribute("readonly", "");\n                                jQuery(datepickerField).datepicker({\n                                        changeMonth: true,\n                                        changeYear: false,\n                                        yearRange: \'-0:+0\',\n                                        // use for different date format and hidden bday field\n                                        dateFormat: "mm/dd",\n                                        altField: "#ltkpopup-hidden-bday",\n                                        altFormat: "mm/dd/1900"\n                                });\n\n\n                                jQuery(datepickerField).focus(function () {\n                                        jQuery(\'#ui-datepicker-div\').appendTo(this.parentNode);\n                                });\n                        });\n                        document.getElementById("ltkpopup-content").appendChild(jQueryUI);\n                });\n                document.getElementById("ltkpopup-content").appendChild(jQueryUIcss);\n        }\n<\/script>',
            formCSS: '#ltkpopup-wrapper .ltkpopup-clearfix::before,#ltkpopup-wrapper .ltkpopup-clearfix::after{content:"";display:table}#ltkpopup-wrapper .ltkpopup-clearfix::after{clear:both}#ltkpopup-wrapper .ltkpopup-clearfix{zoom:1}.ios-only{position:fixed}.ltkpopup-visuallyhidden{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);border:0}.ltkpopup-visuallyhidden.focusable:active,.ltkpopup-visuallyhidden.focusable:focus{position:static;width:auto;height:auto;margin:0;overflow:visible;clip:auto}.ltkpopup-img-fluid{width:100%;height:auto}.ltkpopup-full-width{width:100% !important;max-width:100% !important}.ltkpopup-content-wrap{max-width:450px;margin:0 auto}#ltkpopup-thanks{text-align:center}#ltkpopup-thanks input{display:inline-block}#smile-ui-container,#keyboard-nav-34,#keyboard-nav-37{z-index:99990 !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-wrapper .mobileHide{display:none}}#ltkpopup-content .ltk-grid{margin:0 auto;width:100%}#ltkpopup-content .ltk-row{padding-bottom:20px}#ltkpopup-content .ltk-row:last-of-type{padding-bottom:0px}#ltkpopup-content .ltk-col-1{width:100%}#ltkpopup-content .ltk-col-1-2{width:50%}#ltkpopup-content .ltk-col-2-3{width:66.66%}#ltkpopup-content .ltk-col-1-3{width:33.33%}#ltkpopup-content [class*=\'ltk-col-\']{float:left}#ltkpopup-content [class*=\'ltk-col-\']{padding-right:0}#ltkpopup-content [class*=\'ltk-col-\']:last-of-type{padding-right:0;padding-left:10px}#ltkpopup-content .ltk-col-1-3{padding-right:14px}#ltkpopup-content .ltk-col-1-3+.ltk-col-1-3{padding-right:6px;padding-left:6px}#ltkpopup-content .ltk-col-1-3:last-of-type{padding-right:0;padding-left:0}#ltkpopup-content .ltk-col-1,#ltkpopup-content .ltk-col-1:last-of-type{padding-right:0;padding-top:0;padding-left:0}#ltkpopup-overlay{z-index:100001 !important;position:fixed !important;top:0 !important;bottom:0 !important;width:100% !important;height:100% !important;background-color:#000 !important;opacity:.5 !important;-webkit-transition:all .25s ease-in;transition:all .25s ease-in}#ltkpopup-container{z-index:100010 !important;position:fixed !important;width:710px !important;height:auto !important;max-height:100%;top:50% !important;left:50% !important;margin-left:0 !important;-webkit-transform:translate(-50%, -50%) !important;-moz-transform:translate(-50%, -50%) !important;-ms-transform:translate(-50%, -50%) !important;transform:translate(-50%, -50%) !important;overflow-x:hidden;overflow-y:auto;-webkit-box-shadow:0 5px 15px rgba(0,0,0,0.5);-moz-box-shadow:0 5px 15px rgba(0,0,0,0.5);box-shadow:0 5px 15px rgba(0,0,0,0.5)}#ltkpopup-wrapper{position:relative;margin:0 auto;width:100% !important}#ltkpopup-container .simpleltkmodal-wrap{overflow:visible !important}#ltkpopup-wrapper *{box-sizing:border-box;backface-visibility:hidden !important}#ltkpopup-wrapper{background:transparent;font-size:12px;font-family:Arial,Helvetica,sans-serif;-webkit-font-smoothing:subpixel-antialiased}#ltkpopup-wrapper .no-wrap{white-space:nowrap}#ltkpopup-content{padding:3em;font-size:12px;text-align:left;color:#000;line-height:1.4;background:#F8F8FA}.ltkpopup-fullscreen{position:relative;max-width:710px;height:auto !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-container{width:320px !important}#ltkpopup-wrapper{width:320px !important}#ltkpopup-content{float:none;width:100%;padding:40px 20px 30px 20px}}#ltkpopup-content .ltkpopup-split-content{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-webkit-box-align:center;-moz-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img{max-width:300px;-webkit-box-flex:0 0 300px;-moz-box-flex:0 0 300px;-webkit-flex:0 0 300px;-ms-flex:0 0 300px;flex:0 0 300px;line-height:0;order:2;-ms-flex-order:2}#ltkpopup-content .ltkpopup-split-content.ltkpopup-image-bottom .ltkpopup-contain-img-full{line-height:0}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form{max-width:410px;-webkit-box-flex:0 0 410px;-moz-box-flex:0 0 410px;-webkit-flex:0 0 410px;-ms-flex:0 0 410px;flex:0 0 410px;-ms-flex:0 0 410px;padding:10px 10px 30px;order:1;-ms-flex-order:1}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form .ltkpopup-no-thanks{float:none;text-align:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-full-width{padding-top:30px}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below{flex-wrap:wrap}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form{max-width:100%;-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full{-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%;order:2;line-height:0}#ltkpopup-content.ie6 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie7 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie8 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie9 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie10 .ltkpopup-split-content .ltkpopup-contain-img{width:300px;float:right}#ltkpopup-content.ie6 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie7 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie8 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie9 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie10 .ltkpopup-split-content .ltkpopup-contain-form{width:410px;float:left;padding-top:70px}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below{flex-wrap:wrap}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form{width:100%}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full{width:100%}#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-form{position:relative;left:-2px}#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-img.ltkpopup-img-right img,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-img.ltkpopup-img-right img,#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-form-right,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-form-right{position:relative;right:-2px;left:auto}#ltkpopup-content.safari,#ltkpopup-content.ipad{overflow-x:hidden;overflow-y:hidden}#ltkpopup-content.ie .ltkpopup-split-content,#ltkpopup-content.ie11 .ltkpopup-split-content{padding-bottom:2px}#ltkpopup-content.ie .ltkpopup-split-content .ltkpopup-img-fluid,#ltkpopup-content.ie11 .ltkpopup-split-content .ltkpopup-img-fluid{position:relative;bottom:-1px}#ltkpopup-content.ltkpopup-no-padd{padding:0 !important}#ltkpopup-content.ltkpopup-no-padd .ltkpopup-no-padd{padding:0 !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img-full,#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img{display:none}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form{max-width:100%;flex:0 0 100%;-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%;padding:40px 20px}}#ltkpopup-close-button{position:absolute;left:7px;top:7px;margin:0px;z-index:10}#ltkpopup-close-button a{display:block;width:12px;height:12px;cursor:pointer}#ltkpopup-close-button a svg{width:100%;height:100%;position:relative;display:block;overflow:visible;stroke:#333;stroke-width:6px;-webkit-transition:all .25s linear;transition:all .25s linear}#ltkpopup-close-button a:hover svg{stroke:#858585}#ltkpopup-close-button a:focus svg{stroke:#858585}#ltkpopup-close-button.ltkpopup-circle-close{right:7px;top:7px}#ltkpopup-close-button.ltkpopup-circle-close a{width:22px;height:22px;background:#FFF;border-radius:50%;padding:4px;border:2px solid #333}#ltkpopup-close-button.ltkpopup-circle-close a:hover,#ltkpopup-close-button.ltkpopup-circle-close a:focus{border-color:#858585}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-close-button{right:7px;top:7px}#ltkpopup-close-button a{width:12px;height:12px}}#ltkpopup-content h1,#ltkpopup-content h2,#ltkpopup-content h3,#ltkpopup-content h4,#ltkpopup-content h5,#ltkpopup-content .ltkpopup-headline,#ltkpopup-content .ltkpopup-subheadline{margin:0;padding:0;text-align:center;font-family:Arial,Helvetica,sans-serif !important}#ltkpopup-content h1,#ltkpopup-content .ltkpopup-headline{font-weight:700;font-size:22px;line-height:30px;color:#000;letter-spacing:1px;margin-bottom:10px}#ltkpopup-content h2,#ltkpopup-content .ltkpopup-subheadline{font-weight:400;font-size:18px;line-height:25px;color:#000;display:block;margin-bottom:20px}#ltkpopup-content p,#ltkpopup-content .ltkpopup-content-para{margin:0 0 5px;font-size:12px;line-height:19px;font-family:Arial,Helvetica,sans-serif;text-align:center;letter-spacing:.5px}#ltkpopup-content p.ltkpopup-disclaimer,#ltkpopup-content p.ltkpopup-sms-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer{font-size:8px;line-height:26px;text-align:center;margin:10px 10px 0;letter-spacing:0}#ltkpopup-content p.ltkpopup-disclaimer a,#ltkpopup-content p.ltkpopup-sms-disclaimer a,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a{color:inherit;text-decoration:underline;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content p.ltkpopup-disclaimer a:hover,#ltkpopup-content p.ltkpopup-disclaimer a:focus,#ltkpopup-content p.ltkpopup-sms-disclaimer a:hover,#ltkpopup-content p.ltkpopup-sms-disclaimer a:focus,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:hover,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:focus,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:hover,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:focus{text-decoration:none}#ltkpopup-content p.ltkpopup-disclaimer span,#ltkpopup-content p.ltkpopup-sms-disclaimer span,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer span,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer span{font-weight:700}#ltkpopup-content.ltkpopup-confirm p,#ltkpopup-content.ltkpopup-confirm .ltkpopup-content-para{margin:10px auto}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content h1,#ltkpopup-content .ltkpopup-headline{font-size:22px;line-height:30px}#ltkpopup-content h2,#ltkpopup-content .ltkpopup-subheadline{font-size:18px;line-height:25px}#ltkpopup-content p,#ltkpopup-content .ltkpopup-content-para{font-size:12px;line-height:19px}#ltkpopup-content p.ltkpopup-disclaimer,#ltkpopup-content p.ltkpopup-sms-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer{font-size:8px;line-height:16px}}#ltkpopup-content input[type="text"],#ltkpopup-content input[type="email"],#ltkpopup-content input[type="number"],#ltkpopup-content input[type="tel"]{display:block;width:100%;height:32px;padding:0 1em;margin:0 auto;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:400;text-align:left;color:#000;line-height:normal;background-color:transparent;border:1px solid #000;border-radius:0px !important;box-shadow:inset 0 0 0 1000px #FFF;-webkit-transition:all 0.11s linear;transition:all 0.11s linear;-webkit-appearance:none;-moz-appearance:none;appearance:none}#ltkpopup-content input[type="text"]:focus,#ltkpopup-content input[type="email"]:focus,#ltkpopup-content input[type="number"]:focus,#ltkpopup-content input[type="tel"]:focus{outline:none;border:2px solid #000}#ltkpopup-content input[type="text"]:last-of-type{margin:10px auto 0}#ltkpopup-content .ltkpopup-form-control{position:relative}#ltkpopup-content .ltkpopup-form-contain{max-width:320px;margin:0 auto}#ltkpopup-content input::-webkit-input-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input::-moz-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input:-ms-input-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input::-ms-clear{display:none;width:0;height:0;opacity:0}#ltkpopup-content .ltk-floating-input{width:250px;float:left}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content input[type="text"],#ltkpopup-content input[type="email"],#ltkpopup-content input[type="number"],#ltkpopup-content input[type="tel"]{float:none;width:100%;font-size:15px}#ltkpopup-content .ltk-floating-input{width:100%;padding-bottom:15px}}#ltkpopup-content input[type="radio"]{position:absolute;overflow:hidden;clip:rect(0 0 0 0);height:1px;width:1px;margin:-1px;padding:0;border:0}#ltkpopup-content .radio-wrapper{padding:10px 0;text-align:left}#ltkpopup-content .ltk-radio{position:relative;float:left;width:50%}#ltkpopup-content .ltk-radio label{position:relative;display:block;padding:0px 4px;cursor:pointer}#ltkpopup-content .ltk-radio label::before{position:absolute;display:block;float:left;padding:0 3px 0 0;font-family:FontAwesome;font-size:12px;color:#FFF;content:"\\f111";border-radius:0px}#ltkpopup-content .ltk-radio label span{display:block;padding:0 0 0 22px}#ltkpopup-content .ltk-radio input:checked ~ label::before{color:#FFF;content:"\\f192"}#ltkpopup-content .ltk-radio input:hover+label::before{color:#000}#ltkpopup-content .ltk-radio input:focus+label::before{color:#FFF}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkmodal-wrapper .radio-wrapper{padding:5px 0}}#ltkpopup-content input[type="checkbox"]{position:absolute;overflow:hidden;clip:rect(0 0 0 0);height:1px;width:1px;margin:-1px;padding:0;border:0}#ltkpopup-content fieldset#ltkpopup-options{border:none;margin:5px auto 10px;padding:0;width:100%;max-width:150px}#ltkpopup-content .ltkpopup-legend,#ltkpopup-content .ltkpopup-legend-styling{font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:12px;line-height:19px;text-align:center;color:#000;white-space:normal;margin:0 auto}#ltkpopup-content .ltkpopup-legend .ltklegend-regular,#ltkpopup-content .ltkpopup-legend-styling .ltklegend-regular{font-weight:400;text-transform:none;font-size:8px;line-height:26px;color:#000;display:block}#ltkpopup-content .ltkpopup-column{width:50%;display:block;float:left}#ltkpopup-content .ltkpopup-checkbox{float:left;width:100%}#ltkpopup-content .ltkpopup-checkbox label{display:block;position:relative;padding:0px 0px 3px;cursor:pointer;font-size:14px;margin-top:9px;margin-bottom:0;font-weight:400}#ltkpopup-content .ltkpopup-checkbox label:before{position:absolute !important;display:block;float:left;text-align:center;content:"";width:14px;height:14px;border:1px solid #000}#ltkpopup-content .ltkpopup-checkbox label span{display:block;padding:0px 0 0 24px;line-height:17px}#ltkpopup-content .ltkpopup-checkbox input:checked+label::before{font-family:FontAwesome;content:"\\f00c";color:#000;font-size:14px;line-height:14px}#ltkpopup-content .ltkpopup-checkbox input:focus+label::before,#ltkpopup-content .ltkpopup-checkbox input:hover+label::before{border-color:#000}#ltkpopup-content .ltkpopup-checkbox input:checked:hover+label::before{opacity:.7}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content fieldset#ltkpopup-options{display:block;margin-top:15px}}#ltkpopup-content .dropdown{position:relative;width:100%;height:32px;margin:10px 0;padding:0;font-size:12px;font-weight:400;text-overflow:ellipsis;border-radius:0 !important;cursor:pointer}#ltkpopup-content .dropdown select{width:100%;height:100%;padding:0 10px;z-index:1;font-family:Arial,Helvetica,sans-serif;font-size:12px;font-weight:400;color:#000;text-indent:0 !important;background:#FFF;border:1px solid #000;border-radius:0;cursor:pointer;-webkit-appearance:none !important;-moz-appearance:none !important;appearance:none !important}#ltkpopup-content .dropdown select:focus{border-color:#000;outline:none}#ltkpopup-content .dropdown::before{position:absolute;display:block;right:10px;top:50%;margin-top:-10px;z-index:2;font-family:FontAwesome;font-size:14px;content:"\\f0d7";color:#000;pointer-events:none;-webkit-transition:all .25s linear;transition:all .25s linear}#ltkpopup-content .dropdown select::-ms-expand{display:none !important}#ltkpopup-content input.ltkinputnotvalid,#ltkpopup-content div.dropdown.ltk-select-notvalid,#ltkpopup-content div.dropdown select.ltkinputnotvalid{border-color:red}#ltkpopup-content input.ltkinputnotvalid:focus,#ltkpopup-content div.dropdown.ltk-select-notvalid:focus,#ltkpopup-content div.dropdown select.ltkinputnotvalid:focus{border-color:red}#ltkpopup-content input.ltkinputnotvalid::-webkit-input-placeholder{color:red}#ltkpopup-content input.ltkinputnotvalid::-moz-placeholder{color:red}#ltkpopup-content input.ltkinputnotvalid:-ms-input-placeholder{color:red}#ltkpopup-content .ltkpopup-error-message{display:block;height:14px;text-align:center;line-height:14px;width:100%;font-size:10px;color:red;font-weight:700}#ltkpopup-content .ltkpopup-error-message:empty{visibility:hidden}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-error-message{line-height:14px;font-size:10px}}#ltkpopup-content .ltkpopup-button-container{position:relative;width:100%;overflow:hidden}#ltkpopup-content .ltkpopup-button-container.ltkpopup-flex{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;flex-wrap:wrap;-ms-flex-wrap:wrap;-webkit-box-align:center;-moz-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center;margin-top:20px;text-align:center}#ltkpopup-content .ltkpopup-subscribe,#ltkpopup-content .ltkpopup-close-button,#ltkpopup-content .ltkpopup-faux-subscribe{display:inline-block;position:relative;width:100%;max-width:320px;margin:auto;padding:7px;vertical-align:middle;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:400;color:#FFF;height:32px;text-decoration:none;background-color:#000;border:1px solid #000;border-radius:0 !important;box-shadow:none !important;cursor:pointer;outline:none;-webkit-appearance:none !important;-moz-appearance:none !important;appearance:none !important;-webkit-transition:all .25s linear;transition:all .25s linear;transition:.25s;overflow:hidden}#ltkpopup-content .ltkpopup-subscribe span,#ltkpopup-content .ltkpopup-close-button span,#ltkpopup-content .ltkpopup-faux-subscribe span{position:relative;z-index:1}#ltkpopup-content .ltkpopup-subscribe:hover,#ltkpopup-content .ltkpopup-close-button:hover,#ltkpopup-content .ltkpopup-faux-subscribe:hover{color:#FFF;background-color:#858585;border-color:#858585}#ltkpopup-content .ltkpopup-subscribe:focus,#ltkpopup-content .ltkpopup-close-button:focus,#ltkpopup-content .ltkpopup-faux-subscribe:focus{color:#FFF;background-color:#858585;border-color:#858585;transition:0s}#ltkpopup-content .ltkpopup-close-button{float:none;margin:10px auto 0px;line-height:normal}#ltkpopup-content .ltkpopup-no-thanks{float:none;width:100%;text-align:center}#ltkpopup-content .ltkpopup-no-thanks a,#ltkpopup-content .ltkpopup-no-thanks button{background:none;border:none;display:inline-block;padding:10px;font-size:12px;font-weight:400;color:#000;text-decoration:underline;-webkit-transition:all .25s linear;transition:all .25s linear;cursor:pointer;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content .ltkpopup-no-thanks a:hover,#ltkpopup-content .ltkpopup-no-thanks a:focus,#ltkpopup-content .ltkpopup-no-thanks button:hover,#ltkpopup-content .ltkpopup-no-thanks button:focus{text-decoration:none}#ltkpopup-content .ltkpopup-float-fields{width:350px;margin:0 auto}#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button{width:100px;float:left}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-subscribe,#ltkpopup-content .ltkpopup-close-button,#ltkpopup-content .ltkpopup-faux-subscribe{font-size:16px;margin-top:5px}#ltkpopup-content .ltkpopup-no-thanks a,#ltkpopup-content .ltkpopup-no-thanks button{font-size:12px}#ltkpopup-content .ltkpopup-float-fields{width:100%}#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button{width:100%}}',
            confirmationHTML: '\n\t\t\t\t\t\t\t<!-- Pop-up Confirm / Appears after user submits Popup Form -->\n<div id="ltkpopup-wrapper" class="confirm ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n\t<!-- Custom Fonts can be placed below if applicable -->\n\t\n\t<link rel="stylesheet" href="https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/fontawesomev5.min.css">\n\n\t<!-- Main Popup Content Area -->\n\t<!-- Add class ltkpopup-no-padd for split popups -->\n\t<div id="ltkpopup-content" class="ltkpopup-confirm ltkpopup-no-padd">\n\n\t\t<!-- Pull in the popup container -->\n\t\t<div class="ltkpopup-clearfix ltkpopup-split-content ">\n\n\t<div class="ltkpopup-contain-img" id="ltkpopup-img-contained">\n\t\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/NW_Exit_EMAIL_POPUP_IMG_600x840-min.jpg" alt="" class="ltkpopup-img-fluid" aria-hidden="true">\n\t<\/div>\n\n\t<div class="ltkpopup-contain-form">\n\n\t\t<div class="ltkpopup-form-control">\n\n\t\t\t<div class="ltkpopup-content-wrap">\n\n\t\t\t\t<h1 id="ltkpopup-headline" class="ltkpopup-headline">THANK YOU<\/h1>\n<h2 id="ltkpopup-subheadline" class="ltkpopup-subheadline">You have been subscribed.<\/h2>\n<p id="ltkpopup-content-para" class="ltkpopup-content-para">To apply your 15% off coupon now, click below.<\/p>\n\n\t\t\t\t<div class="ltkpopup-button-container" id="ltkpopup-thanks">\n    <a tabindex="0" class="ltkpopup-close-button ltkpopup-close" href="https://ninewest.com/discount/WELCOME15" target="_blank">APPLY COUPON<\/a>\n<\/div>\n\n\t\t\t<\/div>\n\t\t<\/div>\n\t\t\n\t<\/div>\n\n<\/div>\n\t\t\n\n\t\t<!-- End Content Information -->\n\n\t\t<!-- Close \'X\' Button -->\n\t\t<!-- Add class ltkpopup-circle-close to create a circle close button -->\n<div id="ltkpopup-close-button" class="ltkpopup-circle-close">\n\t<a class="ltkpopup-close" tabindex="0" role="button" aria-label="close">\n\t\t<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">\n\t\t\t<line x1="1" y1="1" x2="28" y2="28" />\n\t\t\t<line x1="28" y1="1" x2="1" y2="28" />\n\t\t<\/svg>\n\t<\/a>\n<\/div>\n\t<\/div>\n<\/div>\n\n\n\n<script>\n\t// Browsers\n\tvar b = document.documentElement;\n\tb.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n\tvar $html = jQuery("html"),\n\t\tua = $html.data("useragent"),\n\t\tpf = $html.data("platform");\n\n\tfunction is(e) {\n\t\treturn ua.indexOf(e) > -1\n\t}\n\tvar browser = {\n\t\tisIE: is("msie") || is("trident/7.0"),\n\t\tisIE7: is("msie 7.0"),\n\t\tisIE8: is("msie 8.0"),\n\t\tisIE9: is("msie 9.0"),\n\t\tisIE10: is("msie 10"),\n\t\tisIE11: is("rv:11") && is("trident/7.0"),\n\t\tisEdge: is("edge"),\n\t\tisChrome: is("chrome") && !is("edge"),\n\t\tisSafari: is("safari") && !is("chrome") && !is("edge"),\n\t\tisFirefox: is("firefox") && !is("edge"),\n\t\tisAndroidChrome: is("android") && is("chrome"),\n\t\tisAndroidDefault: is("android") && !is("chrome"),\n\t\tisWin7: is("windows nt 6.1"),\n\t\tisWin8: is("windows nt 6.2"),\n\t\tisWindows: pf.indexOf("win32") > -1,\n\t\tisWebkit: is("webkit") && !is("edge"),\n\t\tisIPad: is("ipad"),\n\t\tisIPadChrome: is("ipad") && is("crios"),\n\t\tisIPhone: is("iphone"),\n\t\tisIPhoneChrome: is("iphone") && is("crios"),\n\t\tisAndroid: is("android"),\n\t\tisIOS: is("iphone") || is("ipad")\n\t};\n\tfor (var title in browser) {\n\t\tvar helperClass = title.slice(2).toLowerCase();\n\t\tbrowser[title] && jQuery("#ltkpopup-content").addClass(helperClass)\n\t}\n\n\t// Close Function\n\tjQuery(\'.ltkpopup-close\').focus(function () {\n\t\tjQuery(\'.ltkpopup-close\').keypress(function (e) {\n\t\t\tvar key = e.which;\n\t\t\tif (key == 13) {\n\t\t\t\tjQuery(\'#ltkpopup-overlay, #ltkpopup-container\').remove()\n\t\t\t}\n\t\t})\n\t});\n\n\t// Check Input Validity\n\tfunction checkInputValidity(inputEl) {\n\t\tjQuery(inputEl).removeClass("ltkinputnotvalid");\n\t\tvar ltkErrorMessage = jQuery("[data-ltkpopup-error-for=\'" + inputEl.id + "\'");\n\t\tjQuery(ltkErrorMessage).text("");\n\t\tinputEl.checkValidity();\n\t\tif (jQuery(inputEl).is(\':invalid\')) {\n\t\t\tjQuery(inputEl).addClass("ltkinputnotvalid");\n\t\t\tvar ltkErrorMessageText = jQuery(ltkErrorMessage).attr("data-ltkpopup-message");\n\t\t\tjQuery(ltkErrorMessage).text(ltkErrorMessageText);\n\t\t\treturn false;\n\t\t}\n\t\treturn true;\n\t}\n\n\n\n\tchangeFocus = function () {\n\t\tif (document.getElementById("ltkpopup-email") == undefined && document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined) {\n\t\t\tdocument.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n\t\t}\n\t}\n\n\t// Tab Trapping\n\tjQuery(document).ready(function () {\n\t\tsetTimeout(function () {\n\t\t\tfunction triggerFocus(element) {\n\t\t\t\tvar eventType = "onfocusin" in element ? "focusin" : "focus",\n\t\t\t\t\tbubbles = "onfocusin" in element,\n\t\t\t\t\tevent;\n\n\t\t\t\tif ("createEvent" in document) {\n\t\t\t\t\tevent = document.createEvent("Event");\n\t\t\t\t\tevent.initEvent(eventType, bubbles, true);\n\t\t\t\t} else if ("Event" in window) {\n\t\t\t\t\tevent = new Event(eventType, {\n\t\t\t\t\t\tbubbles: bubbles,\n\t\t\t\t\t\tcancelable: true\n\t\t\t\t\t});\n\t\t\t\t}\n\n\t\t\t\telement.focus();\n\t\t\t\telement.dispatchEvent(event);\n\t\t\t}\n\t\t\tif (document.getElementById("ltkpopup-email") != undefined) {\n\t\t\t\ttriggerFocus(document.getElementById("ltkpopup-email"));\n\t\t\t} else {\n\t\t\t\tchangeFocus();\n\t\t\t}\n\t\t}, 0);\n\t});\n\n\tfunction trapTabKey(e) {\n\t\tvar t = document.activeElement,\n\t\t\ts = focusableElems.indexOf(t);\n\t\tif (9 === e.keyCode) {\n\t\t\te.preventDefault();\n\t\t\tmoveTab(s, e.shiftKey)\n\t\t}\n\t}\n\n\tfunction moveTab(index, shift) {\n\t\tvar nextTab = null;\n\t\tvar nextIndex = index;\n\t\tif (shift) {\n\t\t\tif (focusableElems[index] == firstTabStop) {\n\t\t\t\tnextTab = lastTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index - 1;\n\t\t\t\tnextTab = focusableElem[nextIndex];\n\t\t\t}\n\t\t} else {\n\t\t\tif (focusableElems[index] == lastTabStop) {\n\t\t\t\tnextTab = firstTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index + 1;\n\t\t\t\tnextTab = focusableElems[nextIndex];\n\t\t\t}\n\t\t}\n\n\t\tif (jQuery(nextTab).is(":visible")) {\n\t\t\tnextTab.focus();\n\t\t} else {\n\t\t\tmoveTab(nextIndex, shift);\n\t\t}\n\t}\n\twindow.onload = function () {\n\t\tvar e = document.getElementById("ltkpopup-img-contained");\n\t\te && (2 == window.getComputedStyle(e).getPropertyValue("order") && (e.className += " ltkpopup-img-right"))\n\t}, setTimeout(function () {\n\t\t//Do not delete - tab functionality will break\n\t\t_ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n\t\tchangeFocus();\n\t}, 50);\n\tvar focused = document.activeElement;\n\tjQuery(".ltkpopup-close").on("click", function () {\n\t\tfocused.focus()\n\t});\n\tvar focusBox = document.getElementById("ltkpopup-content"),\n\t\tfocusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n\t\tfocusableElem = focusBox.querySelectorAll(focusableElemStr),\n\t\tfocusableElems = Array.prototype.slice.call(focusableElem),\n\t\tfirstTabStop = focusableElems[0],\n\t\tlastTabStop = focusableElems[focusableElems.length - 1];\n\tfocusBox.addEventListener("keydown", trapTabKey);\n\n\t\n\t$("body").bind("DOMSubtreeModified", function() {\n    \tif($(\'#smile-ui-container\')){\n\t\t\t$(\'#smile-ui-container\').css(\'z-index\',\'999\');\n\t\t}\n\t});\n<\/script>\n\t\t\t\t\t\t',
            animation: null,
            urlRedirect: null,
            initialDelay: 2,
            buttonSettings: {
                size: 1,
                shape: 1,
                alignment: 2,
                text: "Subscribe",
                color: "#00BDE5",
                textColor: "#FFFFFF"
            },
            urlRules: [{
                urlMatchRule: 1,
                show: !0,
                url: "/checkouts/"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "thank_you"
            }],
            targetingRules: {
                showWhenDevice: ["Desktop"]
            },
            subscriptionPoint: "Popup",
            engagement: {
                followUpTimeframe: 0,
                showWhenPageSession: 1,
                followUp: !0,
                followUpDelay: 30,
                showIfFromListrakEmail: !1
            },
            overlayClose: !0,
            referrerRule: null
        }
    }, {
        type: 3,
        category: 0,
        popupUID: "882efd18-ad3a-4c17-b595-fec8e915b906",
        popupName: "NW-IG-TTJ",
        clientUID: "4812bcb7-32f3-4732-92d1-a34659911750",
        companyID: 0,
        isActive: !1,
        lastModified: "2022-03-24T19:43:58.77Z",
        settings: {
            scrollDepth: 0,
            isTestMode: !0,
            formHTML: '\n\t\t\t\t\t\t\t<!-- Pop-up Form -->\n<!-- ltkpopup-no-scroll: centers the popup on display by preventing the page from scrolling -->\n<div id="ltkpopup-wrapper" class="signup ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-describedby="ltkpopup-headline">\n\n\t<div id="ltkpopup-content" class="signup"> \n\t\t\n\n\t\t<h1 id="ltkpopup-headline"><span>RECEIVE 20% OFF<\/span><span class="ltkpopup-subheadline">WHEN YOU SUBSCRIBE TODAY<\/span><\/h1>\n\n\t\t<p>Get the latest new arrivals, trends, sales,<br />and exclusive offers from Nine West.<\/p>\n\n\t\t<a class="ltkpopup-sms-link ltkpopup-close ltkpopup-clearfix" href="javascript:void(0);" onclick="handleSMSRedirect()" data-sms-keyword="JOIN" target="_top">\n\t\t\t<div class="ltkpopup-sms-inner-container">\n\t\t\t\t<svg xmlns="http://www.w3.org/2000/svg" width="41.02" height="37.5" viewBox="0 0 41.02 37.5">\n\t\t\t\t\t<g id="message" transform="translate(0 -21.966)">\n\t\t\t\t\t\t<path id="Path_5" data-name="Path 5" d="M0,21.966v37.5l8.771-9.29H41.02V21.966ZM11.365,39.233a3.25,3.25,0,1,1,3.25-3.25A3.254,3.254,0,0,1,11.365,39.233Zm9.147,0a3.25,3.25,0,1,1,3.25-3.25A3.254,3.254,0,0,1,20.512,39.233Zm9.147,0a3.25,3.25,0,1,1,3.25-3.25A3.254,3.254,0,0,1,29.659,39.233Z" />\n\t\t\t\t\t<\/g>\n\t\t\t\t<\/svg>\n\t\t\t\t<span>Tap to Text<br> <span class="ltkpopup-shortcode">JOIN<\/span> to <span class="ltkpopup-shortcode">69629<\/span><\/span>\n\t\t\t<\/div>\n\t\t<\/a>\n\n\t\t<div class="ltkpopup-button-container ltkpopup-clearfix">\n\t\t\t<div class="ltkpopup-no-thanks">\n\t\t\t\t<a href="#" class="ltkpopup-close">No thanks<\/a>\n\t\t\t<\/div>\n\t\t<\/div>\n\n\t\t<p class="ltkpopup-disclaimer">By subscribing to Nine West text messaging, you agree to receive recurring autodialed marketing text messages (e.g. cart reminders) to the mobile number used at opt&dash;in. Consent is not a condition of purchase. Message frequency may vary. Msg &amp; data rates may apply. Reply HELP for help and STOP to cancel. See <a href="https://ninewest.com/policies/terms-of-service" target="_blank">Terms and Conditions<\/a> &amp; <a href="https://ninewest.com/policies/privacy-policy" target="_blank">Privacy&nbsp;Policy<\/a>.<\/p>\n\n\t\t<div id="ltkpopup-close-button">\n\t\t\t<a class="ltkpopup-close" tabindex="0" role="button" aria-label="close">\n\t\t\t\t<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">\n\t\t\t\t\t<line x1="1" y1="1" x2="28" y2="28" />\n\t\t\t\t\t<line x1="28" y1="1" x2="1" y2="28" />\n\t\t\t\t<\/svg>\n\t\t\t<\/a>\n\t\t<\/div>\n\n\t<\/div>\n<\/div>\n\n\n<script type="text/javascript">\n\tfunction handleSMSRedirect() {\n\t\tvar shortCode = \'69629\';\n\t\tvar keyWord = \'JOIN\';\n\t\tvar cc = shortCode.length >= 11 ? \'+\' : \'\';\n\t\tvar userAgent = function () {\n\t\t\treturn !!navigator.userAgent.toLowerCase().match(/(iphone|ipod|ipad)/) ? "&body=" : "?body=";\n\t\t};\n\t\tvar _str = \'sms://\' + cc + shortCode + \'/\' + userAgent() + keyWord;\n\t\tdocument.location.assign(_str);\n\t}\n\n\tsetTimeout(function () {\n\t\thandleSMSRedirect();\n\t}, 0);\n<\/script>\n\n\t\t\t\t\t\t',
            formCSS: '@import url("https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;1,300;1,900&display=swap");#ltkpopup-wrapper .ltkpopup-clearfix::before,#ltkpopup-wrapper .ltkpopup-clearfix::after{content:"";display:table}#ltkpopup-wrapper .ltkpopup-clearfix::after{clear:both}#ltkpopup-wrapper .ltkpopup-clearfix{zoom:1}.ios-only{position:fixed}.ltkpopup-visuallyhidden{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);border:0}.ltkpopup-visuallyhidden.focusable:active,.ltkpopup-visuallyhidden.focusable:focus{position:static;width:auto;height:auto;margin:0;overflow:visible;clip:auto}.ltkpopup-img-fluid{width:100%;height:auto}.ltkpopup-full-width{width:100% !important;max-width:100% !important}.ltkpopup-content-wrap{max-width:450px;margin:0 auto}#ltkpopup-overlay{z-index:100001 !important;position:fixed !important;top:0 !important;bottom:0 !important;width:100% !important;height:100% !important;background-color:#000 !important;opacity:.65 !important;-webkit-transition:all 240ms ease-in;transition:all 240ms ease-in}#ltkpopup-container{z-index:100010 !important;position:fixed !important;width:280px !important;height:auto !important;max-height:100%;top:50% !important;left:50% !important;margin-left:0 !important;-webkit-transform:translate(-50%, -50%) !important;-moz-transform:translate(-50%, -50%) !important;-ms-transform:translate(-50%, -50%) !important;transform:translate(-50%, -50%) !important;overflow-x:hidden;overflow-y:auto}#ltkpopup-wrapper{position:relative;margin:0 auto;width:100% !important}#ltkpopup-container .simpleltkmodal-wrap{overflow:visible !important}#ltkpopup-wrapper *{box-sizing:border-box;backface-visibility:hidden !important}#ltkpopup-wrapper{background:transparent;font-size:13px;font-family:"ltk-FuturaLTPro",sans-serif;-webkit-font-smoothing:subpixel-antialiased}#ltkpopup-wrapper .no-wrap{white-space:nowrap}#ltkpopup-content{float:none;width:100%;padding:31px 16px 38px;font-size:13px;text-align:center;color:#111;line-height:20px;background:#fff}.ltkpopup-form-control{position:relative}#ltkpopup-close-button{position:absolute;right:10px;top:10px;margin:0px;z-index:10}#ltkpopup-close-button a{display:block;width:16px;height:16px;cursor:pointer}#ltkpopup-close-button a svg{width:100%;height:100%;position:relative;display:block;overflow:visible;stroke:#111;stroke-width:8px;-webkit-transition:all 240ms linear;transition:all 240ms linear}#ltkpopup-close-button a:hover svg{stroke:#000}#ltkpopup-close-button a:focus svg{stroke:#444}#ltkpopup-close-button.ltkpopup-circle-close{top:10px;right:10px}#ltkpopup-close-button.ltkpopup-circle-close a{width:16px;height:16px;background:#000;border-radius:50%;padding:10px;border:1px solid #111}#ltkpopup-content h1,#ltkpopup-content h2,#ltkpopup-content h3,#ltkpopup-content h4,#ltkpopup-content h5{margin:0;padding:0;text-align:center;font-family:"ltk-FuturaLTPro",sans-serif}#ltkpopup-content h1{font-weight:700;font-size:30px;line-height:44px;color:#111}#ltkpopup-content h1 span{display:block}#ltkpopup-content h2,#ltkpopup-content .ltkpopup-subheadline{font-weight:700;font-size:16px;line-height:24px;color:#111}#ltkpopup-content p{margin:15px 0 22px;font-size:13px;line-height:20px;text-align:center;font-family:"ltk-FuturaLTPro",sans-serif}#ltkpopup-content p.ltkpopup-disclaimer{margin:11px auto 0;font-size:10px;line-height:15px}#ltkpopup-content p.ltkpopup-disclaimer a{color:inherit;text-decoration:underline;font-family:"ltk-FuturaLTPro",sans-serif}#ltkpopup-content p.ltkpopup-disclaimer a:hover{text-decoration:none}#ltkpopup-content p.ltkpopup-disclaimer span{font-weight:700}@font-face{src:url("https://mediacdn.espssl.com/10030/Shared/NineWest/TTJ/Fonts/FuturaLTPro-Book.eot") format("embedded-opentype"),url("https://mediacdn.espssl.com/10030/Shared/NineWest/TTJ/Fonts/FuturaLTPro-Book.woff2") format("woff2"),url("https://mediacdn.espssl.com/10030/Shared/NineWest/TTJ/Fonts/FuturaLTPro-Book.woff") format("woff"),url("https://mediacdn.espssl.com/10030/Shared/NineWest/TTJ/Fonts/FuturaLTPro-Book.ttf") format("truetype"),url("https://mediacdn.espssl.com/10030/Shared/NineWest/TTJ/Fonts/FuturaLTPro-Book.svg") format("svg");font-family:"ltk-FuturaLTPro";font-weight:400}@font-face{src:url("https://mediacdn.espssl.com/10030/Shared/NineWest/TTJ/Fonts/FuturaLTPro-Heavy.eot") format("embedded-opentype"),url("https://mediacdn.espssl.com/10030/Shared/NineWest/TTJ/Fonts/FuturaLTPro-Heavy.woff2") format("woff2"),url("https://mediacdn.espssl.com/10030/Shared/NineWest/TTJ/Fonts/FuturaLTPro-Heavy.woff") format("woff"),url("https://mediacdn.espssl.com/10030/Shared/NineWest/TTJ/Fonts/FuturaLTPro-Heavy.ttf") format("truetype"),url("https://mediacdn.espssl.com/10030/Shared/NineWest/TTJ/Fonts/FuturaLTPro-Heavy.svg") format("svg");font-family:"ltk-FuturaLTPro";font-weight:700}#ltkpopup-content .ltkpopup-button-container{position:relative;width:100%}#ltkpopup-content .ltkpopup-no-thanks{float:none;width:100%;text-align:center}#ltkpopup-content .ltkpopup-no-thanks a{margin:2px 0 0 0;display:block;padding:10px;font-family:"ltk-FuturaLTPro",sans-serif;font-size:12px;font-weight:700;line-height:17px;color:#111;text-decoration:underline;-webkit-transition:all 240ms linear;transition:all 240ms linear;font-family:"ltk-FuturaLTPro",sans-serif}#ltkpopup-content .ltkpopup-no-thanks a:focus{text-decoration:none}#ltkpopup-content.ltkpopup-sms-image{background:url("https://via.placeholder.com/300x600/e5b13d");background-size:cover;display:table-cell;float:none;width:100%;height:auto;padding:20px;vertical-align:middle}#ltkpopup-client-logo{padding:20px 0;text-align:center}#ltkpopup-client-logo img{width:130px;height:60px;text-align:center;overflow:hidden}#ltkpopup-content .ltkpopup-sms-link{display:block;padding:22px 0 0 85px;margin:0 auto;max-width:234px;height:80px;background-color:#000;border-radius:40px;font-size:15px;font-family:"Roboto",sans-serif;position:relative;text-decoration:none;text-align:left}#ltkpopup-content .ltkpopup-sms-link span{width:auto;font-weight:300;text-align:left;line-height:17px;color:#fff}#ltkpopup-content .ltkpopup-sms-link span .ltkpopup-shortcode{font-style:italic;float:none;font-style:italic;font-weight:900 !important}#ltkpopup-content .ltkpopup-sms-link svg{position:absolute;top:25px;left:29px;width:41px;height:auto;margin:0 0;fill:#fff}#ltkpopup-content .ltkpopup-sms-link div.ltkpopup-sms-inner-container{width:100%;margin:0 auto}',
            confirmationHTML: "<!-- -->",
            animation: null,
            urlRedirect: null,
            initialDelay: 3,
            buttonSettings: {
                size: 1,
                shape: 1,
                alignment: 2,
                text: "Subscribe",
                color: "#00BDE5",
                textColor: "#FFFFFF"
            },
            urlRules: [],
            targetingRules: {
                showWhenDevice: ["Mobile"]
            },
            subscriptionPoint: "Popup",
            engagement: {
                followUpTimeframe: 0,
                showWhenPageSession: 1,
                followUp: !1,
                followUpDelay: 0,
                showIfFromListrakEmail: !1
            },
            overlayClose: !0,
            referrerRule: null
        }
    }, {
        type: 1,
        category: 0,
        popupUID: "224973b4-87f2-4cff-9deb-53ded022f035",
        popupName: "NW- SS23 - Entry Popup",
        clientUID: "4812bcb7-32f3-4732-92d1-a34659911750",
        companyID: 0,
        isActive: !1,
        lastModified: "2023-09-13T15:20:30.79Z",
        settings: {
            scrollDepth: 0,
            isTestMode: !0,
            formHTML: '<!-- Pop-up Form -->\n<!-- ltkpopup-no-scroll: centers the popup on display by preventing the page from scrolling -->\n<!-- ltkpopup-ios-fix: keeps fixed position popups like bottom banners in place in iOS -->\n<div id="ltkpopup-wrapper" class="ltkpopup-signup ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n        <!-- Custom Fonts can be placed below if applicable -->\n        \n        <link rel="stylesheet" href="https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/fontawesomev5.min.css">\n\n\n        <!-- Main Popup Content Area -->\n        <!-- Add class ltkpopup-no-padd for split popups -->\n        <div id="ltkpopup-content" class="ltkpopup-signup ltkpopup-no-padd">\n\n\n                <!-- Pull in the popup container -->\n                <div class="ltkpopup-clearfix ltkpopup-split-content ">\n\n\n        <div class="ltkpopup-contain-img" id="ltkpopup-img-contained">\n                <img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/SS23/Entry_Pop_Up_Email_Optin2.jpg" alt="" class="ltkpopup-img-fluid" aria-hidden="true">\n        <\/div>\n\n\n        <div class="ltkpopup-contain-form">\n\n\n                <div class="ltkpopup-form-control">\n\n\n                        <div class="ltkpopup-content-wrap">\n                                <h1 id="ltkpopup-headline" class="ltkpopup-headline">RECEIVE 15% OFF <span class="ltkpopup-subheadline">WHEN YOU SUBSCRIBE TODAY!<\/span><\/h1>\n<p id="ltkpopup-content-para" class="ltkpopup-content-para">Get the latest on new arrivals, trends, sales, and exclusive&nbsp;offers.<\/p>\n\n\n                                <div class="ltkpopup-form-contain" id="ltkpopup-form">\n\n\n                                        <div class="ltkpopup-form-contain">\n\n\n        <div class="ltkpopup-form-control">\n\n\n                <!-- Email Input Required Error Message|Moved out of column for display purposes -->\n                <div class="ltkpopup-error-message" aria-live="assertive" data-ltkpopup-error-for="ltkpopup-email" data-ltkpopup-message="Please enter a valid email address"><\/div>\n                \n                <label class="ltkpopup-visuallyhidden" for="ltkpopup-email">Email Address<\/label>\n<input autofocus required type="email" id="ltkpopup-email" class="ltkpopup-email" tabindex="0" name="ltkpopup-email" placeholder="Email Address (required)" autocomplete="email" pattern="^([a-zA-Z0-9._+!-]+[@](?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,})$" onchange="_ltk.SCA.Update(\'email\', this.value)" />\n\n\n        <\/div>\n\n\n        <div class="ltkpopup-form-control">\n                \n                <!-- Phone Input Required Error Message | Moved out of column for display purposes -->\n                <div class="ltkpopup-error-message" aria-live="assertive" data-ltkpopup-error-for="ltkpopup-phone" data-ltkpopup-message="Please enter a valid phone number"><\/div>\n\n\n                <label class="ltkpopup-visuallyhidden" for="ltkpopup-phone">Mobile Phone<\/label>\n<input type="tel" id="ltkpopup-phone" class="ltkpopup-email" tabindex="0" name="ltkpopup-phone" placeholder="Mobile Number (optional)" autocomplete="tel" data-inputmask="\'mask\': \'(###) ###-####\'" pattern="^\\D?(\\d{3})\\D?\\D?(\\d{3})\\D?(\\d{4})$" />\n                \n        <\/div>\n\n\n        <!-- Emmet Snippets if applicable -->\n        <!-- zip error dropdown checkbox radio sms-capture -->\n\n\n        <!-- Button Container -->\n        <div class="ltkpopup-button-container ltkpopup-flex ltkpopup-clearfix">\n                <!-- Submit Button -->\n                <button id="ltkpopup-submit" class="ltkpopup-subscribe" tabindex="0" type="submit"><span>SIGN UP NOW<\/span><\/button>\n\n\n                <!-- Text Close Button -->\n                <div class="ltkpopup-no-thanks ltkpopup-visuallyhidden" id="ltkpopup-text-btn">\n                        <!-- Do Not Delete. Add class ltkpopup-visuallyhidden -->\n                        <button tabindex="0" class="ltkpopup-close">maybe later<\/button>\n                <\/div>\n        <\/div>\n\n\n<\/div>\n\n\n                                <\/div>\n\n\n                                <p class="ltkpopup-content-para ltkpopup-disclaimer">By providing your number above, you agree to receive recurring autodialed marketing text msgs to the mobile number used at opt-in from Nine West on 69629. Consent is not a condition of purchase. Msg frequency may vary. Msg & data rates may apply. Reply HELP for help and STOP to cancel.<br><br>See <a href="http://ninewest.com/policies/terms-of-service" target="_blank">Terms and Conditions<\/a> &amp; <a href="http://ninewest.com/policies/privacy-policy" target="_blank">Privacy&nbspPolicy<\/a>.<\/p>\n\n\n                        <\/div>\n                <\/div>\n\n\n        <\/div>\n\n\n<\/div>\n                \n\n\n                <!-- Emmet Snippets if applicable -->\n                <!-- zip error dropdown checkbox radio sms-capture -->\n\n\n                <!-- Do Not Delete. Connects the Popup to Segmentation within the Listrak platform. Input name needs to match segmentation -->\n                <div class="ltkpopup-source">\n                        <input type="hidden" class="text" name="Source.Popup" value="On" tabindex="-1" />\n                <\/div>\n\n\n                <!-- Close \'X\' Button -->\n                <!-- Add class ltkpopup-circle-close to create a circle close button -->\n<div id="ltkpopup-close-button" class="ltkpopup-circle-close">\n        <a class="ltkpopup-close" tabindex="0" role="button" aria-label="close">\n                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">\n                        <line x1="1" y1="1" x2="28" y2="28" />\n                        <line x1="28" y1="1" x2="1" y2="28" />\n                <\/svg>\n        <\/a>\n<\/div>\n\n\n        <\/div>\n        <!-- End ltkpopup-content -->\n\n\n<\/div>\n<!-- End ltkpopup-wrapper -->\n\n\n<script>\n        var emailVal;\n        jQuery(\'#ltkpopup-submit\').on(\'click\', function () {\n                emailVal = jQuery(\'#ltkpopup-email\').val();\n                phoneVal = jQuery(\'#ltkpopup-phone\').val();\n                var e = jQuery(":input");\n                jQuery(e).each(function (e) {\n                        checkInputValidity(this);\n                        if (jQuery(this).is(":invalid")) {\n                                this.setAttribute("aria-describedby", this.id + "-error-message");\n                        } else {\n                                this.removeAttribute("aria-describedby")\n                        }\n                });\n                setTimeout(function () {\n                        if (document.querySelector(".ltkinputnotvalid") != null) {\n                                document.querySelector(".ltkinputnotvalid").focus();\n                        }\n                }, 0);\n        });\n<\/script>\n\n\n<script>\n        // Browsers\n        var b = document.documentElement;\n        b.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n        var $html = jQuery("html"),\n                ua = $html.data("useragent"),\n                pf = $html.data("platform");\n\n\n        function is(e) {\n                return ua.indexOf(e) > -1\n        }\n        var browser = {\n                isIE: is("msie") || is("trident/7.0"),\n                isIE7: is("msie 7.0"),\n                isIE8: is("msie 8.0"),\n                isIE9: is("msie 9.0"),\n                isIE10: is("msie 10"),\n                isIE11: is("rv:11") && is("trident/7.0"),\n                isEdge: is("edge"),\n                isChrome: is("chrome") && !is("edge"),\n                isSafari: is("safari") && !is("chrome") && !is("edge"),\n                isFirefox: is("firefox") && !is("edge"),\n                isAndroidChrome: is("android") && is("chrome"),\n                isAndroidDefault: is("android") && !is("chrome"),\n                isWin7: is("windows nt 6.1"),\n                isWin8: is("windows nt 6.2"),\n                isWindows: pf.indexOf("win32") > -1,\n                isWebkit: is("webkit") && !is("edge"),\n                isIPad: is("ipad"),\n                isIPadChrome: is("ipad") && is("crios"),\n                isIPhone: is("iphone"),\n                isIPhoneChrome: is("iphone") && is("crios"),\n                isAndroid: is("android"),\n                isIOS: is("iphone") || is("ipad")\n        };\n        for (var title in browser) {\n                var helperClass = title.slice(2).toLowerCase();\n                browser[title] && jQuery("#ltkpopup-content").addClass(helperClass)\n        }\n\n\n        // Close Function\n        jQuery(\'.ltkpopup-close\').focus(function () {\n                jQuery(\'.ltkpopup-close\').keypress(function (e) {\n                        var key = e.which;\n                        if (key == 13) {\n                                jQuery(\'#ltkpopup-overlay, #ltkpopup-container\').remove()\n                        }\n                })\n        });\n\n\n        // Check Input Validity\n        function checkInputValidity(inputEl) {\n                jQuery(inputEl).removeClass("ltkinputnotvalid");\n                var ltkErrorMessage = jQuery("[data-ltkpopup-error-for=\'" + inputEl.id + "\'");\n                jQuery(ltkErrorMessage).text("");\n                inputEl.checkValidity();\n                if (jQuery(inputEl).is(\':invalid\')) {\n                        jQuery(inputEl).addClass("ltkinputnotvalid");\n                        var ltkErrorMessageText = jQuery(ltkErrorMessage).attr("data-ltkpopup-message");\n                        jQuery(ltkErrorMessage).text(ltkErrorMessageText);\n                        return false;\n                }\n                return true;\n        }\n\n\n\n\n\n\n        changeFocus = function () {\n                if (document.getElementById("ltkpopup-email") == undefined && document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined) {\n                        document.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n                }\n        }\n\n\n        // Tab Trapping\n        jQuery(document).ready(function () {\n                setTimeout(function () {\n                        function triggerFocus(element) {\n                                var eventType = "onfocusin" in element ? "focusin" : "focus",\n                                        bubbles = "onfocusin" in element,\n                                        event;\n\n\n                                if ("createEvent" in document) {\n                                        event = document.createEvent("Event");\n                                        event.initEvent(eventType, bubbles, true);\n                                } else if ("Event" in window) {\n                                        event = new Event(eventType, {\n                                                bubbles: bubbles,\n                                                cancelable: true\n                                        });\n                                }\n\n\n                                element.focus();\n                                element.dispatchEvent(event);\n                        }\n                        if (document.getElementById("ltkpopup-email") != undefined) {\n                                triggerFocus(document.getElementById("ltkpopup-email"));\n                        } else {\n                                changeFocus();\n                        }\n                }, 0);\n        });\n\n\n        function trapTabKey(e) {\n                var t = document.activeElement,\n                        s = focusableElems.indexOf(t);\n                if (9 === e.keyCode) {\n                        e.preventDefault();\n                        moveTab(s, e.shiftKey)\n                }\n        }\n\n\n        function moveTab(index, shift) {\n                var nextTab = null;\n                var nextIndex = index;\n                if (shift) {\n                        if (focusableElems[index] == firstTabStop) {\n                                nextTab = lastTabStop;\n                        } else {\n                                nextIndex = index - 1;\n                                nextTab = focusableElem[nextIndex];\n                        }\n                } else {\n                        if (focusableElems[index] == lastTabStop) {\n                                nextTab = firstTabStop;\n                        } else {\n                                nextIndex = index + 1;\n                                nextTab = focusableElems[nextIndex];\n                        }\n                }\n\n\n                if (jQuery(nextTab).is(":visible")) {\n                        nextTab.focus();\n                } else {\n                        moveTab(nextIndex, shift);\n                }\n        }\n        window.onload = function () {\n                var e = document.getElementById("ltkpopup-img-contained");\n                e && (2 == window.getComputedStyle(e).getPropertyValue("order") && (e.className += " ltkpopup-img-right"))\n        }, setTimeout(function () {\n                //Do not delete - tab functionality will break\n                _ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n                changeFocus();\n        }, 50);\n        var focused = document.activeElement;\n        jQuery(".ltkpopup-close").on("click", function () {\n                focused.focus()\n        });\n        var focusBox = document.getElementById("ltkpopup-content"),\n                focusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n                focusableElem = focusBox.querySelectorAll(focusableElemStr),\n                focusableElems = Array.prototype.slice.call(focusableElem),\n                firstTabStop = focusableElems[0],\n                lastTabStop = focusableElems[focusableElems.length - 1];\n        focusBox.addEventListener("keydown", trapTabKey);\n\n\n        \n        $("body").bind("DOMSubtreeModified", function() {\n            if($(\'#smile-ui-container\')){\n                        $(\'#smile-ui-container\').css(\'z-index\',\'999\');\n                }\n        });\n<\/script>\n<script>\n    jQuery(document).ready(function () {\n\n\n        if (jQuery("[data-inputmask]").length) {\n            \n                // Input masking for number validation - Get Jquery Input Mask from CDN and load it\n                jQuery.getScript(\n                    "https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.1/jquery.inputmask.bundle.js",\n                    function () {\n                        jQuery("[data-inputmask]").each(function() {\n                             // Mask phone number input after script is loaded\n                            jQuery(this).inputmask({greedy: false, showMaskOnHover: false, definitions: {\n                            \'#\': { validator: "[0-9]", cardinality: 1\n                            }\n                            }\n                            });\n                        });\n                    });\n        }\n    });\n<\/script>\n<script>\n        var datepickerField = document.querySelector("#ltkpopup-datepicker");\n        if (datepickerField != null) {\n                var jQueryUIcss = document.createElement("link");\n                jQueryUIcss.href = "https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css";\n                jQueryUIcss.rel = "stylesheet";\n                jQueryUIcss.addEventListener("load", function () {\n                        var jQueryUI = document.createElement("script");\n                        jQueryUI.src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js";\n                        jQueryUI.addEventListener("load", function () {\n                                datepickerField.setAttribute("readonly", "");\n                                jQuery(datepickerField).datepicker({\n                                        changeMonth: true,\n                                        changeYear: false,\n                                        yearRange: \'-0:+0\',\n                                        // use for different date format and hidden bday field\n                                        dateFormat: "mm/dd",\n                                        altField: "#ltkpopup-hidden-bday",\n                                        altFormat: "mm/dd/1900"\n                                });\n\n\n                                jQuery(datepickerField).focus(function () {\n                                        jQuery(\'#ui-datepicker-div\').appendTo(this.parentNode);\n                                });\n                        });\n                        document.getElementById("ltkpopup-content").appendChild(jQueryUI);\n                });\n                document.getElementById("ltkpopup-content").appendChild(jQueryUIcss);\n        }\n<\/script>',
            formCSS: '#ltkpopup-wrapper .ltkpopup-clearfix::before,#ltkpopup-wrapper .ltkpopup-clearfix::after{content:"";display:table}#ltkpopup-wrapper .ltkpopup-clearfix::after{clear:both}#ltkpopup-wrapper .ltkpopup-clearfix{zoom:1}.ios-only{position:fixed}.ltkpopup-visuallyhidden{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);border:0}.ltkpopup-visuallyhidden.focusable:active,.ltkpopup-visuallyhidden.focusable:focus{position:static;width:auto;height:auto;margin:0;overflow:visible;clip:auto}.ltkpopup-img-fluid{width:100%;height:auto}.ltkpopup-full-width{width:100% !important;max-width:100% !important}.ltkpopup-content-wrap{max-width:450px;margin:0 auto}#ltkpopup-thanks{text-align:center}#ltkpopup-thanks input{display:inline-block}#smile-ui-container,#keyboard-nav-34,#keyboard-nav-37{z-index:99990 !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-wrapper .mobileHide{display:none}}#ltkpopup-content .ltk-grid{margin:0 auto;width:100%}#ltkpopup-content .ltk-row{padding-bottom:20px}#ltkpopup-content .ltk-row:last-of-type{padding-bottom:0px}#ltkpopup-content .ltk-col-1{width:100%}#ltkpopup-content .ltk-col-1-2{width:50%}#ltkpopup-content .ltk-col-2-3{width:66.66%}#ltkpopup-content .ltk-col-1-3{width:33.33%}#ltkpopup-content [class*=\'ltk-col-\']{float:left}#ltkpopup-content [class*=\'ltk-col-\']{padding-right:0}#ltkpopup-content [class*=\'ltk-col-\']:last-of-type{padding-right:0;padding-left:10px}#ltkpopup-content .ltk-col-1-3{padding-right:14px}#ltkpopup-content .ltk-col-1-3+.ltk-col-1-3{padding-right:6px;padding-left:6px}#ltkpopup-content .ltk-col-1-3:last-of-type{padding-right:0;padding-left:0}#ltkpopup-content .ltk-col-1,#ltkpopup-content .ltk-col-1:last-of-type{padding-right:0;padding-top:0;padding-left:0}#ltkpopup-overlay{z-index:100001 !important;position:fixed !important;top:0 !important;bottom:0 !important;width:100% !important;height:100% !important;background-color:#000 !important;opacity:.5 !important;-webkit-transition:all .25s ease-in;transition:all .25s ease-in}#ltkpopup-container{z-index:100010 !important;position:fixed !important;width:710px !important;height:auto !important;max-height:100%;top:50% !important;left:50% !important;margin-left:0 !important;-webkit-transform:translate(-50%, -50%) !important;-moz-transform:translate(-50%, -50%) !important;-ms-transform:translate(-50%, -50%) !important;transform:translate(-50%, -50%) !important;overflow-x:hidden;overflow-y:auto;-webkit-box-shadow:0 5px 15px rgba(0,0,0,0.5);-moz-box-shadow:0 5px 15px rgba(0,0,0,0.5);box-shadow:0 5px 15px rgba(0,0,0,0.5)}#ltkpopup-wrapper{position:relative;margin:0 auto;width:100% !important}#ltkpopup-container .simpleltkmodal-wrap{overflow:visible !important}#ltkpopup-wrapper *{box-sizing:border-box;backface-visibility:hidden !important}#ltkpopup-wrapper{background:transparent;font-size:12px;font-family:Arial,Helvetica,sans-serif;-webkit-font-smoothing:subpixel-antialiased}#ltkpopup-wrapper .no-wrap{white-space:nowrap}#ltkpopup-content{padding:3em;font-size:12px;text-align:left;color:#000;line-height:1.4;background:#f8f8fa}.ltkpopup-fullscreen{position:relative;max-width:710px;height:auto !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-container{width:100% !important;height:100% !important}#ltkpopup-wrapper{width:320px !important}#ltkpopup-content{float:none;width:100%;padding:40px 20px 30px 20px}}#ltkpopup-content .ltkpopup-split-content{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-webkit-box-align:center;-moz-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img{max-width:300px;-webkit-box-flex:0 0 300px;-moz-box-flex:0 0 300px;-webkit-flex:0 0 300px;-ms-flex:0 0 300px;flex:0 0 300px;line-height:0;order:2;-ms-flex-order:2}#ltkpopup-content .ltkpopup-split-content.ltkpopup-image-bottom .ltkpopup-contain-img-full{line-height:0}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form{max-width:410px;-webkit-box-flex:0 0 410px;-moz-box-flex:0 0 410px;-webkit-flex:0 0 410px;-ms-flex:0 0 410px;flex:0 0 410px;-ms-flex:0 0 410px;padding:10px 10px 10px;order:1;-ms-flex-order:1}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form .ltkpopup-no-thanks{float:none;text-align:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-full-width{padding-top:30px}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below{flex-wrap:wrap}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form{max-width:100%;-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full{-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%;order:2;line-height:0}#ltkpopup-content.ie6 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie7 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie8 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie9 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie10 .ltkpopup-split-content .ltkpopup-contain-img{width:300px;float:right}#ltkpopup-content.ie6 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie7 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie8 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie9 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie10 .ltkpopup-split-content .ltkpopup-contain-form{width:410px;float:left;padding-top:70px}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below{flex-wrap:wrap}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form{width:100%}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full{width:100%}#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-form{position:relative;left:-2px}#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-img.ltkpopup-img-right img,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-img.ltkpopup-img-right img,#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-form-right,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-form-right{position:relative;right:-2px;left:auto}#ltkpopup-content.safari,#ltkpopup-content.ipad{overflow-x:hidden;overflow-y:hidden}#ltkpopup-content.ie .ltkpopup-split-content,#ltkpopup-content.ie11 .ltkpopup-split-content{padding-bottom:2px}#ltkpopup-content.ie .ltkpopup-split-content .ltkpopup-img-fluid,#ltkpopup-content.ie11 .ltkpopup-split-content .ltkpopup-img-fluid{position:relative;bottom:-1px}#ltkpopup-content.ltkpopup-no-padd{padding:0 !important}#ltkpopup-content.ltkpopup-no-padd .ltkpopup-no-padd{padding:0 !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-formcontent,#ltkpopup-form,#ltkpopup-wrapper{width:100% !important;height:100% !important;background-color:#F8F8FA}#ltkpopup-content{width:100%}#ltkpopup-content .ltkpopup-split-content{width:100%;height:100%;-webkit-align-items:center;-moz-align-items:center;-ms-align-items:center;align-items:center;-webkit-justify-content:center;-moz-justify-content:center;-ms-justify-content:center;justify-content:center;-ms-flex-pack:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img-full,#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img{display:none}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form{width:100%;flex:0 0 100%;-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%;padding:40px 20px 10px}#ltkpopup-content.ltkpopup-confirm .ltkpopup-split-content .ltkpopup-contain-form{padding:40px 20px}}#ltkpopup-close-button{position:absolute;left:7px;top:7px;margin:0px;z-index:10}#ltkpopup-close-button a{display:block;width:12px;height:12px;cursor:pointer}#ltkpopup-close-button a svg{width:100%;height:100%;position:relative;display:block;overflow:visible;stroke:#333;stroke-width:6px;-webkit-transition:all .25s linear;transition:all .25s linear}#ltkpopup-close-button a:hover svg{stroke:#858585}#ltkpopup-close-button a:focus svg{stroke:#858585}#ltkpopup-close-button.ltkpopup-circle-close{right:7px;top:7px}#ltkpopup-close-button.ltkpopup-circle-close a{width:22px;height:22px;background:#FFF;border-radius:50%;padding:4px;border:2px solid #333}#ltkpopup-close-button.ltkpopup-circle-close a:hover,#ltkpopup-close-button.ltkpopup-circle-close a:focus{border-color:#858585}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-close-button{right:7px;top:7px}#ltkpopup-close-button a{width:12px;height:12px}}#ltkpopup-content h1,#ltkpopup-content h2,#ltkpopup-content h3,#ltkpopup-content h4,#ltkpopup-content h5,#ltkpopup-content .ltkpopup-headline,#ltkpopup-content .ltkpopup-subheadline{margin:0;padding:0;text-align:center;font-family:Arial,Helvetica,sans-serif !important}#ltkpopup-content h1,#ltkpopup-content .ltkpopup-headline{font-weight:700;font-size:26px;line-height:30px;color:#000;letter-spacing:1px;margin-bottom:10px;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content h2,#ltkpopup-content .ltkpopup-subheadline{font-weight:400;font-size:14px;line-height:25px;color:#000;display:block;margin-top:10px;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content p,#ltkpopup-content .ltkpopup-content-para{margin:0 0 5px;font-size:12px;line-height:19px;font-family:Arial,Helvetica,sans-serif;text-align:center;letter-spacing:.5px}#ltkpopup-content p.ltkpopup-disclaimer,#ltkpopup-content p.ltkpopup-sms-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer{font-size:8px;line-height:16px;text-align:center;margin:30px 10px 0;letter-spacing:0}#ltkpopup-content p.ltkpopup-disclaimer a,#ltkpopup-content p.ltkpopup-sms-disclaimer a,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a{color:inherit;text-decoration:underline;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content p.ltkpopup-disclaimer a:hover,#ltkpopup-content p.ltkpopup-disclaimer a:focus,#ltkpopup-content p.ltkpopup-sms-disclaimer a:hover,#ltkpopup-content p.ltkpopup-sms-disclaimer a:focus,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:hover,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:focus,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:hover,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:focus{text-decoration:none}#ltkpopup-content p.ltkpopup-disclaimer span,#ltkpopup-content p.ltkpopup-sms-disclaimer span,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer span,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer span{font-weight:700}#ltkpopup-content.ltkpopup-confirm p,#ltkpopup-content.ltkpopup-confirm .ltkpopup-content-para{margin:10px auto}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content h1,#ltkpopup-content .ltkpopup-headline{font-size:26px;line-height:30px}#ltkpopup-content h2,#ltkpopup-content .ltkpopup-subheadline{font-size:14px;line-height:25px}#ltkpopup-content p,#ltkpopup-content .ltkpopup-content-para{font-size:12px;line-height:19px}#ltkpopup-content p.ltkpopup-disclaimer,#ltkpopup-content p.ltkpopup-sms-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer{font-size:8px;line-height:16px}}#ltkpopup-content input[type="text"],#ltkpopup-content input[type="email"],#ltkpopup-content input[type="number"],#ltkpopup-content input[type="tel"]{display:block;width:100%;height:32px;padding:0 1em;margin:0 auto;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:400;text-align:left;color:#000;line-height:normal;background-color:transparent;border:1px solid #000;border-radius:0px !important;box-shadow:inset 0 0 0 1000px #FFF;-webkit-transition:all 0.11s linear;transition:all 0.11s linear;-webkit-appearance:none;-moz-appearance:none;appearance:none}#ltkpopup-content input[type="text"]:focus,#ltkpopup-content input[type="email"]:focus,#ltkpopup-content input[type="number"]:focus,#ltkpopup-content input[type="tel"]:focus{outline:none;border:2px solid #000}#ltkpopup-content input[type="text"]:last-of-type{margin:10px auto 0}#ltkpopup-content .ltkpopup-form-control{position:relative}#ltkpopup-content .ltkpopup-form-contain{max-width:320px;margin:0 auto}#ltkpopup-content input::-webkit-input-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input::-moz-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input:-ms-input-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input::-ms-clear{display:none;width:0;height:0;opacity:0}#ltkpopup-content .ltk-floating-input{width:250px;float:left}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content input[type="text"],#ltkpopup-content input[type="email"],#ltkpopup-content input[type="number"],#ltkpopup-content input[type="tel"]{float:none;width:100%;font-size:15px}#ltkpopup-content .ltk-floating-input{width:100%;padding-bottom:15px}}#ltkpopup-content input[type="radio"]{position:absolute;overflow:hidden;clip:rect(0 0 0 0);height:1px;width:1px;margin:-1px;padding:0;border:0}#ltkpopup-content .radio-wrapper{padding:10px 0;text-align:left}#ltkpopup-content .ltk-radio{position:relative;float:left;width:50%}#ltkpopup-content .ltk-radio label{position:relative;display:block;padding:0px 4px;cursor:pointer}#ltkpopup-content .ltk-radio label::before{position:absolute;display:block;float:left;padding:0 3px 0 0;font-family:FontAwesome;font-size:12px;color:#fff;content:"\\f111";border-radius:0px}#ltkpopup-content .ltk-radio label span{display:block;padding:0 0 0 22px}#ltkpopup-content .ltk-radio input:checked ~ label::before{color:#fff;content:"\\f192"}#ltkpopup-content .ltk-radio input:hover+label::before{color:#000}#ltkpopup-content .ltk-radio input:focus+label::before{color:#fff}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkmodal-wrapper .radio-wrapper{padding:5px 0}}#ltkpopup-content input[type="checkbox"]{position:absolute;overflow:hidden;clip:rect(0 0 0 0);height:1px;width:1px;margin:-1px;padding:0;border:0}#ltkpopup-content fieldset#ltkpopup-options{border:none;margin:5px auto 10px;padding:0;width:100%;max-width:150px}#ltkpopup-content .ltkpopup-legend,#ltkpopup-content .ltkpopup-legend-styling{font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:12px;line-height:19px;text-align:center;color:#000;white-space:normal;margin:0 auto}#ltkpopup-content .ltkpopup-legend .ltklegend-regular,#ltkpopup-content .ltkpopup-legend-styling .ltklegend-regular{font-weight:400;text-transform:none;font-size:8px;line-height:16px;color:#000;display:block}#ltkpopup-content .ltkpopup-column{width:50%;display:block;float:left}#ltkpopup-content .ltkpopup-checkbox{float:left;width:100%}#ltkpopup-content .ltkpopup-checkbox label{display:block;position:relative;padding:0px 0px 3px;cursor:pointer;font-size:14px;margin-top:9px;margin-bottom:0;font-weight:400}#ltkpopup-content .ltkpopup-checkbox label:before{position:absolute !important;display:block;float:left;text-align:center;content:"";width:14px;height:14px;border:1px solid #000}#ltkpopup-content .ltkpopup-checkbox label span{display:block;padding:0px 0 0 24px;line-height:17px}#ltkpopup-content .ltkpopup-checkbox input:checked+label::before{font-family:FontAwesome;content:"\\f00c";color:#000;font-size:14px;line-height:14px}#ltkpopup-content .ltkpopup-checkbox input:focus+label::before,#ltkpopup-content .ltkpopup-checkbox input:hover+label::before{border-color:#000}#ltkpopup-content .ltkpopup-checkbox input:checked:hover+label::before{opacity:.7}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content fieldset#ltkpopup-options{display:block;margin-top:15px}}#ltkpopup-content .dropdown{position:relative;width:100%;height:32px;margin:10px 0;padding:0;font-size:12px;font-weight:400;text-overflow:ellipsis;border-radius:0 !important;cursor:pointer}#ltkpopup-content .dropdown select{width:100%;height:100%;padding:0 10px;z-index:1;font-family:Arial,Helvetica,sans-serif;font-size:12px;font-weight:400;color:#000;text-indent:0 !important;background:#fff;border:1px solid #000;border-radius:0;cursor:pointer;-webkit-appearance:none !important;-moz-appearance:none !important;appearance:none !important}#ltkpopup-content .dropdown select:focus{border-color:#000;outline:none}#ltkpopup-content .dropdown::before{position:absolute;display:block;right:10px;top:50%;margin-top:-10px;z-index:2;font-family:FontAwesome;font-size:14px;content:"\\f0d7";color:#000;pointer-events:none;-webkit-transition:all .25s linear;transition:all .25s linear}#ltkpopup-content .dropdown select::-ms-expand{display:none !important}#ltkpopup-content input.ltkinputnotvalid,#ltkpopup-content div.dropdown.ltk-select-notvalid,#ltkpopup-content div.dropdown select.ltkinputnotvalid{border-color:red}#ltkpopup-content input.ltkinputnotvalid:focus,#ltkpopup-content div.dropdown.ltk-select-notvalid:focus,#ltkpopup-content div.dropdown select.ltkinputnotvalid:focus{border-color:red}#ltkpopup-content input.ltkinputnotvalid::-webkit-input-placeholder{color:red}#ltkpopup-content input.ltkinputnotvalid::-moz-placeholder{color:red}#ltkpopup-content input.ltkinputnotvalid:-ms-input-placeholder{color:red}#ltkpopup-content .ltkpopup-error-message{display:block;height:14px;text-align:center;line-height:14px;width:100%;font-size:10px;color:red;font-weight:700}#ltkpopup-content .ltkpopup-error-message:empty{visibility:hidden}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-error-message{line-height:14px;font-size:10px}}#ltkpopup-content .ltkpopup-button-container{position:relative;width:100%;overflow:hidden}#ltkpopup-content .ltkpopup-button-container.ltkpopup-flex{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;flex-wrap:wrap;-ms-flex-wrap:wrap;-webkit-box-align:center;-moz-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center;margin-top:15px;text-align:center}#ltkpopup-content .ltkpopup-subscribe,#ltkpopup-content .ltkpopup-close-button,#ltkpopup-content .ltkpopup-faux-subscribe{display:inline-block;position:relative;width:100%;max-width:320px;margin:auto;padding:7px;vertical-align:middle;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:400;color:#fff;height:32px;text-decoration:none;background-color:#000;border:1px solid #000;border-radius:0 !important;box-shadow:none !important;cursor:pointer;outline:none;-webkit-appearance:none !important;-moz-appearance:none !important;appearance:none !important;-webkit-transition:all .25s linear;transition:all .25s linear;transition:.25s;overflow:hidden}#ltkpopup-content .ltkpopup-subscribe span,#ltkpopup-content .ltkpopup-close-button span,#ltkpopup-content .ltkpopup-faux-subscribe span{position:relative;z-index:1}#ltkpopup-content .ltkpopup-subscribe:hover,#ltkpopup-content .ltkpopup-close-button:hover,#ltkpopup-content .ltkpopup-faux-subscribe:hover{color:#fff;background-color:#858585;border-color:#858585}#ltkpopup-content .ltkpopup-subscribe:focus,#ltkpopup-content .ltkpopup-close-button:focus,#ltkpopup-content .ltkpopup-faux-subscribe:focus{color:#fff;background-color:#858585;border-color:#858585;transition:0s}#ltkpopup-content .ltkpopup-close-button{float:none;margin:10px auto 0px;line-height:normal}#ltkpopup-content .ltkpopup-no-thanks{float:none;width:100%;text-align:center}#ltkpopup-content .ltkpopup-no-thanks a,#ltkpopup-content .ltkpopup-no-thanks button{background:none;border:none;display:inline-block;padding:10px;font-size:12px;font-weight:400;color:#000;text-decoration:underline;-webkit-transition:all .25s linear;transition:all .25s linear;cursor:pointer;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content .ltkpopup-no-thanks a:hover,#ltkpopup-content .ltkpopup-no-thanks a:focus,#ltkpopup-content .ltkpopup-no-thanks button:hover,#ltkpopup-content .ltkpopup-no-thanks button:focus{text-decoration:none}#ltkpopup-content .ltkpopup-float-fields{width:350px;margin:0 auto}#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button{width:100px;float:left}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-subscribe,#ltkpopup-content .ltkpopup-close-button,#ltkpopup-content .ltkpopup-faux-subscribe{font-size:16px;margin-top:5px}#ltkpopup-content .ltkpopup-no-thanks a,#ltkpopup-content .ltkpopup-no-thanks button{font-size:12px}#ltkpopup-content .ltkpopup-float-fields{width:100%}#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button{width:100%}}',
            confirmationHTML: '\n\t\t\t\t\t\t\t<!-- Pop-up Confirm / Appears after user submits Popup Form -->\n<div id="ltkpopup-wrapper" class="confirm ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n\t<!-- Custom Fonts can be placed below if applicable -->\n\t\n\t<link rel="stylesheet" href="https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/fontawesomev5.min.css">\n\n\t<!-- Main Popup Content Area -->\n\t<!-- Add class ltkpopup-no-padd for split popups -->\n\t<div id="ltkpopup-content" class="ltkpopup-confirm ltkpopup-no-padd">\n\n\t\t<!-- Pull in the popup container -->\n\t\t<div class="ltkpopup-clearfix ltkpopup-split-content ">\n\n\t<div class="ltkpopup-contain-img" id="ltkpopup-img-contained">\n\t\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/SS22/NW_EMAIL_POPUP_IMG_1440x840_SIGNUP_Final.jpg\n" alt="" class="ltkpopup-img-fluid" aria-hidden="true">\n\t<\/div>\n\n\t<div class="ltkpopup-contain-form">\n\n\t\t<div class="ltkpopup-form-control">\n\n\t\t\t<div class="ltkpopup-content-wrap">\n\n\t\t\t\t<h1 id="ltkpopup-headline" class="ltkpopup-headline">THANK YOU<\/h1>\n<h2 id="ltkpopup-subheadline" class="ltkpopup-subheadline">You have been subscribed.<\/h2>\n<p id="ltkpopup-content-para" class="ltkpopup-content-para">To apply your 15% off coupon now, click below.<\/p>\n\n\t\t\t\t<div class="ltkpopup-button-container" id="ltkpopup-thanks">\n    <a tabindex="0" class="ltkpopup-close-button ltkpopup-close" href="https://ninewest.com/discount/WELCOME15">APPLY COUPON<\/a>\n<\/div>\n\n\t\t\t<\/div>\n\t\t<\/div>\n\t\t\n\t<\/div>\n\n<\/div>\n\t\t\n\n\t\t<!-- End Content Information -->\n\n\t\t<!-- Close \'X\' Button -->\n\t\t<!-- Add class ltkpopup-circle-close to create a circle close button -->\n<div id="ltkpopup-close-button" class="ltkpopup-circle-close">\n\t<a class="ltkpopup-close" tabindex="0" role="button" aria-label="close">\n\t\t<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">\n\t\t\t<line x1="1" y1="1" x2="28" y2="28" />\n\t\t\t<line x1="28" y1="1" x2="1" y2="28" />\n\t\t<\/svg>\n\t<\/a>\n<\/div>\n\t<\/div>\n<\/div>\n\n\n<script>\n\tvar reg = /^\\D?(\\d{3})\\D?\\D?(\\d{3})\\D?(\\d{4})$/;\n\tif (typeof phoneVal != "undefined" && phoneVal != "" && phoneVal.match(reg)) {\n\t\t_ltk.Subscriber.Email = phoneVal;\n\t\t_ltk.Subscriber.List = \'DesktopSMS\';\n\t\t_ltk.Subscriber.Profile.Add(\'Email\', emailVal);\n\t\t_ltk.Subscriber.Submit(true);\n\t}\n<\/script>\n<script>\n\t// Browsers\n\tvar b = document.documentElement;\n\tb.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n\tvar $html = jQuery("html"),\n\t\tua = $html.data("useragent"),\n\t\tpf = $html.data("platform");\n\n\tfunction is(e) {\n\t\treturn ua.indexOf(e) > -1\n\t}\n\tvar browser = {\n\t\tisIE: is("msie") || is("trident/7.0"),\n\t\tisIE7: is("msie 7.0"),\n\t\tisIE8: is("msie 8.0"),\n\t\tisIE9: is("msie 9.0"),\n\t\tisIE10: is("msie 10"),\n\t\tisIE11: is("rv:11") && is("trident/7.0"),\n\t\tisEdge: is("edge"),\n\t\tisChrome: is("chrome") && !is("edge"),\n\t\tisSafari: is("safari") && !is("chrome") && !is("edge"),\n\t\tisFirefox: is("firefox") && !is("edge"),\n\t\tisAndroidChrome: is("android") && is("chrome"),\n\t\tisAndroidDefault: is("android") && !is("chrome"),\n\t\tisWin7: is("windows nt 6.1"),\n\t\tisWin8: is("windows nt 6.2"),\n\t\tisWindows: pf.indexOf("win32") > -1,\n\t\tisWebkit: is("webkit") && !is("edge"),\n\t\tisIPad: is("ipad"),\n\t\tisIPadChrome: is("ipad") && is("crios"),\n\t\tisIPhone: is("iphone"),\n\t\tisIPhoneChrome: is("iphone") && is("crios"),\n\t\tisAndroid: is("android"),\n\t\tisIOS: is("iphone") || is("ipad")\n\t};\n\tfor (var title in browser) {\n\t\tvar helperClass = title.slice(2).toLowerCase();\n\t\tbrowser[title] && jQuery("#ltkpopup-content").addClass(helperClass)\n\t}\n\n\t// Close Function\n\tjQuery(\'.ltkpopup-close\').focus(function () {\n\t\tjQuery(\'.ltkpopup-close\').keypress(function (e) {\n\t\t\tvar key = e.which;\n\t\t\tif (key == 13) {\n\t\t\t\tjQuery(\'#ltkpopup-overlay, #ltkpopup-container\').remove()\n\t\t\t}\n\t\t})\n\t});\n\n\t// Check Input Validity\n\tfunction checkInputValidity(inputEl) {\n\t\tjQuery(inputEl).removeClass("ltkinputnotvalid");\n\t\tvar ltkErrorMessage = jQuery("[data-ltkpopup-error-for=\'" + inputEl.id + "\'");\n\t\tjQuery(ltkErrorMessage).text("");\n\t\tinputEl.checkValidity();\n\t\tif (jQuery(inputEl).is(\':invalid\')) {\n\t\t\tjQuery(inputEl).addClass("ltkinputnotvalid");\n\t\t\tvar ltkErrorMessageText = jQuery(ltkErrorMessage).attr("data-ltkpopup-message");\n\t\t\tjQuery(ltkErrorMessage).text(ltkErrorMessageText);\n\t\t\treturn false;\n\t\t}\n\t\treturn true;\n\t}\n\n\n\n\tchangeFocus = function () {\n\t\tif (document.getElementById("ltkpopup-email") == undefined && document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined) {\n\t\t\tdocument.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n\t\t}\n\t}\n\n\t// Tab Trapping\n\tjQuery(document).ready(function () {\n\t\tsetTimeout(function () {\n\t\t\tfunction triggerFocus(element) {\n\t\t\t\tvar eventType = "onfocusin" in element ? "focusin" : "focus",\n\t\t\t\t\tbubbles = "onfocusin" in element,\n\t\t\t\t\tevent;\n\n\t\t\t\tif ("createEvent" in document) {\n\t\t\t\t\tevent = document.createEvent("Event");\n\t\t\t\t\tevent.initEvent(eventType, bubbles, true);\n\t\t\t\t} else if ("Event" in window) {\n\t\t\t\t\tevent = new Event(eventType, {\n\t\t\t\t\t\tbubbles: bubbles,\n\t\t\t\t\t\tcancelable: true\n\t\t\t\t\t});\n\t\t\t\t}\n\n\t\t\t\telement.focus();\n\t\t\t\telement.dispatchEvent(event);\n\t\t\t}\n\t\t\tif (document.getElementById("ltkpopup-email") != undefined) {\n\t\t\t\ttriggerFocus(document.getElementById("ltkpopup-email"));\n\t\t\t} else {\n\t\t\t\tchangeFocus();\n\t\t\t}\n\t\t}, 0);\n\t});\n\n\tfunction trapTabKey(e) {\n\t\tvar t = document.activeElement,\n\t\t\ts = focusableElems.indexOf(t);\n\t\tif (9 === e.keyCode) {\n\t\t\te.preventDefault();\n\t\t\tmoveTab(s, e.shiftKey)\n\t\t}\n\t}\n\n\tfunction moveTab(index, shift) {\n\t\tvar nextTab = null;\n\t\tvar nextIndex = index;\n\t\tif (shift) {\n\t\t\tif (focusableElems[index] == firstTabStop) {\n\t\t\t\tnextTab = lastTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index - 1;\n\t\t\t\tnextTab = focusableElem[nextIndex];\n\t\t\t}\n\t\t} else {\n\t\t\tif (focusableElems[index] == lastTabStop) {\n\t\t\t\tnextTab = firstTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index + 1;\n\t\t\t\tnextTab = focusableElems[nextIndex];\n\t\t\t}\n\t\t}\n\n\t\tif (jQuery(nextTab).is(":visible")) {\n\t\t\tnextTab.focus();\n\t\t} else {\n\t\t\tmoveTab(nextIndex, shift);\n\t\t}\n\t}\n\twindow.onload = function () {\n\t\tvar e = document.getElementById("ltkpopup-img-contained");\n\t\te && (2 == window.getComputedStyle(e).getPropertyValue("order") && (e.className += " ltkpopup-img-right"))\n\t}, setTimeout(function () {\n\t\t//Do not delete - tab functionality will break\n\t\t_ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n\t\tchangeFocus();\n\t}, 50);\n\tvar focused = document.activeElement;\n\tjQuery(".ltkpopup-close").on("click", function () {\n\t\tfocused.focus()\n\t});\n\tvar focusBox = document.getElementById("ltkpopup-content"),\n\t\tfocusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n\t\tfocusableElem = focusBox.querySelectorAll(focusableElemStr),\n\t\tfocusableElems = Array.prototype.slice.call(focusableElem),\n\t\tfirstTabStop = focusableElems[0],\n\t\tlastTabStop = focusableElems[focusableElems.length - 1];\n\tfocusBox.addEventListener("keydown", trapTabKey);\n\n\t\n\t$("body").bind("DOMSubtreeModified", function() {\n    \tif($(\'#smile-ui-container\')){\n\t\t\t$(\'#smile-ui-container\').css(\'z-index\',\'999\');\n\t\t}\n\t});\n<\/script>\n\t\t\t\t\t\t',
            animation: null,
            urlRedirect: null,
            initialDelay: 2,
            buttonSettings: {
                size: 1,
                shape: 1,
                alignment: 2,
                text: "Subscribe",
                color: "#00BDE5",
                textColor: "#FFFFFF"
            },
            urlRules: [{
                urlMatchRule: 1,
                show: !1,
                url: "/account/"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "/cart"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "/checkouts/"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "/preference-center"
            }],
            targetingRules: {
                showWhenDevice: ["Desktop", "Mobile"]
            },
            subscriptionPoint: "Popup",
            engagement: {
                followUpTimeframe: 0,
                showWhenPageSession: 1,
                followUp: !0,
                followUpDelay: 10,
                showIfFromListrakEmail: !1
            },
            overlayClose: !0,
            referrerRule: null
        }
    }, {
        type: 2,
        category: 0,
        popupUID: "1a3fa9db-c6a5-403d-a501-79a837ba484a",
        popupName: "NW - SS23 - Exit Pop Up",
        clientUID: "4812bcb7-32f3-4732-92d1-a34659911750",
        companyID: 0,
        isActive: !0,
        lastModified: "2023-03-24T20:15:33.46Z",
        settings: {
            scrollDepth: 0,
            isTestMode: !1,
            formHTML: '<!-- Pop-up Form -->\n<!-- ltkpopup-no-scroll: centers the popup on display by preventing the page from scrolling -->\n<!-- ltkpopup-ios-fix: keeps fixed position popups like bottom banners in place in iOS -->\n<div id="ltkpopup-wrapper" class="ltkpopup-signup ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n        <!-- Custom Fonts can be placed below if applicable -->\n        \n        <link rel="stylesheet" href="https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/fontawesomev5.min.css">\n\n\n        <!-- Main Popup Content Area -->\n        <!-- Add class ltkpopup-no-padd for split popups -->\n        <div id="ltkpopup-content" class="ltkpopup-signup ltkpopup-no-padd">\n\n\n                <!-- Pull in the popup container -->\n                <div class="ltkpopup-clearfix ltkpopup-split-content ">\n\n\n        <div class="ltkpopup-contain-img" id="ltkpopup-img-contained">\n                <img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/SS23/Entry_Pop_Up_Email_Optin2.jpg" alt="" class="ltkpopup-img-fluid" aria-hidden="true">\n        <\/div>\n\n\n        <div class="ltkpopup-contain-form">\n\n\n                <div class="ltkpopup-form-control">\n\n\n                        <div class="ltkpopup-content-wrap">\n                                <h2 class="ltkpopup-subheadline">DON\'T LEAVE EMPTY&nbsp;HANDED!<\/h2>\n<h1 id="ltkpopup-headline" class="ltkpopup-headline">ENTER YOUR EMAIL<br> AND RECEIVE AN<br> EXTRA 15%&nbsp;OFF<\/h1>\n\n\n                                <div class="ltkpopup-form-contain" id="ltkpopup-form">\n\n\n                                        <div class="ltkpopup-form-contain">\n\n\n        <div class="ltkpopup-form-control">\n\n\n                <!-- Email Input Required Error Message|Moved out of column for display purposes -->\n                <div class="ltkpopup-error-message" aria-live="assertive" data-ltkpopup-error-for="ltkpopup-email" data-ltkpopup-message="Please enter a valid email address"><\/div>\n                \n                <label class="ltkpopup-visuallyhidden" for="ltkpopup-email">Email Address<\/label>\n<input autofocus required type="email" id="ltkpopup-email" class="ltkpopup-email" tabindex="0" name="ltkpopup-email" placeholder="Email Address (required)" autocomplete="email" pattern="^([a-zA-Z0-9._+!-]+[@](?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,})$" onchange="_ltk.SCA.Update(\'email\', this.value)" />\n\n\n        <\/div>\n\n\n\n\n        <!-- Emmet Snippets if applicable -->\n        <!-- zip error dropdown checkbox radio sms-capture -->\n\n\n        <!-- Button Container -->\n        <div class="ltkpopup-button-container ltkpopup-flex ltkpopup-clearfix">\n                <!-- Submit Button -->\n                <button id="ltkpopup-submit" class="ltkpopup-subscribe" tabindex="0" type="submit"><span>GET YOUR 15% OFF NOW<\/span><\/button>\n\n\n                <!-- Text Close Button -->\n                <div class="ltkpopup-no-thanks ltkpopup-visuallyhidden" id="ltkpopup-text-btn">\n                        <!-- Do Not Delete. Add class ltkpopup-visuallyhidden -->\n                        <button tabindex="0" class="ltkpopup-close">maybe later<\/button>\n                <\/div>\n        <\/div>\n\n\n<\/div>\n\n\n                                <\/div>\n\n\n\n\n                        <\/div>\n                <\/div>\n\n\n        <\/div>\n\n\n<\/div>\n                \n\n\n                <!-- Emmet Snippets if applicable -->\n                <!-- zip error dropdown checkbox radio sms-capture -->\n\n\n                <!-- Do Not Delete. Connects the Popup to Segmentation within the Listrak platform. Input name needs to match segmentation -->\n                <div class="ltkpopup-source">\n                        <input type="hidden" class="text" name="Source.Popup" value="On" tabindex="-1" />\n                <\/div>\n\n\n                <!-- Close \'X\' Button -->\n                <!-- Add class ltkpopup-circle-close to create a circle close button -->\n<div id="ltkpopup-close-button" class="ltkpopup-circle-close">\n        <a class="ltkpopup-close" tabindex="0" role="button" aria-label="close">\n                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">\n                        <line x1="1" y1="1" x2="28" y2="28" />\n                        <line x1="28" y1="1" x2="1" y2="28" />\n                <\/svg>\n        <\/a>\n<\/div>\n\n\n        <\/div>\n        <!-- End ltkpopup-content -->\n\n\n<\/div>\n<!-- End ltkpopup-wrapper -->\n\n\n<script>\n        var emailVal;\n        jQuery(\'#ltkpopup-submit\').on(\'click\', function () {\n                emailVal = jQuery(\'#ltkpopup-email\').val();\n                var e = jQuery(":input");\n                jQuery(e).each(function (e) {\n                        checkInputValidity(this);\n                        if (jQuery(this).is(":invalid")) {\n                                this.setAttribute("aria-describedby", this.id + "-error-message");\n                        } else {\n                                this.removeAttribute("aria-describedby")\n                        }\n                });\n                setTimeout(function () {\n                        if (document.querySelector(".ltkinputnotvalid") != null) {\n                                document.querySelector(".ltkinputnotvalid").focus();\n                        }\n                }, 0);\n        });\n<\/script>\n\n\n<script>\n        // Browsers\n        var b = document.documentElement;\n        b.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n        var $html = jQuery("html"),\n                ua = $html.data("useragent"),\n                pf = $html.data("platform");\n\n\n        function is(e) {\n                return ua.indexOf(e) > -1\n        }\n        var browser = {\n                isIE: is("msie") || is("trident/7.0"),\n                isIE7: is("msie 7.0"),\n                isIE8: is("msie 8.0"),\n                isIE9: is("msie 9.0"),\n                isIE10: is("msie 10"),\n                isIE11: is("rv:11") && is("trident/7.0"),\n                isEdge: is("edge"),\n                isChrome: is("chrome") && !is("edge"),\n                isSafari: is("safari") && !is("chrome") && !is("edge"),\n                isFirefox: is("firefox") && !is("edge"),\n                isAndroidChrome: is("android") && is("chrome"),\n                isAndroidDefault: is("android") && !is("chrome"),\n                isWin7: is("windows nt 6.1"),\n                isWin8: is("windows nt 6.2"),\n                isWindows: pf.indexOf("win32") > -1,\n                isWebkit: is("webkit") && !is("edge"),\n                isIPad: is("ipad"),\n                isIPadChrome: is("ipad") && is("crios"),\n                isIPhone: is("iphone"),\n                isIPhoneChrome: is("iphone") && is("crios"),\n                isAndroid: is("android"),\n                isIOS: is("iphone") || is("ipad")\n        };\n        for (var title in browser) {\n                var helperClass = title.slice(2).toLowerCase();\n                browser[title] && jQuery("#ltkpopup-content").addClass(helperClass)\n        }\n\n\n        // Close Function\n        jQuery(\'.ltkpopup-close\').focus(function () {\n                jQuery(\'.ltkpopup-close\').keypress(function (e) {\n                        var key = e.which;\n                        if (key == 13) {\n                                jQuery(\'#ltkpopup-overlay, #ltkpopup-container\').remove()\n                        }\n                })\n        });\n\n\n        // Check Input Validity\n        function checkInputValidity(inputEl) {\n                jQuery(inputEl).removeClass("ltkinputnotvalid");\n                var ltkErrorMessage = jQuery("[data-ltkpopup-error-for=\'" + inputEl.id + "\'");\n                jQuery(ltkErrorMessage).text("");\n                inputEl.checkValidity();\n                if (jQuery(inputEl).is(\':invalid\')) {\n                        jQuery(inputEl).addClass("ltkinputnotvalid");\n                        var ltkErrorMessageText = jQuery(ltkErrorMessage).attr("data-ltkpopup-message");\n                        jQuery(ltkErrorMessage).text(ltkErrorMessageText);\n                        return false;\n                }\n                return true;\n        }\n\n\n\n\n\n\n        changeFocus = function () {\n                if (document.getElementById("ltkpopup-email") == undefined && document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined) {\n                        document.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n                }\n        }\n\n\n        // Tab Trapping\n        jQuery(document).ready(function () {\n                setTimeout(function () {\n                        function triggerFocus(element) {\n                                var eventType = "onfocusin" in element ? "focusin" : "focus",\n                                        bubbles = "onfocusin" in element,\n                                        event;\n\n\n                                if ("createEvent" in document) {\n                                        event = document.createEvent("Event");\n                                        event.initEvent(eventType, bubbles, true);\n                                } else if ("Event" in window) {\n                                        event = new Event(eventType, {\n                                                bubbles: bubbles,\n                                                cancelable: true\n                                        });\n                                }\n\n\n                                element.focus();\n                                element.dispatchEvent(event);\n                        }\n                        if (document.getElementById("ltkpopup-email") != undefined) {\n                                triggerFocus(document.getElementById("ltkpopup-email"));\n                        } else {\n                                changeFocus();\n                        }\n                }, 0);\n        });\n\n\n        function trapTabKey(e) {\n                var t = document.activeElement,\n                        s = focusableElems.indexOf(t);\n                if (9 === e.keyCode) {\n                        e.preventDefault();\n                        moveTab(s, e.shiftKey)\n                }\n        }\n\n\n        function moveTab(index, shift) {\n                var nextTab = null;\n                var nextIndex = index;\n                if (shift) {\n                        if (focusableElems[index] == firstTabStop) {\n                                nextTab = lastTabStop;\n                        } else {\n                                nextIndex = index - 1;\n                                nextTab = focusableElem[nextIndex];\n                        }\n                } else {\n                        if (focusableElems[index] == lastTabStop) {\n                                nextTab = firstTabStop;\n                        } else {\n                                nextIndex = index + 1;\n                                nextTab = focusableElems[nextIndex];\n                        }\n                }\n\n\n                if (jQuery(nextTab).is(":visible")) {\n                        nextTab.focus();\n                } else {\n                        moveTab(nextIndex, shift);\n                }\n        }\n        window.onload = function () {\n                var e = document.getElementById("ltkpopup-img-contained");\n                e && (2 == window.getComputedStyle(e).getPropertyValue("order") && (e.className += " ltkpopup-img-right"))\n        }, setTimeout(function () {\n                //Do not delete - tab functionality will break\n                _ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n                changeFocus();\n        }, 50);\n        var focused = document.activeElement;\n        jQuery(".ltkpopup-close").on("click", function () {\n                focused.focus()\n        });\n        var focusBox = document.getElementById("ltkpopup-content"),\n                focusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n                focusableElem = focusBox.querySelectorAll(focusableElemStr),\n                focusableElems = Array.prototype.slice.call(focusableElem),\n                firstTabStop = focusableElems[0],\n                lastTabStop = focusableElems[focusableElems.length - 1];\n        focusBox.addEventListener("keydown", trapTabKey);\n\n\n        \n        $("body").bind("DOMSubtreeModified", function() {\n            if($(\'#smile-ui-container\')){\n                        $(\'#smile-ui-container\').css(\'z-index\',\'999\');\n                }\n        });\n<\/script>\n<script>\n    jQuery(document).ready(function () {\n\n\n        if (jQuery("[data-inputmask]").length) {\n            \n                // Input masking for number validation - Get Jquery Input Mask from CDN and load it\n                jQuery.getScript(\n                    "https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.1/jquery.inputmask.bundle.js",\n                    function () {\n                        jQuery("[data-inputmask]").each(function() {\n                             // Mask phone number input after script is loaded\n                            jQuery(this).inputmask({greedy: false, showMaskOnHover: false, definitions: {\n                            \'#\': { validator: "[0-9]", cardinality: 1\n                            }\n                            }\n                            });\n                        });\n                    });\n        }\n    });\n<\/script>\n<script>\n        var datepickerField = document.querySelector("#ltkpopup-datepicker");\n        if (datepickerField != null) {\n                var jQueryUIcss = document.createElement("link");\n                jQueryUIcss.href = "https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css";\n                jQueryUIcss.rel = "stylesheet";\n                jQueryUIcss.addEventListener("load", function () {\n                        var jQueryUI = document.createElement("script");\n                        jQueryUI.src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js";\n                        jQueryUI.addEventListener("load", function () {\n                                datepickerField.setAttribute("readonly", "");\n                                jQuery(datepickerField).datepicker({\n                                        changeMonth: true,\n                                        changeYear: false,\n                                        yearRange: \'-0:+0\',\n                                        // use for different date format and hidden bday field\n                                        dateFormat: "mm/dd",\n                                        altField: "#ltkpopup-hidden-bday",\n                                        altFormat: "mm/dd/1900"\n                                });\n\n\n                                jQuery(datepickerField).focus(function () {\n                                        jQuery(\'#ui-datepicker-div\').appendTo(this.parentNode);\n                                });\n                        });\n                        document.getElementById("ltkpopup-content").appendChild(jQueryUI);\n                });\n                document.getElementById("ltkpopup-content").appendChild(jQueryUIcss);\n        }\n<\/script>',
            formCSS: '#ltkpopup-wrapper .ltkpopup-clearfix::before,#ltkpopup-wrapper .ltkpopup-clearfix::after{content:"";display:table}#ltkpopup-wrapper .ltkpopup-clearfix::after{clear:both}#ltkpopup-wrapper .ltkpopup-clearfix{zoom:1}.ios-only{position:fixed}.ltkpopup-visuallyhidden{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);border:0}.ltkpopup-visuallyhidden.focusable:active,.ltkpopup-visuallyhidden.focusable:focus{position:static;width:auto;height:auto;margin:0;overflow:visible;clip:auto}.ltkpopup-img-fluid{width:100%;height:auto}.ltkpopup-full-width{width:100% !important;max-width:100% !important}.ltkpopup-content-wrap{max-width:450px;margin:0 auto}#ltkpopup-thanks{text-align:center}#ltkpopup-thanks input{display:inline-block}#smile-ui-container,#keyboard-nav-34,#keyboard-nav-37{z-index:99990 !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-wrapper .mobileHide{display:none}}#ltkpopup-content .ltk-grid{margin:0 auto;width:100%}#ltkpopup-content .ltk-row{padding-bottom:20px}#ltkpopup-content .ltk-row:last-of-type{padding-bottom:0px}#ltkpopup-content .ltk-col-1{width:100%}#ltkpopup-content .ltk-col-1-2{width:50%}#ltkpopup-content .ltk-col-2-3{width:66.66%}#ltkpopup-content .ltk-col-1-3{width:33.33%}#ltkpopup-content [class*=\'ltk-col-\']{float:left}#ltkpopup-content [class*=\'ltk-col-\']{padding-right:0}#ltkpopup-content [class*=\'ltk-col-\']:last-of-type{padding-right:0;padding-left:10px}#ltkpopup-content .ltk-col-1-3{padding-right:14px}#ltkpopup-content .ltk-col-1-3+.ltk-col-1-3{padding-right:6px;padding-left:6px}#ltkpopup-content .ltk-col-1-3:last-of-type{padding-right:0;padding-left:0}#ltkpopup-content .ltk-col-1,#ltkpopup-content .ltk-col-1:last-of-type{padding-right:0;padding-top:0;padding-left:0}#ltkpopup-overlay{z-index:100001 !important;position:fixed !important;top:0 !important;bottom:0 !important;width:100% !important;height:100% !important;background-color:#000 !important;opacity:.5 !important;-webkit-transition:all .25s ease-in;transition:all .25s ease-in}#ltkpopup-container{z-index:100010 !important;position:fixed !important;width:710px !important;height:auto !important;max-height:100%;top:50% !important;left:50% !important;margin-left:0 !important;-webkit-transform:translate(-50%, -50%) !important;-moz-transform:translate(-50%, -50%) !important;-ms-transform:translate(-50%, -50%) !important;transform:translate(-50%, -50%) !important;overflow-x:hidden;overflow-y:auto;-webkit-box-shadow:0 5px 15px rgba(0,0,0,0.5);-moz-box-shadow:0 5px 15px rgba(0,0,0,0.5);box-shadow:0 5px 15px rgba(0,0,0,0.5)}#ltkpopup-wrapper{position:relative;margin:0 auto;width:100% !important}#ltkpopup-container .simpleltkmodal-wrap{overflow:visible !important}#ltkpopup-wrapper *{box-sizing:border-box;backface-visibility:hidden !important}#ltkpopup-wrapper{background:transparent;font-size:12px;font-family:Arial,Helvetica,sans-serif;-webkit-font-smoothing:subpixel-antialiased}#ltkpopup-wrapper .no-wrap{white-space:nowrap}#ltkpopup-content{padding:3em;font-size:12px;text-align:left;color:#000;line-height:1.4;background:#F8F8FA}.ltkpopup-fullscreen{position:relative;max-width:710px;height:auto !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-container{width:320px !important}#ltkpopup-wrapper{width:320px !important}#ltkpopup-content{float:none;width:100%;padding:40px 20px 30px 20px}}#ltkpopup-content .ltkpopup-split-content{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-webkit-box-align:center;-moz-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img{max-width:300px;-webkit-box-flex:0 0 300px;-moz-box-flex:0 0 300px;-webkit-flex:0 0 300px;-ms-flex:0 0 300px;flex:0 0 300px;line-height:0;order:2;-ms-flex-order:2}#ltkpopup-content .ltkpopup-split-content.ltkpopup-image-bottom .ltkpopup-contain-img-full{line-height:0}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form{max-width:410px;-webkit-box-flex:0 0 410px;-moz-box-flex:0 0 410px;-webkit-flex:0 0 410px;-ms-flex:0 0 410px;flex:0 0 410px;-ms-flex:0 0 410px;padding:10px 10px 30px;order:1;-ms-flex-order:1}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form .ltkpopup-no-thanks{float:none;text-align:center}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-full-width{padding-top:30px}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below{flex-wrap:wrap}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form{max-width:100%;-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%}#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full{-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%;order:2;line-height:0}#ltkpopup-content.ie6 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie7 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie8 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie9 .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ie10 .ltkpopup-split-content .ltkpopup-contain-img{width:300px;float:right}#ltkpopup-content.ie6 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie7 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie8 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie9 .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.ie10 .ltkpopup-split-content .ltkpopup-contain-form{width:410px;float:left;padding-top:70px}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below{flex-wrap:wrap}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-form{width:100%}#ltkpopup-content.ie6 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie7 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie8 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie9 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full,#ltkpopup-content.ie10 .ltkpopup-split-content.ltkpopup-split-above-below .ltkpopup-contain-img-full{width:100%}#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-img,#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-form,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-form{position:relative;left:-2px}#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-img.ltkpopup-img-right img,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-img.ltkpopup-img-right img,#ltkpopup-content.ipad .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-form-right,#ltkpopup-content.safari .ltkpopup-split-content .ltkpopup-contain-form.ltkpopup-form-right{position:relative;right:-2px;left:auto}#ltkpopup-content.safari,#ltkpopup-content.ipad{overflow-x:hidden;overflow-y:hidden}#ltkpopup-content.ie .ltkpopup-split-content,#ltkpopup-content.ie11 .ltkpopup-split-content{padding-bottom:2px}#ltkpopup-content.ie .ltkpopup-split-content .ltkpopup-img-fluid,#ltkpopup-content.ie11 .ltkpopup-split-content .ltkpopup-img-fluid{position:relative;bottom:-1px}#ltkpopup-content.ltkpopup-no-padd{padding:0 !important}#ltkpopup-content.ltkpopup-no-padd .ltkpopup-no-padd{padding:0 !important}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img-full,#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img{display:none}#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form{max-width:100%;flex:0 0 100%;-webkit-box-flex:0 0 100%;-moz-box-flex:0 0 100%;-webkit-flex:0 0 100%;-ms-flex:0 0 100%;flex:0 0 100%;padding:40px 20px}}#ltkpopup-close-button{position:absolute;left:7px;top:7px;margin:0px;z-index:10}#ltkpopup-close-button a{display:block;width:12px;height:12px;cursor:pointer}#ltkpopup-close-button a svg{width:100%;height:100%;position:relative;display:block;overflow:visible;stroke:#333;stroke-width:6px;-webkit-transition:all .25s linear;transition:all .25s linear}#ltkpopup-close-button a:hover svg{stroke:#858585}#ltkpopup-close-button a:focus svg{stroke:#858585}#ltkpopup-close-button.ltkpopup-circle-close{right:7px;top:7px}#ltkpopup-close-button.ltkpopup-circle-close a{width:22px;height:22px;background:#FFF;border-radius:50%;padding:4px;border:2px solid #333}#ltkpopup-close-button.ltkpopup-circle-close a:hover,#ltkpopup-close-button.ltkpopup-circle-close a:focus{border-color:#858585}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-close-button{right:7px;top:7px}#ltkpopup-close-button a{width:12px;height:12px}}#ltkpopup-content h1,#ltkpopup-content h2,#ltkpopup-content h3,#ltkpopup-content h4,#ltkpopup-content h5,#ltkpopup-content .ltkpopup-headline,#ltkpopup-content .ltkpopup-subheadline{margin:0;padding:0;text-align:center;font-family:Arial,Helvetica,sans-serif !important}#ltkpopup-content h1,#ltkpopup-content .ltkpopup-headline{font-weight:700;font-size:22px;line-height:30px;color:#000;letter-spacing:1px;margin-bottom:10px}#ltkpopup-content h2,#ltkpopup-content .ltkpopup-subheadline{font-weight:400;font-size:18px;line-height:25px;color:#000;display:block;margin-bottom:20px}#ltkpopup-content p,#ltkpopup-content .ltkpopup-content-para{margin:0 0 5px;font-size:12px;line-height:19px;font-family:Arial,Helvetica,sans-serif;text-align:center;letter-spacing:.5px}#ltkpopup-content p.ltkpopup-disclaimer,#ltkpopup-content p.ltkpopup-sms-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer{font-size:8px;line-height:26px;text-align:center;margin:10px 10px 0;letter-spacing:0}#ltkpopup-content p.ltkpopup-disclaimer a,#ltkpopup-content p.ltkpopup-sms-disclaimer a,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a{color:inherit;text-decoration:underline;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content p.ltkpopup-disclaimer a:hover,#ltkpopup-content p.ltkpopup-disclaimer a:focus,#ltkpopup-content p.ltkpopup-sms-disclaimer a:hover,#ltkpopup-content p.ltkpopup-sms-disclaimer a:focus,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:hover,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:focus,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:hover,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:focus{text-decoration:none}#ltkpopup-content p.ltkpopup-disclaimer span,#ltkpopup-content p.ltkpopup-sms-disclaimer span,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer span,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer span{font-weight:700}#ltkpopup-content.ltkpopup-confirm p,#ltkpopup-content.ltkpopup-confirm .ltkpopup-content-para{margin:10px auto}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content h1,#ltkpopup-content .ltkpopup-headline{font-size:22px;line-height:30px}#ltkpopup-content h2,#ltkpopup-content .ltkpopup-subheadline{font-size:18px;line-height:25px}#ltkpopup-content p,#ltkpopup-content .ltkpopup-content-para{font-size:12px;line-height:19px}#ltkpopup-content p.ltkpopup-disclaimer,#ltkpopup-content p.ltkpopup-sms-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer{font-size:8px;line-height:16px}}#ltkpopup-content input[type="text"],#ltkpopup-content input[type="email"],#ltkpopup-content input[type="number"],#ltkpopup-content input[type="tel"]{display:block;width:100%;height:32px;padding:0 1em;margin:0 auto;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:400;text-align:left;color:#000;line-height:normal;background-color:transparent;border:1px solid #000;border-radius:0px !important;box-shadow:inset 0 0 0 1000px #FFF;-webkit-transition:all 0.11s linear;transition:all 0.11s linear;-webkit-appearance:none;-moz-appearance:none;appearance:none}#ltkpopup-content input[type="text"]:focus,#ltkpopup-content input[type="email"]:focus,#ltkpopup-content input[type="number"]:focus,#ltkpopup-content input[type="tel"]:focus{outline:none;border:2px solid #000}#ltkpopup-content input[type="text"]:last-of-type{margin:10px auto 0}#ltkpopup-content .ltkpopup-form-control{position:relative}#ltkpopup-content .ltkpopup-form-contain{max-width:320px;margin:0 auto}#ltkpopup-content input::-webkit-input-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input::-moz-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input:-ms-input-placeholder{font-weight:400;color:#858585;font-family:Arial,Helvetica,sans-serif;opacity:1}#ltkpopup-content input::-ms-clear{display:none;width:0;height:0;opacity:0}#ltkpopup-content .ltk-floating-input{width:250px;float:left}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content input[type="text"],#ltkpopup-content input[type="email"],#ltkpopup-content input[type="number"],#ltkpopup-content input[type="tel"]{float:none;width:100%;font-size:15px}#ltkpopup-content .ltk-floating-input{width:100%;padding-bottom:15px}}#ltkpopup-content input[type="radio"]{position:absolute;overflow:hidden;clip:rect(0 0 0 0);height:1px;width:1px;margin:-1px;padding:0;border:0}#ltkpopup-content .radio-wrapper{padding:10px 0;text-align:left}#ltkpopup-content .ltk-radio{position:relative;float:left;width:50%}#ltkpopup-content .ltk-radio label{position:relative;display:block;padding:0px 4px;cursor:pointer}#ltkpopup-content .ltk-radio label::before{position:absolute;display:block;float:left;padding:0 3px 0 0;font-family:FontAwesome;font-size:12px;color:#FFF;content:"\\f111";border-radius:0px}#ltkpopup-content .ltk-radio label span{display:block;padding:0 0 0 22px}#ltkpopup-content .ltk-radio input:checked ~ label::before{color:#FFF;content:"\\f192"}#ltkpopup-content .ltk-radio input:hover+label::before{color:#000}#ltkpopup-content .ltk-radio input:focus+label::before{color:#FFF}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkmodal-wrapper .radio-wrapper{padding:5px 0}}#ltkpopup-content input[type="checkbox"]{position:absolute;overflow:hidden;clip:rect(0 0 0 0);height:1px;width:1px;margin:-1px;padding:0;border:0}#ltkpopup-content fieldset#ltkpopup-options{border:none;margin:5px auto 10px;padding:0;width:100%;max-width:150px}#ltkpopup-content .ltkpopup-legend,#ltkpopup-content .ltkpopup-legend-styling{font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:12px;line-height:19px;text-align:center;color:#000;white-space:normal;margin:0 auto}#ltkpopup-content .ltkpopup-legend .ltklegend-regular,#ltkpopup-content .ltkpopup-legend-styling .ltklegend-regular{font-weight:400;text-transform:none;font-size:8px;line-height:26px;color:#000;display:block}#ltkpopup-content .ltkpopup-column{width:50%;display:block;float:left}#ltkpopup-content .ltkpopup-checkbox{float:left;width:100%}#ltkpopup-content .ltkpopup-checkbox label{display:block;position:relative;padding:0px 0px 3px;cursor:pointer;font-size:14px;margin-top:9px;margin-bottom:0;font-weight:400}#ltkpopup-content .ltkpopup-checkbox label:before{position:absolute !important;display:block;float:left;text-align:center;content:"";width:14px;height:14px;border:1px solid #000}#ltkpopup-content .ltkpopup-checkbox label span{display:block;padding:0px 0 0 24px;line-height:17px}#ltkpopup-content .ltkpopup-checkbox input:checked+label::before{font-family:FontAwesome;content:"\\f00c";color:#000;font-size:14px;line-height:14px}#ltkpopup-content .ltkpopup-checkbox input:focus+label::before,#ltkpopup-content .ltkpopup-checkbox input:hover+label::before{border-color:#000}#ltkpopup-content .ltkpopup-checkbox input:checked:hover+label::before{opacity:.7}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content fieldset#ltkpopup-options{display:block;margin-top:15px}}#ltkpopup-content .dropdown{position:relative;width:100%;height:32px;margin:10px 0;padding:0;font-size:12px;font-weight:400;text-overflow:ellipsis;border-radius:0 !important;cursor:pointer}#ltkpopup-content .dropdown select{width:100%;height:100%;padding:0 10px;z-index:1;font-family:Arial,Helvetica,sans-serif;font-size:12px;font-weight:400;color:#000;text-indent:0 !important;background:#FFF;border:1px solid #000;border-radius:0;cursor:pointer;-webkit-appearance:none !important;-moz-appearance:none !important;appearance:none !important}#ltkpopup-content .dropdown select:focus{border-color:#000;outline:none}#ltkpopup-content .dropdown::before{position:absolute;display:block;right:10px;top:50%;margin-top:-10px;z-index:2;font-family:FontAwesome;font-size:14px;content:"\\f0d7";color:#000;pointer-events:none;-webkit-transition:all .25s linear;transition:all .25s linear}#ltkpopup-content .dropdown select::-ms-expand{display:none !important}#ltkpopup-content input.ltkinputnotvalid,#ltkpopup-content div.dropdown.ltk-select-notvalid,#ltkpopup-content div.dropdown select.ltkinputnotvalid{border-color:red}#ltkpopup-content input.ltkinputnotvalid:focus,#ltkpopup-content div.dropdown.ltk-select-notvalid:focus,#ltkpopup-content div.dropdown select.ltkinputnotvalid:focus{border-color:red}#ltkpopup-content input.ltkinputnotvalid::-webkit-input-placeholder{color:red}#ltkpopup-content input.ltkinputnotvalid::-moz-placeholder{color:red}#ltkpopup-content input.ltkinputnotvalid:-ms-input-placeholder{color:red}#ltkpopup-content .ltkpopup-error-message{display:block;height:14px;text-align:center;line-height:14px;width:100%;font-size:10px;color:red;font-weight:700}#ltkpopup-content .ltkpopup-error-message:empty{visibility:hidden}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-error-message{line-height:14px;font-size:10px}}#ltkpopup-content .ltkpopup-button-container{position:relative;width:100%;overflow:hidden}#ltkpopup-content .ltkpopup-button-container.ltkpopup-flex{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;flex-wrap:wrap;-ms-flex-wrap:wrap;-webkit-box-align:center;-moz-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center;margin-top:20px;text-align:center}#ltkpopup-content .ltkpopup-subscribe,#ltkpopup-content .ltkpopup-close-button,#ltkpopup-content .ltkpopup-faux-subscribe{display:inline-block;position:relative;width:100%;max-width:320px;margin:auto;padding:7px;vertical-align:middle;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:400;color:#FFF;height:32px;text-decoration:none;background-color:#000;border:1px solid #000;border-radius:0 !important;box-shadow:none !important;cursor:pointer;outline:none;-webkit-appearance:none !important;-moz-appearance:none !important;appearance:none !important;-webkit-transition:all .25s linear;transition:all .25s linear;transition:.25s;overflow:hidden}#ltkpopup-content .ltkpopup-subscribe span,#ltkpopup-content .ltkpopup-close-button span,#ltkpopup-content .ltkpopup-faux-subscribe span{position:relative;z-index:1}#ltkpopup-content .ltkpopup-subscribe:hover,#ltkpopup-content .ltkpopup-close-button:hover,#ltkpopup-content .ltkpopup-faux-subscribe:hover{color:#FFF;background-color:#858585;border-color:#858585}#ltkpopup-content .ltkpopup-subscribe:focus,#ltkpopup-content .ltkpopup-close-button:focus,#ltkpopup-content .ltkpopup-faux-subscribe:focus{color:#FFF;background-color:#858585;border-color:#858585;transition:0s}#ltkpopup-content .ltkpopup-close-button{float:none;margin:10px auto 0px;line-height:normal}#ltkpopup-content .ltkpopup-no-thanks{float:none;width:100%;text-align:center}#ltkpopup-content .ltkpopup-no-thanks a,#ltkpopup-content .ltkpopup-no-thanks button{background:none;border:none;display:inline-block;padding:10px;font-size:12px;font-weight:400;color:#000;text-decoration:underline;-webkit-transition:all .25s linear;transition:all .25s linear;cursor:pointer;font-family:Arial,Helvetica,sans-serif}#ltkpopup-content .ltkpopup-no-thanks a:hover,#ltkpopup-content .ltkpopup-no-thanks a:focus,#ltkpopup-content .ltkpopup-no-thanks button:hover,#ltkpopup-content .ltkpopup-no-thanks button:focus{text-decoration:none}#ltkpopup-content .ltkpopup-float-fields{width:350px;margin:0 auto}#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button{width:100px;float:left}@media only screen and (min-width: 1px) and (max-width: 720px){#ltkpopup-content .ltkpopup-subscribe,#ltkpopup-content .ltkpopup-close-button,#ltkpopup-content .ltkpopup-faux-subscribe{font-size:16px;margin-top:5px}#ltkpopup-content .ltkpopup-no-thanks a,#ltkpopup-content .ltkpopup-no-thanks button{font-size:12px}#ltkpopup-content .ltkpopup-float-fields{width:100%}#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button{width:100%}}',
            confirmationHTML: '\n\t\t\t\t\t\t\t<!-- Pop-up Confirm / Appears after user submits Popup Form -->\n<div id="ltkpopup-wrapper" class="confirm ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n\t<!-- Custom Fonts can be placed below if applicable -->\n\t\n\t<link rel="stylesheet" href="https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/fontawesomev5.min.css">\n\n\t<!-- Main Popup Content Area -->\n\t<!-- Add class ltkpopup-no-padd for split popups -->\n\t<div id="ltkpopup-content" class="ltkpopup-confirm ltkpopup-no-padd">\n\n\t\t<!-- Pull in the popup container -->\n\t\t<div class="ltkpopup-clearfix ltkpopup-split-content ">\n\n\t<div class="ltkpopup-contain-img" id="ltkpopup-img-contained">\n\t\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/NW_Exit_EMAIL_POPUP_IMG_600x840-min.jpg" alt="" class="ltkpopup-img-fluid" aria-hidden="true">\n\t<\/div>\n\n\t<div class="ltkpopup-contain-form">\n\n\t\t<div class="ltkpopup-form-control">\n\n\t\t\t<div class="ltkpopup-content-wrap">\n\n\t\t\t\t<h1 id="ltkpopup-headline" class="ltkpopup-headline">THANK YOU<\/h1>\n<h2 id="ltkpopup-subheadline" class="ltkpopup-subheadline">You have been subscribed.<\/h2>\n<p id="ltkpopup-content-para" class="ltkpopup-content-para">To apply your 15% off coupon now, click below.<\/p>\n\n\t\t\t\t<div class="ltkpopup-button-container" id="ltkpopup-thanks">\n    <a tabindex="0" class="ltkpopup-close-button ltkpopup-close" href="https://ninewest.com/discount/WELCOME15" target="_blank">APPLY COUPON<\/a>\n<\/div>\n\n\t\t\t<\/div>\n\t\t<\/div>\n\t\t\n\t<\/div>\n\n<\/div>\n\t\t\n\n\t\t<!-- End Content Information -->\n\n\t\t<!-- Close \'X\' Button -->\n\t\t<!-- Add class ltkpopup-circle-close to create a circle close button -->\n<div id="ltkpopup-close-button" class="ltkpopup-circle-close">\n\t<a class="ltkpopup-close" tabindex="0" role="button" aria-label="close">\n\t\t<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">\n\t\t\t<line x1="1" y1="1" x2="28" y2="28" />\n\t\t\t<line x1="28" y1="1" x2="1" y2="28" />\n\t\t<\/svg>\n\t<\/a>\n<\/div>\n\t<\/div>\n<\/div>\n\n\n\n<script>\n\t// Browsers\n\tvar b = document.documentElement;\n\tb.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n\tvar $html = jQuery("html"),\n\t\tua = $html.data("useragent"),\n\t\tpf = $html.data("platform");\n\n\tfunction is(e) {\n\t\treturn ua.indexOf(e) > -1\n\t}\n\tvar browser = {\n\t\tisIE: is("msie") || is("trident/7.0"),\n\t\tisIE7: is("msie 7.0"),\n\t\tisIE8: is("msie 8.0"),\n\t\tisIE9: is("msie 9.0"),\n\t\tisIE10: is("msie 10"),\n\t\tisIE11: is("rv:11") && is("trident/7.0"),\n\t\tisEdge: is("edge"),\n\t\tisChrome: is("chrome") && !is("edge"),\n\t\tisSafari: is("safari") && !is("chrome") && !is("edge"),\n\t\tisFirefox: is("firefox") && !is("edge"),\n\t\tisAndroidChrome: is("android") && is("chrome"),\n\t\tisAndroidDefault: is("android") && !is("chrome"),\n\t\tisWin7: is("windows nt 6.1"),\n\t\tisWin8: is("windows nt 6.2"),\n\t\tisWindows: pf.indexOf("win32") > -1,\n\t\tisWebkit: is("webkit") && !is("edge"),\n\t\tisIPad: is("ipad"),\n\t\tisIPadChrome: is("ipad") && is("crios"),\n\t\tisIPhone: is("iphone"),\n\t\tisIPhoneChrome: is("iphone") && is("crios"),\n\t\tisAndroid: is("android"),\n\t\tisIOS: is("iphone") || is("ipad")\n\t};\n\tfor (var title in browser) {\n\t\tvar helperClass = title.slice(2).toLowerCase();\n\t\tbrowser[title] && jQuery("#ltkpopup-content").addClass(helperClass)\n\t}\n\n\t// Close Function\n\tjQuery(\'.ltkpopup-close\').focus(function () {\n\t\tjQuery(\'.ltkpopup-close\').keypress(function (e) {\n\t\t\tvar key = e.which;\n\t\t\tif (key == 13) {\n\t\t\t\tjQuery(\'#ltkpopup-overlay, #ltkpopup-container\').remove()\n\t\t\t}\n\t\t})\n\t});\n\n\t// Check Input Validity\n\tfunction checkInputValidity(inputEl) {\n\t\tjQuery(inputEl).removeClass("ltkinputnotvalid");\n\t\tvar ltkErrorMessage = jQuery("[data-ltkpopup-error-for=\'" + inputEl.id + "\'");\n\t\tjQuery(ltkErrorMessage).text("");\n\t\tinputEl.checkValidity();\n\t\tif (jQuery(inputEl).is(\':invalid\')) {\n\t\t\tjQuery(inputEl).addClass("ltkinputnotvalid");\n\t\t\tvar ltkErrorMessageText = jQuery(ltkErrorMessage).attr("data-ltkpopup-message");\n\t\t\tjQuery(ltkErrorMessage).text(ltkErrorMessageText);\n\t\t\treturn false;\n\t\t}\n\t\treturn true;\n\t}\n\n\n\n\tchangeFocus = function () {\n\t\tif (document.getElementById("ltkpopup-email") == undefined && document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined) {\n\t\t\tdocument.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n\t\t}\n\t}\n\n\t// Tab Trapping\n\tjQuery(document).ready(function () {\n\t\tsetTimeout(function () {\n\t\t\tfunction triggerFocus(element) {\n\t\t\t\tvar eventType = "onfocusin" in element ? "focusin" : "focus",\n\t\t\t\t\tbubbles = "onfocusin" in element,\n\t\t\t\t\tevent;\n\n\t\t\t\tif ("createEvent" in document) {\n\t\t\t\t\tevent = document.createEvent("Event");\n\t\t\t\t\tevent.initEvent(eventType, bubbles, true);\n\t\t\t\t} else if ("Event" in window) {\n\t\t\t\t\tevent = new Event(eventType, {\n\t\t\t\t\t\tbubbles: bubbles,\n\t\t\t\t\t\tcancelable: true\n\t\t\t\t\t});\n\t\t\t\t}\n\n\t\t\t\telement.focus();\n\t\t\t\telement.dispatchEvent(event);\n\t\t\t}\n\t\t\tif (document.getElementById("ltkpopup-email") != undefined) {\n\t\t\t\ttriggerFocus(document.getElementById("ltkpopup-email"));\n\t\t\t} else {\n\t\t\t\tchangeFocus();\n\t\t\t}\n\t\t}, 0);\n\t});\n\n\tfunction trapTabKey(e) {\n\t\tvar t = document.activeElement,\n\t\t\ts = focusableElems.indexOf(t);\n\t\tif (9 === e.keyCode) {\n\t\t\te.preventDefault();\n\t\t\tmoveTab(s, e.shiftKey)\n\t\t}\n\t}\n\n\tfunction moveTab(index, shift) {\n\t\tvar nextTab = null;\n\t\tvar nextIndex = index;\n\t\tif (shift) {\n\t\t\tif (focusableElems[index] == firstTabStop) {\n\t\t\t\tnextTab = lastTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index - 1;\n\t\t\t\tnextTab = focusableElem[nextIndex];\n\t\t\t}\n\t\t} else {\n\t\t\tif (focusableElems[index] == lastTabStop) {\n\t\t\t\tnextTab = firstTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index + 1;\n\t\t\t\tnextTab = focusableElems[nextIndex];\n\t\t\t}\n\t\t}\n\n\t\tif (jQuery(nextTab).is(":visible")) {\n\t\t\tnextTab.focus();\n\t\t} else {\n\t\t\tmoveTab(nextIndex, shift);\n\t\t}\n\t}\n\twindow.onload = function () {\n\t\tvar e = document.getElementById("ltkpopup-img-contained");\n\t\te && (2 == window.getComputedStyle(e).getPropertyValue("order") && (e.className += " ltkpopup-img-right"))\n\t}, setTimeout(function () {\n\t\t//Do not delete - tab functionality will break\n\t\t_ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n\t\tchangeFocus();\n\t}, 50);\n\tvar focused = document.activeElement;\n\tjQuery(".ltkpopup-close").on("click", function () {\n\t\tfocused.focus()\n\t});\n\tvar focusBox = document.getElementById("ltkpopup-content"),\n\t\tfocusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n\t\tfocusableElem = focusBox.querySelectorAll(focusableElemStr),\n\t\tfocusableElems = Array.prototype.slice.call(focusableElem),\n\t\tfirstTabStop = focusableElems[0],\n\t\tlastTabStop = focusableElems[focusableElems.length - 1];\n\tfocusBox.addEventListener("keydown", trapTabKey);\n\n\t\n\t$("body").bind("DOMSubtreeModified", function() {\n    \tif($(\'#smile-ui-container\')){\n\t\t\t$(\'#smile-ui-container\').css(\'z-index\',\'999\');\n\t\t}\n\t});\n<\/script>\n\t\t\t\t\t\t',
            animation: null,
            urlRedirect: null,
            initialDelay: 2,
            buttonSettings: {
                size: 1,
                shape: 1,
                alignment: 2,
                text: "Subscribe",
                color: "#00BDE5",
                textColor: "#FFFFFF"
            },
            urlRules: [{
                urlMatchRule: 1,
                show: !0,
                url: "/checkouts/"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "thank_you"
            }],
            targetingRules: {
                showWhenDevice: ["Desktop"]
            },
            subscriptionPoint: "Popup",
            engagement: {
                followUpTimeframe: 0,
                showWhenPageSession: 1,
                followUp: !0,
                followUpDelay: 30,
                showIfFromListrakEmail: !1
            },
            overlayClose: !0,
            referrerRule: null
        }
    }, {
        type: 4,
        category: 0,
        popupUID: "993ba9f7-5e7c-41d9-93c3-073986fb1879",
        popupName: "NW - SS23 - Persistent Offer Button",
        clientUID: "4812bcb7-32f3-4732-92d1-a34659911750",
        companyID: 0,
        isActive: !0,
        lastModified: "2023-09-14T17:03:48.33Z",
        settings: {
            scrollDepth: 0,
            isTestMode: !1,
            formHTML: '\n\t\t\t\t\t\t\t<!-- Pop-up Form -->\n<!-- ltkpopup-no-scroll: centers the popup on display by preventing the page from scrolling -->\n<!-- ltkpopup-ios-fix: keeps fixed position popups like bottom banners in place in iOS -->\n<div id="ltkpopup-wrapper" class="ltkpopup-signup ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n\t<!-- Main Popup Content Area -->\n\t<div id="ltkpopup-content" class="ltkpopup-signup">\n\t\t<!-- Pull in the popup container -->\n\t\t\n\t\t<div id="ltkpopup-email-form">\n\t\t\t<div class="ltkpopup-clearfix ltkpopup-split-content ltkpopup-split-above-below\n">\n\n\t\n\n<div class="ltkpopup-contain-img">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/650x320.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-mobile-hide" aria-hidden="true">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/320x235.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-desktop-hide" aria-hidden="true">\n<\/div>\n\n\n\n\t<div class="ltkpopup-contain-form">\n\n\t\t\n\t\t<h1 id="ltkpopup-headline" class="ltkpopup-headline ltkpopup-visuallyhidden">Welcome to Easy Spirit<\/h1>\n<h2 id="ltkpopup-content-para" class="ltkpopup-headline">UNLOCK 2O% OFF <span class="ltkpopup-content-para">your first order when you subscribe to our email list.<\/span><\/h2>\n\n\t\t<div class="ltkpopup-form-contain">\n\t\t\t\n\n\n<div class="ltkpopup-clearfix ltkpopup-form-control">\n\n\n\t<div class="ltkpopup-error-message" aria-live="assertive" data-ltkpopup-error-for="ltkpopup-email" data-ltkpopup-message="Please enter a valid email address"><\/div>\n\t<div >\n\t\t<div class="ltkpopup-floating-label-container">\n\t\t\t<label for="ltkpopup-email" class="ltkpopup-floating-label">Enter email address<\/label>\n\t\t\t<input autofocus required type="email" id="ltkpopup-email" class="ltkpopup-email" tabindex="0" name="ltkpopup-email" placeholder="" autocomplete="email" pattern="^([a-zA-Z0-9._+!-]+[@](?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,})$" />\n\t\t<\/div>\n\t<\/div>\n\n\n\t\n\n\t<div class="ltkpopup-button-container ltkpopup-flex ltkpopup-clearfix">\n\t\t<button id="ltkpopup-submit" class="ltkpopup-subscribe" tabindex="0" type="submit"><span>ACTIVATE OFFER<\/span><\/button>\n\t<\/div>\n\n<\/div>\n\n\n\n\n<div class="ltkpopup-no-thanks" id="ltkpopup-text-btn">\n\t<button tabindex="0" class="ltkpopup-close">No, thanks<\/button>\n<\/div>\n\n\t\t<\/div>\n\n\t\t<p class="ltkpopup-content-para ltkpopup-disclaimer">All offers exclude Gift Cards and Final Sale/Clearance. Some additional product exclusions may apply per brand/season. See <a href="https://ninewest.com/policies/terms-of-service" target="_blank">Terms and Conditions<\/a> &amp; <a href="https://ninewest.com/policies/privacy-policy" target="_blank">Privacy&nbsp;Policy<\/a>.<\/p>\n\n\t<\/div>\n\n<\/div>\n\t\t<\/div>\n\n\t\t\n\n\t\t<!-- Emmet Snippets if applicable -->\n\t\t<!-- zip error dropdown checkbox radio sms-capture -->\n\n\t\t<!-- Do Not Delete. Connects the Popup to Segmentation within the Listrak platform. Input name needs to match segmentation -->\n\t\t<div class="ltkpopup-source">\n\t\t\t<input type="hidden" class="text" name="ltkSource" value="On" tabindex="-1" />\n\t\t<\/div>\n\t\t\n\n\t\t<!-- Close \'X\' Button -->\n\t\t\n\n\t<\/div>\n\t<!-- End ltkpopup-content -->\n\n<\/div>\n<!-- End ltkpopup-wrapper -->\n\n<script>\n\tvar emailVal;\n\tvar phoneVal;\n\tvar emailField = document.getElementById(\'ltkpopup-email\');\n\tif (emailField != null) {\n\t\temailField.addEventListener(\'change\', function () {\n\t\t\temailVal = this.value;\n\t\t\t_ltk.SCA.Update(\'email\', this.value);\n\t\t});\n\t}\n\tvar phoneField = document.getElementById(\'ltkpopup-phone\');\n\tif (phoneField != null) {\n\t\tphoneField.addEventListener(\'change\', function () {\n\t\t\tphoneVal = this.value;\n\t\t});\n\t}\n\tvar submitBtn = document.getElementById(\'ltkpopup-submit\');\n\tif (submitBtn != null) {\n\t\tsubmitBtn.addEventListener(\'click\', function () {\n\t\t\tvar e = jQuery("#ltkpopup-content :input");\n\t\t\tjQuery(e).each(function (e) {\n\t\t\t\tcheckInputValidity(this);\n\t\t\t\tif (jQuery(this).is(":invalid")) {\n\t\t\t\t\tthis.setAttribute("aria-describedby", this.id + "-error-message");\n\t\t\t\t} else {\n\t\t\t\t\tthis.removeAttribute("aria-describedby")\n\t\t\t\t}\n\t\t\t});\n\t\t\tsetTimeout(function () {\n\t\t\t\tif (document.querySelector(".ltkinputnotvalid") != null) {\n\t\t\t\t\tdocument.querySelector(".ltkinputnotvalid").focus();\n\t\t\t\t}\n\t\t\t}, 0);\n\t\t});\n\t}\n<\/script>\n\n<script>\n\t// Browsers\n\tvar b = document.documentElement;\n\tb.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n\tvar ua = navigator.userAgent.toLowerCase(),\n\t\tpf = navigator.platform.toLowerCase();\n\n\tfunction is(e) {\n\t\treturn ua.indexOf(e) > -1\n\t}\n\tvar browser = {\n\t\tIE: is("msie") || is("trident/7.0"),\n\t\tIE7: is("msie 7.0"),\n\t\tIE8: is("msie 8.0"),\n\t\tIE9: is("msie 9.0"),\n\t\tIE10: is("msie 10"),\n\t\tIE11: is("rv:11") && is("trident/7.0"),\n\t\tEdge: is("edge"),\n\t\tChrome: is("chrome") && !is("edge"),\n\t\tSafari: is("safari") && !is("chrome") && !is("edge"),\n\t\tFirefox: is("firefox") && !is("edge"),\n\t\tAndroidChrome: is("android") && is("chrome"),\n\t\tAndroidDefault: is("android") && !is("chrome"),\n\t\tWin7: is("windows nt 6.1"),\n\t\tWin8: is("windows nt 6.2"),\n\t\tWindows: pf.indexOf("win32") > -1,\n\t\tWebkit: is("webkit") && !is("edge"),\n\t\tIPad: is("ipad"),\n\t\tIPadChrome: is("ipad") && is("crios"),\n\t\tIPhone: is("iphone"),\n\t\tIPhoneChrome: is("iphone") && is("crios"),\n\t\tAndroid: is("android"),\n\t\tIOS: is("iphone") || is("ipad")\n\t};\n\tfor (var title in browser) {\n\t\tif (browser[title]) {\n\t\t\tdocument.getElementById("ltkpopup-content").classList.add(String(title).toLowerCase());\n\t\t}\n\t}\n\n\t// Close Function\n\tvar focused = document.activeElement;\n\tvar closeBtns = document.querySelectorAll(\'.ltkpopup-close\');\n\tfor (var i = 0; i < closeBtns.length; i++) {\n\t\tcloseBtns[i].addEventListener("click", function (e) {\n\t\t\t_ltk.Popup.close();\n\t\t\tfocused.focus();\n\t\t});\n\t}\n\n\t// Check Input Validity\n\tfunction checkInputValidity(inputEl) {\n\t\tvar ltkErrorClass = "ltkinputnotvalid";\n\t\tvar ltkErrorMessage = document.querySelector("[data-ltkpopup-error-for=\'" + inputEl.id + "\']");\n\t\tvar ltkLabel = document.querySelector("label[for=\'" + inputEl.id + "\']");\n\t\tif (ltkErrorMessage != undefined) {\n\t\t\tltkErrorMessage.innerText = "";\n\t\t\tinputEl.classList.remove(ltkErrorClass);\n\t\t\tif (ltkLabel != undefined) {\n\t\t\t\tltkLabel.classList.remove(ltkErrorClass);\n\t\t\t}\n\t\t}\n\t\tinputEl.checkValidity();\n\t\tif (!inputEl.validity.valid) {\n\t\t\tinputEl.classList.add(ltkErrorClass);\n\t\t\tif (ltkLabel != undefined) {\n\t\t\t\tltkLabel.classList.add(ltkErrorClass);\n\t\t\t}\n\t\t\tif (ltkErrorMessage != undefined) {\n\t\t\t\tltkErrorMessage.innerText = ltkErrorMessage.getAttribute("data-ltkpopup-message");\n\t\t\t}\n\t\t\treturn false;\n\t\t}\n\t\treturn true;\n\t}\n\n\t// Override close CTA focus called by onescript 2x\n\tonescriptFocus = 0;\n\twrapperFocus = function () {\t\n\t\tdocument.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n\t\tonescriptFocus ++;\n\t\tif(onescriptFocus == 1) {\n\t\t\tdocument.querySelector(\'.simpleltkmodal-wrap button\').removeEventListener(\'focus\', wrapperFocus);\n\t\t}\n\t}\n\n\t// Tab Trapping\n\tsetTimeout(function () {\n\t\tfunction triggerFocus(element) {\n\t\t\tvar eventType = "onfocusin" in element ? "focusin" : "focus",\n\t\t\t\tbubbles = "onfocusin" in element,\n\t\t\t\tevent;\n\n\t\t\tif ("createEvent" in document) {\n\t\t\t\tevent = document.createEvent("Event");\n\t\t\t\tevent.initEvent(eventType, bubbles, true);\n\t\t\t} else if ("Event" in window) {\n\t\t\t\tevent = new Event(eventType, {\n\t\t\t\t\tbubbles: bubbles,\n\t\t\t\t\tcancelable: true\n\t\t\t\t});\n\t\t\t}\n\n\t\t\telement.focus();\n\t\t\telement.dispatchEvent(event);\n\t\t}\n\t\tif (document.getElementById("ltkpopup-email") != undefined) {\n\t\t\ttriggerFocus(document.getElementById("ltkpopup-email"));\n\t\t} else if (document.getElementById("ltkpopup-phone") != undefined) {\n\t\t\ttriggerFocus(document.getElementById("ltkpopup-phone"));\n\t\t} else if (document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined && document.querySelector(\'.simpleltkmodal-wrap input\') == null && document.querySelector(\'.simpleltkmodal-wrap button\') != null) {\n\t\t\tdocument.querySelector(\'.simpleltkmodal-wrap button\').addEventListener(\'focus\', wrapperFocus);\n\t\t}\n\t}, 0);\n\n\tfunction trapTabKey(e) {\n\t\tvar t = document.activeElement,\n\t\t\ts = focusableElems.indexOf(t);\n\t\tif (9 === e.keyCode) {\n\t\t\te.preventDefault();\n\t\t\tmoveTab(s, e.shiftKey)\n\t\t}\n\t}\n\n\tfunction moveTab(index, shift) {\n\t\tvar nextTab = null;\n\t\tvar nextIndex = index;\n\t\tif (shift) {\n\t\t\tif (focusableElems[index] == firstTabStop) {\n\t\t\t\tnextTab = lastTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index - 1;\n\t\t\t\tnextTab = focusableElem[nextIndex];\n\t\t\t}\n\t\t} else {\n\t\t\tif (focusableElems[index] == lastTabStop) {\n\t\t\t\tnextTab = firstTabStop;\n\t\t\t\tnextIndex = 0;\n\t\t\t} else {\n\t\t\t\tnextIndex = index + 1;\n\t\t\t\tnextTab = focusableElems[nextIndex];\n\t\t\t}\n\t\t}\n\t\tif (nextTab.offsetParent != null) {\n\t\t\tnextTab.focus();\n\t\t} else {\n\t\t\tmoveTab(nextIndex, shift);\n\t\t}\n\t}\n\tsetTimeout(function () {\n\t\t//Do not delete - tab functionality will break\n\t\t_ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n\t}, 50);\n\tvar focusBox = document.getElementById("ltkpopup-content"),\n\t\tfocusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n\t\tfocusableElem = focusBox.querySelectorAll(focusableElemStr),\n\t\tfocusableElems = Array.prototype.slice.call(focusableElem),\n\t\tfirstTabStop = focusableElems[0],\n\t\tlastTabStop = focusableElems[focusableElems.length - 1];\n\tfocusBox.addEventListener("keydown", trapTabKey);\n\n\n\t// floating labels\n\tjQuery(\'.ltkpopup-floating-label-container :input\').each(function () {\n\t\tthis.addEventListener(\'blur\', removeFloat, false);\n\t\tif (this.hasAttribute(\'data-inputmask\') || this.id == \'ltkpopup-datepicker\') {\n\t\t\tthis.addEventListener(\'focus\', addFloat, false);\n\t\t} else {\n\t\t\tthis.addEventListener(\'click\', addFloat, false);\n\t\t\tthis.addEventListener(\'keydown\', addFloat, false);\n\t\t}\n\t});\n\n\tfunction addFloat(event) {\n\t\tjQuery(event.target).closest(".ltkpopup-floating-label-container").addClass(\'ltkpopup-floatLabel\');\n\t\tjQuery("[data-ltkpopup-error-for=\'" + event.target.id + "\']").addClass(\'ltkpopup-floatLabel\');\n\t}\n\n\tfunction removeFloat(event) {\n\t\tif (event.target.value.length == 0 && !event.target.classList.contains("ltkpopup-datepicker")) {\n\t\t\tjQuery(event.target).closest(".ltkpopup-floating-label-container").removeClass(\'ltkpopup-floatLabel\');\n\t\t\tjQuery("[data-ltkpopup-error-for=\'" + event.target.id + "\']").removeClass(\'ltkpopup-floatLabel\');\n\t\t}\n\t}\n<\/script>\n<script>\n\tif (document.querySelectorAll("[data-inputmask]").length > 0) {\n\n\t\t// Input masking for number validation - Get Jquery Input Mask from CDN and load it\n\t\tjQuery.getScript(\n\t\t\t"https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.1/jquery.inputmask.bundle.js",\n\t\t\tfunction () {\n\t\t\t\tjQuery("[data-inputmask]").each(function () {\n\t\t\t\t\t// Mask phone number input after script is loaded\n\t\t\t\t\tjQuery(this).inputmask({\n\t\t\t\t\t\tgreedy: false,\n\t\t\t\t\t\tshowMaskOnHover: false,\n\t\t\t\t\t\tdefinitions: {\n\t\t\t\t\t\t\t\'#\': {\n\t\t\t\t\t\t\t\tvalidator: "[0-9]",\n\t\t\t\t\t\t\t\tcardinality: 1\n\t\t\t\t\t\t\t}\n\t\t\t\t\t\t}\n\t\t\t\t\t});\n\t\t\t\t});\n\t\t\t});\n\t}\n<\/script>\n<script>\n\tvar datepickerField = document.querySelector("#ltkpopup-datepicker");\n\tif (datepickerField != null) {\n\t\tvar jQueryUIcss = document.createElement("link");\n\t\tjQueryUIcss.href = "https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css";\n\t\tjQueryUIcss.rel = "stylesheet";\n\t\tjQueryUIcss.addEventListener("load", function () {\n\t\t\tvar jQueryUI = document.createElement("script");\n\t\t\tjQueryUI.src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js";\n\t\t\tjQueryUI.addEventListener("load", function () {\n\t\t\t\tdatepickerField.setAttribute("readonly", "");\n\t\t\t\tjQuery(datepickerField).datepicker({\n\t\t\t\t\tchangeMonth: true,\n\t\t\t\t\tchangeYear: false,\n\t\t\t\t\tyearRange: \'-0:+0\',\n\t\t\t\t\t// use for different date format and hidden bday field\n\t\t\t\t\tdateFormat: "mm/dd",\n\t\t\t\t\taltField: "#ltkpopup-hidden-bday",\n\t\t\t\t\taltFormat: "mm/dd/1900",\n\t\t\t\t\tonClose: function (selectedDate) {\n\t\t\t\t\t\t\t\tif (selectedDate == "") {\n\t\t\t\t\t\t\t\t\tjQuery(this).closest(".ltkpopup-floating-label-container").removeClass(\'ltkpopup-floatLabel\');\n\t\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\t}\n\t\t\t\t\t});\n\n\t\t\t\tjQuery(datepickerField).focus(function () {\n\t\t\t\t\tjQuery(\'#ui-datepicker-div\').appendTo(this.parentNode);\n\t\t\t\t});\n\t\t\t});\n\t\t\tdocument.getElementById("ltkpopup-content").appendChild(jQueryUI);\n\t\t});\n\t\tdocument.getElementById("ltkpopup-content").appendChild(jQueryUIcss);\n\t}\n<\/script>\n\n\n\n\t\t\t\t\t\t',
            formCSS: '#ltkpopup-wrapper .ltkpopup-clearfix::before,\n#ltkpopup-wrapper .ltkpopup-clearfix::after {\n content: "";\n display: table;\n}\n#ltkpopup-wrapper .ltkpopup-clearfix::after {\n clear: both;\n}\n#ltkpopup-wrapper .ltkpopup-clearfix {\n zoom: 1;\n}\n.ios-only {\n position: fixed;\n}\n.ltkpopup-visuallyhidden {\n position: absolute;\n width: 1px;\n height: 1px;\n margin: -1px;\n padding: 0;\n overflow: hidden;\n clip: rect(0 0 0 0);\n border: 0;\n}\n.ltkpopup-visuallyhidden.focusable:active,\n.ltkpopup-visuallyhidden.focusable:focus {\n position: static;\n width: auto;\n height: auto;\n margin: 0;\n overflow: visible;\n clip: auto;\n}\n.ltkpopup-img-fluid {\n width: 100%;\n height: auto;\n display: block;\n}\n#ltkpopup-thanks {\n text-align: center;\n}\n#ltkpopup-thanks input {\n display: inline-block;\n}\n.ltkpopup-logo {\n display: block;\n width: 100px;\n height: auto;\n margin: 0 auto;\n}\n.ltkpopup-desktop-hide {\n display: none;\n}\n.acsb-trigger,\niframe#launcher,\n.olark-launch-button-wrapper,\n#___ratingbadge_0,\n#onetrust-banner-sdk,\n#chat-widget-container {\n z-index: 9999990 !important;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-wrapper .ltkpopup-mobile-hide {\n  display: none;\n }\n #ltkpopup-wrapper .ltkpopup-desktop-hide {\n  display: block;\n }\n #ltkpopup-wrapper .ltkpopup-logo {\n  width: 100px;\n }\n}\n#ltkpopup-overlay {\n z-index: 10000001 !important;\n position: fixed !important;\n top: 0 !important;\n bottom: 0 !important;\n width: 100% !important;\n height: 100% !important;\n background-color: #777876 !important;\n opacity: 0.5 !important;\n -webkit-transition: all 0.25s ease-in;\n transition: all 0.25s ease-in;\n}\n#ltkpopup-container {\n z-index: 10000010 !important;\n position: fixed !important;\n width: 650px !important;\n height: auto !important;\n max-height: 100%;\n top: 50% !important;\n left: 50% !important;\n margin-left: 0 !important;\n -webkit-transform: translate(-50%, -50%) !important;\n -moz-transform: translate(-50%, -50%) !important;\n -ms-transform: translate(-50%, -50%) !important;\n transform: translate(-50%, -50%) !important;\n overflow-x: hidden;\n overflow-y: auto;\n}\n#ltkpopup-container .simpleltkmodal-wrap {\n overflow: visible !important;\n}\n#ltkpopup-wrapper {\n background: transparent;\n font-size: 14px;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n -webkit-font-smoothing: subpixel-antialiased;\n position: relative;\n margin: 0 auto;\n width: 100% !important;\n}\n#ltkpopup-wrapper.no-wrap {\n white-space: nowrap;\n}\n#ltkpopup-wrapper * {\n box-sizing: border-box;\n backface-visibility: hidden !important;\n}\n#ltkpopup-content {\n font-size: 14px;\n text-align: left;\n color: #000000;\n line-height: 1.4;\n background: #fff;\n}\n#ltkpopup-content .ltkpopup-contain-form {\n padding: 16px 90px 13px;\n background-color: #f2f3f8;\n}\n#ltkpopup-sms-confirm,\n#ltkpopup-sms-no-thanks,\n#ltkpopup-sms-content {\n display: none;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-container {\n  width: 300px !important;\n }\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-container {\n  width: 320px !important;\n }\n #ltkpopup-content {\n  float: none;\n  width: 100%;\n }\n #ltkpopup-content .ltkpopup-contain-form {\n  padding: 17px 10px 9px;\n }\n}\n#ltkpopup-content .ltkpopup-split-content {\n display: -webkit-box;\n display: -moz-box;\n display: -ms-flexbox;\n display: -webkit-flex;\n display: flex;\n -webkit-align-items: center;\n -moz-align-items: center;\n -ms-align-items: center;\n align-items: center;\n}\n#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img {\n -webkit-box-flex: 0 0 350px;\n -moz-box-flex: 0 0 350px;\n -webkit-flex: 0 0 350px;\n -ms-flex: 0 0 350px;\n flex: 0 0 350px;\n line-height: 0;\n -webkit-box-ordinal-group: 1;\n -moz-box-ordinal-group: 1;\n -ms-flex-order: 1;\n -webkit-order: 1;\n order: 1;\n}\n#ltkpopup-content\n .ltkpopup-split-content\n .ltkpopup-contain-img.ltkpopup-img-right,\n#ltkpopup-content\n .ltkpopup-split-content\n .ltkpopup-contain-img.ltkpopup-img-bottom {\n -webkit-box-ordinal-group: 3;\n -moz-box-ordinal-group: 3;\n -ms-flex-order: 3;\n -webkit-order: 3;\n order: 3;\n}\n#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form {\n max-width: 300px;\n -webkit-box-flex: 0 0 300px;\n -moz-box-flex: 0 0 300px;\n -webkit-flex: 0 0 300px;\n -ms-flex: 0 0 300px;\n flex: 0 0 300px;\n -webkit-box-ordinal-group: 2;\n -moz-box-ordinal-group: 2;\n -ms-flex-order: 2;\n -webkit-order: 2;\n order: 2;\n min-height: 325px;\n}\n#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below {\n flex-wrap: wrap;\n}\n#ltkpopup-content\n .ltkpopup-split-content.ltkpopup-split-above-below\n .ltkpopup-contain-form,\n#ltkpopup-content\n .ltkpopup-split-content.ltkpopup-split-above-below\n .ltkpopup-contain-img {\n max-width: 100%;\n -webkit-box-flex: 0 0 100%;\n -moz-box-flex: 0 0 100%;\n -webkit-flex: 0 0 100%;\n -ms-flex: 0 0 100%;\n flex: 0 0 100%;\n}\n#ltkpopup-content.safari,\n#ltkpopup-content.ipad {\n overflow-x: hidden;\n overflow-y: hidden;\n}\n#ltkpopup-content.safari\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-img,\n#ltkpopup-content.safari\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-form,\n#ltkpopup-content.ipad\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-img,\n#ltkpopup-content.ipad\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-form {\n position: relative;\n left: -2px;\n}\n#ltkpopup-content.safari\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-img.ltkpopup-img-right\n img,\n#ltkpopup-content.safari\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-form.ltkpopup-img-right\n img,\n#ltkpopup-content.ipad\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-img.ltkpopup-img-right\n img,\n#ltkpopup-content.ipad\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-form.ltkpopup-img-right\n img {\n position: relative;\n right: -2px;\n left: auto;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img {\n  display: none;\n }\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-content .ltkpopup-split-content {\n  display: block;\n }\n #ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form {\n  max-width: none;\n  min-height: 315px;\n }\n #ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img {\n  display: block;\n  width: 100%;\n }\n #ltkpopup-content.safari\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-img,\n #ltkpopup-content.safari\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-form,\n #ltkpopup-content.ipad\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-img,\n #ltkpopup-content.ipad\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-form {\n  left: 0;\n }\n #ltkpopup-content.safari\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-img.ltkpopup-img-right\n  img,\n #ltkpopup-content.safari\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-form.ltkpopup-img-right\n  img,\n #ltkpopup-content.ipad\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-img.ltkpopup-img-right\n  img,\n #ltkpopup-content.ipad\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-form.ltkpopup-img-right\n  img {\n  right: 0;\n }\n}\n#ltkpopup-close-button {\n position: absolute;\n right: 12px;\n top: 12px;\n margin: 0px;\n z-index: 10;\n}\n#ltkpopup-close-button a {\n display: block;\n width: 20px;\n height: 20px;\n cursor: pointer;\n}\n#ltkpopup-close-button a svg {\n width: 20px;\n height: 20px;\n position: relative;\n display: block;\n overflow: visible;\n stroke: #a9a9a9;\n stroke-width: 4px;\n -webkit-transition: all 0.25s linear;\n transition: all 0.25s linear;\n}\n#ltkpopup-close-button a:hover svg {\n stroke: #000;\n}\n#ltkpopup-close-button a:focus svg {\n stroke: #000;\n}\n#ltkpopup-close-button.ltkpopup-circle-close a {\n width: 35px;\n height: 35px;\n background: #d3d3d3;\n border-radius: 50%;\n padding: 10px;\n border: 1px solid #777876;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-close-button {\n  right: 12px;\n  top: 12px;\n }\n #ltkpopup-close-button a {\n  width: 20px;\n  height: 20px;\n }\n #ltkpopup-close-button a svg {\n  width: 20px;\n  height: 20px;\n  stroke: #a9a9a9;\n  stroke-width: 4px;\n }\n #ltkpopup-close-button a:hover svg {\n  stroke: #000;\n }\n #ltkpopup-close-button a:focus svg {\n  stroke: #000;\n }\n}\n#ltkpopup-content h1,\n#ltkpopup-content h2,\n#ltkpopup-content h3,\n#ltkpopup-content h4,\n#ltkpopup-content h5,\n#ltkpopup-content .ltkpopup-headline,\n#ltkpopup-content .ltkpopup-subheadline {\n margin: 0;\n padding: 0;\n text-align: center;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n}\n#ltkpopup-content h1,\n#ltkpopup-content .ltkpopup-headline {\n font-weight: 500;\n font-size: 40px;\n line-height: 56px;\n color: #000000;\n letter-spacing: 0;\n}\n#ltkpopup-content h2,\n#ltkpopup-content .ltkpopup-subheadline {\n font-weight: 400;\n font-size: 20px;\n line-height: 28px;\n color: #000000;\n letter-spacing: 0;\n}\n\n#ltkpopup-content h2,\n#ltkpopup-content .ltkpopup-subheadline2 {\n font-weight: 400;\n font-size: 14px;\n line-height: 28px;\n color: #000000;\n letter-spacing: 0;\n}\n\n#ltkpopup-content p,\n#ltkpopup-content .ltkpopup-content-para {\n margin: 0px auto 14px;\n font-size: 14px;\n line-height: 21px;\n color: #000000;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n letter-spacing: 0;\n text-align: center;\n display: block;\n font-weight: 400;\n}\n#ltkpopup-content p.ltkpopup-disclaimer,\n#ltkpopup-content p.ltkpopup-sms-disclaimer,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer {\n font-size: 10px;\n line-height: 16px;\n text-align: center;\n margin: 8px auto 0;\n color: #000000;\n}\n#ltkpopup-content p.ltkpopup-disclaimer a,\n#ltkpopup-content p.ltkpopup-sms-disclaimer a,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a {\n color: inherit;\n text-decoration: underline;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n letter-spacing: 0;\n}\n#ltkpopup-content p.ltkpopup-disclaimer a:hover,\n#ltkpopup-content p.ltkpopup-disclaimer a:focus,\n#ltkpopup-content p.ltkpopup-sms-disclaimer a:hover,\n#ltkpopup-content p.ltkpopup-sms-disclaimer a:focus,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:hover,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:focus,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:hover,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:focus {\n text-decoration: none;\n}\n#ltkpopup-content p.ltkpopup-disclaimer span,\n#ltkpopup-content p.ltkpopup-sms-disclaimer span,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer span,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer span {\n font-weight: 700;\n}\n#ltkpopup-content .ltkpopup-coupon {\n font-size: 28px;\n line-height: 23px;\n width: 170px;\n margin: 20px auto;\n display: block;\n}\n#ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-form .ltkpopup-coupon {\n margin: 11px 140px 15px;\n}\n#ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-form p.ltkpopup-sms-disclaimer,\n#ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-form\n .ltkpopup-content-para.ltkpopup-sms-disclaimer {\n margin: 5px -70px 0;\n}\n#ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-confirm .ltkpopup-headline {\n margin-top: 20px;\n}\n#ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-confirm p.ltkpopup-disclaimer,\n#ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-confirm\n .ltkpopup-content-para.ltkpopup-disclaimer {\n margin: 37px auto 0;\n}\n#ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-no-thanks .ltkpopup-headline {\n margin-top: 37px;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-content h1,\n #ltkpopup-content .ltkpopup-headline {\n  font-size: 28px;\n  line-height: 39px;\n }\n #ltkpopup-content h2,\n #ltkpopup-content .ltkpopup-subheadline {\n  font-size: 20px;\n  line-height: 28px;\n }\n #ltkpopup-content p,\n #ltkpopup-content .ltkpopup-content-para {\n  font-size: 14px;\n  line-height: 21px;\n  margin: 4px 20px 0;\n }\n #ltkpopup-content p.ltkpopup-disclaimer,\n #ltkpopup-content p.ltkpopup-sms-disclaimer,\n #ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,\n #ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer {\n  font-size: 10px;\n  line-height: 16px;\n  margin: 7px auto 0;\n }\n #ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-form .ltkpopup-coupon {\n  margin: 8px auto 12px 70px\n }\n #ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-form\n  .ltkpopup-subheadline.ltkpopup-mobile-smaller {\n  font-size: 14px;\n  line-height: 21px;\n }\n #ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-form p.ltkpopup-sms-disclaimer,\n #ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-form\n  .ltkpopup-content-para.ltkpopup-sms-disclaimer {\n  margin: 17px auto 0;\n }\n #ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-confirm p,\n #ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-confirm\n  .ltkpopup-content-para {\n  margin-bottom: 20px;\n }\n}\n@font-face {\n src: url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-regular.eot")\n   format("embedded-opentype"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-regular.woff2")\n   format("woff2"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-regular.woff")\n   format("woff"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-regular.ttf")\n   format("truetype"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-regular.svg")\n   format("svg");\n font-family: "ltk-FontAwesome";\n font-weight: 400;\n}\n@font-face {\n src: url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-solid.eot")\n   format("embedded-opentype"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-solid.woff2")\n   format("woff2"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-solid.woff")\n   format("woff"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-solid.ttf")\n   format("truetype"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-solid.svg")\n   format("svg");\n font-family: "ltk-FontAwesome";\n font-weight: 900;\n}\n@font-face {\n src: url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-brands.eot")\n   format("embedded-opentype"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-brands.woff2")\n   format("woff2"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-brands.woff")\n   format("woff"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-brands.ttf")\n   format("truetype"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-brands.svg")\n   format("svg");\n font-family: "ltk-FontAwesome";\n font-weight: 400;\n font-style: oblique;\n}\n\n#ltkpopup-content input[type="text"],\n#ltkpopup-content input[type="email"],\n#ltkpopup-content input[type="number"],\n#ltkpopup-content input[type="tel"] {\n display: block;\n width: 100%;\n height: 40px;\n padding: 0 15px;\n margin: 0 auto;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n font-size: 15px;\n font-weight: 400;\n text-align: center;\n color: #000000;\n line-height: normal;\n background-color: #fff;\n border: 1.5px solid #777876;\n border-radius: 0px !important;\n -webkit-transition: all 0.11s linear;\n transition: all 0.11s linear;\n -webkit-appearance: none;\n -moz-appearance: none;\n appearance: none;\n letter-spacing: 0;\n}\n#ltkpopup-content input[type="text"]:focus,\n#ltkpopup-content input[type="email"]:focus,\n#ltkpopup-content input[type="number"]:focus,\n#ltkpopup-content input[type="tel"]:focus {\n outline: none;\n border-color: #000000;\n}\n#ltkpopup-content .ltkpopup-form-control {\n position: relative;\n max-width: 360px;\n margin: 0 auto;\n}\n#ltkpopup-content input::-webkit-input-placeholder {\n font-weight: inherit;\n color: #000000;\n font-family: inherit;\n opacity: 1;\n}\n#ltkpopup-content input::-moz-placeholder {\n font-weight: inherit;\n color: #000000;\n font-family: inherit;\n opacity: 1;\n}\n#ltkpopup-content input:-ms-input-placeholder {\n font-weight: inherit;\n color: #000000;\n font-family: inherit;\n opacity: 1;\n}\n#ltkpopup-content input::-ms-clear {\n display: none;\n width: 0;\n height: 0;\n opacity: 0;\n}\n#ltkpopup-content .ltk-floating-input {\n width: 250px;\n float: left;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-content input[type="text"],\n #ltkpopup-content input[type="email"],\n #ltkpopup-content input[type="number"],\n #ltkpopup-content input[type="tel"] {\n  float: none;\n  width: 100%;\n  font-size: 15px;\n  height: 40px;\n }\n #ltkpopup-content .ltkpopup-form-control {\n  max-width: 259px;\n }\n #ltkpopup-content .ltk-floating-input {\n  width: 100%;\n }\n}\n#ltkpopup-content label {\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n font-size: 15px;\n font-weight: 400;\n line-height: normal;\n color: #000000;\n letter-spacing: 0;\n display: block;\n width: 100%;\n text-align: center;\n padding: 0 15px;\n}\n#ltkpopup-content .ltkpopup-floating-label-container {\n position: relative;\n}\n#ltkpopup-content\n .ltkpopup-floating-label-container\n label.ltkpopup-floating-label {\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n height: 36px;\n line-height: 36px;\n position: absolute;\n top: 2.5px;\n z-index: 6;\n transition: height 120ms ease-out, line-height 120ms ease-out,\n  font-size 120ms ease-out;\n pointer-events: none;\n color: #000000;\n white-space: nowrap;\n}\n#ltkpopup-content .ltkpopup-floating-label-container input {\n padding-top: 10px;\n}\n#ltkpopup-content\n .ltkpopup-floating-label-container.ltkpopup-floatLabel\n label.ltkpopup-floating-label {\n font-size: 10px;\n line-height: 10px;\n height: 10px;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-content label {\n  font-size: 15px;\n }\n #ltkpopup-content\n  .ltkpopup-floating-label-container\n  label.ltkpopup-floating-label {\n  height: 36px;\n  line-height: 36px;\n }\n #ltkpopup-content .ltkpopup-floating-label-container input {\n  padding-top: 10px;\n }\n #ltkpopup-content\n  .ltkpopup-floating-label-container.ltkpopup-floatLabel\n  label.ltkpopup-floating-label {\n  font-size: 10px;\n  line-height: 10px;\n  height: 10px;\n }\n}\n#ltkpopup-content input[type="checkbox"],\n#ltkpopup-content input[type="radio"] {\n position: absolute;\n overflow: hidden;\n clip: rect(0 0 0 0);\n height: 1px;\n width: 1px;\n margin: -1px;\n padding: 0;\n border: 0;\n}\n#ltkpopup-content fieldset.ltkpopup-options {\n border: none;\n margin: 10px auto;\n padding: 0;\n width: 100%;\n}\n#ltkpopup-content legend,\n#ltkpopup-content .ltkpopup-legend {\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n font-weight: 700;\n font-size: 14px;\n line-height: 21px;\n text-align: center;\n color: #000000;\n white-space: normal;\n margin: 0 auto;\n}\n#ltkpopup-content legend span,\n#ltkpopup-content .ltkpopup-legend span {\n font-weight: 400;\n font-size: 10px;\n line-height: 16px;\n color: #000000;\n display: block;\n}\n#ltkpopup-content .ltkpopup-checkbox,\n#ltkpopup-content .ltkpopup-radio {\n float: left;\n width: 50%;\n}\n#ltkpopup-content .ltkpopup-checkbox label,\n#ltkpopup-content .ltkpopup-radio label {\n display: block;\n position: relative;\n cursor: pointer;\n font-size: 14px;\n margin-top: 15px;\n font-weight: 400;\n}\n#ltkpopup-content .ltkpopup-checkbox label:before,\n#ltkpopup-content .ltkpopup-radio label:before {\n position: absolute;\n display: block;\n float: left;\n text-align: center;\n font-family: "ltk-FontAwesome";\n font-weight: 400;\n font-size: 14px;\n color: #d3d3d3;\n}\n#ltkpopup-content .ltkpopup-checkbox label span,\n#ltkpopup-content .ltkpopup-radio label span {\n display: block;\n padding: 0 0 0 25px;\n line-height: 21px;\n}\n#ltkpopup-content .ltkpopup-checkbox label:before {\n content: "";\n width: 14px;\n height: 14px;\n border: 1px solid #777876;\n}\n#ltkpopup-content .ltkpopup-checkbox input:checked + label::before {\n content: "\\f00c";\n color: #000000;\n font-size: 14px;\n line-height: 14px;\n font-family: "ltk-FontAwesome";\n font-weight: 900;\n}\n#ltkpopup-content .ltkpopup-checkbox input:focus + label::before,\n#ltkpopup-content .ltkpopup-checkbox input:hover + label::before {\n border-color: #000000;\n}\n#ltkpopup-content .ltkpopup-checkbox input:checked + label:hover::before {\n opacity: 0.7;\n}\n#ltkpopup-content .ltkpopup-checkbox input:checked:focus + label:hover::before {\n opacity: 1;\n}\n#ltkpopup-content .ltkpopup-radio label::before {\n content: "\\f111";\n}\n#ltkpopup-content .ltkpopup-radio input:checked ~ label::before {\n color: #000;\n content: "\\f192";\n}\n#ltkpopup-content .ltkpopup-radio input:focus + label::before,\n#ltkpopup-content .ltkpopup-radio input:hover + label::before {\n color: #000;\n}\n#ltkpopup-content .dropdown {\n position: relative;\n width: 100%;\n height: 40px;\n margin: 10px 0;\n padding: 0;\n font-size: 14px;\n font-weight: 400;\n text-overflow: ellipsis;\n border-radius: 0 !important;\n cursor: pointer;\n}\n#ltkpopup-content .dropdown select {\n width: 100%;\n height: 100%;\n padding: 0 10px;\n z-index: 1;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n font-size: 14px;\n font-weight: 400;\n color: #000000;\n text-indent: 0 !important;\n background: #fff;\n border: 1px solid #777876;\n border-radius: 0;\n cursor: pointer;\n -webkit-appearance: none !important;\n -moz-appearance: none !important;\n appearance: none !important;\n}\n#ltkpopup-content .dropdown select:focus {\n border-color: #000000;\n outline: none;\n}\n#ltkpopup-content .dropdown::before {\n position: absolute;\n display: block;\n right: 10px;\n top: 50%;\n margin-top: -10px;\n z-index: 2;\n font-size: 14px;\n content: "\\f0d7";\n color: #000000;\n pointer-events: none;\n -webkit-transition: all 0.25s linear;\n transition: all 0.25s linear;\n font-family: "ltk-FontAwesome";\n font-weight: 400;\n}\n#ltkpopup-content .dropdown select::-ms-expand {\n display: none !important;\n}\n#ltkpopup-content input.ltkinputnotvalid,\n#ltkpopup-content div.dropdown.ltk-select-notvalid,\n#ltkpopup-content div.dropdown select.ltkinputnotvalid {\n border-color: red;\n}\n#ltkpopup-content input.ltkinputnotvalid:focus,\n#ltkpopup-content div.dropdown.ltk-select-notvalid:focus,\n#ltkpopup-content div.dropdown select.ltkinputnotvalid:focus {\n border-color: red;\n}\n#ltkpopup-content input.ltkinputnotvalid::-webkit-input-placeholder {\n color: red;\n}\n#ltkpopup-content input.ltkinputnotvalid::-moz-placeholder {\n color: red;\n}\n#ltkpopup-content input.ltkinputnotvalid:-ms-input-placeholder {\n color: red;\n}\n#ltkpopup-content label.ltkinputnotvalid,\n#ltkpopup-content label.ltkpopup-floating-label.ltkinputnotvalid {\n color: red;\n}\n#ltkpopup-content .ltkpopup-error-message {\n display: block;\n height: 20px;\n color: red;\n text-align: center;\n line-height: 20px;\n width: 100%;\n font-size: 14px;\n}\n#ltkpopup-content .ltkpopup-error-message.ltkpopup-floating-error {\n position: absolute;\n left: 1.5px;\n top: 1.5px;\n z-index: 7;\n width: calc(100% - (3px));\n white-space: nowrap;\n transition: 0.25s;\n pointer-events: none;\n line-height: 37px;\n height: 37px;\n background-color: #fff;\n}\n#ltkpopup-content\n .ltkpopup-error-message.ltkpopup-floating-error.ltkpopup-floatLabel {\n height: 10px;\n line-height: 10px;\n font-size: 10px;\n}\n#ltkpopup-content .ltkpopup-error-message:empty {\n visibility: hidden;\n}\n#ltkpopup-content\n .ltkpopup-float-fields\n .ltkpopup-error-message.ltkpopup-floating-error {\n width: 247px;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-content .ltkpopup-error-message {\n  line-height: 18px;\n  font-size: 14px;\n  height: 18px;\n }\n #ltkpopup-content .ltkpopup-error-message.ltkpopup-floating-error {\n  line-height: 37px;\n  height: 37px;\n }\n}\n#ltkpopup-content .ltkpopup-button-container {\n position: relative;\n width: 100%;\n overflow: hidden;\n}\n#ltkpopup-content .ltkpopup-subscribe,\n#ltkpopup-content .ltkpopup-close-button,\n#ltkpopup-content .ltkpopup-faux-subscribe,\n#ltkpopup-content .ltkpopup-sms-link {\n display: block;\n position: relative;\n width: 100%;\n margin: 10px auto 17px;\n padding: 0 20px;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n font-size: 15px;\n font-weight: 400;\n color: #ffffff;\n height: 40px;\n text-decoration: none;\n background-color: #000000;\n border: 1px solid #000000;\n border-radius: 0px !important;\n box-shadow: none !important;\n cursor: pointer;\n outline: none;\n -webkit-appearance: none !important;\n -moz-appearance: none !important;\n appearance: none !important;\n -webkit-transition: all 0.25s linear;\n transition: all 0.25s linear;\n transition: 0.25s;\n overflow: hidden;\n letter-spacing: 0;\n text-align: center;\n line-height: 40px;\n}\n#ltkpopup-content .ltkpopup-subscribe span,\n#ltkpopup-content .ltkpopup-close-button span,\n#ltkpopup-content .ltkpopup-faux-subscribe span,\n#ltkpopup-content .ltkpopup-sms-link span {\n position: relative;\n z-index: 1;\n}\n#ltkpopup-content .ltkpopup-subscribe:hover,\n#ltkpopup-content .ltkpopup-close-button:hover,\n#ltkpopup-content .ltkpopup-faux-subscribe:hover,\n#ltkpopup-content .ltkpopup-sms-link:hover {\n color: #fff;\n background-color: #777777;\n border-color: #777777;\n}\n#ltkpopup-content .ltkpopup-subscribe:focus,\n#ltkpopup-content .ltkpopup-close-button:focus,\n#ltkpopup-content .ltkpopup-faux-subscribe:focus,\n#ltkpopup-content .ltkpopup-sms-link:focus {\n color: #fff;\n background-color: #777777;\n border-color: #777777;\n transition: 0s;\n}\n#ltkpopup-content .ltkpopup-faux-subscribe {\n margin: 7px auto 0;\n}\n#ltkpopup-content .ltkpopup-sms-link {\n padding: 0 0 0 0;\n height: 40px;\n line-height: 21px;\n background: url("") no-repeat #000000 left 30px top 22px;\n background-size: 41px auto;\n}\n#ltkpopup-content .ltkpopup-sms-link > span {\n display: block;\n font-weight: 300;\n text-align: center;\n}\n#ltkpopup-content .ltkpopup-sms-link .ltkpopup-shortcode {\n font-style: italic;\n font-weight: 700;\n}\n#ltkpopup-content .ltkpopup-close-button {\n float: none;\n margin: 10px auto 17px;\n max-width: 360px;\n}\n#ltkpopup-content .ltkpopup-no-thanks {\n float: none;\n width: 100%;\n text-align: center;\n}\n#ltkpopup-content .ltkpopup-no-thanks span {\n font-size: 14px;\n line-height: 20px;\n color: #000000;\n}\n#ltkpopup-content .ltkpopup-no-thanks a,\n#ltkpopup-content .ltkpopup-no-thanks button {\n background: none;\n border: none;\n display: inline-block;\n padding: 10px 0;\n font-size: 14px;\n line-height: 20px;\n font-weight: 400;\n color: #000000;\n text-decoration: underline;\n -webkit-transition: all 0.25s linear;\n transition: all 0.25s linear;\n cursor: pointer;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n letter-spacing: 0;\n}\n#ltkpopup-content .ltkpopup-no-thanks a:hover,\n#ltkpopup-content .ltkpopup-no-thanks a:focus,\n#ltkpopup-content .ltkpopup-no-thanks button:hover,\n#ltkpopup-content .ltkpopup-no-thanks button:focus {\n text-decoration: none;\n}\n#ltkpopup-content .ltkpopup-float-fields {\n width: 350px;\n margin: 0 auto;\n}\n#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button {\n width: 100px;\n float: left;\n}\n#ltkpopup-content\n .ltkpopup-float-fields\n .ltk-floating-button\n .ltkpopup-subscribe,\n#ltkpopup-content\n .ltkpopup-float-fields\n .ltk-floating-button\n .ltkpopup-faux-subscribe {\n margin: 0 auto;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-content .ltkpopup-subscribe,\n #ltkpopup-content .ltkpopup-close-button,\n #ltkpopup-content .ltkpopup-faux-subscribe,\n #ltkpopup-content .ltkpopup-sms-link {\n  font-size: 15px;\n  margin: 10px auto 3px;\n  height: 40px;\n  line-height: 40px;\n }\n #ltkpopup-content .ltkpopup-faux-subscribe,\n #ltkpopup-content .ltkpopup-sms-link {\n  margin: 16px auto 2px;\n }\n #ltkpopup-content .ltkpopup-close-button {\n  float: none;\n  margin: 10px auto 3px;\n  max-width: 259px;\n }\n #ltkpopup-content .ltkpopup-no-thanks a,\n #ltkpopup-content .ltkpopup-no-thanks button {\n  font-size: 14px;\n  line-height: 20px;\n }\n #ltkpopup-content .ltkpopup-no-thanks a:focus-visible,\n #ltkpopup-content .ltkpopup-no-thanks button:focus-visible {\n  outline: none;\n }\n #ltkpopup-content .ltkpopup-float-fields {\n  width: 100%;\n }\n #ltkpopup-content .ltkpopup-float-fields .ltk-floating-button {\n  width: 100%;\n }\n #ltkpopup-content\n  .ltkpopup-float-fields\n  .ltk-floating-button\n  .ltkpopup-subscribe {\n  margin: 10px auto 3px;\n }\n #ltkpopup-content\n  .ltkpopup-float-fields\n  .ltk-floating-button\n  .ltkpopup-faux-subscribe {\n  margin: 16px auto 2px;\n }\n}\n#ltkpopup-content .ltkpopup-datepicker {\n background-image: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNSIgaGVpZ2h0PSIxNy4xNDMiIHZpZXdCb3g9IjAgMCAxNSAxNy4xNDMiPjxwYXRoIGlkPSJJY29uX2F3ZXNvbWUtY2FsZW5kYXItYWx0IiBkYXRhLW5hbWU9Ikljb24gYXdlc29tZS1jYWxlbmRhci1hbHQiIGQ9Ik0wLDE1LjUzNmExLjYwOCwxLjYwOCwwLDAsMCwxLjYwNywxLjYwN0gxMy4zOTNBMS42MDgsMS42MDgsMCwwLDAsMTUsMTUuNTM2VjYuNDI5SDBaTTEwLjcxNCw4Ljk3M2EuNC40LDAsMCwxLC40LS40aDEuMzM5YS40LjQsMCwwLDEsLjQuNHYxLjMzOWEuNC40LDAsMCwxLS40LjRIMTEuMTE2YS40LjQsMCwwLDEtLjQtLjRabTAsNC4yODZhLjQuNCwwLDAsMSwuNC0uNGgxLjMzOWEuNC40LDAsMCwxLC40LjRWMTQuNmEuNC40LDAsMCwxLS40LjRIMTEuMTE2YS40LjQsMCwwLDEtLjQtLjRaTTYuNDI5LDguOTczYS40LjQsMCwwLDEsLjQtLjRIOC4xN2EuNC40LDAsMCwxLC40LjR2MS4zMzlhLjQuNCwwLDAsMS0uNC40SDYuODNhLjQuNCwwLDAsMS0uNC0uNFptMCw0LjI4NmEuNC40LDAsMCwxLC40LS40SDguMTdhLjQuNCwwLDAsMSwuNC40VjE0LjZhLjQuNCwwLDAsMS0uNC40SDYuODNhLjQuNCwwLDAsMS0uNC0uNFpNMi4xNDMsOC45NzNhLjQuNCwwLDAsMSwuNC0uNEgzLjg4NGEuNC40LDAsMCwxLC40LjR2MS4zMzlhLjQuNCwwLDAsMS0uNC40SDIuNTQ1YS40LjQsMCwwLDEtLjQtLjRabTAsNC4yODZhLjQuNCwwLDAsMSwuNC0uNEgzLjg4NGEuNC40LDAsMCwxLC40LjRWMTQuNmEuNC40LDAsMCwxLS40LjRIMi41NDVhLjQuNCwwLDAsMS0uNC0uNFpNMTMuMzkzLDIuMTQzSDExLjc4NlYuNTM2QS41MzcuNTM3LDAsMCwwLDExLjI1LDBIMTAuMTc5YS41MzcuNTM3LDAsMCwwLS41MzYuNTM2VjIuMTQzSDUuMzU3Vi41MzZBLjUzNy41MzcsMCwwLDAsNC44MjEsMEgzLjc1YS41MzcuNTM3LDAsMCwwLS41MzYuNTM2VjIuMTQzSDEuNjA3QTEuNjA4LDEuNjA4LDAsMCwwLDAsMy43NVY1LjM1N0gxNVYzLjc1QTEuNjA4LDEuNjA4LDAsMCwwLDEzLjM5MywyLjE0M1oiIGZpbGw9IiMzMyIvPjwvc3ZnPg==");\n background-size: auto;\n background-position: right 10px center;\n background-repeat: no-repeat;\n box-shadow: none !important;\n}\n#ltkpopup-content span.ui-datepicker-year {\n display: none;\n}\n#ltkpopup-content .ui-widget {\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n font-weight: 400;\n text-transform: uppercase;\n}\n#ltkpopup-content #ui-datepicker-div {\n z-index: 1001000 !important;\n position: fixed !important;\n top: 50% !important;\n left: 50% !important;\n margin-left: 0 !important;\n -webkit-transform: translate(-50%, -50%) !important;\n -moz-transform: translate(-50%, -50%) !important;\n -ms-transform: translate(-50%, -50%) !important;\n transform: translate(-50%, -50%) !important;\n -webkit-box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.09);\n -moz-box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.09);\n box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.09);\n}\n#ltkpopup-content .ui-datepicker {\n padding: 0;\n}\n#ltkpopup-content .ui-widget.ui-widget-content {\n border-width: 0px;\n color: #777876 !important;\n}\n#ltkpopup-content .ui-corner-all,\n#ltkpopup-content .ui-corner-bottom,\n#ltkpopup-content .ui-corner-right,\n#ltkpopup-content .ui-corner-br,\n#ltkpopup-content .ui-corner-left,\n#ltkpopup-content .ui-corner-bl,\n#ltkpopup-content .ui-corner-top,\n#ltkpopup-content .ui-corner-tr,\n#ltkpopup-content .ui-corner-tl {\n border-radius: 0;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-header {\n background-color: #000000;\n color: #fff;\n padding: 9px 23px;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n border-width: 0;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-title {\n text-align: left;\n margin: 0;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-title select {\n -webkit-appearance: none;\n -moz-appearance: none;\n appearance: none;\n background: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNCIgaGVpZ2h0PSI4LjAwNCIgdmlld0JveD0iMCAwIDE0IDguMDA0Ij48cGF0aCBpZD0iSWNvbl9pb25pYy1pb3MtYXJyb3ctYmFjayIgZGF0YS1uYW1lPSJJY29uIGlvbmljLWlvcy1hcnJvdy1iYWNrIiBkPSJNMTYuODQyLDEzLjE5MiwxMS41NDQsNy45YTEsMSwwLDAsMSwxLjQxNy0xLjQxM2w2LDZhMSwxLDAsMCwxLC4wMjksMS4zOEwxMi45NjYsMTkuOWExLDEsMCwwLDEtMS40MTctMS40MTNaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgyMC4xOTQgLTExLjI1MSkgcm90YXRlKDkwKSIgZmlsbD0iI2ZmZiIvPjwvc3ZnPg==")\n  no-repeat #777876;\n background-position: right 7px center;\n background-size: 10px auto;\n color: #fff;\n border-width: 0px;\n width: auto;\n padding-right: 24px;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-title select::-ms-expand {\n display: none;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-prev,\n#ltkpopup-content .ui-datepicker .ui-datepicker-next {\n top: 50%;\n transform: translate(0, -50%);\n width: 8px;\n height: 14px;\n cursor: pointer;\n color: #fff;\n}\n#ltkpopup-content\n .ui-datepicker\n .ui-datepicker-prev.ui-datepicker-next-hover.ui-state-hover,\n#ltkpopup-content\n .ui-datepicker\n .ui-datepicker-prev.ui-datepicker-prev-hover.ui-state-hover,\n#ltkpopup-content\n .ui-datepicker\n .ui-datepicker-next.ui-datepicker-next-hover.ui-state-hover,\n#ltkpopup-content\n .ui-datepicker\n .ui-datepicker-next.ui-datepicker-prev-hover.ui-state-hover {\n border-width: 0;\n width: 10px;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-next {\n right: 26px;\n}\n#ltkpopup-content\n .ui-datepicker\n .ui-datepicker-next.ui-datepicker-next-hover.ui-state-hover {\n right: 24px;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-prev {\n transform: translate(0, -50%) rotate(90deg);\n right: 84px;\n left: auto;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-next {\n transform: translate(0, -50%) rotate(270deg);\n}\n#ltkpopup-content .ui-widget-header .ui-icon {\n background: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNCIgaGVpZ2h0PSI4LjAwNCIgdmlld0JveD0iMCAwIDE0IDguMDA0Ij48cGF0aCBpZD0iSWNvbl9pb25pYy1pb3MtYXJyb3ctYmFjayIgZGF0YS1uYW1lPSJJY29uIGlvbmljLWlvcy1hcnJvdy1iYWNrIiBkPSJNMTYuODQyLDEzLjE5MiwxMS41NDQsNy45YTEsMSwwLDAsMSwxLjQxNy0xLjQxM2w2LDZhMSwxLDAsMCwxLC4wMjksMS4zOEwxMi45NjYsMTkuOWExLDEsMCwwLDEtMS40MTctMS40MTNaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgyMC4xOTQgLTExLjI1MSkgcm90YXRlKDkwKSIgZmlsbD0iI2ZmZiIvPjwvc3ZnPg==")\n  no-repeat #777876;\n background-position: center;\n}\n#ltkpopup-content .ui-datepicker table {\n font-size: 14px;\n margin: 0;\n}\n#ltkpopup-content .ui-datepicker th {\n background-color: #a9a9a9;\n color: #fff;\n font-weight: 400;\n padding: 0;\n height: 35px;\n line-height: 35px;\n}\n#ltkpopup-content .ui-datepicker td span,\n#ltkpopup-content .ui-datepicker td a {\n text-align: center;\n padding: 8px 0;\n}\n#ltkpopup-content .ui-state-default,\n#ltkpopup-content .ui-widget-content .ui-state-default,\n#ltkpopup-content .ui-widget-header .ui-state-default,\n#ltkpopup-content .ui-button,\n#ltkpopup-content html .ui-button.ui-state-disabled:hover,\n#ltkpopup-content html .ui-button.ui-state-disabled:active {\n border: 2px solid transparent;\n background: transparent;\n color: inherit;\n}\n#ltkpopup-content .ui-state-highlight,\n#ltkpopup-content .ui-widget-content .ui-state-highlight,\n#ltkpopup-content .ui-widget-header .ui-state-highlight {\n border: 2px solid #a9a9a9;\n background: #fff;\n color: inherit;\n}\n#ltkpopup-content .ui-state-active,\n#ltkpopup-content .ui-widget-content .ui-state-active,\n#ltkpopup-content .ui-widget-header .ui-state-active,\n#ltkpopup-content a.ui-button:active,\n#ltkpopup-content .ui-button:active,\n#ltkpopup-content .ui-button.ui-state-active:hover {\n border: 2px solid #a9a9a9;\n background: #a9a9a9;\n color: #fff;\n}\n#ltkpopup-content .ui-state-hover,\n#ltkpopup-content .ui-widget-content .ui-state-hover,\n#ltkpopup-content .ui-widget-header .ui-state-hover,\n#ltkpopup-content .ui-state-focus,\n#ltkpopup-content .ui-widget-content .ui-state-focus,\n#ltkpopup-content .ui-widget-header .ui-state-focus,\n#ltkpopup-content .ui-button:hover,\n#ltkpopup-content .ui-button:focus {\n border: 2px solid transparent;\n background: #d3d3d3;\n color: inherit;\n}\n#ltkpopup-content .ui-datepicker-buttonpane {\n text-align: center;\n margin: 0;\n border: 0;\n}\n#ltkpopup-content .ui-datepicker-buttonpane button {\n float: none;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n font-weight: 400;\n font-size: 12px;\n margin: 0;\n padding: 0;\n}\n#ltkpopup-content .ui-datepicker-buttonpane button[data-handler="today"] {\n display: none;\n}\n#ltkpopup-web-push-overlay {\n width: 100%;\n height: 100%;\n position: fixed;\n top: 0;\n left: 0;\n display: none;\n transition: opacity 0.25s ease-in-out;\n}\n#ltkpopup-web-push-overlay.ltkpopup-overlay-show {\n display: block;\n}\n#ltkpopup-web-push-overlay .ltkpopup-web-push-content {\n width: 100%;\n margin-top: 100px;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n position: relative;\n}\n#ltkpopup-web-push-overlay .ltkpopup-web-push-content #ltkpopup-close-button {\n top: -82px;\n}\n#ltkpopup-web-push-overlay\n .ltkpopup-web-push-content\n #ltkpopup-close-button\n a\n svg {\n stroke: #fff;\n}\n#ltkpopup-web-push-overlay .ltkpopup-web-push-content:before {\n width: 300px;\n height: 96px;\n background-image: url("data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJMYXllcl8xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDM2LjcgMTEuNyIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYuNyAxMS43OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+CjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyIgZmlsbD0icmdiKDUxLCA1MSwgNTEpIiBkYXRhLWNvbG9yLWlkLWZpbGw9ImN1cnJlbnRDb2xvciI+Cgkuc3Qwe2ZpbGw6bm9uZTtzdHJva2U6I0ZGRkZGRjtzdHJva2Utd2lkdGg6MS41O3N0cm9rZS1saW5lY2FwOnJvdW5kO3N0cm9rZS1saW5lam9pbjpyb3VuZDt9Cjwvc3R5bGU+CjxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0wLjksNC4zbDMuNS0zLjVsMy41LDMuNSIgZmlsbD0ibm9uZSIgZGF0YS1jb2xvci1pZC1maWxsPSJjdXJyZW50Q29sb3IiPjwvcGF0aD4KPHBhdGggY2xhc3M9InN0MCIgZD0iTTQuNCwwLjh2NmMwLDQuNyw1LjEsNCwxMS40LDRoMjAiIGZpbGw9Im5vbmUiIGRhdGEtY29sb3ItaWQtZmlsbD0iY3VycmVudENvbG9yIj48L3BhdGg+Cjwvc3ZnPg==");\n background-size: cover;\n content: "";\n position: absolute;\n top: 25px;\n left: 260px;\n}\n#ltkpopup-web-push-overlay .ltkpopup-web-push-content .ltkpopup-web-push-pos {\n position: absolute;\n top: 0;\n left: 590px;\n}\n#ltkpopup-web-push-overlay\n .ltkpopup-web-push-content\n .ltkpopup-web-push-pos\n h3 {\n color: #fff;\n font-size: 30px;\n margin: 30px auto;\n}\n#ltkpopup-web-push-overlay .ltkpopup-web-push-content .ltkpopup-web-push-pos p {\n color: #fff;\n max-width: 390px;\n}\n#ltkpopup-container.ltkpopup-overlay-show {\n width: 100% !important;\n height: 100% !important;\n}\n#ltkpopup-container.ltkpopup-webpush-visible {\n visibility: visible;\n}\n#ltkpopup-overlay.ltkpopup-webpush-visible {\n visibility: visible;\n}\n@-moz-document url-prefix() {\n #ltkpopup-web-push-overlay .ltkpopup-web-push-content:before {\n  left: 470px;\n }\n #ltkpopup-web-push-overlay .ltkpopup-web-push-content .ltkpopup-web-push-pos {\n  left: 800px;\n }\n}\n@supports (-ms-ime-align: auto) {\n #ltkpopup-web-push-overlay .ltkpopup-web-push-content:before {\n  top: 50px;\n }\n #ltkpopup-web-push-overlay .ltkpopup-web-push-content .ltkpopup-web-push-pos {\n  top: 25px;\n }\n}\n@media only screen and (max-width: 992px) {\n #ltkpopup-web-push-overlay .ltkpopup-web-push-content:before {\n  width: 140px;\n }\n #ltkpopup-web-push-overlay .ltkpopup-web-push-content .ltkpopup-web-push-pos {\n  left: 440px;\n }\n}\n@media only screen and (max-device-width: 1200px) {\n #ltkpopup-web-push-overlay.ltkpopup-overlay-show {\n  display: none;\n }\n}\n',
            confirmationHTML: '\n\t\t\t\t\t\t\t\n\n<!-- Pop-up Confirm / Appears after user submits Popup Form -->\n<div id="ltkpopup-wrapper" class="confirm ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-sms-headline" aria-describedby="ltkpopup-sms-para">\n\t<!-- Main Popup Content Area -->\n\t<div id="ltkpopup-content" class="ltkpopup-confirm ltkpopup-sms-form">\n\n\t\t<!-- Pull in the popup container -->\n\t\t\n\t\t<div id="ltkpopup-sms-form">\n\t<div class="ltkpopup-clearfix ltkpopup-split-content ltkpopup-split-above-below">\n\n\t\t\n\n<div class="ltkpopup-contain-img">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/650x320.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-mobile-hide" aria-hidden="true">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/320x235.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-desktop-hide" aria-hidden="true">\n<\/div>\n\n\n\n\t\t<div class="ltkpopup-contain-form">\n\n\t\t\t\n\t\t\t<h1 id="ltkpopup-sms-headline" class="ltkpopup-subheadline">HERE&rsquo;S YOUR 2O% OFFER CODE: <span class="ltkpopup-coupon">WELCOME20<\/span><\/h1>\n<p id="ltkpopup-sms-para" class="ltkpopup-content-para ltkpopup-mobile-smaller">Want another 2O% off for a <br class="ltkpopup-desktop-hide">future&nbsp;purchase?<\/p>\n\n\t\t\t<div class="ltkpopup-form-contain">\n\t\t\t\t\n<div class="ltkpopup-clearfix ltkpopup-form-control ltkpopup-mobile-hide">\n\n\t<div class="ltkpopup-error-message" aria-live="assertive" data-ltkpopup-error-for="ltkpopup-phone" data-ltkpopup-message="Please enter a valid mobile number"><\/div>\n\n<div >\n\t<div class="ltkpopup-floating-label-container" >\n\t\t<label for="ltkpopup-phone" class="ltkpopup-floating-label" >Enter mobile number<\/label>\n\t\t<input autofocus required type="tel" id="ltkpopup-phone" class="ltkpopup-email" tabindex="0" name="ltkpopup-phone" placeholder="" autocomplete="tel" data-inputmask="\'mask\': \'(###) ###-####\'" pattern="^\\D?(\\d{3})\\D?\\D?(\\d{3})\\D?(\\d{4})$" />\n\t<\/div>\n<\/div>\n\n\t<div class="ltkpopup-button-container ltkpopup-flex ltkpopup-clearfix">\n\t\t<button id="ltkpopup-faux-submit" class="ltkpopup-faux-subscribe" tabindex="0" type="submit">SIGN ME UP<\/button>\n\t<\/div>\n\n<\/div>\n\n\n<div class="ltkpopup-clearfix ltkpopup-form-control ltkpopup-desktop-hide">\n\t<a id="ltkpopup-ttj-button" class="ltkpopup-sms-link ltkpopup-close ltkpopup-tap-to-join" href="sms://69629/" data-sms-keyword="Send this text for recurring automated Nine West marketing alerts + cart reminders" target="_top">\n\t\t<span>Sign up for texts\n\t\t<\/span>\n\t<\/a>\n<\/div>\n\n\n\n<div class="ltkpopup-no-thanks" id="ltkpopup-text-btn">\n\t<button tabindex="0" id="ltkpopup-skip-sms" >I&rsquo;ll skip the texts for now<\/button>\n<\/div>\n\n\t\t\t<\/div>\n\n\t\t\t<p id="ltkpopup-content-sms-disc" class="ltkpopup-content-para ltkpopup-sms-disclaimer">All offers exclude Gift Cards and Final Sale/Clearance. Some additional product exclusions may apply per brand/season. By subscribing to Nine West text messaging on 69629, you agree to receive recurring automated marketing text msgs (e.g. cart reminders) to the mobile number used at opt&dash;in. Consent is not a condition of purchase. Msg frequency may vary. Msg &amp; data rates may apply. Reply HELP for help and STOP to cancel. See <a href="https://ninewest.com/policies/terms-of-service" target="_blank">Terms and Conditions<\/a> &amp; <a href="https://ninewest.com/policies/privacy-policy" target="_blank">Privacy&nbsp;Policy<\/a>.<\/p>\n\n\t\t<\/div>\n\n\t<\/div>\n<\/div>\n\n<div id="ltkpopup-sms-confirm" aria-hidden="true">\n\n\t<div class="ltkpopup-clearfix ltkpopup-split-content ltkpopup-split-above-below">\n\n\t\t\n\n\n<div class="ltkpopup-contain-img">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/650x320.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-mobile-hide" aria-hidden="true">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/320x235.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-desktop-hide" aria-hidden="true">\n<\/div>\n\n\n\n\t\t<div class="ltkpopup-contain-form">\n\n\t\t\t\n\t\t\t<h1 id="ltkpopup-sms-confirm-headline" class="ltkpopup-headline ltkpopup-visuallyhidden">Welcome to Nine West<\/h1>\n<h2 id="ltkpopup-sms-confirm-subheadline" class="ltkpopup-headline">YOU\'RE IN<\/h2>\n<p id="ltkpopup-sms-confirm-content-para" class="ltkpopup-content-para">Check your text messages to confirm <br class="ltkpopup-mobile-hide">your subscription and receive your&nbsp;offer.<\/p>\n\t\t\t\n\t\t\t<div class="ltkpopup-button-container" id="ltkpopup-thanks">\n    <button tabindex="0" class="ltkpopup-close ltkpopup-close-button">Start shopping<\/button>\n<\/div>\n\t\t\t\n\t\t\t<p class="ltkpopup-content-para ltkpopup-disclaimer">All offers exclude Gift Cards and Final Sale/Clearance. Some additional product exclusions may apply per brand/season. See <a href="https://ninewest.com/policies/terms-of-service" target="_blank">Terms and Conditions<\/a> &amp; <a href="https://ninewest.com/policies/privacy-policy" target="_blank">Privacy&nbsp;Policy<\/a>.<\/p>\n\n\t\t<\/div>\n\n\t<\/div>\n\n<\/div>\n\n\n\n<div id="ltkpopup-sms-no-thanks" aria-hidden="true">\n\n\t<div class="ltkpopup-clearfix ltkpopup-split-content ltkpopup-split-above-below">\n\n\t\n\n<div class="ltkpopup-contain-img">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/650x320.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-mobile-hide" aria-hidden="true">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/320x235.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-desktop-hide" aria-hidden="true">\n<\/div>\n\n\n\n\t<div class="ltkpopup-contain-form">\n\n\t\t\n\t\t<h1 id="ltkpopup-sms-no-thanks-headline" class="ltkpopup-headline ltkpopup-visuallyhidden">Welcome to Earth<\/h1>\n<h2 id="ltkpopup-sms-no-thanks-subheadline" class="ltkpopup-headline">Thank you!<\/h2>\n<p id="ltkpopup-sms-no-thanks-content-para" class="ltkpopup-content-para">Here\'s your 20% offer code: <span class="ltkpopup-coupon">welcome20<\/span><\/p>\n\t\t\n\t\t<div class="ltkpopup-button-container" id="ltkpopup-thanks">\n    <button tabindex="0" class="ltkpopup-close ltkpopup-close-button">Start shopping<\/button>\n<\/div>\n\t\t\n\t\t\n\n\t<\/div>\n\n<\/div>\n\n<\/div>\n\n\t\t\n\n\t\t<!-- End Content Information -->\n\n\t\t<!-- Close \'X\' Button -->\n\t\t\n\t<\/div>\n<\/div>\n\n\n\n\n\n<script>\n\t// Browsers\n\tvar b = document.documentElement;\n\tb.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n\tvar ua = navigator.userAgent.toLowerCase(),\n\t\tpf = navigator.platform.toLowerCase();\n\n\tfunction is(e) {\n\t\treturn ua.indexOf(e) > -1\n\t}\n\tvar browser = {\n\t\tIE: is("msie") || is("trident/7.0"),\n\t\tIE7: is("msie 7.0"),\n\t\tIE8: is("msie 8.0"),\n\t\tIE9: is("msie 9.0"),\n\t\tIE10: is("msie 10"),\n\t\tIE11: is("rv:11") && is("trident/7.0"),\n\t\tEdge: is("edge"),\n\t\tChrome: is("chrome") && !is("edge"),\n\t\tSafari: is("safari") && !is("chrome") && !is("edge"),\n\t\tFirefox: is("firefox") && !is("edge"),\n\t\tAndroidChrome: is("android") && is("chrome"),\n\t\tAndroidDefault: is("android") && !is("chrome"),\n\t\tWin7: is("windows nt 6.1"),\n\t\tWin8: is("windows nt 6.2"),\n\t\tWindows: pf.indexOf("win32") > -1,\n\t\tWebkit: is("webkit") && !is("edge"),\n\t\tIPad: is("ipad"),\n\t\tIPadChrome: is("ipad") && is("crios"),\n\t\tIPhone: is("iphone"),\n\t\tIPhoneChrome: is("iphone") && is("crios"),\n\t\tAndroid: is("android"),\n\t\tIOS: is("iphone") || is("ipad")\n\t};\n\tfor (var title in browser) {\n\t\tif (browser[title]) {\n\t\t\tdocument.getElementById("ltkpopup-content").classList.add(String(title).toLowerCase());\n\t\t}\n\t}\n\n\t// Close Function\n\tvar focused = document.activeElement;\n\tvar closeBtns = document.querySelectorAll(\'.ltkpopup-close\');\n\tfor (var i = 0; i < closeBtns.length; i++) {\n\t\tcloseBtns[i].addEventListener("click", function (e) {\n\t\t\t_ltk.Popup.close();\n\t\t\tfocused.focus();\n\t\t});\n\t}\n\n\t// Check Input Validity\n\tfunction checkInputValidity(inputEl) {\n\t\tvar ltkErrorClass = "ltkinputnotvalid";\n\t\tvar ltkErrorMessage = document.querySelector("[data-ltkpopup-error-for=\'" + inputEl.id + "\']");\n\t\tvar ltkLabel = document.querySelector("label[for=\'" + inputEl.id + "\']");\n\t\tif (ltkErrorMessage != undefined) {\n\t\t\tltkErrorMessage.innerText = "";\n\t\t\tinputEl.classList.remove(ltkErrorClass);\n\t\t\tif (ltkLabel != undefined) {\n\t\t\t\tltkLabel.classList.remove(ltkErrorClass);\n\t\t\t}\n\t\t}\n\t\tinputEl.checkValidity();\n\t\tif (!inputEl.validity.valid) {\n\t\t\tinputEl.classList.add(ltkErrorClass);\n\t\t\tif (ltkLabel != undefined) {\n\t\t\t\tltkLabel.classList.add(ltkErrorClass);\n\t\t\t}\n\t\t\tif (ltkErrorMessage != undefined) {\n\t\t\t\tltkErrorMessage.innerText = ltkErrorMessage.getAttribute("data-ltkpopup-message");\n\t\t\t}\n\t\t\treturn false;\n\t\t}\n\t\treturn true;\n\t}\n\n\t// Override close CTA focus called by onescript 2x\n\tonescriptFocus = 0;\n\twrapperFocus = function () {\t\n\t\tdocument.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n\t\tonescriptFocus ++;\n\t\tif(onescriptFocus == 1) {\n\t\t\tdocument.querySelector(\'.simpleltkmodal-wrap button\').removeEventListener(\'focus\', wrapperFocus);\n\t\t}\n\t}\n\n\t// Tab Trapping\n\tsetTimeout(function () {\n\t\tfunction triggerFocus(element) {\n\t\t\tvar eventType = "onfocusin" in element ? "focusin" : "focus",\n\t\t\t\tbubbles = "onfocusin" in element,\n\t\t\t\tevent;\n\n\t\t\tif ("createEvent" in document) {\n\t\t\t\tevent = document.createEvent("Event");\n\t\t\t\tevent.initEvent(eventType, bubbles, true);\n\t\t\t} else if ("Event" in window) {\n\t\t\t\tevent = new Event(eventType, {\n\t\t\t\t\tbubbles: bubbles,\n\t\t\t\t\tcancelable: true\n\t\t\t\t});\n\t\t\t}\n\n\t\t\telement.focus();\n\t\t\telement.dispatchEvent(event);\n\t\t}\n\t\tif (document.getElementById("ltkpopup-email") != undefined) {\n\t\t\ttriggerFocus(document.getElementById("ltkpopup-email"));\n\t\t} else if (document.getElementById("ltkpopup-phone") != undefined) {\n\t\t\ttriggerFocus(document.getElementById("ltkpopup-phone"));\n\t\t} else if (document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined && document.querySelector(\'.simpleltkmodal-wrap input\') == null && document.querySelector(\'.simpleltkmodal-wrap button\') != null) {\n\t\t\tdocument.querySelector(\'.simpleltkmodal-wrap button\').addEventListener(\'focus\', wrapperFocus);\n\t\t}\n\t}, 0);\n\n\tfunction trapTabKey(e) {\n\t\tvar t = document.activeElement,\n\t\t\ts = focusableElems.indexOf(t);\n\t\tif (9 === e.keyCode) {\n\t\t\te.preventDefault();\n\t\t\tmoveTab(s, e.shiftKey)\n\t\t}\n\t}\n\n\tfunction moveTab(index, shift) {\n\t\tvar nextTab = null;\n\t\tvar nextIndex = index;\n\t\tif (shift) {\n\t\t\tif (focusableElems[index] == firstTabStop) {\n\t\t\t\tnextTab = lastTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index - 1;\n\t\t\t\tnextTab = focusableElem[nextIndex];\n\t\t\t}\n\t\t} else {\n\t\t\tif (focusableElems[index] == lastTabStop) {\n\t\t\t\tnextTab = firstTabStop;\n\t\t\t\tnextIndex = 0;\n\t\t\t} else {\n\t\t\t\tnextIndex = index + 1;\n\t\t\t\tnextTab = focusableElems[nextIndex];\n\t\t\t}\n\t\t}\n\t\tif (nextTab.offsetParent != null) {\n\t\t\tnextTab.focus();\n\t\t} else {\n\t\t\tmoveTab(nextIndex, shift);\n\t\t}\n\t}\n\tsetTimeout(function () {\n\t\t//Do not delete - tab functionality will break\n\t\t_ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n\t}, 50);\n\tvar focusBox = document.getElementById("ltkpopup-content"),\n\t\tfocusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n\t\tfocusableElem = focusBox.querySelectorAll(focusableElemStr),\n\t\tfocusableElems = Array.prototype.slice.call(focusableElem),\n\t\tfirstTabStop = focusableElems[0],\n\t\tlastTabStop = focusableElems[focusableElems.length - 1];\n\tfocusBox.addEventListener("keydown", trapTabKey);\n\n\n\t// floating labels\n\tjQuery(\'.ltkpopup-floating-label-container :input\').each(function () {\n\t\tthis.addEventListener(\'blur\', removeFloat, false);\n\t\tif (this.hasAttribute(\'data-inputmask\') || this.id == \'ltkpopup-datepicker\') {\n\t\t\tthis.addEventListener(\'focus\', addFloat, false);\n\t\t} else {\n\t\t\tthis.addEventListener(\'click\', addFloat, false);\n\t\t\tthis.addEventListener(\'keydown\', addFloat, false);\n\t\t}\n\t});\n\n\tfunction addFloat(event) {\n\t\tjQuery(event.target).closest(".ltkpopup-floating-label-container").addClass(\'ltkpopup-floatLabel\');\n\t\tjQuery("[data-ltkpopup-error-for=\'" + event.target.id + "\']").addClass(\'ltkpopup-floatLabel\');\n\t}\n\n\tfunction removeFloat(event) {\n\t\tif (event.target.value.length == 0 && !event.target.classList.contains("ltkpopup-datepicker")) {\n\t\t\tjQuery(event.target).closest(".ltkpopup-floating-label-container").removeClass(\'ltkpopup-floatLabel\');\n\t\t\tjQuery("[data-ltkpopup-error-for=\'" + event.target.id + "\']").removeClass(\'ltkpopup-floatLabel\');\n\t\t}\n\t}\n<\/script>\n\n<script>\n\tif (document.querySelectorAll("[data-inputmask]").length > 0) {\n\n\t\t// Input masking for number validation - Get Jquery Input Mask from CDN and load it\n\t\tjQuery.getScript(\n\t\t\t"https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.1/jquery.inputmask.bundle.js",\n\t\t\tfunction () {\n\t\t\t\tjQuery("[data-inputmask]").each(function () {\n\t\t\t\t\t// Mask phone number input after script is loaded\n\t\t\t\t\tjQuery(this).inputmask({\n\t\t\t\t\t\tgreedy: false,\n\t\t\t\t\t\tshowMaskOnHover: false,\n\t\t\t\t\t\tdefinitions: {\n\t\t\t\t\t\t\t\'#\': {\n\t\t\t\t\t\t\t\tvalidator: "[0-9]",\n\t\t\t\t\t\t\t\tcardinality: 1\n\t\t\t\t\t\t\t}\n\t\t\t\t\t\t}\n\t\t\t\t\t});\n\t\t\t\t});\n\t\t\t});\n\t}\n<\/script>\n<script>\n\tjQuery(\'#ltkpopup-faux-submit\').on(\'click\', function () {\n\t\tvar e = jQuery("#ltkpopup-sms-form :input");\n\t\tvar formIsValid = true;\n\t\tjQuery(e).each(function (e) {\n\t\t\tif (checkInputValidity(this)) {\n\t\t\t\tif (this.id == \'ltkpopup-phone\') {\n\t\t\t\t\t_ltk.Subscriber.Email = this.value;\n\t\t\t\t\tthis.removeAttribute("aria-describedby");\n\t\t\t\t}\n\t\t\t} else {\n\t\t\t\tformIsValid = false;\n\t\t\t\tthis.setAttribute("aria-describedby", this.id + "-error-message");\n\t\t\t\tdocument.querySelector(".ltkinputnotvalid").focus();\n\t\t\t}\n\t\t});\n\t\tif (formIsValid) {\n\t\t\tjQuery(e).each(function (e) {\n\t\t\t\tlet fieldMapping = this.name;\n\t\t\t\tif (this.type == "radio") {\n\t\t\t\t\tfieldMapping = this.name + "." + this.value;\n\t\t\t\t}\n\t\t\t\tif (this.type == "checkbox" || this.type == "radio") {\n\t\t\t\t\tif (this.checked) {\n\t\t\t\t\t\tthis.value = "on";\n\t\t\t\t\t} else {\n\t\t\t\t\t\tthis.value = "off";\n\t\t\t\t\t}\n\t\t\t\t}\n\t\t\t\t_ltk.Subscriber.Profile.Add(fieldMapping, this.value);\n\t\t\t});\n\t\t\tltkpopupNextPage(\'ltkpopup-sms-confirm\');\n\t\t\t_ltk.Subscriber.List = \'DesktopSMS\';\n\t\t\t_ltk.Subscriber.Profile.Add(\'Email\', emailVal);\n\t\t\t_ltk.Subscriber.Submit(true);\n\t\t}\n\t});\n\tvar skipSMS = document.getElementById("ltkpopup-skip-sms");\n\tif (skipSMS != null) {\n\t\tskipSMS.addEventListener("click", function (e) {\n\t\t\tltkpopupNextPage(\'ltkpopup-sms-no-thanks\');\n\t\t});\n\t}\n\tif (window.location.href.indexOf("ltknextpage=1") > -1 || window.location.href.indexOf("ltkconfirmpage=sms") > -1) {\n\t\tltkpopupNextPage(\'ltkpopup-sms-confirm\');\n\t}\n\tif (window.location.href.indexOf("ltkconfirmpage=nothanks") > -1) {\n\t\tltkpopupNextPage(\'ltkpopup-sms-no-thanks\');\n\t}\n\n\tfunction ltkpopupNextPage(nextPage) {\n\t\tjQuery(\'#ltkpopup-content\').fadeOut(\'slow\', function () {\n\t\t\tjQuery(\'#ltkpopup-sms-form\').attr(\'aria-hidden\', \'true\').hide();\n\t\t\tsetTimeout(function () {\n\t\t\t\tjQuery(\'#\' + nextPage).show().attr(\'aria-hidden\', \'false\');\n\t\t\t\tjQuery(\'#ltkpopup-wrapper\').attr({\n\t\t\t\t\t\'aria-labelledby\': nextPage + \'-headline\',\n\t\t\t\t\t\'aria-describedby\': nextPage + \'-content-para\'\n\t\t\t\t})\n\t\t\t\tjQuery(\'#ltkpopup-content\').removeClass(\'ltkpopup-sms-form\').addClass(nextPage).fadeIn(\'slow\');\n\t\t\t}, 300);\n\t\t});\n\t}\n<\/script>\n<script>\n\tvar datepickerField = document.querySelector("#ltkpopup-datepicker");\n\tif (datepickerField != null) {\n\t\tvar jQueryUIcss = document.createElement("link");\n\t\tjQueryUIcss.href = "https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css";\n\t\tjQueryUIcss.rel = "stylesheet";\n\t\tjQueryUIcss.addEventListener("load", function () {\n\t\t\tvar jQueryUI = document.createElement("script");\n\t\t\tjQueryUI.src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js";\n\t\t\tjQueryUI.addEventListener("load", function () {\n\t\t\t\tdatepickerField.setAttribute("readonly", "");\n\t\t\t\tjQuery(datepickerField).datepicker({\n\t\t\t\t\tchangeMonth: true,\n\t\t\t\t\tchangeYear: false,\n\t\t\t\t\tyearRange: \'-0:+0\',\n\t\t\t\t\t// use for different date format and hidden bday field\n\t\t\t\t\tdateFormat: "mm/dd",\n\t\t\t\t\taltField: "#ltkpopup-hidden-bday",\n\t\t\t\t\taltFormat: "mm/dd/1900",\n\t\t\t\t\tonClose: function (selectedDate) {\n\t\t\t\t\t\t\t\tif (selectedDate == "") {\n\t\t\t\t\t\t\t\t\tjQuery(this).closest(".ltkpopup-floating-label-container").removeClass(\'ltkpopup-floatLabel\');\n\t\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\t}\n\t\t\t\t\t});\n\n\t\t\t\tjQuery(datepickerField).focus(function () {\n\t\t\t\t\tjQuery(\'#ui-datepicker-div\').appendTo(this.parentNode);\n\t\t\t\t});\n\t\t\t});\n\t\t\tdocument.getElementById("ltkpopup-content").appendChild(jQueryUI);\n\t\t});\n\t\tdocument.getElementById("ltkpopup-content").appendChild(jQueryUIcss);\n\t}\n<\/script>\n\n\n\n\n\n\t\t\t\t\t\t',
            animation: null,
            urlRedirect: null,
            initialDelay: 3,
            buttonSettings: {
                size: 2,
                shape: 2,
                alignment: 2,
                text: "  SAVE  15%  ",
                color: "#000000",
                textColor: "#FFFFFF"
            },
            urlRules: [{
                urlMatchRule: 1,
                show: !1,
                url: "checkouts"
            }],
            targetingRules: {
                showWhenDevice: ["Desktop", "Mobile"]
            },
            subscriptionPoint: "Popup",
            engagement: {
                followUpTimeframe: 0,
                showWhenPageSession: 2,
                followUp: !0,
                followUpDelay: 1,
                showIfFromListrakEmail: !0
            },
            overlayClose: !1,
            referrerRule: null
        }
    }, {
        type: 1,
        category: 0,
        popupUID: "bf79d2b5-76da-4da1-8e0f-c6d9ad14ecad",
        popupName: "NW- FA23 - Entry Popup",
        clientUID: "4812bcb7-32f3-4732-92d1-a34659911750",
        companyID: 0,
        isActive: !0,
        lastModified: "2023-11-21T13:56:32.146Z",
        settings: {
            scrollDepth: 0,
            isTestMode: !1,
            formHTML: '\n\t\t\t\t\t\t\t<!-- Pop-up Form -->\n<!-- ltkpopup-no-scroll: centers the popup on display by preventing the page from scrolling -->\n<!-- ltkpopup-ios-fix: keeps fixed position popups like bottom banners in place in iOS -->\n<div id="ltkpopup-wrapper" class="ltkpopup-signup ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-headline" aria-describedby="ltkpopup-content-para">\n\t<!-- Main Popup Content Area -->\n\t<div id="ltkpopup-content" class="ltkpopup-signup">\n\t\t<!-- Pull in the popup container -->\n\t\t\n\t\t<div id="ltkpopup-email-form">\n\t\t\t<div class="ltkpopup-clearfix ltkpopup-split-content ltkpopup-split-above-below\n">\n\n\t\n\n<div class="ltkpopup-contain-img">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/650x320.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-mobile-hide" aria-hidden="true">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/320x235.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-desktop-hide" aria-hidden="true">\n<\/div>\n\n\n\n\t<div class="ltkpopup-contain-form">\n\n\t\t\n\t\t<h1 id="ltkpopup-headline" class="ltkpopup-headline ltkpopup-visuallyhidden">Welcome to Easy Spirit<\/h1>\n<h2 id="ltkpopup-content-para" class="ltkpopup-headline">UNLOCK 15% OFF <span class="ltkpopup-content-para">your first order when you subscribe to our email list.<\/span><\/h2>\n\n\t\t<div class="ltkpopup-form-contain">\n\t\t\t\n\n\n<div class="ltkpopup-clearfix ltkpopup-form-control">\n\n\n\t<div class="ltkpopup-error-message" aria-live="assertive" data-ltkpopup-error-for="ltkpopup-email" data-ltkpopup-message="Please enter a valid email address"><\/div>\n\t<div >\n\t\t<div class="ltkpopup-floating-label-container">\n\t\t\t<label for="ltkpopup-email" class="ltkpopup-floating-label">Enter email address<\/label>\n\t\t\t<input autofocus required type="email" id="ltkpopup-email" class="ltkpopup-email" tabindex="0" name="ltkpopup-email" placeholder="" autocomplete="email" pattern="^([a-zA-Z0-9._+!-]+[@](?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,})$" />\n\t\t<\/div>\n\t<\/div>\n\n\n\t\n\n\t<div class="ltkpopup-button-container ltkpopup-flex ltkpopup-clearfix">\n\t\t<button id="ltkpopup-submit" class="ltkpopup-subscribe" tabindex="0" type="submit"><span>ACTIVATE OFFER<\/span><\/button>\n\t<\/div>\n\n<\/div>\n\n\n\n\n<div class="ltkpopup-no-thanks" id="ltkpopup-text-btn">\n\t<button tabindex="0" class="ltkpopup-close">No, thanks<\/button>\n<\/div>\n\n\t\t<\/div>\n\n\t\t<p class="ltkpopup-content-para ltkpopup-disclaimer">All offers exclude Gift Cards and Final Sale/Clearance. Some additional product exclusions may apply per brand/season. See <a href="https://ninewest.com/policies/terms-of-service" target="_blank">Terms and Conditions<\/a> &amp; <a href="https://ninewest.com/policies/privacy-policy" target="_blank">Privacy&nbsp;Policy<\/a>.<\/p>\n\n\t<\/div>\n\n<\/div>\n\t\t<\/div>\n\n\t\t\n\n\t\t<!-- Emmet Snippets if applicable -->\n\t\t<!-- zip error dropdown checkbox radio sms-capture -->\n\n\t\t<!-- Do Not Delete. Connects the Popup to Segmentation within the Listrak platform. Input name needs to match segmentation -->\n\t\t<div class="ltkpopup-source">\n\t\t\t<input type="hidden" class="text" name="ltkSource" value="On" tabindex="-1" />\n\t\t<\/div>\n\t\t\n\n\t\t<!-- Close \'X\' Button -->\n\t\t\n\n\t<\/div>\n\t<!-- End ltkpopup-content -->\n\n<\/div>\n<!-- End ltkpopup-wrapper -->\n\n<script>\n\tvar emailVal;\n\tvar phoneVal;\n\tvar emailField = document.getElementById(\'ltkpopup-email\');\n\tif (emailField != null) {\n\t\temailField.addEventListener(\'change\', function () {\n\t\t\temailVal = this.value;\n\t\t\t_ltk.SCA.Update(\'email\', this.value);\n\t\t});\n\t}\n\tvar phoneField = document.getElementById(\'ltkpopup-phone\');\n\tif (phoneField != null) {\n\t\tphoneField.addEventListener(\'change\', function () {\n\t\t\tphoneVal = this.value;\n\t\t});\n\t}\n\tvar submitBtn = document.getElementById(\'ltkpopup-submit\');\n\tif (submitBtn != null) {\n\t\tsubmitBtn.addEventListener(\'click\', function () {\n\t\t\tvar e = jQuery("#ltkpopup-content :input");\n\t\t\tjQuery(e).each(function (e) {\n\t\t\t\tcheckInputValidity(this);\n\t\t\t\tif (jQuery(this).is(":invalid")) {\n\t\t\t\t\tthis.setAttribute("aria-describedby", this.id + "-error-message");\n\t\t\t\t} else {\n\t\t\t\t\tthis.removeAttribute("aria-describedby")\n\t\t\t\t}\n\t\t\t});\n\t\t\tsetTimeout(function () {\n\t\t\t\tif (document.querySelector(".ltkinputnotvalid") != null) {\n\t\t\t\t\tdocument.querySelector(".ltkinputnotvalid").focus();\n\t\t\t\t}\n\t\t\t}, 0);\n\t\t});\n\t}\n<\/script>\n\n<script>\n\t// Browsers\n\tvar b = document.documentElement;\n\tb.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n\tvar ua = navigator.userAgent.toLowerCase(),\n\t\tpf = navigator.platform.toLowerCase();\n\n\tfunction is(e) {\n\t\treturn ua.indexOf(e) > -1\n\t}\n\tvar browser = {\n\t\tIE: is("msie") || is("trident/7.0"),\n\t\tIE7: is("msie 7.0"),\n\t\tIE8: is("msie 8.0"),\n\t\tIE9: is("msie 9.0"),\n\t\tIE10: is("msie 10"),\n\t\tIE11: is("rv:11") && is("trident/7.0"),\n\t\tEdge: is("edge"),\n\t\tChrome: is("chrome") && !is("edge"),\n\t\tSafari: is("safari") && !is("chrome") && !is("edge"),\n\t\tFirefox: is("firefox") && !is("edge"),\n\t\tAndroidChrome: is("android") && is("chrome"),\n\t\tAndroidDefault: is("android") && !is("chrome"),\n\t\tWin7: is("windows nt 6.1"),\n\t\tWin8: is("windows nt 6.2"),\n\t\tWindows: pf.indexOf("win32") > -1,\n\t\tWebkit: is("webkit") && !is("edge"),\n\t\tIPad: is("ipad"),\n\t\tIPadChrome: is("ipad") && is("crios"),\n\t\tIPhone: is("iphone"),\n\t\tIPhoneChrome: is("iphone") && is("crios"),\n\t\tAndroid: is("android"),\n\t\tIOS: is("iphone") || is("ipad")\n\t};\n\tfor (var title in browser) {\n\t\tif (browser[title]) {\n\t\t\tdocument.getElementById("ltkpopup-content").classList.add(String(title).toLowerCase());\n\t\t}\n\t}\n\n\t// Close Function\n\tvar focused = document.activeElement;\n\tvar closeBtns = document.querySelectorAll(\'.ltkpopup-close\');\n\tfor (var i = 0; i < closeBtns.length; i++) {\n\t\tcloseBtns[i].addEventListener("click", function (e) {\n\t\t\t_ltk.Popup.close();\n\t\t\tfocused.focus();\n\t\t});\n\t}\n\n\t// Check Input Validity\n\tfunction checkInputValidity(inputEl) {\n\t\tvar ltkErrorClass = "ltkinputnotvalid";\n\t\tvar ltkErrorMessage = document.querySelector("[data-ltkpopup-error-for=\'" + inputEl.id + "\']");\n\t\tvar ltkLabel = document.querySelector("label[for=\'" + inputEl.id + "\']");\n\t\tif (ltkErrorMessage != undefined) {\n\t\t\tltkErrorMessage.innerText = "";\n\t\t\tinputEl.classList.remove(ltkErrorClass);\n\t\t\tif (ltkLabel != undefined) {\n\t\t\t\tltkLabel.classList.remove(ltkErrorClass);\n\t\t\t}\n\t\t}\n\t\tinputEl.checkValidity();\n\t\tif (!inputEl.validity.valid) {\n\t\t\tinputEl.classList.add(ltkErrorClass);\n\t\t\tif (ltkLabel != undefined) {\n\t\t\t\tltkLabel.classList.add(ltkErrorClass);\n\t\t\t}\n\t\t\tif (ltkErrorMessage != undefined) {\n\t\t\t\tltkErrorMessage.innerText = ltkErrorMessage.getAttribute("data-ltkpopup-message");\n\t\t\t}\n\t\t\treturn false;\n\t\t}\n\t\treturn true;\n\t}\n\n\t// Override close CTA focus called by onescript 2x\n\tonescriptFocus = 0;\n\twrapperFocus = function () {\t\n\t\tdocument.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n\t\tonescriptFocus ++;\n\t\tif(onescriptFocus == 1) {\n\t\t\tdocument.querySelector(\'.simpleltkmodal-wrap button\').removeEventListener(\'focus\', wrapperFocus);\n\t\t}\n\t}\n\n\t// Tab Trapping\n\tsetTimeout(function () {\n\t\tfunction triggerFocus(element) {\n\t\t\tvar eventType = "onfocusin" in element ? "focusin" : "focus",\n\t\t\t\tbubbles = "onfocusin" in element,\n\t\t\t\tevent;\n\n\t\t\tif ("createEvent" in document) {\n\t\t\t\tevent = document.createEvent("Event");\n\t\t\t\tevent.initEvent(eventType, bubbles, true);\n\t\t\t} else if ("Event" in window) {\n\t\t\t\tevent = new Event(eventType, {\n\t\t\t\t\tbubbles: bubbles,\n\t\t\t\t\tcancelable: true\n\t\t\t\t});\n\t\t\t}\n\n\t\t\telement.focus();\n\t\t\telement.dispatchEvent(event);\n\t\t}\n\t\tif (document.getElementById("ltkpopup-email") != undefined) {\n\t\t\ttriggerFocus(document.getElementById("ltkpopup-email"));\n\t\t} else if (document.getElementById("ltkpopup-phone") != undefined) {\n\t\t\ttriggerFocus(document.getElementById("ltkpopup-phone"));\n\t\t} else if (document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined && document.querySelector(\'.simpleltkmodal-wrap input\') == null && document.querySelector(\'.simpleltkmodal-wrap button\') != null) {\n\t\t\tdocument.querySelector(\'.simpleltkmodal-wrap button\').addEventListener(\'focus\', wrapperFocus);\n\t\t}\n\t}, 0);\n\n\tfunction trapTabKey(e) {\n\t\tvar t = document.activeElement,\n\t\t\ts = focusableElems.indexOf(t);\n\t\tif (9 === e.keyCode) {\n\t\t\te.preventDefault();\n\t\t\tmoveTab(s, e.shiftKey)\n\t\t}\n\t}\n\n\tfunction moveTab(index, shift) {\n\t\tvar nextTab = null;\n\t\tvar nextIndex = index;\n\t\tif (shift) {\n\t\t\tif (focusableElems[index] == firstTabStop) {\n\t\t\t\tnextTab = lastTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index - 1;\n\t\t\t\tnextTab = focusableElem[nextIndex];\n\t\t\t}\n\t\t} else {\n\t\t\tif (focusableElems[index] == lastTabStop) {\n\t\t\t\tnextTab = firstTabStop;\n\t\t\t\tnextIndex = 0;\n\t\t\t} else {\n\t\t\t\tnextIndex = index + 1;\n\t\t\t\tnextTab = focusableElems[nextIndex];\n\t\t\t}\n\t\t}\n\t\tif (nextTab.offsetParent != null) {\n\t\t\tnextTab.focus();\n\t\t} else {\n\t\t\tmoveTab(nextIndex, shift);\n\t\t}\n\t}\n\tsetTimeout(function () {\n\t\t//Do not delete - tab functionality will break\n\t\t_ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n\t}, 50);\n\tvar focusBox = document.getElementById("ltkpopup-content"),\n\t\tfocusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n\t\tfocusableElem = focusBox.querySelectorAll(focusableElemStr),\n\t\tfocusableElems = Array.prototype.slice.call(focusableElem),\n\t\tfirstTabStop = focusableElems[0],\n\t\tlastTabStop = focusableElems[focusableElems.length - 1];\n\tfocusBox.addEventListener("keydown", trapTabKey);\n\n\n\t// floating labels\n\tjQuery(\'.ltkpopup-floating-label-container :input\').each(function () {\n\t\tthis.addEventListener(\'blur\', removeFloat, false);\n\t\tif (this.hasAttribute(\'data-inputmask\') || this.id == \'ltkpopup-datepicker\') {\n\t\t\tthis.addEventListener(\'focus\', addFloat, false);\n\t\t} else {\n\t\t\tthis.addEventListener(\'click\', addFloat, false);\n\t\t\tthis.addEventListener(\'keydown\', addFloat, false);\n\t\t}\n\t});\n\n\tfunction addFloat(event) {\n\t\tjQuery(event.target).closest(".ltkpopup-floating-label-container").addClass(\'ltkpopup-floatLabel\');\n\t\tjQuery("[data-ltkpopup-error-for=\'" + event.target.id + "\']").addClass(\'ltkpopup-floatLabel\');\n\t}\n\n\tfunction removeFloat(event) {\n\t\tif (event.target.value.length == 0 && !event.target.classList.contains("ltkpopup-datepicker")) {\n\t\t\tjQuery(event.target).closest(".ltkpopup-floating-label-container").removeClass(\'ltkpopup-floatLabel\');\n\t\t\tjQuery("[data-ltkpopup-error-for=\'" + event.target.id + "\']").removeClass(\'ltkpopup-floatLabel\');\n\t\t}\n\t}\n<\/script>\n<script>\n\tif (document.querySelectorAll("[data-inputmask]").length > 0) {\n\n\t\t// Input masking for number validation - Get Jquery Input Mask from CDN and load it\n\t\tjQuery.getScript(\n\t\t\t"https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.1/jquery.inputmask.bundle.js",\n\t\t\tfunction () {\n\t\t\t\tjQuery("[data-inputmask]").each(function () {\n\t\t\t\t\t// Mask phone number input after script is loaded\n\t\t\t\t\tjQuery(this).inputmask({\n\t\t\t\t\t\tgreedy: false,\n\t\t\t\t\t\tshowMaskOnHover: false,\n\t\t\t\t\t\tdefinitions: {\n\t\t\t\t\t\t\t\'#\': {\n\t\t\t\t\t\t\t\tvalidator: "[0-9]",\n\t\t\t\t\t\t\t\tcardinality: 1\n\t\t\t\t\t\t\t}\n\t\t\t\t\t\t}\n\t\t\t\t\t});\n\t\t\t\t});\n\t\t\t});\n\t}\n<\/script>\n<script>\n\tvar datepickerField = document.querySelector("#ltkpopup-datepicker");\n\tif (datepickerField != null) {\n\t\tvar jQueryUIcss = document.createElement("link");\n\t\tjQueryUIcss.href = "https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css";\n\t\tjQueryUIcss.rel = "stylesheet";\n\t\tjQueryUIcss.addEventListener("load", function () {\n\t\t\tvar jQueryUI = document.createElement("script");\n\t\t\tjQueryUI.src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js";\n\t\t\tjQueryUI.addEventListener("load", function () {\n\t\t\t\tdatepickerField.setAttribute("readonly", "");\n\t\t\t\tjQuery(datepickerField).datepicker({\n\t\t\t\t\tchangeMonth: true,\n\t\t\t\t\tchangeYear: false,\n\t\t\t\t\tyearRange: \'-0:+0\',\n\t\t\t\t\t// use for different date format and hidden bday field\n\t\t\t\t\tdateFormat: "mm/dd",\n\t\t\t\t\taltField: "#ltkpopup-hidden-bday",\n\t\t\t\t\taltFormat: "mm/dd/1900",\n\t\t\t\t\tonClose: function (selectedDate) {\n\t\t\t\t\t\t\t\tif (selectedDate == "") {\n\t\t\t\t\t\t\t\t\tjQuery(this).closest(".ltkpopup-floating-label-container").removeClass(\'ltkpopup-floatLabel\');\n\t\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\t}\n\t\t\t\t\t});\n\n\t\t\t\tjQuery(datepickerField).focus(function () {\n\t\t\t\t\tjQuery(\'#ui-datepicker-div\').appendTo(this.parentNode);\n\t\t\t\t});\n\t\t\t});\n\t\t\tdocument.getElementById("ltkpopup-content").appendChild(jQueryUI);\n\t\t});\n\t\tdocument.getElementById("ltkpopup-content").appendChild(jQueryUIcss);\n\t}\n<\/script>\n\n\n\n\t\t\t\t\t\t',
            formCSS: '#ltkpopup-wrapper .ltkpopup-clearfix::before,\n#ltkpopup-wrapper .ltkpopup-clearfix::after {\n content: "";\n display: table;\n}\n#ltkpopup-wrapper .ltkpopup-clearfix::after {\n clear: both;\n}\n#ltkpopup-wrapper .ltkpopup-clearfix {\n zoom: 1;\n}\n.ios-only {\n position: fixed;\n}\n.ltkpopup-visuallyhidden {\n position: absolute;\n width: 1px;\n height: 1px;\n margin: -1px;\n padding: 0;\n overflow: hidden;\n clip: rect(0 0 0 0);\n border: 0;\n}\n.ltkpopup-visuallyhidden.focusable:active,\n.ltkpopup-visuallyhidden.focusable:focus {\n position: static;\n width: auto;\n height: auto;\n margin: 0;\n overflow: visible;\n clip: auto;\n}\n.ltkpopup-img-fluid {\n width: 100%;\n height: auto;\n display: block;\n}\n#ltkpopup-thanks {\n text-align: center;\n}\n#ltkpopup-thanks input {\n display: inline-block;\n}\n.ltkpopup-logo {\n display: block;\n width: 100px;\n height: auto;\n margin: 0 auto;\n}\n.ltkpopup-desktop-hide {\n display: none;\n}\n.acsb-trigger,\niframe#launcher,\n.olark-launch-button-wrapper,\n#___ratingbadge_0,\n#onetrust-banner-sdk,\n#chat-widget-container {\n z-index: 9999990 !important;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-wrapper .ltkpopup-mobile-hide {\n  display: none;\n }\n #ltkpopup-wrapper .ltkpopup-desktop-hide {\n  display: block;\n }\n #ltkpopup-wrapper .ltkpopup-logo {\n  width: 100px;\n }\n}\n#ltkpopup-overlay {\n z-index: 10000001 !important;\n position: fixed !important;\n top: 0 !important;\n bottom: 0 !important;\n width: 100% !important;\n height: 100% !important;\n background-color: #777876 !important;\n opacity: 0.5 !important;\n -webkit-transition: all 0.25s ease-in;\n transition: all 0.25s ease-in;\n}\n#ltkpopup-container {\n z-index: 10000010 !important;\n position: fixed !important;\n width: 650px !important;\n height: auto !important;\n max-height: 100%;\n top: 50% !important;\n left: 50% !important;\n margin-left: 0 !important;\n -webkit-transform: translate(-50%, -50%) !important;\n -moz-transform: translate(-50%, -50%) !important;\n -ms-transform: translate(-50%, -50%) !important;\n transform: translate(-50%, -50%) !important;\n overflow-x: hidden;\n overflow-y: auto;\n}\n#ltkpopup-container .simpleltkmodal-wrap {\n overflow: visible !important;\n}\n#ltkpopup-wrapper {\n background: transparent;\n font-size: 14px;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n -webkit-font-smoothing: subpixel-antialiased;\n position: relative;\n margin: 0 auto;\n width: 100% !important;\n}\n#ltkpopup-wrapper.no-wrap {\n white-space: nowrap;\n}\n#ltkpopup-wrapper * {\n box-sizing: border-box;\n backface-visibility: hidden !important;\n}\n#ltkpopup-content {\n font-size: 14px;\n text-align: left;\n color: #000000;\n line-height: 1.4;\n background: #fff;\n}\n#ltkpopup-content .ltkpopup-contain-form {\n padding: 16px 90px 13px;\n background-color: #f2f3f8;\n}\n#ltkpopup-sms-confirm,\n#ltkpopup-sms-no-thanks,\n#ltkpopup-sms-content {\n display: none;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-container {\n  width: 300px !important;\n }\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-container {\n  width: 320px !important;\n }\n #ltkpopup-content {\n  float: none;\n  width: 100%;\n }\n #ltkpopup-content .ltkpopup-contain-form {\n  padding: 17px 10px 9px;\n }\n}\n#ltkpopup-content .ltkpopup-split-content {\n display: -webkit-box;\n display: -moz-box;\n display: -ms-flexbox;\n display: -webkit-flex;\n display: flex;\n -webkit-align-items: center;\n -moz-align-items: center;\n -ms-align-items: center;\n align-items: center;\n}\n#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img {\n -webkit-box-flex: 0 0 350px;\n -moz-box-flex: 0 0 350px;\n -webkit-flex: 0 0 350px;\n -ms-flex: 0 0 350px;\n flex: 0 0 350px;\n line-height: 0;\n -webkit-box-ordinal-group: 1;\n -moz-box-ordinal-group: 1;\n -ms-flex-order: 1;\n -webkit-order: 1;\n order: 1;\n}\n#ltkpopup-content\n .ltkpopup-split-content\n .ltkpopup-contain-img.ltkpopup-img-right,\n#ltkpopup-content\n .ltkpopup-split-content\n .ltkpopup-contain-img.ltkpopup-img-bottom {\n -webkit-box-ordinal-group: 3;\n -moz-box-ordinal-group: 3;\n -ms-flex-order: 3;\n -webkit-order: 3;\n order: 3;\n}\n#ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form {\n max-width: 300px;\n -webkit-box-flex: 0 0 300px;\n -moz-box-flex: 0 0 300px;\n -webkit-flex: 0 0 300px;\n -ms-flex: 0 0 300px;\n flex: 0 0 300px;\n -webkit-box-ordinal-group: 2;\n -moz-box-ordinal-group: 2;\n -ms-flex-order: 2;\n -webkit-order: 2;\n order: 2;\n min-height: 325px;\n}\n#ltkpopup-content .ltkpopup-split-content.ltkpopup-split-above-below {\n flex-wrap: wrap;\n}\n#ltkpopup-content\n .ltkpopup-split-content.ltkpopup-split-above-below\n .ltkpopup-contain-form,\n#ltkpopup-content\n .ltkpopup-split-content.ltkpopup-split-above-below\n .ltkpopup-contain-img {\n max-width: 100%;\n -webkit-box-flex: 0 0 100%;\n -moz-box-flex: 0 0 100%;\n -webkit-flex: 0 0 100%;\n -ms-flex: 0 0 100%;\n flex: 0 0 100%;\n}\n#ltkpopup-content.safari,\n#ltkpopup-content.ipad {\n overflow-x: hidden;\n overflow-y: hidden;\n}\n#ltkpopup-content.safari\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-img,\n#ltkpopup-content.safari\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-form,\n#ltkpopup-content.ipad\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-img,\n#ltkpopup-content.ipad\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-form {\n position: relative;\n left: -2px;\n}\n#ltkpopup-content.safari\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-img.ltkpopup-img-right\n img,\n#ltkpopup-content.safari\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-form.ltkpopup-img-right\n img,\n#ltkpopup-content.ipad\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-img.ltkpopup-img-right\n img,\n#ltkpopup-content.ipad\n .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n .ltkpopup-contain-form.ltkpopup-img-right\n img {\n position: relative;\n right: -2px;\n left: auto;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img {\n  display: none;\n }\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-content .ltkpopup-split-content {\n  display: block;\n }\n #ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-form {\n  max-width: none;\n  min-height: 315px;\n }\n #ltkpopup-content .ltkpopup-split-content .ltkpopup-contain-img {\n  display: block;\n  width: 100%;\n }\n #ltkpopup-content.safari\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-img,\n #ltkpopup-content.safari\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-form,\n #ltkpopup-content.ipad\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-img,\n #ltkpopup-content.ipad\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-form {\n  left: 0;\n }\n #ltkpopup-content.safari\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-img.ltkpopup-img-right\n  img,\n #ltkpopup-content.safari\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-form.ltkpopup-img-right\n  img,\n #ltkpopup-content.ipad\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-img.ltkpopup-img-right\n  img,\n #ltkpopup-content.ipad\n  .ltkpopup-split-content:not(.ltkpopup-split-above-below)\n  .ltkpopup-contain-form.ltkpopup-img-right\n  img {\n  right: 0;\n }\n}\n#ltkpopup-close-button {\n position: absolute;\n right: 12px;\n top: 12px;\n margin: 0px;\n z-index: 10;\n}\n#ltkpopup-close-button a {\n display: block;\n width: 20px;\n height: 20px;\n cursor: pointer;\n}\n#ltkpopup-close-button a svg {\n width: 20px;\n height: 20px;\n position: relative;\n display: block;\n overflow: visible;\n stroke: #a9a9a9;\n stroke-width: 4px;\n -webkit-transition: all 0.25s linear;\n transition: all 0.25s linear;\n}\n#ltkpopup-close-button a:hover svg {\n stroke: #000;\n}\n#ltkpopup-close-button a:focus svg {\n stroke: #000;\n}\n#ltkpopup-close-button.ltkpopup-circle-close a {\n width: 35px;\n height: 35px;\n background: #d3d3d3;\n border-radius: 50%;\n padding: 10px;\n border: 1px solid #777876;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-close-button {\n  right: 12px;\n  top: 12px;\n }\n #ltkpopup-close-button a {\n  width: 20px;\n  height: 20px;\n }\n #ltkpopup-close-button a svg {\n  width: 20px;\n  height: 20px;\n  stroke: #a9a9a9;\n  stroke-width: 4px;\n }\n #ltkpopup-close-button a:hover svg {\n  stroke: #000;\n }\n #ltkpopup-close-button a:focus svg {\n  stroke: #000;\n }\n}\n#ltkpopup-content h1,\n#ltkpopup-content h2,\n#ltkpopup-content h3,\n#ltkpopup-content h4,\n#ltkpopup-content h5,\n#ltkpopup-content .ltkpopup-headline,\n#ltkpopup-content .ltkpopup-subheadline {\n margin: 0;\n padding: 0;\n text-align: center;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n}\n#ltkpopup-content h1,\n#ltkpopup-content .ltkpopup-headline {\n font-weight: 500;\n font-size: 40px;\n line-height: 56px;\n color: #000000;\n letter-spacing: 0;\n}\n#ltkpopup-content h2,\n#ltkpopup-content .ltkpopup-subheadline {\n font-weight: 400;\n font-size: 20px;\n line-height: 28px;\n color: #000000;\n letter-spacing: 0;\n}\n\n#ltkpopup-content h2,\n#ltkpopup-content .ltkpopup-subheadline2 {\n font-weight: 400;\n font-size: 14px;\n line-height: 28px;\n color: #000000;\n letter-spacing: 0;\n}\n\n#ltkpopup-content p,\n#ltkpopup-content .ltkpopup-content-para {\n margin: 0px auto 14px;\n font-size: 14px;\n line-height: 21px;\n color: #000000;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n letter-spacing: 0;\n text-align: center;\n display: block;\n font-weight: 400;\n}\n#ltkpopup-content p.ltkpopup-disclaimer,\n#ltkpopup-content p.ltkpopup-sms-disclaimer,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer {\n font-size: 10px;\n line-height: 16px;\n text-align: center;\n margin: 8px auto 0;\n color: #000000;\n}\n#ltkpopup-content p.ltkpopup-disclaimer a,\n#ltkpopup-content p.ltkpopup-sms-disclaimer a,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a {\n color: inherit;\n text-decoration: underline;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n letter-spacing: 0;\n}\n#ltkpopup-content p.ltkpopup-disclaimer a:hover,\n#ltkpopup-content p.ltkpopup-disclaimer a:focus,\n#ltkpopup-content p.ltkpopup-sms-disclaimer a:hover,\n#ltkpopup-content p.ltkpopup-sms-disclaimer a:focus,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:hover,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer a:focus,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:hover,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer a:focus {\n text-decoration: none;\n}\n#ltkpopup-content p.ltkpopup-disclaimer span,\n#ltkpopup-content p.ltkpopup-sms-disclaimer span,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer span,\n#ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer span {\n font-weight: 700;\n}\n#ltkpopup-content .ltkpopup-coupon {\n font-size: 28px;\n line-height: 23px;\n width: 170px;\n margin: 20px auto;\n display: block;\n}\n#ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-form .ltkpopup-coupon {\n margin: 11px 140px 15px;\n}\n#ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-form p.ltkpopup-sms-disclaimer,\n#ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-form\n .ltkpopup-content-para.ltkpopup-sms-disclaimer {\n margin: 5px -70px 0;\n}\n#ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-confirm .ltkpopup-headline {\n margin-top: 20px;\n}\n#ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-confirm p.ltkpopup-disclaimer,\n#ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-confirm\n .ltkpopup-content-para.ltkpopup-disclaimer {\n margin: 37px auto 0;\n}\n#ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-no-thanks .ltkpopup-headline {\n margin-top: 37px;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-content h1,\n #ltkpopup-content .ltkpopup-headline {\n  font-size: 28px;\n  line-height: 39px;\n }\n #ltkpopup-content h2,\n #ltkpopup-content .ltkpopup-subheadline {\n  font-size: 20px;\n  line-height: 28px;\n }\n #ltkpopup-content p,\n #ltkpopup-content .ltkpopup-content-para {\n  font-size: 14px;\n  line-height: 21px;\n  margin: 4px 20px 0;\n }\n #ltkpopup-content p.ltkpopup-disclaimer,\n #ltkpopup-content p.ltkpopup-sms-disclaimer,\n #ltkpopup-content .ltkpopup-content-para.ltkpopup-disclaimer,\n #ltkpopup-content .ltkpopup-content-para.ltkpopup-sms-disclaimer {\n  font-size: 10px;\n  line-height: 16px;\n  margin: 7px auto 0;\n }\n #ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-form .ltkpopup-coupon {\n  margin: 8px auto 12px 70px\n }\n #ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-form\n  .ltkpopup-subheadline.ltkpopup-mobile-smaller {\n  font-size: 14px;\n  line-height: 21px;\n }\n #ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-form p.ltkpopup-sms-disclaimer,\n #ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-form\n  .ltkpopup-content-para.ltkpopup-sms-disclaimer {\n  margin: 17px auto 0;\n }\n #ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-confirm p,\n #ltkpopup-content.ltkpopup-confirm.ltkpopup-sms-confirm\n  .ltkpopup-content-para {\n  margin-bottom: 20px;\n }\n}\n@font-face {\n src: url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-regular.eot")\n   format("embedded-opentype"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-regular.woff2")\n   format("woff2"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-regular.woff")\n   format("woff"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-regular.ttf")\n   format("truetype"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-regular.svg")\n   format("svg");\n font-family: "ltk-FontAwesome";\n font-weight: 400;\n}\n@font-face {\n src: url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-solid.eot")\n   format("embedded-opentype"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-solid.woff2")\n   format("woff2"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-solid.woff")\n   format("woff"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-solid.ttf")\n   format("truetype"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-solid.svg")\n   format("svg");\n font-family: "ltk-FontAwesome";\n font-weight: 900;\n}\n@font-face {\n src: url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-brands.eot")\n   format("embedded-opentype"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-brands.woff2")\n   format("woff2"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-brands.woff")\n   format("woff"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-brands.ttf")\n   format("truetype"),\n  url("https://mediacdn.espssl.com/1/Shared/Templates/Popup/Fonts/FontAwesome6/FA-brands.svg")\n   format("svg");\n font-family: "ltk-FontAwesome";\n font-weight: 400;\n font-style: oblique;\n}\n\n#ltkpopup-content input[type="text"],\n#ltkpopup-content input[type="email"],\n#ltkpopup-content input[type="number"],\n#ltkpopup-content input[type="tel"] {\n display: block;\n width: 100%;\n height: 40px;\n padding: 0 15px;\n margin: 0 auto;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n font-size: 15px;\n font-weight: 400;\n text-align: center;\n color: #000000;\n line-height: normal;\n background-color: #fff;\n border: 1.5px solid #777876;\n border-radius: 0px !important;\n -webkit-transition: all 0.11s linear;\n transition: all 0.11s linear;\n -webkit-appearance: none;\n -moz-appearance: none;\n appearance: none;\n letter-spacing: 0;\n}\n#ltkpopup-content input[type="text"]:focus,\n#ltkpopup-content input[type="email"]:focus,\n#ltkpopup-content input[type="number"]:focus,\n#ltkpopup-content input[type="tel"]:focus {\n outline: none;\n border-color: #000000;\n}\n#ltkpopup-content .ltkpopup-form-control {\n position: relative;\n max-width: 360px;\n margin: 0 auto;\n}\n#ltkpopup-content input::-webkit-input-placeholder {\n font-weight: inherit;\n color: #000000;\n font-family: inherit;\n opacity: 1;\n}\n#ltkpopup-content input::-moz-placeholder {\n font-weight: inherit;\n color: #000000;\n font-family: inherit;\n opacity: 1;\n}\n#ltkpopup-content input:-ms-input-placeholder {\n font-weight: inherit;\n color: #000000;\n font-family: inherit;\n opacity: 1;\n}\n#ltkpopup-content input::-ms-clear {\n display: none;\n width: 0;\n height: 0;\n opacity: 0;\n}\n#ltkpopup-content .ltk-floating-input {\n width: 250px;\n float: left;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-content input[type="text"],\n #ltkpopup-content input[type="email"],\n #ltkpopup-content input[type="number"],\n #ltkpopup-content input[type="tel"] {\n  float: none;\n  width: 100%;\n  font-size: 15px;\n  height: 40px;\n }\n #ltkpopup-content .ltkpopup-form-control {\n  max-width: 259px;\n }\n #ltkpopup-content .ltk-floating-input {\n  width: 100%;\n }\n}\n#ltkpopup-content label {\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n font-size: 15px;\n font-weight: 400;\n line-height: normal;\n color: #000000;\n letter-spacing: 0;\n display: block;\n width: 100%;\n text-align: center;\n padding: 0 15px;\n}\n#ltkpopup-content .ltkpopup-floating-label-container {\n position: relative;\n}\n#ltkpopup-content\n .ltkpopup-floating-label-container\n label.ltkpopup-floating-label {\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n height: 36px;\n line-height: 36px;\n position: absolute;\n top: 2.5px;\n z-index: 6;\n transition: height 120ms ease-out, line-height 120ms ease-out,\n  font-size 120ms ease-out;\n pointer-events: none;\n color: #000000;\n white-space: nowrap;\n}\n#ltkpopup-content .ltkpopup-floating-label-container input {\n padding-top: 10px;\n}\n#ltkpopup-content\n .ltkpopup-floating-label-container.ltkpopup-floatLabel\n label.ltkpopup-floating-label {\n font-size: 10px;\n line-height: 10px;\n height: 10px;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-content label {\n  font-size: 15px;\n }\n #ltkpopup-content\n  .ltkpopup-floating-label-container\n  label.ltkpopup-floating-label {\n  height: 36px;\n  line-height: 36px;\n }\n #ltkpopup-content .ltkpopup-floating-label-container input {\n  padding-top: 10px;\n }\n #ltkpopup-content\n  .ltkpopup-floating-label-container.ltkpopup-floatLabel\n  label.ltkpopup-floating-label {\n  font-size: 10px;\n  line-height: 10px;\n  height: 10px;\n }\n}\n#ltkpopup-content input[type="checkbox"],\n#ltkpopup-content input[type="radio"] {\n position: absolute;\n overflow: hidden;\n clip: rect(0 0 0 0);\n height: 1px;\n width: 1px;\n margin: -1px;\n padding: 0;\n border: 0;\n}\n#ltkpopup-content fieldset.ltkpopup-options {\n border: none;\n margin: 10px auto;\n padding: 0;\n width: 100%;\n}\n#ltkpopup-content legend,\n#ltkpopup-content .ltkpopup-legend {\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n font-weight: 700;\n font-size: 14px;\n line-height: 21px;\n text-align: center;\n color: #000000;\n white-space: normal;\n margin: 0 auto;\n}\n#ltkpopup-content legend span,\n#ltkpopup-content .ltkpopup-legend span {\n font-weight: 400;\n font-size: 10px;\n line-height: 16px;\n color: #000000;\n display: block;\n}\n#ltkpopup-content .ltkpopup-checkbox,\n#ltkpopup-content .ltkpopup-radio {\n float: left;\n width: 50%;\n}\n#ltkpopup-content .ltkpopup-checkbox label,\n#ltkpopup-content .ltkpopup-radio label {\n display: block;\n position: relative;\n cursor: pointer;\n font-size: 14px;\n margin-top: 15px;\n font-weight: 400;\n}\n#ltkpopup-content .ltkpopup-checkbox label:before,\n#ltkpopup-content .ltkpopup-radio label:before {\n position: absolute;\n display: block;\n float: left;\n text-align: center;\n font-family: "ltk-FontAwesome";\n font-weight: 400;\n font-size: 14px;\n color: #d3d3d3;\n}\n#ltkpopup-content .ltkpopup-checkbox label span,\n#ltkpopup-content .ltkpopup-radio label span {\n display: block;\n padding: 0 0 0 25px;\n line-height: 21px;\n}\n#ltkpopup-content .ltkpopup-checkbox label:before {\n content: "";\n width: 14px;\n height: 14px;\n border: 1px solid #777876;\n}\n#ltkpopup-content .ltkpopup-checkbox input:checked + label::before {\n content: "\\f00c";\n color: #000000;\n font-size: 14px;\n line-height: 14px;\n font-family: "ltk-FontAwesome";\n font-weight: 900;\n}\n#ltkpopup-content .ltkpopup-checkbox input:focus + label::before,\n#ltkpopup-content .ltkpopup-checkbox input:hover + label::before {\n border-color: #000000;\n}\n#ltkpopup-content .ltkpopup-checkbox input:checked + label:hover::before {\n opacity: 0.7;\n}\n#ltkpopup-content .ltkpopup-checkbox input:checked:focus + label:hover::before {\n opacity: 1;\n}\n#ltkpopup-content .ltkpopup-radio label::before {\n content: "\\f111";\n}\n#ltkpopup-content .ltkpopup-radio input:checked ~ label::before {\n color: #000;\n content: "\\f192";\n}\n#ltkpopup-content .ltkpopup-radio input:focus + label::before,\n#ltkpopup-content .ltkpopup-radio input:hover + label::before {\n color: #000;\n}\n#ltkpopup-content .dropdown {\n position: relative;\n width: 100%;\n height: 40px;\n margin: 10px 0;\n padding: 0;\n font-size: 14px;\n font-weight: 400;\n text-overflow: ellipsis;\n border-radius: 0 !important;\n cursor: pointer;\n}\n#ltkpopup-content .dropdown select {\n width: 100%;\n height: 100%;\n padding: 0 10px;\n z-index: 1;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n font-size: 14px;\n font-weight: 400;\n color: #000000;\n text-indent: 0 !important;\n background: #fff;\n border: 1px solid #777876;\n border-radius: 0;\n cursor: pointer;\n -webkit-appearance: none !important;\n -moz-appearance: none !important;\n appearance: none !important;\n}\n#ltkpopup-content .dropdown select:focus {\n border-color: #000000;\n outline: none;\n}\n#ltkpopup-content .dropdown::before {\n position: absolute;\n display: block;\n right: 10px;\n top: 50%;\n margin-top: -10px;\n z-index: 2;\n font-size: 14px;\n content: "\\f0d7";\n color: #000000;\n pointer-events: none;\n -webkit-transition: all 0.25s linear;\n transition: all 0.25s linear;\n font-family: "ltk-FontAwesome";\n font-weight: 400;\n}\n#ltkpopup-content .dropdown select::-ms-expand {\n display: none !important;\n}\n#ltkpopup-content input.ltkinputnotvalid,\n#ltkpopup-content div.dropdown.ltk-select-notvalid,\n#ltkpopup-content div.dropdown select.ltkinputnotvalid {\n border-color: red;\n}\n#ltkpopup-content input.ltkinputnotvalid:focus,\n#ltkpopup-content div.dropdown.ltk-select-notvalid:focus,\n#ltkpopup-content div.dropdown select.ltkinputnotvalid:focus {\n border-color: red;\n}\n#ltkpopup-content input.ltkinputnotvalid::-webkit-input-placeholder {\n color: red;\n}\n#ltkpopup-content input.ltkinputnotvalid::-moz-placeholder {\n color: red;\n}\n#ltkpopup-content input.ltkinputnotvalid:-ms-input-placeholder {\n color: red;\n}\n#ltkpopup-content label.ltkinputnotvalid,\n#ltkpopup-content label.ltkpopup-floating-label.ltkinputnotvalid {\n color: red;\n}\n#ltkpopup-content .ltkpopup-error-message {\n display: block;\n height: 20px;\n color: red;\n text-align: center;\n line-height: 20px;\n width: 100%;\n font-size: 14px;\n}\n#ltkpopup-content .ltkpopup-error-message.ltkpopup-floating-error {\n position: absolute;\n left: 1.5px;\n top: 1.5px;\n z-index: 7;\n width: calc(100% - (3px));\n white-space: nowrap;\n transition: 0.25s;\n pointer-events: none;\n line-height: 37px;\n height: 37px;\n background-color: #fff;\n}\n#ltkpopup-content\n .ltkpopup-error-message.ltkpopup-floating-error.ltkpopup-floatLabel {\n height: 10px;\n line-height: 10px;\n font-size: 10px;\n}\n#ltkpopup-content .ltkpopup-error-message:empty {\n visibility: hidden;\n}\n#ltkpopup-content\n .ltkpopup-float-fields\n .ltkpopup-error-message.ltkpopup-floating-error {\n width: 247px;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-content .ltkpopup-error-message {\n  line-height: 18px;\n  font-size: 14px;\n  height: 18px;\n }\n #ltkpopup-content .ltkpopup-error-message.ltkpopup-floating-error {\n  line-height: 37px;\n  height: 37px;\n }\n}\n#ltkpopup-content .ltkpopup-button-container {\n position: relative;\n width: 100%;\n overflow: hidden;\n}\n#ltkpopup-content .ltkpopup-subscribe,\n#ltkpopup-content .ltkpopup-close-button,\n#ltkpopup-content .ltkpopup-faux-subscribe,\n#ltkpopup-content .ltkpopup-sms-link {\n display: block;\n position: relative;\n width: 100%;\n margin: 10px auto 17px;\n padding: 0 20px;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n font-size: 15px;\n font-weight: 400;\n color: #ffffff;\n height: 40px;\n text-decoration: none;\n background-color: #000000;\n border: 1px solid #000000;\n border-radius: 0px !important;\n box-shadow: none !important;\n cursor: pointer;\n outline: none;\n -webkit-appearance: none !important;\n -moz-appearance: none !important;\n appearance: none !important;\n -webkit-transition: all 0.25s linear;\n transition: all 0.25s linear;\n transition: 0.25s;\n overflow: hidden;\n letter-spacing: 0;\n text-align: center;\n line-height: 40px;\n}\n#ltkpopup-content .ltkpopup-subscribe span,\n#ltkpopup-content .ltkpopup-close-button span,\n#ltkpopup-content .ltkpopup-faux-subscribe span,\n#ltkpopup-content .ltkpopup-sms-link span {\n position: relative;\n z-index: 1;\n}\n#ltkpopup-content .ltkpopup-subscribe:hover,\n#ltkpopup-content .ltkpopup-close-button:hover,\n#ltkpopup-content .ltkpopup-faux-subscribe:hover,\n#ltkpopup-content .ltkpopup-sms-link:hover {\n color: #fff;\n background-color: #777777;\n border-color: #777777;\n}\n#ltkpopup-content .ltkpopup-subscribe:focus,\n#ltkpopup-content .ltkpopup-close-button:focus,\n#ltkpopup-content .ltkpopup-faux-subscribe:focus,\n#ltkpopup-content .ltkpopup-sms-link:focus {\n color: #fff;\n background-color: #777777;\n border-color: #777777;\n transition: 0s;\n}\n#ltkpopup-content .ltkpopup-faux-subscribe {\n margin: 7px auto 0;\n}\n#ltkpopup-content .ltkpopup-sms-link {\n padding: 0 0 0 0;\n height: 40px;\n line-height: 21px;\n background: url("") no-repeat #000000 left 30px top 22px;\n background-size: 41px auto;\n}\n#ltkpopup-content .ltkpopup-sms-link > span {\n display: block;\n font-weight: 300;\n text-align: center;\n}\n#ltkpopup-content .ltkpopup-sms-link .ltkpopup-shortcode {\n font-style: italic;\n font-weight: 700;\n}\n#ltkpopup-content .ltkpopup-close-button {\n float: none;\n margin: 10px auto 17px;\n max-width: 360px;\n}\n#ltkpopup-content .ltkpopup-no-thanks {\n float: none;\n width: 100%;\n text-align: center;\n}\n#ltkpopup-content .ltkpopup-no-thanks span {\n font-size: 14px;\n line-height: 20px;\n color: #000000;\n}\n#ltkpopup-content .ltkpopup-no-thanks a,\n#ltkpopup-content .ltkpopup-no-thanks button {\n background: none;\n border: none;\n display: inline-block;\n padding: 10px 0;\n font-size: 14px;\n line-height: 20px;\n font-weight: 400;\n color: #000000;\n text-decoration: underline;\n -webkit-transition: all 0.25s linear;\n transition: all 0.25s linear;\n cursor: pointer;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n letter-spacing: 0;\n}\n#ltkpopup-content .ltkpopup-no-thanks a:hover,\n#ltkpopup-content .ltkpopup-no-thanks a:focus,\n#ltkpopup-content .ltkpopup-no-thanks button:hover,\n#ltkpopup-content .ltkpopup-no-thanks button:focus {\n text-decoration: none;\n}\n#ltkpopup-content .ltkpopup-float-fields {\n width: 350px;\n margin: 0 auto;\n}\n#ltkpopup-content .ltkpopup-float-fields .ltk-floating-button {\n width: 100px;\n float: left;\n}\n#ltkpopup-content\n .ltkpopup-float-fields\n .ltk-floating-button\n .ltkpopup-subscribe,\n#ltkpopup-content\n .ltkpopup-float-fields\n .ltk-floating-button\n .ltkpopup-faux-subscribe {\n margin: 0 auto;\n}\n@media only screen and (min-width: 1px) and (max-width: 660px) {\n #ltkpopup-content .ltkpopup-subscribe,\n #ltkpopup-content .ltkpopup-close-button,\n #ltkpopup-content .ltkpopup-faux-subscribe,\n #ltkpopup-content .ltkpopup-sms-link {\n  font-size: 15px;\n  margin: 10px auto 3px;\n  height: 40px;\n  line-height: 40px;\n }\n #ltkpopup-content .ltkpopup-faux-subscribe,\n #ltkpopup-content .ltkpopup-sms-link {\n  margin: 16px auto 2px;\n }\n #ltkpopup-content .ltkpopup-close-button {\n  float: none;\n  margin: 10px auto 3px;\n  max-width: 259px;\n }\n #ltkpopup-content .ltkpopup-no-thanks a,\n #ltkpopup-content .ltkpopup-no-thanks button {\n  font-size: 14px;\n  line-height: 20px;\n }\n #ltkpopup-content .ltkpopup-no-thanks a:focus-visible,\n #ltkpopup-content .ltkpopup-no-thanks button:focus-visible {\n  outline: none;\n }\n #ltkpopup-content .ltkpopup-float-fields {\n  width: 100%;\n }\n #ltkpopup-content .ltkpopup-float-fields .ltk-floating-button {\n  width: 100%;\n }\n #ltkpopup-content\n  .ltkpopup-float-fields\n  .ltk-floating-button\n  .ltkpopup-subscribe {\n  margin: 10px auto 3px;\n }\n #ltkpopup-content\n  .ltkpopup-float-fields\n  .ltk-floating-button\n  .ltkpopup-faux-subscribe {\n  margin: 16px auto 2px;\n }\n}\n#ltkpopup-content .ltkpopup-datepicker {\n background-image: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNSIgaGVpZ2h0PSIxNy4xNDMiIHZpZXdCb3g9IjAgMCAxNSAxNy4xNDMiPjxwYXRoIGlkPSJJY29uX2F3ZXNvbWUtY2FsZW5kYXItYWx0IiBkYXRhLW5hbWU9Ikljb24gYXdlc29tZS1jYWxlbmRhci1hbHQiIGQ9Ik0wLDE1LjUzNmExLjYwOCwxLjYwOCwwLDAsMCwxLjYwNywxLjYwN0gxMy4zOTNBMS42MDgsMS42MDgsMCwwLDAsMTUsMTUuNTM2VjYuNDI5SDBaTTEwLjcxNCw4Ljk3M2EuNC40LDAsMCwxLC40LS40aDEuMzM5YS40LjQsMCwwLDEsLjQuNHYxLjMzOWEuNC40LDAsMCwxLS40LjRIMTEuMTE2YS40LjQsMCwwLDEtLjQtLjRabTAsNC4yODZhLjQuNCwwLDAsMSwuNC0uNGgxLjMzOWEuNC40LDAsMCwxLC40LjRWMTQuNmEuNC40LDAsMCwxLS40LjRIMTEuMTE2YS40LjQsMCwwLDEtLjQtLjRaTTYuNDI5LDguOTczYS40LjQsMCwwLDEsLjQtLjRIOC4xN2EuNC40LDAsMCwxLC40LjR2MS4zMzlhLjQuNCwwLDAsMS0uNC40SDYuODNhLjQuNCwwLDAsMS0uNC0uNFptMCw0LjI4NmEuNC40LDAsMCwxLC40LS40SDguMTdhLjQuNCwwLDAsMSwuNC40VjE0LjZhLjQuNCwwLDAsMS0uNC40SDYuODNhLjQuNCwwLDAsMS0uNC0uNFpNMi4xNDMsOC45NzNhLjQuNCwwLDAsMSwuNC0uNEgzLjg4NGEuNC40LDAsMCwxLC40LjR2MS4zMzlhLjQuNCwwLDAsMS0uNC40SDIuNTQ1YS40LjQsMCwwLDEtLjQtLjRabTAsNC4yODZhLjQuNCwwLDAsMSwuNC0uNEgzLjg4NGEuNC40LDAsMCwxLC40LjRWMTQuNmEuNC40LDAsMCwxLS40LjRIMi41NDVhLjQuNCwwLDAsMS0uNC0uNFpNMTMuMzkzLDIuMTQzSDExLjc4NlYuNTM2QS41MzcuNTM3LDAsMCwwLDExLjI1LDBIMTAuMTc5YS41MzcuNTM3LDAsMCwwLS41MzYuNTM2VjIuMTQzSDUuMzU3Vi41MzZBLjUzNy41MzcsMCwwLDAsNC44MjEsMEgzLjc1YS41MzcuNTM3LDAsMCwwLS41MzYuNTM2VjIuMTQzSDEuNjA3QTEuNjA4LDEuNjA4LDAsMCwwLDAsMy43NVY1LjM1N0gxNVYzLjc1QTEuNjA4LDEuNjA4LDAsMCwwLDEzLjM5MywyLjE0M1oiIGZpbGw9IiMzMyIvPjwvc3ZnPg==");\n background-size: auto;\n background-position: right 10px center;\n background-repeat: no-repeat;\n box-shadow: none !important;\n}\n#ltkpopup-content span.ui-datepicker-year {\n display: none;\n}\n#ltkpopup-content .ui-widget {\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n font-weight: 400;\n text-transform: uppercase;\n}\n#ltkpopup-content #ui-datepicker-div {\n z-index: 1001000 !important;\n position: fixed !important;\n top: 50% !important;\n left: 50% !important;\n margin-left: 0 !important;\n -webkit-transform: translate(-50%, -50%) !important;\n -moz-transform: translate(-50%, -50%) !important;\n -ms-transform: translate(-50%, -50%) !important;\n transform: translate(-50%, -50%) !important;\n -webkit-box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.09);\n -moz-box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.09);\n box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.09);\n}\n#ltkpopup-content .ui-datepicker {\n padding: 0;\n}\n#ltkpopup-content .ui-widget.ui-widget-content {\n border-width: 0px;\n color: #777876 !important;\n}\n#ltkpopup-content .ui-corner-all,\n#ltkpopup-content .ui-corner-bottom,\n#ltkpopup-content .ui-corner-right,\n#ltkpopup-content .ui-corner-br,\n#ltkpopup-content .ui-corner-left,\n#ltkpopup-content .ui-corner-bl,\n#ltkpopup-content .ui-corner-top,\n#ltkpopup-content .ui-corner-tr,\n#ltkpopup-content .ui-corner-tl {\n border-radius: 0;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-header {\n background-color: #000000;\n color: #fff;\n padding: 9px 23px;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n border-width: 0;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-title {\n text-align: left;\n margin: 0;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-title select {\n -webkit-appearance: none;\n -moz-appearance: none;\n appearance: none;\n background: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNCIgaGVpZ2h0PSI4LjAwNCIgdmlld0JveD0iMCAwIDE0IDguMDA0Ij48cGF0aCBpZD0iSWNvbl9pb25pYy1pb3MtYXJyb3ctYmFjayIgZGF0YS1uYW1lPSJJY29uIGlvbmljLWlvcy1hcnJvdy1iYWNrIiBkPSJNMTYuODQyLDEzLjE5MiwxMS41NDQsNy45YTEsMSwwLDAsMSwxLjQxNy0xLjQxM2w2LDZhMSwxLDAsMCwxLC4wMjksMS4zOEwxMi45NjYsMTkuOWExLDEsMCwwLDEtMS40MTctMS40MTNaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgyMC4xOTQgLTExLjI1MSkgcm90YXRlKDkwKSIgZmlsbD0iI2ZmZiIvPjwvc3ZnPg==")\n  no-repeat #777876;\n background-position: right 7px center;\n background-size: 10px auto;\n color: #fff;\n border-width: 0px;\n width: auto;\n padding-right: 24px;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-title select::-ms-expand {\n display: none;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-prev,\n#ltkpopup-content .ui-datepicker .ui-datepicker-next {\n top: 50%;\n transform: translate(0, -50%);\n width: 8px;\n height: 14px;\n cursor: pointer;\n color: #fff;\n}\n#ltkpopup-content\n .ui-datepicker\n .ui-datepicker-prev.ui-datepicker-next-hover.ui-state-hover,\n#ltkpopup-content\n .ui-datepicker\n .ui-datepicker-prev.ui-datepicker-prev-hover.ui-state-hover,\n#ltkpopup-content\n .ui-datepicker\n .ui-datepicker-next.ui-datepicker-next-hover.ui-state-hover,\n#ltkpopup-content\n .ui-datepicker\n .ui-datepicker-next.ui-datepicker-prev-hover.ui-state-hover {\n border-width: 0;\n width: 10px;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-next {\n right: 26px;\n}\n#ltkpopup-content\n .ui-datepicker\n .ui-datepicker-next.ui-datepicker-next-hover.ui-state-hover {\n right: 24px;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-prev {\n transform: translate(0, -50%) rotate(90deg);\n right: 84px;\n left: auto;\n}\n#ltkpopup-content .ui-datepicker .ui-datepicker-next {\n transform: translate(0, -50%) rotate(270deg);\n}\n#ltkpopup-content .ui-widget-header .ui-icon {\n background: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNCIgaGVpZ2h0PSI4LjAwNCIgdmlld0JveD0iMCAwIDE0IDguMDA0Ij48cGF0aCBpZD0iSWNvbl9pb25pYy1pb3MtYXJyb3ctYmFjayIgZGF0YS1uYW1lPSJJY29uIGlvbmljLWlvcy1hcnJvdy1iYWNrIiBkPSJNMTYuODQyLDEzLjE5MiwxMS41NDQsNy45YTEsMSwwLDAsMSwxLjQxNy0xLjQxM2w2LDZhMSwxLDAsMCwxLC4wMjksMS4zOEwxMi45NjYsMTkuOWExLDEsMCwwLDEtMS40MTctMS40MTNaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgyMC4xOTQgLTExLjI1MSkgcm90YXRlKDkwKSIgZmlsbD0iI2ZmZiIvPjwvc3ZnPg==")\n  no-repeat #777876;\n background-position: center;\n}\n#ltkpopup-content .ui-datepicker table {\n font-size: 14px;\n margin: 0;\n}\n#ltkpopup-content .ui-datepicker th {\n background-color: #a9a9a9;\n color: #fff;\n font-weight: 400;\n padding: 0;\n height: 35px;\n line-height: 35px;\n}\n#ltkpopup-content .ui-datepicker td span,\n#ltkpopup-content .ui-datepicker td a {\n text-align: center;\n padding: 8px 0;\n}\n#ltkpopup-content .ui-state-default,\n#ltkpopup-content .ui-widget-content .ui-state-default,\n#ltkpopup-content .ui-widget-header .ui-state-default,\n#ltkpopup-content .ui-button,\n#ltkpopup-content html .ui-button.ui-state-disabled:hover,\n#ltkpopup-content html .ui-button.ui-state-disabled:active {\n border: 2px solid transparent;\n background: transparent;\n color: inherit;\n}\n#ltkpopup-content .ui-state-highlight,\n#ltkpopup-content .ui-widget-content .ui-state-highlight,\n#ltkpopup-content .ui-widget-header .ui-state-highlight {\n border: 2px solid #a9a9a9;\n background: #fff;\n color: inherit;\n}\n#ltkpopup-content .ui-state-active,\n#ltkpopup-content .ui-widget-content .ui-state-active,\n#ltkpopup-content .ui-widget-header .ui-state-active,\n#ltkpopup-content a.ui-button:active,\n#ltkpopup-content .ui-button:active,\n#ltkpopup-content .ui-button.ui-state-active:hover {\n border: 2px solid #a9a9a9;\n background: #a9a9a9;\n color: #fff;\n}\n#ltkpopup-content .ui-state-hover,\n#ltkpopup-content .ui-widget-content .ui-state-hover,\n#ltkpopup-content .ui-widget-header .ui-state-hover,\n#ltkpopup-content .ui-state-focus,\n#ltkpopup-content .ui-widget-content .ui-state-focus,\n#ltkpopup-content .ui-widget-header .ui-state-focus,\n#ltkpopup-content .ui-button:hover,\n#ltkpopup-content .ui-button:focus {\n border: 2px solid transparent;\n background: #d3d3d3;\n color: inherit;\n}\n#ltkpopup-content .ui-datepicker-buttonpane {\n text-align: center;\n margin: 0;\n border: 0;\n}\n#ltkpopup-content .ui-datepicker-buttonpane button {\n float: none;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n font-weight: 400;\n font-size: 12px;\n margin: 0;\n padding: 0;\n}\n#ltkpopup-content .ui-datepicker-buttonpane button[data-handler="today"] {\n display: none;\n}\n#ltkpopup-web-push-overlay {\n width: 100%;\n height: 100%;\n position: fixed;\n top: 0;\n left: 0;\n display: none;\n transition: opacity 0.25s ease-in-out;\n}\n#ltkpopup-web-push-overlay.ltkpopup-overlay-show {\n display: block;\n}\n#ltkpopup-web-push-overlay .ltkpopup-web-push-content {\n width: 100%;\n margin-top: 100px;\n font-family: FuturaLTPro-Heavy,Sans-Serif!important;\n position: relative;\n}\n#ltkpopup-web-push-overlay .ltkpopup-web-push-content #ltkpopup-close-button {\n top: -82px;\n}\n#ltkpopup-web-push-overlay\n .ltkpopup-web-push-content\n #ltkpopup-close-button\n a\n svg {\n stroke: #fff;\n}\n#ltkpopup-web-push-overlay .ltkpopup-web-push-content:before {\n width: 300px;\n height: 96px;\n background-image: url("data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJMYXllcl8xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDM2LjcgMTEuNyIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYuNyAxMS43OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+CjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyIgZmlsbD0icmdiKDUxLCA1MSwgNTEpIiBkYXRhLWNvbG9yLWlkLWZpbGw9ImN1cnJlbnRDb2xvciI+Cgkuc3Qwe2ZpbGw6bm9uZTtzdHJva2U6I0ZGRkZGRjtzdHJva2Utd2lkdGg6MS41O3N0cm9rZS1saW5lY2FwOnJvdW5kO3N0cm9rZS1saW5lam9pbjpyb3VuZDt9Cjwvc3R5bGU+CjxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0wLjksNC4zbDMuNS0zLjVsMy41LDMuNSIgZmlsbD0ibm9uZSIgZGF0YS1jb2xvci1pZC1maWxsPSJjdXJyZW50Q29sb3IiPjwvcGF0aD4KPHBhdGggY2xhc3M9InN0MCIgZD0iTTQuNCwwLjh2NmMwLDQuNyw1LjEsNCwxMS40LDRoMjAiIGZpbGw9Im5vbmUiIGRhdGEtY29sb3ItaWQtZmlsbD0iY3VycmVudENvbG9yIj48L3BhdGg+Cjwvc3ZnPg==");\n background-size: cover;\n content: "";\n position: absolute;\n top: 25px;\n left: 260px;\n}\n#ltkpopup-web-push-overlay .ltkpopup-web-push-content .ltkpopup-web-push-pos {\n position: absolute;\n top: 0;\n left: 590px;\n}\n#ltkpopup-web-push-overlay\n .ltkpopup-web-push-content\n .ltkpopup-web-push-pos\n h3 {\n color: #fff;\n font-size: 30px;\n margin: 30px auto;\n}\n#ltkpopup-web-push-overlay .ltkpopup-web-push-content .ltkpopup-web-push-pos p {\n color: #fff;\n max-width: 390px;\n}\n#ltkpopup-container.ltkpopup-overlay-show {\n width: 100% !important;\n height: 100% !important;\n}\n#ltkpopup-container.ltkpopup-webpush-visible {\n visibility: visible;\n}\n#ltkpopup-overlay.ltkpopup-webpush-visible {\n visibility: visible;\n}\n@-moz-document url-prefix() {\n #ltkpopup-web-push-overlay .ltkpopup-web-push-content:before {\n  left: 470px;\n }\n #ltkpopup-web-push-overlay .ltkpopup-web-push-content .ltkpopup-web-push-pos {\n  left: 800px;\n }\n}\n@supports (-ms-ime-align: auto) {\n #ltkpopup-web-push-overlay .ltkpopup-web-push-content:before {\n  top: 50px;\n }\n #ltkpopup-web-push-overlay .ltkpopup-web-push-content .ltkpopup-web-push-pos {\n  top: 25px;\n }\n}\n@media only screen and (max-width: 992px) {\n #ltkpopup-web-push-overlay .ltkpopup-web-push-content:before {\n  width: 140px;\n }\n #ltkpopup-web-push-overlay .ltkpopup-web-push-content .ltkpopup-web-push-pos {\n  left: 440px;\n }\n}\n@media only screen and (max-device-width: 1200px) {\n #ltkpopup-web-push-overlay.ltkpopup-overlay-show {\n  display: none;\n }\n}\n',
            confirmationHTML: '\n\t\t\t\t\t\t\t\n\n<!-- Pop-up Confirm / Appears after user submits Popup Form -->\n<div id="ltkpopup-wrapper" class="confirm ltkpopup-no-scroll" name="version3-custom" role="dialog" aria-labelledby="ltkpopup-sms-headline" aria-describedby="ltkpopup-sms-para">\n\t<!-- Main Popup Content Area -->\n\t<div id="ltkpopup-content" class="ltkpopup-confirm ltkpopup-sms-form">\n\n\t\t<!-- Pull in the popup container -->\n\t\t\n\t\t<div id="ltkpopup-sms-form">\n\t<div class="ltkpopup-clearfix ltkpopup-split-content ltkpopup-split-above-below">\n\n\t\t\n\n<div class="ltkpopup-contain-img">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/650x320.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-mobile-hide" aria-hidden="true">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/320x235.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-desktop-hide" aria-hidden="true">\n<\/div>\n\n\n\n\t\t<div class="ltkpopup-contain-form">\n\n\t\t\t\n\t\t\t<h1 id="ltkpopup-sms-headline" class="ltkpopup-subheadline">HERE&rsquo;S YOUR 15% OFFER CODE: <span class="ltkpopup-coupon">WELCOME15<\/span><\/h1>\n<p id="ltkpopup-sms-para" class="ltkpopup-content-para ltkpopup-mobile-smaller">Want another 15% off for a <br class="ltkpopup-desktop-hide">future&nbsp;purchase?<\/p>\n\n\t\t\t<div class="ltkpopup-form-contain">\n\t\t\t\t\n<div class="ltkpopup-clearfix ltkpopup-form-control ltkpopup-mobile-hide">\n\n\t<div class="ltkpopup-error-message" aria-live="assertive" data-ltkpopup-error-for="ltkpopup-phone" data-ltkpopup-message="Please enter a valid mobile number"><\/div>\n\n<div >\n\t<div class="ltkpopup-floating-label-container" >\n\t\t<label for="ltkpopup-phone" class="ltkpopup-floating-label" >Enter mobile number<\/label>\n\t\t<input autofocus required type="tel" id="ltkpopup-phone" class="ltkpopup-email" tabindex="0" name="ltkpopup-phone" placeholder="" autocomplete="tel" data-inputmask="\'mask\': \'(###) ###-####\'" pattern="^\\D?(\\d{3})\\D?\\D?(\\d{3})\\D?(\\d{4})$" />\n\t<\/div>\n<\/div>\n\n\t<div class="ltkpopup-button-container ltkpopup-flex ltkpopup-clearfix">\n\t\t<button id="ltkpopup-faux-submit" class="ltkpopup-faux-subscribe" tabindex="0" type="submit">SIGN ME UP<\/button>\n\t<\/div>\n\n<\/div>\n\n\n<div class="ltkpopup-clearfix ltkpopup-form-control ltkpopup-desktop-hide">\n\t<a id="ltkpopup-ttj-button" class="ltkpopup-sms-link ltkpopup-close ltkpopup-tap-to-join" href="sms://69629/" data-sms-keyword="Send this text for recurring automated Nine West marketing alerts + cart reminders" target="_top">\n\t\t<span>Sign up for texts\n\t\t<\/span>\n\t<\/a>\n<\/div>\n\n\n\n<div class="ltkpopup-no-thanks" id="ltkpopup-text-btn">\n\t<button tabindex="0" id="ltkpopup-skip-sms" >I&rsquo;ll skip the texts for now<\/button>\n<\/div>\n\n\t\t\t<\/div>\n\n\t\t\t<p id="ltkpopup-content-sms-disc" class="ltkpopup-content-para ltkpopup-sms-disclaimer">All offers exclude Gift Cards and Final Sale/Clearance. Some additional product exclusions may apply per brand/season. By subscribing to Nine West text messaging on 69629, you agree to receive recurring automated marketing text msgs (e.g. cart reminders) to the mobile number used at opt&dash;in. Consent is not a condition of purchase. Msg frequency may vary. Msg &amp; data rates may apply. Reply HELP for help and STOP to cancel. See <a href="https://ninewest.com/policies/terms-of-service" target="_blank">Terms and Conditions<\/a> &amp; <a href="https://ninewest.com/policies/privacy-policy" target="_blank">Privacy&nbsp;Policy<\/a>.<\/p>\n\n\t\t<\/div>\n\n\t<\/div>\n<\/div>\n\n<div id="ltkpopup-sms-confirm" aria-hidden="true">\n\n\t<div class="ltkpopup-clearfix ltkpopup-split-content ltkpopup-split-above-below">\n\n\t\t\n\n\n<div class="ltkpopup-contain-img">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/650x320.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-mobile-hide" aria-hidden="true">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/320x235.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-desktop-hide" aria-hidden="true">\n<\/div>\n\n\n\n\t\t<div class="ltkpopup-contain-form">\n\n\t\t\t\n\t\t\t<h1 id="ltkpopup-sms-confirm-headline" class="ltkpopup-headline ltkpopup-visuallyhidden">Welcome to Nine West<\/h1>\n<h2 id="ltkpopup-sms-confirm-subheadline" class="ltkpopup-headline">YOU\'RE IN<\/h2>\n<p id="ltkpopup-sms-confirm-content-para" class="ltkpopup-content-para">Check your text messages to confirm <br class="ltkpopup-mobile-hide">your subscription and receive your&nbsp;offer.<\/p>\n\t\t\t\n\t\t\t<div class="ltkpopup-button-container" id="ltkpopup-thanks">\n    <button tabindex="0" class="ltkpopup-close ltkpopup-close-button">Start shopping<\/button>\n<\/div>\n\t\t\t\n\t\t\t<p class="ltkpopup-content-para ltkpopup-disclaimer">All offers exclude Gift Cards and Final Sale/Clearance. Some additional product exclusions may apply per brand/season. See <a href="https://ninewest.com/policies/terms-of-service" target="_blank">Terms and Conditions<\/a> &amp; <a href="https://ninewest.com/policies/privacy-policy" target="_blank">Privacy&nbsp;Policy<\/a>.<\/p>\n\n\t\t<\/div>\n\n\t<\/div>\n\n<\/div>\n\n\n\n<div id="ltkpopup-sms-no-thanks" aria-hidden="true">\n\n\t<div class="ltkpopup-clearfix ltkpopup-split-content ltkpopup-split-above-below">\n\n\t\n\n<div class="ltkpopup-contain-img">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/650x320.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-mobile-hide" aria-hidden="true">\n\t<img src="https://mediacdn.espssl.com/10030/Shared/NineWest/popup/F23/320x235.jpg" alt="" class="ltkpopup-img-fluid ltkpopup-desktop-hide" aria-hidden="true">\n<\/div>\n\n\n\n\t<div class="ltkpopup-contain-form">\n\n\t\t\n\t\t<h1 id="ltkpopup-sms-no-thanks-headline" class="ltkpopup-headline ltkpopup-visuallyhidden">Welcome to Nine West<\/h1>\n<h2 id="ltkpopup-sms-no-thanks-subheadline" class="ltkpopup-headline">Thank you!<\/h2>\n<p id="ltkpopup-sms-no-thanks-content-para" class="ltkpopup-content-para">Here\'s your 15% offer code: <span class="ltkpopup-coupon">WELCOME15<\/span><\/p>\n\t\t\n\t\t<div class="ltkpopup-button-container" id="ltkpopup-thanks">\n    <button tabindex="0" class="ltkpopup-close ltkpopup-close-button">Start shopping<\/button>\n<\/div>\n\t\t\n\t\t\n\n\t<\/div>\n\n<\/div>\n\n<\/div>\n\n\t\t\n\n\t\t<!-- End Content Information -->\n\n\t\t<!-- Close \'X\' Button -->\n\t\t\n\t<\/div>\n<\/div>\n\n\n\n\n\n<script>\n\t// Browsers\n\tvar b = document.documentElement;\n\tb.className = b.className.replace("no-js", "js"), b.setAttribute("data-useragent", navigator.userAgent.toLowerCase()), b.setAttribute("data-platform", navigator.platform.toLowerCase());\n\tvar ua = navigator.userAgent.toLowerCase(),\n\t\tpf = navigator.platform.toLowerCase();\n\n\tfunction is(e) {\n\t\treturn ua.indexOf(e) > -1\n\t}\n\tvar browser = {\n\t\tIE: is("msie") || is("trident/7.0"),\n\t\tIE7: is("msie 7.0"),\n\t\tIE8: is("msie 8.0"),\n\t\tIE9: is("msie 9.0"),\n\t\tIE10: is("msie 10"),\n\t\tIE11: is("rv:11") && is("trident/7.0"),\n\t\tEdge: is("edge"),\n\t\tChrome: is("chrome") && !is("edge"),\n\t\tSafari: is("safari") && !is("chrome") && !is("edge"),\n\t\tFirefox: is("firefox") && !is("edge"),\n\t\tAndroidChrome: is("android") && is("chrome"),\n\t\tAndroidDefault: is("android") && !is("chrome"),\n\t\tWin7: is("windows nt 6.1"),\n\t\tWin8: is("windows nt 6.2"),\n\t\tWindows: pf.indexOf("win32") > -1,\n\t\tWebkit: is("webkit") && !is("edge"),\n\t\tIPad: is("ipad"),\n\t\tIPadChrome: is("ipad") && is("crios"),\n\t\tIPhone: is("iphone"),\n\t\tIPhoneChrome: is("iphone") && is("crios"),\n\t\tAndroid: is("android"),\n\t\tIOS: is("iphone") || is("ipad")\n\t};\n\tfor (var title in browser) {\n\t\tif (browser[title]) {\n\t\t\tdocument.getElementById("ltkpopup-content").classList.add(String(title).toLowerCase());\n\t\t}\n\t}\n\n\t// Close Function\n\tvar focused = document.activeElement;\n\tvar closeBtns = document.querySelectorAll(\'.ltkpopup-close\');\n\tfor (var i = 0; i < closeBtns.length; i++) {\n\t\tcloseBtns[i].addEventListener("click", function (e) {\n\t\t\t_ltk.Popup.close();\n\t\t\tfocused.focus();\n\t\t});\n\t}\n\n\t// Check Input Validity\n\tfunction checkInputValidity(inputEl) {\n\t\tvar ltkErrorClass = "ltkinputnotvalid";\n\t\tvar ltkErrorMessage = document.querySelector("[data-ltkpopup-error-for=\'" + inputEl.id + "\']");\n\t\tvar ltkLabel = document.querySelector("label[for=\'" + inputEl.id + "\']");\n\t\tif (ltkErrorMessage != undefined) {\n\t\t\tltkErrorMessage.innerText = "";\n\t\t\tinputEl.classList.remove(ltkErrorClass);\n\t\t\tif (ltkLabel != undefined) {\n\t\t\t\tltkLabel.classList.remove(ltkErrorClass);\n\t\t\t}\n\t\t}\n\t\tinputEl.checkValidity();\n\t\tif (!inputEl.validity.valid) {\n\t\t\tinputEl.classList.add(ltkErrorClass);\n\t\t\tif (ltkLabel != undefined) {\n\t\t\t\tltkLabel.classList.add(ltkErrorClass);\n\t\t\t}\n\t\t\tif (ltkErrorMessage != undefined) {\n\t\t\t\tltkErrorMessage.innerText = ltkErrorMessage.getAttribute("data-ltkpopup-message");\n\t\t\t}\n\t\t\treturn false;\n\t\t}\n\t\treturn true;\n\t}\n\n\t// Override close CTA focus called by onescript 2x\n\tonescriptFocus = 0;\n\twrapperFocus = function () {\t\n\t\tdocument.querySelectorAll(".simpleltkmodal-wrap")[0].focus();\n\t\tonescriptFocus ++;\n\t\tif(onescriptFocus == 1) {\n\t\t\tdocument.querySelector(\'.simpleltkmodal-wrap button\').removeEventListener(\'focus\', wrapperFocus);\n\t\t}\n\t}\n\n\t// Tab Trapping\n\tsetTimeout(function () {\n\t\tfunction triggerFocus(element) {\n\t\t\tvar eventType = "onfocusin" in element ? "focusin" : "focus",\n\t\t\t\tbubbles = "onfocusin" in element,\n\t\t\t\tevent;\n\n\t\t\tif ("createEvent" in document) {\n\t\t\t\tevent = document.createEvent("Event");\n\t\t\t\tevent.initEvent(eventType, bubbles, true);\n\t\t\t} else if ("Event" in window) {\n\t\t\t\tevent = new Event(eventType, {\n\t\t\t\t\tbubbles: bubbles,\n\t\t\t\t\tcancelable: true\n\t\t\t\t});\n\t\t\t}\n\n\t\t\telement.focus();\n\t\t\telement.dispatchEvent(event);\n\t\t}\n\t\tif (document.getElementById("ltkpopup-email") != undefined) {\n\t\t\ttriggerFocus(document.getElementById("ltkpopup-email"));\n\t\t} else if (document.getElementById("ltkpopup-phone") != undefined) {\n\t\t\ttriggerFocus(document.getElementById("ltkpopup-phone"));\n\t\t} else if (document.querySelectorAll(".simpleltkmodal-wrap")[0] != undefined && document.querySelector(\'.simpleltkmodal-wrap input\') == null && document.querySelector(\'.simpleltkmodal-wrap button\') != null) {\n\t\t\tdocument.querySelector(\'.simpleltkmodal-wrap button\').addEventListener(\'focus\', wrapperFocus);\n\t\t}\n\t}, 0);\n\n\tfunction trapTabKey(e) {\n\t\tvar t = document.activeElement,\n\t\t\ts = focusableElems.indexOf(t);\n\t\tif (9 === e.keyCode) {\n\t\t\te.preventDefault();\n\t\t\tmoveTab(s, e.shiftKey)\n\t\t}\n\t}\n\n\tfunction moveTab(index, shift) {\n\t\tvar nextTab = null;\n\t\tvar nextIndex = index;\n\t\tif (shift) {\n\t\t\tif (focusableElems[index] == firstTabStop) {\n\t\t\t\tnextTab = lastTabStop;\n\t\t\t} else {\n\t\t\t\tnextIndex = index - 1;\n\t\t\t\tnextTab = focusableElem[nextIndex];\n\t\t\t}\n\t\t} else {\n\t\t\tif (focusableElems[index] == lastTabStop) {\n\t\t\t\tnextTab = firstTabStop;\n\t\t\t\tnextIndex = 0;\n\t\t\t} else {\n\t\t\t\tnextIndex = index + 1;\n\t\t\t\tnextTab = focusableElems[nextIndex];\n\t\t\t}\n\t\t}\n\t\tif (nextTab.offsetParent != null) {\n\t\t\tnextTab.focus();\n\t\t} else {\n\t\t\tmoveTab(nextIndex, shift);\n\t\t}\n\t}\n\tsetTimeout(function () {\n\t\t//Do not delete - tab functionality will break\n\t\t_ltk.Modal.simpleModal.impl.unbindEvents("keydown.simpleltkmodal"), _ltk.Modal.simpleModal.impl.unbindEvents("focus");\n\t}, 50);\n\tvar focusBox = document.getElementById("ltkpopup-content"),\n\t\tfocusableElemStr = \'a[href], [title], input:not([type=hidden]), [tabindex="0"], [tabindex="1"]\',\n\t\tfocusableElem = focusBox.querySelectorAll(focusableElemStr),\n\t\tfocusableElems = Array.prototype.slice.call(focusableElem),\n\t\tfirstTabStop = focusableElems[0],\n\t\tlastTabStop = focusableElems[focusableElems.length - 1];\n\tfocusBox.addEventListener("keydown", trapTabKey);\n\n\n\t// floating labels\n\tjQuery(\'.ltkpopup-floating-label-container :input\').each(function () {\n\t\tthis.addEventListener(\'blur\', removeFloat, false);\n\t\tif (this.hasAttribute(\'data-inputmask\') || this.id == \'ltkpopup-datepicker\') {\n\t\t\tthis.addEventListener(\'focus\', addFloat, false);\n\t\t} else {\n\t\t\tthis.addEventListener(\'click\', addFloat, false);\n\t\t\tthis.addEventListener(\'keydown\', addFloat, false);\n\t\t}\n\t});\n\n\tfunction addFloat(event) {\n\t\tjQuery(event.target).closest(".ltkpopup-floating-label-container").addClass(\'ltkpopup-floatLabel\');\n\t\tjQuery("[data-ltkpopup-error-for=\'" + event.target.id + "\']").addClass(\'ltkpopup-floatLabel\');\n\t}\n\n\tfunction removeFloat(event) {\n\t\tif (event.target.value.length == 0 && !event.target.classList.contains("ltkpopup-datepicker")) {\n\t\t\tjQuery(event.target).closest(".ltkpopup-floating-label-container").removeClass(\'ltkpopup-floatLabel\');\n\t\t\tjQuery("[data-ltkpopup-error-for=\'" + event.target.id + "\']").removeClass(\'ltkpopup-floatLabel\');\n\t\t}\n\t}\n<\/script>\n\n<script>\n\tif (document.querySelectorAll("[data-inputmask]").length > 0) {\n\n\t\t// Input masking for number validation - Get Jquery Input Mask from CDN and load it\n\t\tjQuery.getScript(\n\t\t\t"https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.1/jquery.inputmask.bundle.js",\n\t\t\tfunction () {\n\t\t\t\tjQuery("[data-inputmask]").each(function () {\n\t\t\t\t\t// Mask phone number input after script is loaded\n\t\t\t\t\tjQuery(this).inputmask({\n\t\t\t\t\t\tgreedy: false,\n\t\t\t\t\t\tshowMaskOnHover: false,\n\t\t\t\t\t\tdefinitions: {\n\t\t\t\t\t\t\t\'#\': {\n\t\t\t\t\t\t\t\tvalidator: "[0-9]",\n\t\t\t\t\t\t\t\tcardinality: 1\n\t\t\t\t\t\t\t}\n\t\t\t\t\t\t}\n\t\t\t\t\t});\n\t\t\t\t});\n\t\t\t});\n\t}\n<\/script>\n<script>\n\tjQuery(\'#ltkpopup-faux-submit\').on(\'click\', function () {\n\t\tvar e = jQuery("#ltkpopup-sms-form :input");\n\t\tvar formIsValid = true;\n\t\tjQuery(e).each(function (e) {\n\t\t\tif (checkInputValidity(this)) {\n\t\t\t\tif (this.id == \'ltkpopup-phone\') {\n\t\t\t\t\t_ltk.Subscriber.Email = this.value;\n\t\t\t\t\tthis.removeAttribute("aria-describedby");\n\t\t\t\t}\n\t\t\t} else {\n\t\t\t\tformIsValid = false;\n\t\t\t\tthis.setAttribute("aria-describedby", this.id + "-error-message");\n\t\t\t\tdocument.querySelector(".ltkinputnotvalid").focus();\n\t\t\t}\n\t\t});\n\t\tif (formIsValid) {\n\t\t\tjQuery(e).each(function (e) {\n\t\t\t\tlet fieldMapping = this.name;\n\t\t\t\tif (this.type == "radio") {\n\t\t\t\t\tfieldMapping = this.name + "." + this.value;\n\t\t\t\t}\n\t\t\t\tif (this.type == "checkbox" || this.type == "radio") {\n\t\t\t\t\tif (this.checked) {\n\t\t\t\t\t\tthis.value = "on";\n\t\t\t\t\t} else {\n\t\t\t\t\t\tthis.value = "off";\n\t\t\t\t\t}\n\t\t\t\t}\n\t\t\t\t_ltk.Subscriber.Profile.Add(fieldMapping, this.value);\n\t\t\t});\n\t\t\tltkpopupNextPage(\'ltkpopup-sms-confirm\');\n\t\t\t_ltk.Subscriber.List = \'DesktopSMS\';\n\t\t\t_ltk.Subscriber.Profile.Add(\'Email\', emailVal);\n\t\t\t_ltk.Subscriber.Submit(true);\n\t\t}\n\t});\n\tvar skipSMS = document.getElementById("ltkpopup-skip-sms");\n\tif (skipSMS != null) {\n\t\tskipSMS.addEventListener("click", function (e) {\n\t\t\tltkpopupNextPage(\'ltkpopup-sms-no-thanks\');\n\t\t});\n\t}\n\tif (window.location.href.indexOf("ltknextpage=1") > -1 || window.location.href.indexOf("ltkconfirmpage=sms") > -1) {\n\t\tltkpopupNextPage(\'ltkpopup-sms-confirm\');\n\t}\n\tif (window.location.href.indexOf("ltkconfirmpage=nothanks") > -1) {\n\t\tltkpopupNextPage(\'ltkpopup-sms-no-thanks\');\n\t}\n\n\tfunction ltkpopupNextPage(nextPage) {\n\t\tjQuery(\'#ltkpopup-content\').fadeOut(\'slow\', function () {\n\t\t\tjQuery(\'#ltkpopup-sms-form\').attr(\'aria-hidden\', \'true\').hide();\n\t\t\tsetTimeout(function () {\n\t\t\t\tjQuery(\'#\' + nextPage).show().attr(\'aria-hidden\', \'false\');\n\t\t\t\tjQuery(\'#ltkpopup-wrapper\').attr({\n\t\t\t\t\t\'aria-labelledby\': nextPage + \'-headline\',\n\t\t\t\t\t\'aria-describedby\': nextPage + \'-content-para\'\n\t\t\t\t})\n\t\t\t\tjQuery(\'#ltkpopup-content\').removeClass(\'ltkpopup-sms-form\').addClass(nextPage).fadeIn(\'slow\');\n\t\t\t}, 300);\n\t\t});\n\t}\n<\/script>\n<script>\n\tvar datepickerField = document.querySelector("#ltkpopup-datepicker");\n\tif (datepickerField != null) {\n\t\tvar jQueryUIcss = document.createElement("link");\n\t\tjQueryUIcss.href = "https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css";\n\t\tjQueryUIcss.rel = "stylesheet";\n\t\tjQueryUIcss.addEventListener("load", function () {\n\t\t\tvar jQueryUI = document.createElement("script");\n\t\t\tjQueryUI.src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js";\n\t\t\tjQueryUI.addEventListener("load", function () {\n\t\t\t\tdatepickerField.setAttribute("readonly", "");\n\t\t\t\tjQuery(datepickerField).datepicker({\n\t\t\t\t\tchangeMonth: true,\n\t\t\t\t\tchangeYear: false,\n\t\t\t\t\tyearRange: \'-0:+0\',\n\t\t\t\t\t// use for different date format and hidden bday field\n\t\t\t\t\tdateFormat: "mm/dd",\n\t\t\t\t\taltField: "#ltkpopup-hidden-bday",\n\t\t\t\t\taltFormat: "mm/dd/1900",\n\t\t\t\t\tonClose: function (selectedDate) {\n\t\t\t\t\t\t\t\tif (selectedDate == "") {\n\t\t\t\t\t\t\t\t\tjQuery(this).closest(".ltkpopup-floating-label-container").removeClass(\'ltkpopup-floatLabel\');\n\t\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\t}\n\t\t\t\t\t});\n\n\t\t\t\tjQuery(datepickerField).focus(function () {\n\t\t\t\t\tjQuery(\'#ui-datepicker-div\').appendTo(this.parentNode);\n\t\t\t\t});\n\t\t\t});\n\t\t\tdocument.getElementById("ltkpopup-content").appendChild(jQueryUI);\n\t\t});\n\t\tdocument.getElementById("ltkpopup-content").appendChild(jQueryUIcss);\n\t}\n<\/script>\n\n\n\n\n\n\t\t\t\t\t\t',
            animation: null,
            urlRedirect: null,
            initialDelay: 2,
            buttonSettings: {
                size: 1,
                shape: 1,
                alignment: 2,
                text: "Subscribe",
                color: "#00BDE5",
                textColor: "#FFFFFF"
            },
            urlRules: [{
                urlMatchRule: 1,
                show: !1,
                url: "/account/"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "/cart"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "/checkouts/"
            }, {
                urlMatchRule: 1,
                show: !1,
                url: "/preference-center"
            }],
            targetingRules: {
                showWhenDevice: ["Desktop", "Mobile"]
            },
            subscriptionPoint: "Popup",
            engagement: {
                followUpTimeframe: 0,
                showWhenPageSession: 1,
                followUp: !0,
                followUpDelay: 10,
                showIfFromListrakEmail: !1
            },
            overlayClose: !0,
            referrerRule: null
        }
    }], t, i, r, u, f, e, o, s, h, l, c, a, v);
    n.initialize();
    _ltk.Popup = {
        openManualByName: n.openManualByName,
        close: n.close
    }
}, this, ["modalInit"]);
_ltk.Click.Submit();
_ltk.Click.Submit = function() {},
    function() {
        var n = setTimeout(function() {
            _ltk.Activity.AddPageBrowse()
        }, 500);
        document.addEventListener("ltkPageBrowse", function() {
            clearTimeout(n)
        })
    }();
_ltk.Signup.SubscribeFromTrigger("load"),
    function() {
        function u(n) {
            var t = "_ltk.Snippet.dropped";
            if (window.sessionStorage)
                if (n) sessionStorage.setItem(t, n);
                else return n = sessionStorage.getItem(t), sessionStorage.removeItem(t), n
        }

        function e(n) {
            try {
                var t = new Function(n);
                return function() {
                    i(t)
                }
            } catch (r) {
                return function() {
                    function o() {
                        var n = f.pop();
                        if (n)
                            if (n.src) _ltk_util.getScript(n.src, function() {
                                i(o)
                            });
                            else try {
                                (null || eval)(n.innerHTML)
                            } finally {
                                i(o)
                            }
                    }
                    var s = "ltk-snippet",
                        t = document.getElementById(s) || document.createElement("div"),
                        f, e, u, r;
                    for (t.id = s, t.style.display = "none", t.innerHTML = "<br>" + n, t.removeChild(t.firstChild), f = [], e = t.getElementsByTagName("script"), u = e.length - 1; u >= 0; u--) r = e[u], r.type && r.type != "text/javascript" || (r.parentElement.removeChild(r), f.push(r));
                    _ltk_util.domready(function() {
                        document.body.appendChild(t);
                        i(o)
                    })
                }
            }
        }

        function i(t) {
            setTimeout(function() {
                try {
                    t()
                } catch (i) {
                    if (_ltk.Exception.Submit(i, "JS " + (n ? "Test" : "Live") + " Snippet exception"), n) throw new Error(i.stack || i);
                }
            }, 0)
        }
        var n = /ltkjstestmode/gi.test(document.location.href),
            f = e(n ? u() || "" : "<script>\r\n_ltk_util.ready(function () {\r\n// Email Capture\r\njQuery(\"body\").on(\"focusout\", \"[type='email']\", function(e) {\r\n  if(_ltk.isValidEmail(e.target.value)){\r\n    _ltk.SCA.Update(\"email\", e.target.value);\r\n  }\r\n});\r\n\r\n// Track Your Order\r\n_ltk.SCA.CaptureEmail('order[email]'); \r\n});\r\n<\/script>\n\n<script>\r\n//Run Pref center code on pref center pages only\r\n(function(){\r\n    if(document.querySelector('[data-ltk-prefcenter]')) {\r\n        var el = document.createElement('script');\r\n        el.id = 'ltkPrefCenterFrame';\r\n        el.src = '//services.listrak.com/API/S/ltkPrefCenterFrame';\r\n        document.querySelector('script').parentNode.insertBefore(el, document.querySelector('script'));\r\n    }\r\n})();\r\n<\/script>\n\n<script>\r\n// MLG (2/4/22)\r\n\r\n// Footer\r\n_ltk.Signup.New('Footer', 'footer input[name=\"contact[email]\"]', _ltk.Signup.TYPE.CLICK, 'footer button[type=\"submit\"]');\r\n\r\n// Account Create\r\nif (location.pathname.match(\"/register\")) {\r\n  _ltk.Signup.New('AccountCreate', 'customer[email]', _ltk.Signup.TYPE.DEFAULT, '#create_customer [type=\"submit\"]');\r\n  _ltk.Signup.SetField('AccountCreate', 'customer[first_name]', {key: \"FirstName\"});\r\n  _ltk.Signup.SetField('AccountCreate', 'customer[last_name]', {key: \"LastName\"});\r\n}\r\n<\/script>\n\n<script>\r\n\tif (window.location.href.indexOf(\"ltkautopop=1\") > -1) {\r\n\t\tltkLaunchpopup('NW-IG-TTJ');\r\n\t}\r\n\r\n\tfunction ltkLaunchpopup(popupName) {\r\n\t\tvar popuplaunched = false;\r\n\t\tif (typeof _ltk == \"object\" && typeof _ltk.Popup == \"object\" && typeof _ltk.Popup.openManualByName == \"function\") {\r\n\t\t\tpopuplaunched = true;\r\n\t\t\t_ltk.Popup.openManualByName(popupName);\r\n\t\t} else {\r\n\t\t\tsetTimeout(function () {\r\n\t\t\t\tltkLaunchpopup(popupName);\r\n\t\t\t}, 100);\r\n\t\t}\r\n\t}\r\n<\/script>\n\n"),
            t, r;
        f();
        n && window.FileReader && (t = function(n) {
            n.stopPropagation();
            n.preventDefault()
        }, r = function(n) {
            var r, f, i;
            t(n);
            r = n.dataTransfer.files;
            r.length && (f = r[0], i = new FileReader, i.onload = function() {
                u(i.result);
                location.reload()
            }, i.readAsText(f))
        }, document.body.addEventListener("dragenter", t, !1), document.body.addEventListener("dragover", t, !1), document.body.addEventListener("drop", r, !1))
    }();
_ltk.TapToJoin = (new tapToJoinHandler).handleSMSRedirect;
typeof exports != "undefined" && (exports.tapToJoinHandler = tapToJoinHandler);
document.dispatchEvent ? (customEvent = new _ltk_util.CustomEvent("ltkAsyncListener"), document.dispatchEvent(customEvent)) : document.fireEvent && (document.documentElement.ltkAsyncProperty += 1),
    function() {
        function t() {
            setTimeout(function() {
                if (n.length) try {
                    n.shift()()
                } finally {
                    t()
                }
            })
        }
        if (!(_ltk.push instanceof Function)) {
            var n = _ltk.push || [];
            _ltk.push = function(i) {
                n.push(i);
                t()
            };
            t()
        }
    }()