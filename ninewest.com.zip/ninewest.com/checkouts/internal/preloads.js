(function() {
    var baseURL = "https://cdn.shopify.com/shopifycloud/checkout-web/assets/";
    var scripts = ["https://cdn.shopify.com/shopifycloud/checkout-web/assets/runtime.latest.en.216120befe7fc7d83058.js", "https://cdn.shopify.com/shopifycloud/checkout-web/assets/568.latest.en.9485cba652f34ad14bb5.js", "https://cdn.shopify.com/shopifycloud/checkout-web/assets/608.latest.en.f38c4cedb9fc7720704a.js", "https://cdn.shopify.com/shopifycloud/checkout-web/assets/758.latest.en.4c208d48ab93e82a760e.js", "https://cdn.shopify.com/shopifycloud/checkout-web/assets/app.latest.en.b0e9fce3f5b43b52a106.js", "https://cdn.shopify.com/shopifycloud/checkout-web/assets/Information.latest.en.faad9d6f6ff532e66a1c.js"];
    var styles = ["https://cdn.shopify.com/shopifycloud/checkout-web/assets/568.latest.en.909df351ad87f7f9fcc9.css", "https://cdn.shopify.com/shopifycloud/checkout-web/assets/app.latest.en.f5aea76e2b1cba6520da.css", "https://cdn.shopify.com/shopifycloud/checkout-web/assets/739.latest.en.cb2d2fb5c673c1375a48.css"];
    var fontPreconnectUrls = ["https://fonts.shopifycdn.com"];
    var fontPrefetchUrls = ["https://fonts.shopifycdn.com/lato/lato_n4.c86cddcf8b15d564761aaa71b6201ea326f3648b.woff2?valid_until=MTcwNDAxNDE4OQ&hmac=a912600c68d157e2598edffddda90707a66ccd4c711e01b72570ad59088589ed", "https://fonts.shopifycdn.com/lato/lato_n7.f0037142450bd729bdf6ba826f5fdcd80f2787ba.woff2?valid_until=MTcwNDAxNDE4OQ&hmac=efcd3c9660790691aafc77d35273400bc4e634c4ab697b12fc5aec86258ebb65"];
    var imgPrefetchUrls = ["https://cdn.shopify.com/s/files/1/0267/3737/7324/files/NineWest_Logo_x320.jpg?v=1613697835"];

    function preconnect(url, callback) {
        var link = document.createElement('link');
        link.rel = 'dns-prefetch preconnect';
        link.href = url;
        link.crossOrigin = '';
        link.onload = link.onerror = callback;
        document.head.appendChild(link);
    }

    function preconnectAssets() {
        var resources = [baseURL].concat(fontPreconnectUrls);
        var index = 0;
        (function next() {
            var res = resources[index++];
            if (res) preconnect(res[0], next);
        })();
    }

    function prefetch(url, as, callback) {
        var link = document.createElement('link');
        if (link.relList.supports('prefetch')) {
            link.rel = 'prefetch';
            link.fetchPriority = 'low';
            link.as = as;
            if (as === 'font') link.type = 'font/woff2';
            link.href = url;
            link.crossOrigin = '';
            link.onload = link.onerror = callback;
            document.head.appendChild(link);
        } else {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', url, true);
            xhr.onloadend = callback;
            xhr.send();
        }
    }

    function prefetchAssets() {
        var resources = [].concat(
            scripts.map(function(url) {
                return [url, 'script'];
            }),
            styles.map(function(url) {
                return [url, 'style'];
            }),
            fontPrefetchUrls.map(function(url) {
                return [url, 'font'];
            }),
            imgPrefetchUrls.map(function(url) {
                return [url, 'image'];
            })
        );
        var index = 0;
        (function next() {
            var res = resources[index++];
            if (res) prefetch(res[0], res[1], next);
        })();
    }

    function onLoaded() {
        preconnectAssets();
        prefetchAssets();
    }

    if (document.readyState === 'complete') {
        onLoaded();
    } else {
        addEventListener('load', onLoaded);
    }
})();