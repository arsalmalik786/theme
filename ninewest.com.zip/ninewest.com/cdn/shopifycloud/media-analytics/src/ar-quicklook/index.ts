import ready from '../ready';
import querySelectAndTrack from './query-select-and-track';

ready(querySelectAndTrack);
