window.klarna_OSMP = window.klarna_OSMP || {};
window.klarna_OSMP.placements = [{
    "id": 8615,
    "name": "Product",
    "data_key": "credit-promotion-small",
    "data_preloaded": "false",
    "placement_page": "product",
    "anchor_element": ".purchase-details",
    "padding_top": true,
    "padding_bottom": false,
    "padding_left": false,
    "padding_right": false,
    "justification": "left",
    "theme": "light",
    "static_page": null,
    "data_locale": null,
    "position": "above",
    "install_method": "dragdrop",
    "locale_option": "auto",
    "honor_storefront_locale": false,
    "country": "US",
    "countries": null,
    "type": "dynamic"
}, {
    "id": 8616,
    "name": "Cart",
    "data_key": "credit-promotion-small",
    "data_preloaded": "false",
    "placement_page": "cart",
    "anchor_element": ".cart__featured-links",
    "padding_top": true,
    "padding_bottom": false,
    "padding_left": false,
    "padding_right": true,
    "justification": "left",
    "theme": "light",
    "static_page": null,
    "data_locale": null,
    "position": "above",
    "install_method": "dragdrop",
    "locale_option": "auto",
    "honor_storefront_locale": false,
    "country": "US",
    "countries": null,
    "type": "dynamic"
}];
window.klarna_OSMP.store = {
    "currency": "USD",
    "endpoint": "us",
    "playground_active": false,
    "client_id": "20b49a88-26a9-5a01-83de-8ea205462be2",
    "mid_locales": {
        "US": ["en-US", "es-US"]
    },
    "fallback_placement": "top-strip-promotion-badge"
};
(() => {
    "use strict";
    var e, t, r, n = {
            961: (e, t, r) => {
                r.d(t, {
                    E: () => n
                });
                const n = () => {
                    var e;
                    return Boolean(null === (e = window.frameElement) || void 0 === e ? void 0 : e.getAttribute("data-in-admin-app"))
                }
            }
        },
        o = {};

    function a(e) {
        var t = o[e];
        if (void 0 !== t) return t.exports;
        var r = o[e] = {
            id: e,
            loaded: !1,
            exports: {}
        };
        return n[e].call(r.exports, r, r.exports, a), r.loaded = !0, r.exports
    }
    a.m = n, a.n = e => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return a.d(t, {
            a: t
        }), t
    }, a.d = (e, t) => {
        for (var r in t) a.o(t, r) && !a.o(e, r) && Object.defineProperty(e, r, {
            enumerable: !0,
            get: t[r]
        })
    }, a.f = {}, a.e = e => Promise.all(Object.keys(a.f).reduce(((t, r) => (a.f[r](e, t), t)), [])), a.u = e => e + ".index.js", a.g = function() {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || new Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }(), a.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), e = {}, t = "client:", a.l = (r, n, o, i) => {
        if (e[r]) e[r].push(n);
        else {
            var l, d;
            if (void 0 !== o)
                for (var s = document.getElementsByTagName("script"), u = 0; u < s.length; u++) {
                    var c = s[u];
                    if (c.getAttribute("src") == r || c.getAttribute("data-webpack") == t + o) {
                        l = c;
                        break
                    }
                }
            l || (d = !0, (l = document.createElement("script")).charset = "utf-8", l.timeout = 120, a.nc && l.setAttribute("nonce", a.nc), l.setAttribute("data-webpack", t + o), l.src = r), e[r] = [n];
            var p = (t, n) => {
                    l.onerror = l.onload = null, clearTimeout(f);
                    var o = e[r];
                    if (delete e[r], l.parentNode && l.parentNode.removeChild(l), o && o.forEach((e => e(n))), t) return t(n)
                },
                f = setTimeout(p.bind(null, void 0, {
                    type: "timeout",
                    target: l
                }), 12e4);
            l.onerror = p.bind(null, l.onerror), l.onload = p.bind(null, l.onload), d && document.head.appendChild(l)
        }
    }, a.nmd = e => (e.paths = [], e.children || (e.children = []), e), a.p = "https://production-klarna-il-shopify-osm.s3.eu-west-1.amazonaws.com/ff11466d552028207a205623962e6ad15c5e1ea0/", (() => {
        var e = {
            179: 0
        };
        a.f.j = (t, r) => {
            var n = a.o(e, t) ? e[t] : void 0;
            if (0 !== n)
                if (n) r.push(n[2]);
                else {
                    var o = new Promise(((r, o) => n = e[t] = [r, o]));
                    r.push(n[2] = o);
                    var i = a.p + a.u(t),
                        l = new Error;
                    a.l(i, (r => {
                        if (a.o(e, t) && (0 !== (n = e[t]) && (e[t] = void 0), n)) {
                            var o = r && ("load" === r.type ? "missing" : r.type),
                                i = r && r.target && r.target.src;
                            l.message = "Loading chunk " + t + " failed.\n(" + o + ": " + i + ")", l.name = "ChunkLoadError", l.type = o, l.request = i, n[1](l)
                        }
                    }), "chunk-" + t, t)
                }
        };
        var t = (t, r) => {
                var n, o, [i, l, d] = r,
                    s = 0;
                if (i.some((t => 0 !== e[t]))) {
                    for (n in l) a.o(l, n) && (a.m[n] = l[n]);
                    d && d(a)
                }
                for (t && t(r); s < i.length; s++) o = i[s], a.o(e, o) && e[o] && e[o][0](), e[o] = 0
            },
            r = self.webpackChunkclient = self.webpackChunkclient || [];
        r.forEach(t.bind(null, 0)), r.push = t.bind(null, r.push.bind(r))
    })(), a.nc = void 0, r = a(961), (async () => {
        if ((0, r.E)()) {
            const {
                default: e
            } = await Promise.all([a.e(121), a.e(326)]).then(a.bind(a, 326));
            await e.initialize()
        } else if (!window.KOSMApp) {
            window.KOSMApp = !0;
            const {
                default: e
            } = await Promise.all([a.e(258), a.e(906)]).then(a.bind(a, 906));
            window.KOSMApp = e, await e.init()
        }
    })()
})();