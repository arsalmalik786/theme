function loadSmileScript(e, t) {
    var i = document,
        n = i.createElement("script");
    n.async = !1, n.defer = !0, n.src = "https://js.smile.io/v1/" + e, t ? n.type = "module" : n.setAttribute("nomodule", ""), i.querySelector("head").appendChild(n)
}
"noModule" in document.createElement("script") || loadSmileScript("runtime-3eec20150a344b56e117.legacy.js", !1),
    function() {
        var e = document.querySelector(".smile-shopify-init");
        if ("fetch" in window && e) {
            var {
                channelKey: t,
                digest: i,
                customerAcceptsMarketing: n,
                customerEmail: s,
                customerFirstName: o,
                customerId: a,
                customerLastName: r,
                customerOrdersCount: c,
                customerTags: m,
                customerTotalSpent: l
            } = e.dataset, d = function() {
                var e = "smile_ncet",
                    t = new URLSearchParams(window.location.search).has("smile_no_cache"),
                    i = (new Date).getTime();
                try {
                    t && sessionStorage.setItem(e, (i + 9e5).toString());
                    var n = sessionStorage.getItem(e);
                    n && ((t = Number.parseInt(n) > i) || sessionStorage.removeItem(e))
                } catch (e) {}
                return t
            }(), p = {
                Accept: "application/json",
                "Smile-Channel-Key": t,
                "Smile-Client": "smile-ui",
                "Content-Type": "application/json"
            }, u = new URL("https://platform.smile.io/v1/smile_ui/init");
            u.searchParams.append("channel_key", t), d && u.searchParams.append("no_cache", d), window.__smile_ui_init_data__ = fetch(u.toString(), {
                headers: p
            }).then((function(e) {
                return e.json()
            })), i && (window.__smile_ui_customer_data__ = fetch("https://platform.smile.io/v1/shopify/identify_customer", {
                method: "POST",
                headers: p,
                body: JSON.stringify({
                    customer: {
                        accepts_marketing: n,
                        email: s,
                        first_name: o,
                        id: a,
                        last_name: r,
                        orders_count: c,
                        tags: m,
                        total_spent: l
                    },
                    digest: i
                })
            }).then((function(e) {
                return e.json()
            })))
        }
    }(), window.addEventListener("smile:load-async-script", (function(e) {
        loadSmileScript(e.detail, !0)
    })), "noModule" in document.createElement("script") ? loadSmileScript("smile-lite-bd1e820d91.js", !0) : (loadSmileScript("smile-shopify-0bf3986314b8d662727a.modern.js", !0), loadSmileScript("vendor-108ef4307b9453682b2b.modern.js", !0), loadSmileScript("smile-shopify-fbed5f0fd941b593fb77.legacy.js", !1), loadSmileScript("vendor-583d8fe537285d2d770d.legacy.js", !1));