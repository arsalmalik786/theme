(() => {
    "use strict";
    var e, t, i, o, n, r = {},
        a = {};

    function l(e) {
        var t = a[e];
        if (void 0 !== t) return t.exports;
        var i = a[e] = {
            id: e,
            exports: {}
        };
        return r[e].call(i.exports, i, i.exports, l), i.exports
    }
    l.m = r, l.amdO = {}, e = [], l.O = (t, i, o, n) => {
        if (!i) {
            var r = 1 / 0;
            for (c = 0; c < e.length; c++) {
                for (var [i, o, n] = e[c], a = !0, s = 0; s < i.length; s++)(!1 & n || r >= n) && Object.keys(l.O).every((e => l.O[e](i[s]))) ? i.splice(s--, 1) : (a = !1, n < r && (r = n));
                if (a) {
                    e.splice(c--, 1);
                    var d = o();
                    void 0 !== d && (t = d)
                }
            }
            return t
        }
        n = n || 0;
        for (var c = e.length; c > 0 && e[c - 1][2] > n; c--) e[c] = e[c - 1];
        e[c] = [i, o, n]
    }, l.n = e => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return l.d(t, {
            a: t
        }), t
    }, i = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__, l.t = function(e, o) {
        if (1 & o && (e = this(e)), 8 & o) return e;
        if ("object" == typeof e && e) {
            if (4 & o && e.__esModule) return e;
            if (16 & o && "function" == typeof e.then) return e
        }
        var n = Object.create(null);
        l.r(n);
        var r = {};
        t = t || [null, i({}), i([]), i(i)];
        for (var a = 2 & o && e;
            "object" == typeof a && !~t.indexOf(a); a = i(a)) Object.getOwnPropertyNames(a).forEach((t => r[t] = () => e[t]));
        return r.default = () => e, l.d(n, r), n
    }, l.d = (e, t) => {
        for (var i in t) l.o(t, i) && !l.o(e, i) && Object.defineProperty(e, i, {
            enumerable: !0,
            get: t[i]
        })
    }, l.f = {}, l.e = e => Promise.all(Object.keys(l.f).reduce(((t, i) => (l.f[i](e, t), t)), [])), l.u = e => e + "-" + {
        "smile-ui-styles": "2bc6e63e080534c3dfa8",
        "src_smile-ui_app_components_Panel_Cards_Shared_ReferralUrlShare_tsx-src_smile-ui_app_componen-7a872f": "f04c8a0c5ffd732e0cb5",
        "src_smile-ui_app_containers_Prompt_Prompt_tsx": "8a5b2517a8954b0328a0",
        "src_smile-ui_app_containers_Launcher_tsx": "f78e90b9bbf162c75ef3",
        "src_smile-ui_app_containers_Nudges_tsx": "0ed1146a4f04892939a7",
        "src_smile-ui_app_containers_Panel_PanelView_tsx": "823bc28bd5e21b7d08e6",
        translations0: "02631c51e3cd1eca7d15",
        translations1: "d8e6592308cae39477c0",
        translations2: "b3c03bd2cb8025f02dd5",
        translations3: "4cb784942324e14c36b0",
        translations4: "69192d47b0fd0bb1bf16",
        translations5: "0f459eb7beed405472a7"
    }[e] + ".modern.js", l.miniCssF = e => {}, l.g = function() {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || new Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }(), l.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), o = {}, n = "smile-ui:", l.l = (e, t, i, r) => {
        if (o[e]) o[e].push(t);
        else {
            var a, s;
            if (void 0 !== i)
                for (var d = document.getElementsByTagName("script"), c = 0; c < d.length; c++) {
                    var m = d[c];
                    if (m.getAttribute("src") == e || m.getAttribute("data-webpack") == n + i) {
                        a = m;
                        break
                    }
                }
            a || (s = !0, (a = document.createElement("script")).charset = "utf-8", a.timeout = 120, l.nc && a.setAttribute("nonce", l.nc), a.setAttribute("data-webpack", n + i), a.src = e), o[e] = [t];
            var u = (t, i) => {
                    a.onerror = a.onload = null, clearTimeout(p);
                    var n = o[e];
                    if (delete o[e], a.parentNode && a.parentNode.removeChild(a), n && n.forEach((e => e(i))), t) return t(i)
                },
                p = setTimeout(u.bind(null, void 0, {
                    type: "timeout",
                    target: a
                }), 12e4);
            a.onerror = u.bind(null, a.onerror), a.onload = u.bind(null, a.onload), s && document.head.appendChild(a)
        }
    }, l.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, l.p = "https://js.smile.io/v1/", (() => {
        var e = {
            runtime: 0
        };
        l.f.j = (t, i) => {
            var o = l.o(e, t) ? e[t] : void 0;
            if (0 !== o)
                if (o) i.push(o[2]);
                else if ("runtime" != t) {
                var n = new Promise(((i, n) => o = e[t] = [i, n]));
                i.push(o[2] = n);
                var r = l.p + l.u(t),
                    a = new Error;
                l.l(r, (i => {
                    if (l.o(e, t) && (0 !== (o = e[t]) && (e[t] = void 0), o)) {
                        var n = i && ("load" === i.type ? "missing" : i.type),
                            r = i && i.target && i.target.src;
                        a.message = "Loading chunk " + t + " failed.\n(" + n + ": " + r + ")", a.name = "ChunkLoadError", a.type = n, a.request = r, o[1](a)
                    }
                }), "chunk-" + t, t)
            } else e[t] = 0
        }, l.O.j = t => 0 === e[t];
        var t = (t, i) => {
                var o, n, [r, a, s] = i,
                    d = 0;
                if (r.some((t => 0 !== e[t]))) {
                    for (o in a) l.o(a, o) && (l.m[o] = a[o]);
                    if (s) var c = s(l)
                }
                for (t && t(i); d < r.length; d++) n = r[d], l.o(e, n) && e[n] && e[n][0](), e[n] = 0;
                return l.O(c)
            },
            i = self.webpackChunksmile_ui = self.webpackChunksmile_ui || [];
        i.forEach(t.bind(null, 0)), i.push = t.bind(null, i.push.bind(i))
    })(), l.nc = void 0
})(), (async () => {
    let e = (() => {
            let e = navigator.userAgent;
            return e && e.headers && "string" == typeof e.headers["user-agent"] && (e = e.headers["user-agent"]), "string" == typeof e && (/(android|bb\d+|meego).+mobile|armv7l|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series[46]0|samsungbrowser|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(e) && !/CrOS/.test(e))
        })(),
        t = () => e ? "mobile" : "desktop",
        i = {
            square: 0,
            shaved: 5,
            rounded: 10,
            circular: 30
        },
        o = () => {
            ["smile-shopify-0bf3986314b8d662727a.modern.js", "vendor-108ef4307b9453682b2b.modern.js"].map((e => window.dispatchEvent(new CustomEvent("smile:load-async-script", {
                detail: e
            }))))
        },
        [n, r] = await Promise.all([window.__smile_ui_init_data__, window.__smile_ui_customer_data__]);
    if ((e => {
            if (!e || e.account.load_js_sdk_at_launch) return !0;
            let t = document.getElementsByClassName("sweettooth-points-balance").length > 0,
                i = (o = e.nudges, n = window.location.pathname, o ? o.filter((function(e) {
                    return n.indexOf(e.url_path) > -1
                })) : []).length > 0;
            var o, n;
            let r = new URLSearchParams(window.location.search);
            return r.get("smile_deep_link") || r.get("st_intent") || document.querySelector("[data-smile-deep-link]") || window.location.hash.includes("smile-") || t || i
        })(n) || !((e, i) => {
            if (i && "disabled" === i.customer.state) return !1;
            let o = window.location.pathname,
                n = e.launcher.is_visible,
                r = e.launcher.visibility_setting.includes(t()),
                a = e.launcher.hide_on_index_page && "/" === o,
                l = e.launcher.hidden_url_paths.every((e => -1 === o.indexOf(e)));
            return n && r && !a && l
        })(n, r)) return o();
    window.addEventListener("hashchange", (e => {
        new URL(e.newURL).hash.startsWith("#smile-") && o()
    })), (n => {
        let {
            display_setting: r,
            launcher: a
        } = n, l = `smile_ui_${t()}_`, s = `border:0;outline:0;position:fixed;height:60px;z-index:0;overflow:hidden;box-shadow:0 0 25px 0 rgb(0 0 0 / 5%);${r[`${l}position`]}:${r[`${l}side_margin`]};bottom:${r[`${l}bottom_margin`]};border-radius:${i[a.border_radius_style]}px !important;`, d = document.createRange().createContextualFragment('<div id="smile-ui-lite-container"style="position:fixed;width:0;height:0;bottom:0;right:0;z-index:2147483647"aria-live="polite"><style>@keyframes smileLiteFadeInOut{from{opacity:0;transform:scale(.8)}to{opacity:1;transform:scale(1)}}#smile-ui-lite-launcher-frame-container{animation:smileLiteFadeInOut .2s ease-in-out!important;animation-delay:150ms!important;animation-fill-mode:forwards!important;transition:all .2s ease-in-out!important;opacity:0}#smile-ui-lite-launcher-frame-container.smile-improved-mobile-launcher{height:44px!important}</style><div id="smile-ui-lite-launcher-frame-container"><iframe title="Smile.io Rewards Program Launcher"id="smile-lite-launcher-frame"style="position:absolute;height:0;max-height:100%;max-width:100%;min-height:100%;min-width:100%;width:0;border:0;outline:0;top:0;right:0;bottom:0;left:0"></iframe></div></div>');
        d.getElementById("smile-ui-lite-launcher-frame-container").style.cssText = s, document.body.appendChild(d), (t => {
            let {
                launcher: n,
                account: r
            } = t, a = e && "text" === n.mobile_layout || !e && n.layout.includes("text"), l = e && "text" !== n.mobile_layout || !e && ("image" === n.layout || "text_and_icon" === n.layout), s = e && r.uses_improved_mobile_launcher ? "smile-improved-mobile-launcher" : "", d = e && r.uses_improved_mobile_launcher ? n.mobile_text : n.text, c = "<!doctypehtml><html lang=\"en-US\"><head><meta charset=\"utf-8\"><meta content=\"width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no\"name=\"viewport\"><style>@font-face{font-family:'Proxima Nova';font-style:normal;font-weight:400;font-display:block;src:local('Proxima Nova'),url('https://js.smile.io/v1/assets/fonts/proximanova-regular.woff2') format('woff2'),url('https://js.smile.io/v1/assets/fonts/proximanova-regular.woff') format('woff');unicode-range:U+000-5FF}*,::after,::before{box-sizing:border-box}:root{-moz-tab-size:4;tab-size:4}body,html{height:100%}html{line-height:1.15;-webkit-text-size-adjust:100%}body{margin:0;font-family:'Proxima Nova',arial,sans-serif;font-size:14px}button::-moz-focus-inner{border-style:none;padding:0}button:-moz-focusring{outline:1px dotted ButtonText}button{font-family:inherit;margin:0;text-transform:none;-webkit-appearance:button;height:60px;max-height:60px;line-height:30px;min-width:60px;display:inline-flex;align-items:center;position:fixed;bottom:0;text-align:center;font-size:16px;padding:15px 20px;border:none;outline:0;user-select:none;cursor:pointer;white-space:nowrap}button.smile-improved-mobile-launcher{height:44px;min-width:44px;padding:12px}button img{width:30px;height:30px}button.smile-improved-mobile-launcher img{width:20px;height:20px}button img+span{margin-left:12px}button:focus{position:relative}.close-icon{background-image:url(\"data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20'%3E%3Cpath fill='%23FFF' fill-rule='nonzero' d='M11.06 10l3.713 3.712a.75.75 0 0 1-1.06 1.061L10 11.061l-3.712 3.712a.75.75 0 0 1-1.061-1.06L8.939 10 5.227 6.288a.75.75 0 1 1 1.06-1.061L10 8.939l3.712-3.712a.75.75 0 0 1 1.061 1.06L11.061 10z'/%3E%3C/svg%3E\");height:26px;width:26px;padding:6px;margin:17px;position:absolute;top:0;right:0;left:0;bottom:0;background-size:100%;background-repeat:no-repeat;background-position:50%}</style><title></title></head><body></body></html>".replace("</body>", `<button aria-label="Open Smile.io Rewards Program" class="${s}" style="background-color:${n.color};color:${n.text_color};border-radius:${i[n.border_radius_style]}px;${l&&!a?"padding:15px":""}">\n        ${(l?`<img src="${n.icon_url}?color=${encodeURIComponent(n.text_color)}" role="presentation">`:"")+(a?`<span>${d}</span>`:"")}\n      </button></body>`), m = t.display_setting && t.display_setting.customer_locale;
            m && c.replace('lang="en-US"', `lang="${m}"`);
            let u = document.getElementById("smile-lite-launcher-frame");
            u.addEventListener("load", (() => {
                let e = u.contentDocument.querySelector("button"),
                    t = document.getElementById("smile-ui-lite-launcher-frame-container");
                t.style.width = `${e.offsetWidth}px`, s && t.classList.add(s), e.addEventListener("click", o, {
                    once: !0
                })
            })), u.srcdoc = c
        })(n), document.addEventListener("smile-ui-loaded", (() => {
            new MutationObserver((function(e, t) {
                if (!e.find((e => e.target && "smile-ui-container" === e.target.id))) return;
                window.SmileUI && window.SmileUI.openPanel({
                    data: {
                        trigger: "launcher"
                    }
                });
                let i = document.getElementById("smile-ui-lite-container");
                i.parentNode.removeChild(i), t.disconnect()
            })).observe(document.body, {
                attributes: !1,
                childList: !0,
                subtree: !0
            })
        }))
    })(n), (() => {
        let e = document.createElement("link").relList,
            t = !!(e && e.supports && e.supports("prefetch"));

        function i(e) {
            let i = document.createElement("link");
            i.href = "https://js.smile.io/v1/" + e, i.setAttribute("crossorigin", ""), t ? i.rel = "prefetch" : (i.rel = "preload", i.as = "script"), document.querySelector("head").appendChild(i)
        }
        i("smile-shopify-0bf3986314b8d662727a.modern.js"), i("vendor-108ef4307b9453682b2b.modern.js")
    })()
})();