(self.webpackChunksmile_ui = self.webpackChunksmile_ui || []).push([
    ["src_smile-ui_app_containers_Nudges_tsx"], {
        50679: (e, t, s) => {
            "use strict";
            s.r(t), s.d(t, {
                default: () => Z
            });
            var i = s(80222),
                r = s.n(i),
                n = s(8446),
                a = s.n(n),
                l = s(86),
                u = s.n(l),
                o = s(66870),
                d = s.n(o),
                c = s(29747),
                m = s.n(c),
                g = s(96718),
                h = s.n(g),
                p = s(26171),
                _ = s(14418),
                f = s.n(_),
                b = s(37659),
                v = s.n(b),
                y = s(87198),
                w = s.n(y),
                N = s(28222),
                L = s.n(N),
                C = s(68817),
                D = s.n(C),
                k = s(63805),
                E = s.n(k),
                P = s(59748),
                M = s(96561),
                $ = s(50558),
                H = s(57729),
                S = s(28044),
                x = s(86896);
            const R = e => {
                const t = (0, x.Z)().formatMessage({
                    id: "dismiss.label",
                    defaultMessage: "Dismiss"
                });
                return P.default.createElement("div", {
                    className: `dismiss-button-container ${e.className||""}`
                }, P.default.createElement("div", {
                    className: `dismiss-button ${e.className||""}`,
                    tabIndex: 0,
                    role: "button",
                    onClick: e.onClick,
                    onKeyDown: e.onKeyDown,
                    "aria-label": t
                }, P.default.createElement("span", {
                    className: "dismiss-button-icon"
                })))
            };
            var F = s(35887),
                I = s(3210),
                A = s(78381);

            function U(e, t) {
                var s = L()(e);
                if (r()) {
                    var i = r()(e);
                    t && (i = f()(i).call(i, (function(t) {
                        return a()(e, t).enumerable
                    }))), s.push.apply(s, i)
                }
                return s
            }

            function W(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var s, i, r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u()(s = U(Object(r), !0)).call(s, (function(t) {
                        (0, p.Z)(e, t, r[t])
                    })) : d() ? m()(e, d()(r)) : u()(i = U(Object(r))).call(i, (function(t) {
                        h()(e, t, a()(r, t))
                    }))
                }
                return e
            }
            let K = localStorage.getItem("smile_increase_account_creation_nudge");
            const O = (e, {
                customerAuthToken: t
            }) => {
                let s = function(e) {
                        var t = window.location.pathname;
                        return e ? e.filter((function(e) {
                            return t.indexOf(e.url_path) > -1
                        })) : []
                    }(e),
                    i = f()(s).call(s, (e => e.requires_customer ? t : !t));
                return {
                    availableNudges: i,
                    currentNudge: i[0] || null
                }
            };
            class V extends P.Component {
                constructor(e) {
                    super(e), this.urlHasDeepLink = () => {
                        let e = new(v())(window.location.search),
                            t = e.get("smile_deep_link"),
                            s = e.get("st_intent"),
                            i = this.queryParamPrompt;
                        return !!(t || s || i)
                    }, this.accessibilityKeyboardListener = e => {
                        9 === e.keyCode && (this.setState({
                            accessibilityClass: "accessibility-nav-keyboard"
                        }), this.frameWindow.removeEventListener("keydown", this.accessibilityKeyboardListener), this.frameWindow.addEventListener("mousedown", this.accessibilityMouseListener), this.frameWindow.addEventListener("touchstart", this.accessibilityMouseListener, {
                            passive: !0
                        }))
                    }, this.accessibilityMouseListener = () => {
                        this.setState({
                            accessibilityClass: "accessibility-nav-mouse"
                        }), this.frameWindow.removeEventListener("mousedown", this.accessibilityMouseListener), this.frameWindow.removeEventListener("touchstart", this.accessibilityMouseListener, {
                            passive: !0
                        }), this.frameWindow.addEventListener("keydown", this.accessibilityKeyboardListener)
                    }, this.fetchDataForNudges = e => {
                        let {
                            fetchCustomerPointsProducts: t,
                            fetchLatestUnusedRewardFulfillment: s,
                            sessionAuthData: i
                        } = this.props;
                        return {
                            increase_points_spending: () => t(i),
                            increase_reward_usage: () => s(i)
                        }[e.delivery_type] || A.E
                    }, this.handleCurrentNudgeDismissal = () => {
                        let {
                            dismissNudge: e,
                            clearNudges: t,
                            launcherInstance: s,
                            previewMode: i,
                            toggleLauncherState: r
                        } = this.props;
                        i || (e(), w()((() => {
                            t(), r(!s.isOpen)
                        }), H.Uk))
                    }, this.handleCurrentNudgeDismissalViaKeyboard = e => {
                        "Esc" !== e.key && "Escape" !== e.key || this.handleCurrentNudgeDismissal()
                    }, this.renderNudgesHeight = () => {
                        if (!this.nudgesContainer || !this.nudgesContainer.current) return;
                        let e = this.nudgesContainer.current.ownerDocument.querySelector(".nudges-body .frame-content").offsetHeight;
                        this.setState({
                            nudgeFrameHeight: e
                        })
                    }, this.state = {
                        isMobile: E()(),
                        nudgeFrameHeight: 335,
                        accessibilityClass: "accessibility-nav-keyboard",
                        availableNudges: e.nudges.availableNudges
                    }, this.nudgesContainer = P.default.createRef()
                }
                componentDidMount() {
                    let {
                        nudges: e,
                        previewMode: t,
                        sessionAuthData: s,
                        setCurrentNudge: i,
                        prompt: r,
                        clearNudges: n
                    } = this.props;
                    if (t) return;
                    if (r.isAvailable || this.urlHasDeepLink()) return void n();
                    window.addEventListener("resize", this.renderNudgesHeight);
                    let {
                        availableNudges: a,
                        currentNudge: l
                    } = O(e.availableNudges, s);
                    if (null !== l) {
                        var u, o, d;
                        this.setState({
                            availableNudges: a
                        });
                        let e = this.fetchDataForNudges(l)(),
                            t = D()("discount_code");
                        if ("increase_reward_usage" === (null == l ? void 0 : l.delivery_type) && t) e.then((() => {
                            let e = this.props.customer.latestUnusedRewardFulfillment.code;
                            t !== e && i(l)
                        }));
                        else if ("increase_guest_referral_url_sharing" === (null == l ? void 0 : l.delivery_type) && null != (u = window.SmileUI.platformAttributes) && u.isOrderStatusPage && null != (o = this.context.displaySettings) && null != (d = o.featureFlags) && d.usesGuestReferralNudge) {
                            var c;
                            i(l), null == (c = window.SmileUI.platformAttributes) || c.identifyGuest({}).then((e => {
                                (0, H.FN)(!0), this.triggerNudgeAsPrompt({
                                    customer: null == e ? void 0 : e.customer
                                })
                            }))
                        } else i(l)
                    }
                }
                componentDidUpdate() {
                    let e, {
                            clearNudges: t,
                            customer: s,
                            currentNudgeReady: i,
                            nudges: r,
                            latestUnusedRewardFulfillmentHasLoaded: n,
                            pointsProducts: a,
                            pointsProductsHaveLoaded: l,
                            rewardPrograms: u,
                            setCurrentNudge: o,
                            setCurrentNudgeReady: d,
                            smileUICustomerHasLoaded: c,
                            previewMode: m,
                            prompt: g
                        } = this.props,
                        {
                            availableNudges: h
                        } = this.state;
                    if (m && r.currentNudge && r.isVisible && i) {
                        d(!1);
                        let e = {};
                        return "increase_guest_referral_url_sharing" === r.currentNudge.delivery_type && (e = {
                            customer: s
                        }), void this.triggerNudgeAsPrompt(e)
                    }
                    if (r.currentNudge && r.isVisible && !i) {
                        var p, _, b;
                        if (g.isAvailable || this.urlHasDeepLink()) return void t();
                        const i = null == (p = u.referrals_program) ? void 0 : p.is_enabled,
                            v = null == (_ = u.points_program) ? void 0 : _.is_enabled,
                            y = null == (b = u.milestone_vip_program) ? void 0 : b.is_enabled,
                            w = i || v || y;
                        switch (r.currentNudge.delivery_type) {
                            case "increase_reward_usage":
                                n && c && (null === s.latestUnusedRewardFulfillment ? e = !1 : w && (e = !0));
                                break;
                            case "increase_points_spending":
                                if (l && c) {
                                    e = f()(a).call(a, (e => !0 === e.can_afford)).length >= 1 && v
                                }
                                break;
                            case "increase_referral_url_sharing":
                                c && (e = i);
                                break;
                            case "increase_account_creation":
                                let t = !1;
                                try {
                                    t = JSON.parse(K)
                                } catch (e) {
                                    localStorage.removeItem("smile_increase_account_creation_nudge")
                                }
                                if (!0 !== t || m) {
                                    if (w) {
                                        if (!m) try {
                                            localStorage.setItem("smile_increase_account_creation_nudge", !0)
                                        } catch (e) {}
                                        e = !0
                                    }
                                } else e = !1
                        }
                        if (!1 === e) {
                            let e = f()(h).call(h, (e => r.currentNudge.id !== e.id));
                            this.setState({
                                availableNudges: e
                            }), e.length > 0 ? (o(e[0]), this.fetchDataForNudges(e[0])()) : o({})
                        } else !0 === e && (d(!0), this.triggerNudgeAsPrompt())
                    }
                }
                triggerNudgeAsPrompt(e = {}) {
                    this.props.triggerPrompt({
                        type: "nudge",
                        data: W({
                            subType: this.props.nudges.currentNudge.delivery_type,
                            nudge: this.props.nudges.currentNudge
                        }, e)
                    })
                }
                componentWillUnmount() {
                    window.removeEventListener("resize", this.renderNudgesHeight), this.frameWindow && (this.frameWindow.removeEventListener("keydown", this.accessibilityKeyboardListener), this.frameWindow.removeEventListener("mousedown", this.accessibilityMouseListener), this.frameWindow.removeEventListener("touchstart", this.accessibilityMouseListener, {
                        passive: !0
                    }))
                }
                render() {
                    let {
                        currentNudgeReady: e,
                        launcherData: t,
                        launcherInstance: s,
                        nudges: i,
                        panelInstance: r,
                        panelData: n,
                        previewMode: a,
                        prompt: l,
                        rewardPrograms: u
                    } = this.props, {
                        nudgeFrameHeight: o,
                        accessibilityClass: d,
                        isMobile: c
                    } = this.state, {
                        displaySettings: m
                    } = this.context, {
                        button_font_color: g,
                        smile_ui_desktop_bottom_margin: h,
                        smile_ui_desktop_position: p,
                        smile_ui_desktop_side_margin: _,
                        smile_ui_mobile_bottom_margin: b,
                        smile_ui_mobile_position: v,
                        smile_ui_mobile_side_margin: y
                    } = m, w = _, N = h, C = p;
                    c && (w = y, N = b, C = v);
                    let D = null;
                    if (a) N = "5px", w = "5px", o = "387px", D = i.currentNudge && !r.isOpen;
                    else {
                        var k;
                        let t = f()(k = L()(u)).call(k, (e => u[e] && u[e].is_enabled));
                        D = i.currentNudge && i.currentNudge.id && !0 === e && !1 === l.isAvailable && t.length > 0 && !r.isOpen
                    }
                    let E = `smile-nudge-border-radius-${n.border_radius_style}`,
                        $ = `smile-button-border-radius-${n.button_border_radius_style}`,
                        H = `smile-input-border-radius-${n.input_border_radius_style}`,
                        x = `smile-theme-${m.theme}`,
                        I = `calc(${w} - 30px)`,
                        A = "",
                        U = F.t_ + F.wS;
                    s.isVisible || (U = 0, A = "smile-no-launcher");
                    let W = {
                        height: o,
                        bottom: `calc(${N} + ${U}px - 20px)`
                    };
                    "left" === C ? W.left = I : W.right = I;
                    let K = "smile-button-font-color-" + ("#000000" === g ? "dark" : "light");
                    return !0 === D && P.default.createElement("div", {
                        className: "smile-nudges-frame-container"
                    }, P.default.createElement(S.Z, {
                        initialContent: (0, F.FL)({
                            bodyClassName: `nudges-body nudges-body-${C}`
                        }),
                        title: "Smile.io Rewards Program Nudge",
                        className: `smile-nudges-frame ${A} smile-nudges-frame-${C}`,
                        style: W,
                        contentDidMount: this.renderNudgesHeight
                    }, P.default.createElement(M.Kr, null, (({
                        window: e
                    }) => {
                        this.frameWindow || (this.frameWindow = e, this.frameWindow.addEventListener("mousedown", this.accessibilityMouseListener), this.frameWindow.addEventListener("touchstart", this.accessibilityMouseListener, {
                            passive: !0
                        }))
                    })), P.default.createElement("div", {
                        className: `${E} ${$} ${H} ${x} ${K} ${d}`,
                        ref: this.nudgesContainer
                    }, P.default.createElement(R, {
                        className: `${a?"preview-mode":""} ${t.is_visible?"":"no-launcher"} ${this.state.isMobile?"mobile":""}`,
                        onClick: this.handleCurrentNudgeDismissal,
                        onKeyDown: this.handleCurrentNudgeDismissalViaKeyboard
                    }))))
                }
            }
            V.contextType = I.Z;
            const Z = (0, $.$j)((e => ({
                currentNudgeReady: e.currentNudgeReady,
                customer: e.customer,
                latestUnusedRewardFulfillmentHasLoaded: e.latestUnusedRewardFulfillmentHasLoaded,
                launcherData: e.launcherData,
                launcherInstance: e.launcherInstance,
                nudges: e.nudges,
                panelInstance: e.panelInstance,
                panelData: e.panelData,
                previewData: e.previewData,
                previewMode: e.previewMode,
                prompt: e.prompt,
                pointsProducts: e.pointsProducts,
                pointsProductsHaveLoaded: e.pointsProductsHaveLoaded,
                rewardPrograms: e.rewardPrograms,
                salesChannel: e.salesChannel,
                smileUICustomerHasLoaded: e.smileUICustomerHasLoaded,
                sessionAuthData: e.sessionAuthData
            })), (e => ({
                setCurrentNudgeReady: t => e((0, H.FN)(t)),
                dismissNudge: () => e((0, H.l)()),
                clearNudges: () => e((0, H.A_)()),
                fetchCustomerPointsProducts: t => e((0, H.hM)(t)),
                fetchLatestUnusedRewardFulfillment: t => e((0, H.Eb)(t)),
                setCurrentNudge: t => e((0, H.xE)(t)),
                toggleLauncherState: t => e((0, H.p2)(t)),
                triggerPrompt: t => e((0, H.m3)(t))
            })))(V)
        },
        68817: e => {
            e.exports = function(e) {
                if ("undefined" == typeof document) return null;
                var t, s = document.cookie,
                    i = s.search(new RegExp("\\b" + e + "=")),
                    r = s.indexOf(";", i);
                return ~i ? "{" === (t = decodeURIComponent(s.substring(i, ~r ? r : void 0).split("=")[1])).charAt(0) ? JSON.parse(t) : t : null
            }
        },
        86896: (e, t, s) => {
            "use strict";
            s.d(t, {
                Z: () => a
            });
            var i = s(59748),
                r = s(74806),
                n = s(680);

            function a() {
                var e = i.useContext(r._y);
                return (0, n.lq)(e), e
            }
        }
    }
]);