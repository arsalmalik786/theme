import type { IComponentRegistry } from './registry';
import { getComponentRegistry } from './registry';

export type ComponentRegistryBootstrap = (ComponentRegistry: IComponentRegistry) => void;

export const componentRegistryBootstrap = (bootstrap: ComponentRegistryBootstrap) => {
  const componentRegistry = getComponentRegistry();
  bootstrap(componentRegistry);
};
