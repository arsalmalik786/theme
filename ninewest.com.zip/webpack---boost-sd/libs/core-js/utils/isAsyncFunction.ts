import type { AnyFunction } from '../types';

export const isAsyncFunction = (fn: AnyFunction) => {
  return fn.constructor.name === 'AsyncFunction';
};
