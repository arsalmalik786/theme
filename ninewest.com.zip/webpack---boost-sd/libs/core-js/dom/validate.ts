export const isHTMLSupportRenderElement = (e: unknown): e is HTMLElement | HTMLElement[] => {
  if (Array.isArray(e)) {
    return e.some((e) => e instanceof HTMLElement);
  }

  return e instanceof HTMLElement;
};
