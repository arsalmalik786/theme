type BootstrapModuleExport<M> = {
  default: () => M;
};

function yieldToMain() {
  return new Promise((resolve) => {
    setTimeout(resolve, 0);
  });
}

const bootstrapModule = <P>(importer: () => Promise<BootstrapModuleExport<P>>) => {
  return function lazyImport() {
    return new Promise((resolve) => {
      importer().then(({ default: bootstrap }) => {
        const r = bootstrap();
        resolve(r);
      });
    });
  };
};

export const bootstrapAppModules = async () => {
  const tasks = [
    bootstrapModule(() => import(/* webpackPrefetch: true */ './registry/bootstrap')),
    bootstrapModule(() => import(/* webpackPrefetch: true */ './logger/bootstrap')),
    bootstrapModule(() => import(/* webpackPrefetch: true */ './history/bootstrap')),
    bootstrapModule(() => import(/* webpackPrefetch: true */ './translation/bootstrap')),
  ];

  while (tasks.length > 0) {
    // Shift the first task off the tasks array:
    const task = tasks.shift();

    if (task) {
      await task();
    }

    // Yield to the main thread:
    await yieldToMain();
  }
};
