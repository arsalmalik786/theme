import { setupAppHistory } from '@boost-sd/core-js/history';

export const bootstrapAppHistory = () => {
  setupAppHistory();
};

export default bootstrapAppHistory;
