/*
 Copyright(c) 2023 TransUnion LLC. All Rights Reserved. 80808bae-d4c3-47ac-9929-5d77264d823c
*/
(function() {
    (function c() {
        var a = window,
            b = a.io_global_object_name || "IGLOO";
        a = a[b] = a[b] || {};
        a = a.io = a.io || {};
        b = a.io_ddp;
        if (a.logoMain) return !1;
        a.logoMain = c;
        a.logoVer = "5.7.0";
        b && b._if_ubb && (b._CTOKEN = "j4VY/6TJuMpRu8mxBivjZ1BNbSwozzxdZScERrzleL8=", b._if_ubb());
        try {
            a.api.io_bb.add("LID", "WLM3/jdvEtOswOtT6sIMBL27mx5Ds/pY2kXE3hLOHOvtnDF4Wrw0LK2Y729oZXicChD0UeJtVd4OEJP99ydP4Q==")
        } catch (d) {}
    })();
}).call(this);