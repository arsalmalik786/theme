"use strict";
(self.boostSDAppLibWp = self.boostSDAppLibWp || []).push([
    [973], {
        8973: (p, s, t) => {
            t.r(s), t.d(s, {
                bootstrapAppHistory: () => b,
                default: () => i
            });
            var o = t(4822);
            const b = () => {
                    (0, o.iT)()
                },
                i = b
        }
    }
]);
//# sourceMappingURL=973.e5ac88816d46fd09ae03.js.map