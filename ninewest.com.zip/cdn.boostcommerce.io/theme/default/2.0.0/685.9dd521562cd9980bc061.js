"use strict";
(self.boostSDAppLibWp = self.boostSDAppLibWp || []).push([
    [685], {
        8685: (o, t, s) => {
            s.r(t), s.d(t, {
                bootstrapAppRegistry: () => _,
                default: () => a
            });
            var i = s(7409);
            const _ = () => {
                    "__BoostCustomization__" in window && (Array.isArray(window.__BoostCustomization__) ? window.__BoostCustomization__ : [window.__BoostCustomization__]).forEach((o => (o => {
                        o((0, i.bv)())
                    })(o)))
                },
                a = _
        }
    }
]);
//# sourceMappingURL=685.9dd521562cd9980bc061.js.map