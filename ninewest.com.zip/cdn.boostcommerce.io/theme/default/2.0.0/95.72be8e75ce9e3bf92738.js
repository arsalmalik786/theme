"use strict";
(self.boostSDAppLibWp = self.boostSDAppLibWp || []).push([
    [95], {
        7434: (e, t, n) => {
            n.r(t), n.d(t, {
                bootstrapAppLogger: () => r,
                default: () => g
            });
            var o = n(7409);
            class s {
                _enabled;
                constructor(e) {
                    this._enabled = e ? .enabled || !0;
                    l[e ? .namespace || "default"] = this
                }
                get enabled() {
                    return this._enabled
                }
                _guard = () => this._enabled;
                enable(e = !0) {
                    this._enabled = e
                }
                log = (...e) => {
                    this._guard() && console.log(...e)
                };
                logLevel = (e = "info", ...t) => {
                    this._guard() && console[e](...t)
                }
            }
            const l = {};
            new Proxy({}, {
                get(e, t) {
                    const n = ((e = "default") => {
                        const t = l[e];
                        if (t) return t;
                        console.warn("Logger hasn't been initialized")
                    })();
                    if (n) return Reflect.get(n, t)
                }
            });
            var a = n(9962);
            const r = () => {
                    const e = (0, a.hq)(),
                        t = (0, a.fZ)();
                    let n = !1;
                    "logger" in e ? n = e.logger : "development" === e.mode ? n = !0 : t ? .env && (n = "staging" === t.env);
                    const l = new s({
                        enabled: n,
                        namespace: "default"
                    });
                    (0, o.xr)("Logger", l)
                },
                g = r
        }
    }
]);
//# sourceMappingURL=95.72be8e75ce9e3bf92738.js.map