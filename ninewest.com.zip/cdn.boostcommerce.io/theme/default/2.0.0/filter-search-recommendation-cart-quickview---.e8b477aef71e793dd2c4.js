"use strict";
(self.boostSDAppLibWp = self.boostSDAppLibWp || []).push([
    [129], {
        7409: (e, t, n) => {
            n.d(t, {
                bv: () => E,
                r1: () => y,
                xr: () => C
            });
            n(6406), n(724), n(6728);
            var r = n(2322),
                o = n(2784),
                s = n(8316);
            class l extends o.Component {
                componentDidUpdate() {
                    try {
                        const e = (0, s.findDOMNode)(this);
                        (e instanceof Element || e instanceof NodeList || e instanceof Text) && Object.assign(this.props.innerRef, {
                            current: e
                        })
                    } catch {}
                }
                componentDidMount() {
                    try {
                        const e = (0, s.findDOMNode)(this);
                        (e instanceof Element || e instanceof NodeList || e instanceof Text) && Object.assign(this.props.innerRef, {
                            current: e
                        })
                    } catch {}
                }
                render() {
                    return this.props.children
                }
            }
            var u = n(7923),
                a = n(772),
                i = n(2592),
                c = n(5513);
            const f = e => !!e && ("object" == typeof e || "function" == typeof e) && "function" == typeof e.then,
                d = (0, o.createContext)(null);
            var p = n(6421);
            const m = function(e) {
                return (0, p.Z)(e, 4)
            };

            function g(e, t, n, r) {
                switch (t) {
                    case "transform":
                        {
                            const {
                                props: t,
                                style: r,
                                className: o
                            } = n.getParams(),
                            {
                                props: s,
                                style: l,
                                className: u
                            } = e;
                            let a = t,
                                i = r,
                                c = o;
                            if (s) {
                                const e = m(a);
                                a = s instanceof Function ? s(e, n) : s
                            }
                            return l && (i = l instanceof Function ? l(m(r || {}), n) : l),
                            u && (c = u instanceof Function ? u(o || "", n) : u),
                            {
                                props: a,
                                style: i,
                                className: c
                            }
                        }
                    case "before-init":
                        e.beforeInit && n.isInitialing() && e.beforeInit(n);
                        break;
                    case "before-render":
                        e.beforeRender && e.beforeRender(n);
                        break;
                    case "after-init":
                        e.afterInit && 1 === n.getRenderCount() && e.afterInit(n);
                        break;
                    case "after-render":
                        e.afterRender && e.afterRender(n);
                        break;
                    case "render":
                        if (e.render) return e.render(n, r);
                        break;
                    case "unmount":
                        e.unMount && e.unMount(n)
                }
            }
            const h = "BoostSDComponentRegistry",
                P = (0, a.Z)(window, h) || {
                    components: {},
                    modules: {},
                    queueModulesPluginInit: {},
                    getComponentOptionsInContext(e, t, n = {
                        exact: !0
                    }) {
                        const r = P.components[e];
                        if (!r) return void console.warn(`Component ${e} not found`);
                        if (!t || 0 === t.length) return r;
                        const o = Array.isArray(t) ? t : t.split(".");
                        let s = r.contexts[o[0]];
                        for (let l = 1; l < o.length; l++) {
                            const e = o[l];
                            if (!s ? .children[e]) {
                                if (n.exact) return;
                                return s
                            }
                            s = s.children[e]
                        }
                        return s
                    },
                    useComponentPlugin(e, t) {
                        (0, i.Z)(t).forEach((t => {
                            const n = e.split("."),
                                r = n.at(-1);
                            if (!r) return;
                            P.components[r] || (P.components[r] = {
                                name: r,
                                plugins: [],
                                contexts: {},
                                totalPlugins: 0,
                                disableDefaultRenderer: !1
                            });
                            const o = P.components[r],
                                s = Object.assign(t, {
                                    options: t.apply()
                                });
                            "enabled" in s || (s.enabled = !0);
                            const l = n.slice(0, -1);
                            if (0 === l.length) return o.plugins.push(s), void(o.totalPlugins += 1);
                            let u = o.contexts[l[0]] ? ? = {
                                plugins: [],
                                children: {}
                            };
                            if (l.length > 0)
                                for (let e = 1; e < l.length; e++) {
                                    const t = l[e];
                                    u.children[t] ? ? = {
                                        plugins: [],
                                        children: {}
                                    }, u = u.children[t]
                                }
                            u.plugins.push(s), o.totalPlugins += 1
                        }))
                    },
                    getComponentPluginsInContext(e, t, n) {
                        if (!e || !P.components[e]) return;
                        const r = P.components[e];
                        if (0 === r.totalPlugins) return [];
                        const o = [...r.plugins];
                        if (!t || 0 === t.length) return o;
                        const s = Array.isArray(t) ? t : t.split(".");
                        let l = r.contexts;
                        for (let u = 0; u < s.length; u++) {
                            const e = s[u];
                            l[e] && (o.push(...l[e].plugins), l = l[e].children)
                        }
                        return o.filter((e => !0 !== n ? .enabledOnly || !!e.enabled))
                    },
                    setComponentDebug(e, t = !0) {
                        const n = e.split("."),
                            r = n.at(-1);
                        if (!r) return;
                        const o = n.slice(0, -1),
                            s = P.getComponentOptionsInContext(r, o, {
                                exact: !1
                            });
                        s && (s.debug = t)
                    },
                    getParentElmByPath(e, t) {
                        const n = Array.isArray(t) ? t : t.split(".");
                        let r = e.getParentElm();
                        if (r && r.name === n.at(-1)) {
                            for (let e = n.length - 2; e >= 0; e--) {
                                r = r.getParentElm();
                                const t = n[e];
                                if (r ? .name !== t) return
                            }
                            return r
                        }
                    },
                    getNearestParentElm(e, t) {
                        let n = e.getParentElm();
                        for (; n ? .name !== t;) {
                            if (!n) return;
                            n = n.getParentElm()
                        }
                        return n
                    },
                    getChildElmByPath(e, t) {
                        const n = t.split(".");
                        let r = e;
                        for (let o = 0; o < n.length; o++) {
                            const e = n[o],
                                t = r.getElmRenderContextValue();
                            if (!t) break;
                            const s = (0, a.Z)(t.childrenContext, e);
                            if (!s || Array.isArray(s)) return;
                            const l = s() ? .element;
                            if (!l) return;
                            r = l
                        }
                        return r
                    },
                    useModulePlugin(e, t) {
                        const n = P.modules[e];
                        if (!n) return P.queueModulesPluginInit[e] || (P.queueModulesPluginInit[e] = []), void P.queueModulesPluginInit[e].push((() => {
                            P.useModulePlugin(e, t)
                        }));
                        const r = n.properties;
                        (0, i.Z)(t).forEach((e => {
                            const t = ((e, t) => {
                                    const n = {
                                            name: e.name,
                                            enabled: e.enabled,
                                            hooks: {
                                                methods: {}
                                            }
                                        },
                                        r = n.hooks.methods;
                                    return Object.keys(t).forEach((e => {
                                        "function" == typeof t[e] && (r[e] = {
                                            beforeMethodCall: new Set,
                                            methodFulfilled: new Set,
                                            methodPending: new Set,
                                            methodReject: new Set
                                        })
                                    })), n
                                })(e, r),
                                o = t.hooks.methods,
                                s = {
                                    on(e, t, n) {
                                        if ("function" == typeof r[t]) {
                                            const r = o[t][e];
                                            return r ? .add(n), () => {
                                                r ? .delete(n)
                                            }
                                        }
                                    }
                                };
                            e.apply(s), n.plugins.push(t)
                        }))
                    },
                    getModule(e, t) {
                        const n = P.modules[e];
                        if (n) return t ? .original ? n.__original : n.properties;
                        console.warn(`Module ${e} not found`)
                    }
                };
            (0, c.Z)(window, h, P);
            const b = window.requestIdleCallback || function(e) {
                    const t = Date.now();
                    return setTimeout((function() {
                        e({
                            didTimeout: !1,
                            timeRemaining: function() {
                                return Math.max(0, 50 - (Date.now() - t))
                            }
                        })
                    }), 1)
                },
                y = (e, t) => {
                    const n = P.components[e],
                        s = {
                            name: e,
                            totalPlugins: n ? .totalPlugins || 0,
                            plugins: n ? .plugins || [],
                            disableDefaultRenderer: n ? .disableDefaultRenderer || !1,
                            contexts: n ? .contexts || {},
                            CustomizedComponentHOC(n) {
                                const a = (0, o.useContext)(d),
                                    i = (0, o.useRef)(null),
                                    c = P.getComponentPluginsInContext(e, a ? .renderContextPath, {
                                        enabledOnly: !0
                                    }) || [],
                                    f = !!c ? .length,
                                    p = (0, o.useRef)(!1),
                                    h = (0, o.useRef)(!1),
                                    {
                                        rootElementRef: y,
                                        element: C,
                                        updateState: E
                                    } = (e => {
                                        const t = (0, o.useRef)(0),
                                            n = (0, o.useRef)(null),
                                            [, r] = (0, o.useState)({}),
                                            s = (0, o.useRef)(null),
                                            l = {
                                                style: e.renderState ? .style || {},
                                                className: e.renderState ? .className || "",
                                                props: { ...e.renderState ? .props,
                                                    helpersRef : e => {
                                                        s.current = e
                                                    }
                                                }
                                            },
                                            u = {
                                                name: e.name,
                                                isInitialing: () => 0 === t.current,
                                                getHelpers: () => s ? .current || {},
                                                getRenderCount: () => t.current,
                                                render() {
                                                    r({})
                                                },
                                                getRootElm: () => n.current,
                                                getParentElm: () => e.parent,
                                                getParams: () => m(l),
                                                getAppliedPlugins: () => e.plugins || [],
                                                getRenderContextPath: () => e.renderContextPaths,
                                                getElmRenderContextValue: e.getElmRenderContextValue
                                            };
                                        return (0, o.useEffect)((() => {
                                            t.current += 1
                                        })), (0, o.useEffect)((() => {
                                            const e = u.getRootElm();
                                            if (e instanceof HTMLElement) {
                                                const {
                                                    style: t,
                                                    className: n
                                                } = u.getParams();
                                                t && Object.assign(e.style, t), n && e.classList.add(...n.split(" ").filter(Boolean))
                                            }
                                        })), {
                                            element: u,
                                            rootElementRef: n,
                                            updateState: e => {
                                                const t = { ...l,
                                                    ...e
                                                };
                                                Object.assign(l, t)
                                            }
                                        }
                                    })({
                                        name: e,
                                        renderState: {
                                            props: n
                                        },
                                        plugins: c,
                                        parent: a ? .element,
                                        renderContextPaths: a ? .renderContextPath && [...a.renderContextPath],
                                        getElmRenderContextValue: () => i.current
                                    });
                                let R = s.disableDefaultRenderer ? null : (0, r.jsx)(t, { ...C.getParams().props
                                });
                                const x = (({
                                    element: e,
                                    enabled: t
                                }) => {
                                    const n = e.getRenderContextPath() ? .join(" > ") || e.name;
                                    return {
                                        logAction: (r, {
                                            onPhase: o,
                                            source: s
                                        }) => {
                                            if (!t) return r();
                                            console.group(`Component: %c${e.name}`, "color: cyan"), console.group(`On: %c${o}`, "color: LightGreen"), console.groupEnd(), console.group(`Context: %c${n}`, "color: orange"), console.groupEnd(), console.group(`From: %c${s}`, "color: ivory"), console.log("%cInput Rendering State", "color: NavajoWhite", e.getParams()), r(), console.log("%cOutput Rendering State", "color: NavajoWhite", e.getParams()), console.groupEnd(), console.groupEnd()
                                        }
                                    }
                                })({
                                    element: C,
                                    enabled: !!s.debug
                                });
                                if (f) {
                                    c.forEach((e => {
                                        x.logAction((() => {
                                            const t = g(e.options, "transform", C);
                                            E(t)
                                        }), {
                                            onPhase: "transform",
                                            source: e.name
                                        })
                                    })), C.isInitialing() && c.forEach((e => {
                                        x.logAction((() => {
                                            g(e.options, "before-init", C)
                                        }), {
                                            onPhase: "before-init",
                                            source: e.name
                                        })
                                    }));
                                    const e = C.getParams().props;
                                    R = R ? (0, o.cloneElement)(R, e) : null, c.forEach((e => {
                                        x.logAction((() => {
                                            e.options.render && (R = g(e.options, "render", C, R))
                                        }), {
                                            onPhase: "render",
                                            source: e.name
                                        })
                                    }))
                                }(0, o.useEffect)((function() {
                                    if (f) return c ? .forEach((e => {
                                        x.logAction((() => {
                                            g(e.options, "after-init", C)
                                        }), {
                                            onPhase: "after-init",
                                            source: e.name
                                        })
                                    })), () => {
                                        c ? .forEach((e => {
                                            x.logAction((() => {
                                                g(e.options, "unmount", C)
                                            }), {
                                                onPhase: "unmount",
                                                source: e.name
                                            })
                                        }))
                                    }
                                }), []), (0, o.useLayoutEffect)((function() {
                                    f && (h.current || (h.current = !0, c.forEach((e => {
                                        x.logAction((() => {
                                            g(e.options, "before-render", C)
                                        }), {
                                            onPhase: "before-render",
                                            source: e.name
                                        })
                                    })), h.current = !1))
                                })), (0, o.useEffect)((function() {
                                    f && (p.current || (p.current = !0, c ? .forEach((e => {
                                        x.logAction((() => {
                                            g(e.options, "after-render", C)
                                        }), {
                                            onPhase: "after-render",
                                            source: e.name
                                        })
                                    })), p.current = !1))
                                })), (0, o.useEffect)((function() {
                                    if (!f) return;
                                    const e = C.getRootElm();
                                    if (e) {
                                        const t = Object.keys(e).find((e => e.startsWith("__reactFiber$")));
                                        if (t) {
                                            const n = e[t];
                                            n.return ? .alternate && (n.return.alternate = new Proxy(n.return.alternate, {
                                                set: (e, t, n) => ("return" === t && (h.current || (h.current = !0, c ? .forEach((e => {
                                                    x.logAction((() => {
                                                        g(e.options, "before-render", C)
                                                    }), {
                                                        onPhase: "before-render",
                                                        source: e.name
                                                    })
                                                })), h.current = !1), p.current || (p.current = !0, b((() => {
                                                    c ? .forEach((e => {
                                                        x.logAction((() => {
                                                            g(e.options, "after-render", C)
                                                        }), {
                                                            onPhase: "after-render",
                                                            source: e.name
                                                        })
                                                    })), p.current = !1
                                                })))), Reflect.set(e, t, n))
                                            }))
                                        }
                                    }
                                }), [C.getRootElm(), f]), (0, o.useEffect)((() => {
                                    a && a.registryChildrenContext(e, (() => i.current))
                                }), []);
                                const A = (0, o.useRef)({});
                                return i.current || (i.current = {
                                    element: C,
                                    renderContextPath: [...a ? .renderContextPath || [], e],
                                    childrenContext: A.current,
                                    registryChildrenContext(e, t) {
                                        const n = A.current[e];
                                        n || (A.current[e] = t), n && !Array.isArray(n) && (A.current[e] = [n, t])
                                    }
                                }), (0, r.jsx)(d.Provider, {
                                    value: i.current,
                                    children: (0, r.jsx)(l, {
                                        innerRef: y,
                                        children: (M = R, (Array.isArray(M) ? M.some((e => e instanceof HTMLElement)) : M instanceof HTMLElement) ? (0, r.jsx)(u.c, {
                                            elements: R
                                        }) : R)
                                    })
                                });
                                var M
                            }
                        };
                    return s.CustomizedComponentHOC.displayName = e, P.components[e] = s, s.CustomizedComponentHOC
                },
                C = (e, t) => {
                    const n = ((e, t) => {
                        const n = {
                            name: e,
                            plugins: [],
                            __original: t,
                            properties: new Proxy(t, {
                                get(e, t) {
                                    if ("function" == typeof e[t]) {
                                        if (n.useOriginal) return Reflect.get(e, t);
                                        const r = t,
                                            o = n.plugins.reduce(((e, t) => {
                                                const n = t.hooks.methods[r] || {};
                                                return e.beforeMethodCall.push(...n.beforeMethodCall || []), e.methodPending.push(...n.methodPending || []), e.methodFulfilled.push(...n.methodFulfilled || []), e.methodReject.push(...n.methodReject || []), e
                                            }), {
                                                beforeMethodCall: [],
                                                methodPending: [],
                                                methodFulfilled: [],
                                                methodReject: []
                                            });
                                        return new Proxy(e[r], {
                                            apply: (e, t, n) => {
                                                const r = {
                                                    args: n,
                                                    result: null,
                                                    error: null
                                                };
                                                if ("AsyncFunction" === e.constructor.name) return new Promise((async (s, l) => {
                                                    await Promise.all(o.beforeMethodCall.map((e => e(r))));
                                                    const u = Reflect.apply(e, t, n);
                                                    if (f(u)) return r.result = null, r.error = null, await Promise.all(o.methodPending.map((e => e(r)))), u.then((async e => {
                                                        if (r.result = e, r.error = null, await Promise.all(o.methodFulfilled.map((e => e(r)))), null != r.error) return l(r.error);
                                                        s(r.result)
                                                    })).catch((async e => {
                                                        if (r.error = e, r.result = null, await Promise.all(o.methodReject.map((e => e(r)))), null != r.result) return s(r.result);
                                                        l(r.error)
                                                    }))
                                                }));
                                                o.beforeMethodCall.map((e => e(r)));
                                                const s = Reflect.apply(e, t, n);
                                                return r.result = s, r.error = null, o.methodFulfilled.map((e => e(r))), r.result
                                            }
                                        })
                                    }
                                    return Reflect.get(e, t)
                                }
                            })
                        };
                        return n
                    })(e, t);
                    return P.modules[e] = n, P.queueModulesPluginInit[e] ? .length && (P.queueModulesPluginInit[e].forEach((e => e())), P.queueModulesPluginInit[e] = []), n.properties
                },
                E = () => P
        },
        7923: (e, t, n) => {
            n.d(t, {
                c: () => o
            });
            var r = n(2784);
            const o = ({
                elements: e
            }) => {
                const t = (0, r.useRef)(),
                    n = (0, r.createElement)("template", {
                        ref: t
                    });
                return (0, r.useLayoutEffect)((() => {
                    const n = t.current;
                    n && n.parentNode && n.replaceWith(...Array.isArray(e) ? e : [e])
                })), n
            }
        }
    }
]);
//# sourceMappingURL=filter-search-recommendation-cart-quickview---.e8b477aef71e793dd2c4.js.map