(() => {
    "use strict";
    const t = "boostSDAnalytics",
        e = "boostSDSessionId",
        o = {
            VIEW_PRODUCT: "view_product",
            QUICK_VIEW: "quick_view",
            ADD_TO_CART: "add_to_cart",
            BUY_NOW: "buy_now"
        },
        n = "filter",
        r = "search",
        i = "suggest",
        l = "recommend",
        s = "boostSDRequestIdProductClickedKey",
        c = "boostSDRecommendationActiveKey";
    var d, a, u, v, g, p, f, b;
    const m = "boost-sd__",
        y = `.${m}suggestion-queries-item--product`,
        S = `.${m}product-item, .${m}product-item-list-view-layout`,
        _ = `.${m}recommendation`,
        A = `.${m}btn-quick-view`,
        D = (null === (a = boostSDAppConfig) || void 0 === a || null === (d = a.analytics) || void 0 === d ? void 0 : d.selectorAddToCart) ? null === (v = boostSDAppConfig) || void 0 === v || null === (u = v.analytics) || void 0 === u ? void 0 : u.selectorAddToCart : `.${m}btn-add-to-cart, form[action="/cart/add"] *[type="submit"], form[action="/cart/add"] *[name="add"]`,
        h = (null === (p = boostSDAppConfig) || void 0 === p || null === (g = p.analytics) || void 0 === g ? void 0 : g.selectorBuyNow) ? null === (b = boostSDAppConfig) || void 0 === b || null === (f = b.analytics) || void 0 === f ? void 0 : f.selectorBuyNow : `.${m}btn-buy-now, .shopify-payment-button__button, .shopify-payment-button, #dynamic-checkout-cart`,
        O = `.${m}quick-view`;

    function I(t, e, o) {
        return e in t ? Object.defineProperty(t, e, {
            value: o,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = o, t
    }

    function x(t) {
        for (var e = 1; e < arguments.length; e++) {
            var o = null != arguments[e] ? arguments[e] : {},
                n = Object.keys(o);
            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(o).filter((function(t) {
                return Object.getOwnPropertyDescriptor(o, t).enumerable
            })))), n.forEach((function(e) {
                I(t, e, o[e])
            }))
        }
        return t
    }
    var k = "";
    const w = localStorage.getItem(e);
    var C = w ? null == w ? void 0 : w.replaceAll('"', "") : "";
    w && (null == w ? void 0 : w.includes("")) && localStorage.setItem(e, null == w ? void 0 : w.replaceAll('"', ""));
    const T = () => "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (function(t) {
            var e = 16 * Math.random() | 0;
            return ("x" == t ? e : 3 & e | 8).toString(16)
        })),
        R = t => {
            try {
                const e = localStorage.getItem(t);
                return e ? JSON.parse(e) : null
            } catch (t) {
                return null
            }
        },
        N = (t, e) => {
            try {
                null != e ? localStorage.setItem(t, JSON.stringify(e)) : localStorage.setItem(t, "")
            } catch (t) {}
        },
        q = () => {
            var t, e;
            return "collection" === (null === (e = boostSDAppConfig) || void 0 === e || null === (t = e.generalSettings) || void 0 === t ? void 0 : t.page)
        },
        j = () => {
            var t, e;
            return "search" === (null === (e = boostSDAppConfig) || void 0 === e || null === (t = e.generalSettings) || void 0 === t ? void 0 : t.page)
        },
        E = () => {
            var t, e;
            return "product" === (null === (e = boostSDAppConfig) || void 0 === e || null === (t = e.generalSettings) || void 0 === t ? void 0 : t.page)
        },
        U = () => {
            let t = "";
            switch (!0) {
                case q():
                    t = "collection_page";
                    break;
                case j():
                    t = "search_page";
                    break;
                case E():
                    t = "product_page";
                    break;
                case (() => {
                    var t, e;
                    return "cart" === (null === (e = boostSDAppConfig) || void 0 === e || null === (t = e.generalSettings) || void 0 === t ? void 0 : t.page)
                })():
                    t = "cart_page";
                    break;
                case (() => {
                    var t, e;
                    return "index" === (null === (e = boostSDAppConfig) || void 0 === e || null === (t = e.generalSettings) || void 0 === t ? void 0 : t.page)
                })():
                    t = "home_page"
            }
            return t
        },
        W = t => {
            const e = R("boostSDRequestIdSaveInfoRequest");
            return e && e[t] ? e[t] : {
                query_string: "",
                action: "filter"
            }
        },
        P = (t, d, a, u = {}) => {
            let v = (null == u ? void 0 : u.rid) ? null == u ? void 0 : u.rid : ((t, e) => {
                let o = "";
                switch (e) {
                    case n:
                        o = "boostSDRequestIdFilterKey";
                        break;
                    case r:
                        o = "boostSDRequestIdSearchKey";
                        break;
                    case i:
                        o = "boostSDRequestIdSuggestKey";
                        break;
                    case l:
                        o = "boostSDRequestIdRecommendationKey"
                }
                if (!o) return "";
                if (e === l) {
                    const e = R(c);
                    if (e && e.pid === t) return e.rid
                }
                const s = R(o);
                if (s) {
                    const e = Object.keys(s);
                    for (let o = 0; o < e.length; o++) {
                        var d;
                        if (null === (d = s[e[o]]) || void 0 === d ? void 0 : d.includes(Number(t))) return e[o]
                    }
                }
                return ""
            })(t, a);
            if (a) {
                const e = ((t, e = 50) => {
                    let o = R(t) || {};
                    if (Object.keys(o).length >= e) {
                        const t = {},
                            n = Object.keys(o),
                            r = Object.values(o);
                        for (let o = 0; o < e; o++) t[n[o]] = r[o];
                        o = t
                    }
                    return o
                })(s, 3);
                e[Number(t)] && delete e[Number(t)];
                const o = x({
                    [Number(t)]: v
                }, e);
                N(s, o)
            }
            if (!a || !v) {
                const e = R(s);
                if (!e || !e[Number(t)]) return !1;
                v = e[Number(t)]
            }
            const g = W(v).query_string;
            d === o.QUICK_VIEW && (d = o.VIEW_PRODUCT), a || (a = W(v).action);
            const p = k;
            return x({
                tid: Shopify.shop,
                qs: g,
                eid: T(),
                rid: v,
                ct: p || localStorage.getItem("cartToken"),
                pid: t,
                t: (new Date).toISOString(),
                u: d,
                a: a || "other",
                r: document.referrer,
                sid: C || (C = T(), localStorage.setItem(e, C), C),
                cid: (null === (f = __st) || void 0 === f ? void 0 : f.id) || (null === (m = meta) || void 0 === m || null === (b = m.page) || void 0 === b ? void 0 : b.customerId) || (null === (_ = ShopifyAnalytics) || void 0 === _ || null === (S = _.meta) || void 0 === S || null === (y = S.page) || void 0 === y ? void 0 : y.customerId) || (null === (O = ShopifyAnalytics) || void 0 === O || null === (h = O.lib) || void 0 === h || null === (D = h.user()) || void 0 === D || null === (A = D.traits()) || void 0 === A ? void 0 : A.uniqToken),
                pg: U()
            }, u);
            var f, b, m, y, S, _, A, D, h, O
        },
        K = e => {
            var o = R(t);
            Array.isArray(o) || (o = []);
            const n = o.filter((t => t.pid != e.productId));
            n.push(e), N(t, n)
        };
    const B = (e, o) => {
            var n, r;
            const i = (null === (r = window.boostSDAppConfig) || void 0 === r || null === (n = r.api) || void 0 === n ? void 0 : n.analyticsUrl) || "https://lambda.mybcapps.com/e";
            if ("recommend" === e.a && ["add_to_cart", "buy_now"].includes(e.u) && localStorage.removeItem(c), o) return setTimeout((() => {
                return t = e, void fetch("/cart.js").then((t => t.json())).then((e => {
                    const o = e.token;
                    k = o, o && localStorage.setItem("cartToken", o), t && (t.ct = o, B(t, !1))
                })).catch((e => {
                    B(t, !1), console.log("error call refresh cartToken, send tracking without cart token", e)
                }));
                var t
            }), 1200);
            (async function(t = "", e = {}) {
                return (await fetch(t, {
                    method: "POST",
                    body: JSON.stringify(e)
                })).json()
            })(i, e).then((o => {
                (o.error = "") && (e => {
                    var o = R(t);
                    if (Array.isArray(o)) {
                        var n = o.filter((t => t.pid != e));
                        N(t, n)
                    }
                })(e.pid)
            }))
        },
        $ = t => {
            if (!t || !t.target) return;
            if ("keydown" == t.type && "Enter" !== t.key) return;
            const e = t.target.closest(y);
            if (!e) return;
            const n = e.getAttribute("data-id");
            if (!n) return;
            const r = P(n, o.VIEW_PRODUCT, i);
            K(r), B(r)
        };
    (t => {
        if (!t) return null;
        console.log("register event initInstantSearch"), document.addEventListener("click", $, !0), document.addEventListener("keydown", $, !0)
    })(!0);
    const V = t => {
        if (!t || !t.target) return;
        const e = t.target;
        let i = j() ? r : q ? n : l;
        if (e.closest(_) && (i = l), i !== l && E()) return;
        let s = o.VIEW_PRODUCT;
        e.closest(A) ? s = o.QUICK_VIEW : e.closest(h) ? s = o.BUY_NOW : e.closest(D) && (s = o.ADD_TO_CART);
        let d = "";
        const a = e.closest(S);
        var u;
        a ? d = a.getAttribute("id") || "" : s != o.ADD_TO_CART && s != o.BUY_NOW || (d = null === (u = e.closest(O)) || void 0 === u ? void 0 : u.getAttribute("product-id"));
        if (!d) return;
        if (e.closest(O)) {
            const t = R(c);
            t && d === t.pid && (i = l)
        }
        const v = {};
        if (i === l) {
            const t = e.closest(_),
                o = null == t ? void 0 : t.parentNode;
            if (null == o ? void 0 : o.id) {
                var g, p, f;
                const t = null === (g = o.id) || void 0 === g ? void 0 : g.replace("boost-sd-widget-", ""),
                    e = null === (p = o.classList[0]) || void 0 === p ? void 0 : p.replace("boost-sd-", "");
                v.wid = t, v.rt = e;
                const n = R("boostSDRequestIdMoreInformationKey");
                if ((null === (f = Object.keys(n)) || void 0 === f ? void 0 : f.length) > 0) {
                    var b;
                    const e = Object.keys(n).find((e => n[e].wid === t));
                    !v.rt && n[e] && (v.rt = null === (b = n[e]) || void 0 === b ? void 0 : b.rt), v.rid = e, N(c, {
                        rid: e,
                        wid: v.wid,
                        rt: v.rt,
                        pid: d
                    })
                }
            }
        }
        if (E() && [o.ADD_TO_CART, o.BUY_NOW].includes(s)) return;
        const m = P(d, s, i, v);
        K(m), B(m, [o.ADD_TO_CART, o.BUY_NOW].includes(s))
    };
    console.log("register event initCollectionSearchPage"), document.addEventListener("click", V, !0);
    const Y = t => {
        if (!t || !t.target) return;
        const e = t.target,
            n = e.closest(h);
        if (e.closest(D) || n) {
            var r, i, l;
            let t = {
                    pid: null === (l = boostSDAppConfig) || void 0 === l || null === (i = l.generalSettings) || void 0 === i || null === (r = i.product_id) || void 0 === r ? void 0 : r.toString(),
                    u: n ? o.BUY_NOW : o.ADD_TO_CART
                },
                c = "";
            const d = e.closest(_);
            if (d) {
                var s;
                const e = null === (s = d.parentElement) || void 0 === s ? void 0 : s.id;
                e && (c = "recommend", t.wid = e.replace("boost-sd-widget-", ""))
            }
            const a = e.closest(O);
            if (a) {
                const e = a.getAttribute("product-id");
                e && (t.pid = e, c = "recommend")
            }
            if (t = P(t.pid, t.u, c, t), !t) return;
            K(t), B(t, !0)
        }
    };
    E() && (console.log("register event initOtherPage"), document.addEventListener("click", Y, !0))
})();
//# sourceMappingURL=boost-sd-analytic.js.map