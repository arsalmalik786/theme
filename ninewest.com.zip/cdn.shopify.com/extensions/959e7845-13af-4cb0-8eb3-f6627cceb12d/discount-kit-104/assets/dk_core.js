class DiscountKit {
    CART_CHANGED_REGEX = /cart\/(add|update|change|clear)(?!.*app=discount_kit)/
    BASE_ENGINE_URL = 'https://engine.discountkit.app'
    // BASE_ENGINE_URL = 'http://127.0.0.1:8788'

    constructor(shop, rate) {
        this.shop = shop
        this.rate = rate
        this._events = {
            'discount_kit:engine_result': [],
            'discount_kit:cart_updated': [],
        }
        this.engineResult = []

        this.runEngine(this.shop, this.rate)

        this.interceptFetchRequest(this.CART_CHANGED_REGEX, () => {
            this.runEngine(this.shop, this.rate)
        })

        this.interceptXMLHttpRequest(this.CART_CHANGED_REGEX, () => {
            this.runEngine(this.shop, this.rate)
        })
    }

    on(event, listener) {
        if (!this._events[event]) {
            this._events[event] = []
        }
        this._events[event].push(listener)
        return () => {
            this._events[event] = this._events[event].filter((fn) => fn !== listener)
        }
    }

    publish(event, ...args) {
        if (!this._events[event]) {
            return
        }
        document.dispatchEvent(new CustomEvent(event, {
            detail: args
        }))
        this._events[event].forEach((listener) => {
            listener(...args)
        })
    }

    interceptFetchRequest(matches, cb) {
        const originalFetch = fetch

        window.fetch = async function(input, init) {
            return originalFetch(input, init).then((res) => {
                if (matches.test(res.url)) {
                    cb()
                }
                return Promise.resolve(res)
            })
        }
    }

    interceptXMLHttpRequest(matches, cb) {
        const originalOpen = XMLHttpRequest.prototype.open

        XMLHttpRequest.prototype.open = function() {
            this.addEventListener('load', function() {
                if (matches.test(this.responseURL)) {
                    cb()
                }
            })
            originalOpen.apply(this, arguments)
        }
    }

    async fetchCart() {
        const cartReq = await fetch(
            `${window.Shopify.routes.root}apps/discountkit/cart?app=discount_kit`
        )
        const {
            cart,
            item_collections: collections
        } = await cartReq.json()
        return {
            cart,
            collections
        }
    }

    async runEngine(shop, rate) {
        const {
            cart,
            collections
        } = await this.fetchCart()
        const engineResult = await this.fetchEngine(cart, collections, rate, shop)
        this.engineResult = engineResult
        this.publish('discount_kit:engine_result', {
            engineResult,
            cart,
            collections,
            customerTags: window.dKCustomerTags || [],
            customerB2b: window.dKCustomerB2b || false,
        })
    }

    async fetchEngine(cart, collections, rate, shop) {
        try {
            return await fetch(
                `${this.BASE_ENGINE_URL}/v1/storefront/run?shop=${shop}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        presentmentCurrencyRate: rate,
                        cart,
                        collections,
                        customerTags: window.dKCustomerTags || [],
                        customerB2b: window.dKCustomerB2b || false,
                    }),
                }
            ).then((res) => res.json())
        } catch (_e) {
            console.error(_e)
            return []
        }
    }
}

window.discountKit =
    window.discountKit ||
    new DiscountKit(window.Shopify.shop, window.Shopify.currency.rate)