class OrderGoalBanner extends HTMLElement {
    get locale() {
        return this.getAttribute('locale')
    }
    get editor() {
        return this.getAttribute('editor')
    }
    get spendT() {
        return this.getAttribute('spend')
    }
    get moreAndT() {
        return this.getAttribute('more_and')
    }
    get percentageSaveT() {
        return this.getAttribute('percentage_save')
    }
    get percentageCapT() {
        return this.getAttribute('percentage_cap')
    }
    get fixedSaveT() {
        return this.getAttribute('fixed_save')
    }
    get fixedCapT() {
        return this.getAttribute('fixed_cap')
    }

    async connectedCallback() {
        this.dkCheckInterval = setInterval(() => {
            if (window.discountKit) {
                this._unsub = window.discountKit.on(
                    'discount_kit:engine_result',
                    this.handleEngineResult.bind(this)
                )
                clearInterval(this.dkCheckInterval)
            }
        }, 100)
    }

    disconnectedCallback() {
        this._unsub()
    }

    async handleEngineResult(data) {
        const {
            engineResult
        } = data
        const discount =
            engineResult && engineResult.length ?
            engineResult.filter((d) => d.discountType === 'ORDER_GOAL')[0] :
            null
        if (discount) {
            Shopify.analytics.publish('dk_storefront_order_goal_view', {
                discount_id: discount.id,
            })
        }

        this.renderMessage(discount)
    }

    getText(nextTier, formatter) {
        return nextTier.gets.type === 'percentage' ?
            `${this.percentageSaveT} ${nextTier.gets.value}${this.percentageCapT}` :
            `${this.fixedSaveT} ${formatter.format(nextTier.gets.value / 100)} ${
          this.fixedCapT
        }`
    }

    renderMessage(discount) {
        const activeCurrency = window.Shopify.currency.active
        const formatter = Intl.NumberFormat(this.locale, {
            style: 'currency',
            currency: activeCurrency,
        })
        if (discount && discount.distance.nextTierIndex !== null) {
            const existingMessageContainer = this.querySelector('.dk-order-wrapper')
            if (!existingMessageContainer) {
                this.appendChild(this.querySelector('template').content.cloneNode(true))
            }
            const messageContainer = this.querySelector('.dk-order-text')

            const tiers = discount.config.tiers
            const nextTier = tiers[discount.distance.nextTierIndex]
            const distanceAmount = discount.distance.distanceToNextTier
            let getText = this.getText(nextTier, formatter)
            const calculatedCondition = formatter.format(distanceAmount / 100)
            messageContainer.innerHTML = `${this.spendT} ${calculatedCondition} ${this.moreAndT} ${getText}`
        } else {
            const existingMessageContainer = this.querySelector('.dk-order-wrapper')
            if (existingMessageContainer) this.removeChild(existingMessageContainer)
        }
    }
}

customElements.define('order-goal-banner', OrderGoalBanner)