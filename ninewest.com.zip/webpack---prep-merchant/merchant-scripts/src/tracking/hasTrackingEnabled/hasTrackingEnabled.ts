import getScriptElement from '../../utils/ScriptDetection/v2/getScriptElement/getScriptElement'

export default function hasTrackingEnabled(): boolean {
  const element = getScriptElement()
  return element?.getAttribute('data-enable-tracking') === 'true'
}