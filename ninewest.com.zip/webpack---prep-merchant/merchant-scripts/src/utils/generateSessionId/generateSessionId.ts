// Separate file for testability in order to create a global mock
// The mock is defined in tests/helpers/setup-unit.ts
// https://github.com/ai/nanoid/issues/363

import { customAlphabet } from 'nanoid'

export const generateSessionId = customAlphabet('useandom26T198340PX75pxJACKVERYMINDBUSHWOLFGQZbfghjklqvwyzrict', 21)
