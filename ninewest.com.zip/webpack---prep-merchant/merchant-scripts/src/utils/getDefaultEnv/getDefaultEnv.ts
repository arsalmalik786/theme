export default function getDefaultEnv() {
  return `${process.env.ENVIRONMENT}`.split('-').pop()
}