export default function request(url: string, forceReload = false): Promise<any> {
  return fetch(
    url,
    {
      cache: forceReload ? 'reload' : 'default'
    }
  )
    .then(r => r?.text?.())
    .then(responseText => (responseText ? JSON.parse(responseText) : null))
}