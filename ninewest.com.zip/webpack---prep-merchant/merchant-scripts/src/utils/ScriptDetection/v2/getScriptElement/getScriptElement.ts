const SCRIPT_TAG_CSS_SELECTOR = process.env.ENVIRONMENT === 'test'
  ? 'script[src*="test"][src*="/lib.js"]'
  : 'script[src*="klarnaservices"][src*="/lib.js"],script[src*="pre-purchase"][src*="/lib.js"]'

export default function getScriptElement(): HTMLScriptElement {
  return document.currentScript as HTMLScriptElement || document.querySelector(SCRIPT_TAG_CSS_SELECTOR)
}