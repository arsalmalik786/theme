export function shouldUseShadowDom() {
  return window.localStorage.getItem('USE_SHADOW_DOM') !== 'false'
}