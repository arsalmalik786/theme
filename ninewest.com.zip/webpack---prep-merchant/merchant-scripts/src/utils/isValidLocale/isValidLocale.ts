import config from '../../config'

export default function isValidLocale(locale?: string): boolean {
  return config.SUPPORTED_LOCALES.map((l: string) => l.toLowerCase()).includes(locale?.toLowerCase())
}
