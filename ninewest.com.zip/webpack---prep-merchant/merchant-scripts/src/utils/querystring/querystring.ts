import querystringify from 'querystringify'

export const { parse } = querystringify

export const stringify = (obj: object) => {
  const o = Object.fromEntries(Object.entries(obj).filter(([_, v]) => v !== null && v !== undefined))
  return querystringify.stringify(o)
}