import { CountryCode } from '../../types/Localization'
import { regionMapping } from './regionMapping'

export const getRegionFromLocale = (locale: string | null) => {
  // eslint-disable-next-line no-param-reassign
  locale = locale.replace('_', '-')
  const countryCode = locale.split('-')[1].toLowerCase() as CountryCode
  return regionMapping[countryCode]
}