import { stringify } from '../querystring/querystring'

export function buildHttpQuery(map: object): string {
  const o = stringify(map || {})
  return Object.keys(o).length ? `?${o}` : ''
}