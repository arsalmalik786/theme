import config from '../../../../config'
import cookies from '../../../../utils/cookies/cookies'
import getBaseUrl from '../../../../utils/getBaseUrl/getBaseUrl'
import getElementDataSet from '../../../../utils/getElementDataSet/v2/getElementDataSet'
import { buildHttpQuery } from '../../../../utils/url/url'

export default function getUrl(element: HTMLElement): string {
  const {
    key, locale, purchaseAmount, purchase_amount, messagePrefix, customPaymentMethodIds, ...nonObfuscatedAttributes
  } = getElementDataSet(element)
  const sessionId = cookies.getValue(config.COOKIE_SESSION_ID_NAME)

  const params = {
    ver: process.env.APP_VERSION,
    b: sessionId,
    d: key,
    e: locale,
    g: window.Klarna.OnsiteMessaging.clientId,
    purchase_amount: purchaseAmount || purchase_amount,
    message_prefix: messagePrefix,
    custom_payment_method_ids: customPaymentMethodIds,
    ...nonObfuscatedAttributes
  }

  const baseUrl = getBaseUrl(locale) || process.env.CMA_BASE_URL

  return `${baseUrl}/v3/i${buildHttpQuery(params)}`
}