import config from '../../../config'

export default function hasFontsLink(element: Element) {
  return element.querySelector(`link[rel=stylesheet][href="${config.KLARNA_FONTS_URL}"]`)
}