(self.webpackChunkclient = self.webpackChunkclient || []).push([
    [906], {
        112: (e, t, n) => {
            "use strict";
            n.d(t, {
                CK: () => r,
                Xq: () => a,
                _v: () => i
            });
            const a = (...e) => {
                    console.log("[klarna-osm]", ...e)
                },
                i = e => new Promise((t => setTimeout(t, e))),
                r = () => ["tmenu-app"].filter((e => !!document.getElementById(e)))
        },
        803: (e, t, n) => {
            "use strict";
            n.d(t, {
                Z: () => r
            });
            var a = n(112);
            const i = [
                    ["afterpay", ["afterpay.crucialcommerceapps.com/appJS", "static.afterpay.com/shopify-afterpay-javascript.js"]]
                ],
                r = {
                    async getCompetitorSelectors() {
                        const e = [],
                            t = await this.getFoundCompetitors();
                        return (0, a.Xq)("[getCompetitorSelectors] Got competitors", t), t.forEach((t => {
                            const n = this.getCompetitorElement(t);
                            n && e.push(n)
                        })), e
                    },
                    async getFoundCompetitors() {
                        await (0, a._v)(1500);
                        const e = [];
                        return document.querySelectorAll("script").forEach((t => {
                            i.forEach((([n, a]) => {
                                a.forEach((a => {
                                    t.src.includes(a) && !e.includes(n) && e.push(n)
                                }))
                            }))
                        })), e
                    },
                    getCompetitorElement(e) {
                        return (0, a.Xq)("[getCompetitorElement]", e), "afterpay" === e ? this.findAfterpayElement() : null
                    },
                    findAfterpayElement() {
                        var e;
                        let t = null;
                        if (window.afterpay_product_selector) return window.afterpay_product_selector;
                        if (window.Afterpay && window.Afterpay.supportedTheme && window.Afterpay.supportedTheme.product) {
                            (0, a.Xq)("[findAfterpayElement] Found window.Afterpay.supportedTheme");
                            const e = window.Afterpay.supportedTheme.product;
                            t = e[Object.keys(e).reduce(((e, t) => e && e > t ? e : t), "")].selector
                        } else window.Afterpay && void 0 === window.Afterpay.supportedTheme && window.Afterpay.commonElements.product && window.Afterpay.commonElements.product.price_selector && ((0, a.Xq)("[findAfterpayElement] Found window.Afterpay.commonElements"), t = null !== (e = window.Afterpay.commonElements.product.price_selector.find((e => {
                            try {
                                if (document.querySelector(e)) return e
                            } catch (e) {}
                            return null
                        }))) && void 0 !== e ? e : null);
                        return (0, a.Xq)("[findAfterpayElement] got productElement", t), t
                    }
                }
        },
        906: (e, t, n) => {
            "use strict";
            n.d(t, {
                default: () => g
            });
            var a = n(258),
                i = n(112),
                r = n(991);
            const o = {
                    "Europe/Vienna": "AT",
                    "Australia/Lord_Howe": "AU",
                    "Antarctica/Macquarie": "AU",
                    "Australia/Hobart": "AU",
                    "Australia/Currie": "AU",
                    "Australia/Melbourne": "AU",
                    "Australia/Sydney": "AU",
                    "Australia/Broken_Hill": "AU",
                    "Australia/Brisbane": "AU",
                    "Australia/Lindeman": "AU",
                    "Australia/Adelaide": "AU",
                    "Australia/Darwin": "AU",
                    "Australia/Perth": "AU",
                    "Australia/Eucla": "AU",
                    "Europe/Brussels": "BE",
                    "America/St_Johns": "CA",
                    "America/Halifax": "CA",
                    "America/Glace_Bay": "CA",
                    "America/Moncton": "CA",
                    "America/Goose_Bay": "CA",
                    "America/Blanc-Sablon": "CA",
                    "America/Toronto": "CA",
                    "America/Nipigon": "CA",
                    "America/Thunder_Bay": "CA",
                    "America/Iqaluit": "CA",
                    "America/Pangnirtung": "CA",
                    "America/Resolute": "CA",
                    "America/Atikokan": "CA",
                    "America/Rankin_Inlet": "CA",
                    "America/Winnipeg": "CA",
                    "America/Rainy_River": "CA",
                    "America/Regina": "CA",
                    "America/Swift_Current": "CA",
                    "America/Edmonton": "CA",
                    "America/Cambridge_Bay": "CA",
                    "America/Yellowknife": "CA",
                    "America/Inuvik": "CA",
                    "America/Creston": "CA",
                    "America/Dawson_Creek": "CA",
                    "America/Vancouver": "CA",
                    "America/Whitehorse": "CA",
                    "America/Dawson": "CA",
                    "Europe/Zurich": "CH",
                    "Europe/Prague": "CZ",
                    "Europe/Berlin": "DE",
                    "Europe/Busingen": "DE",
                    "Europe/Copenhagen": "DK",
                    "Europe/Madrid": "ES",
                    "Africa/Ceuta": "ES",
                    "Atlantic/Canary": "ES",
                    "Europe/Helsinki": "FI",
                    "Europe/Paris": "FR",
                    "Europe/Budapest": "HU",
                    "Europe/Rome": "IT",
                    "America/Mexico_City": "MX",
                    "America/Cancun": "MX",
                    "America/Merida": "MX",
                    "America/Monterrey": "MX",
                    "America/Matamoros": "MX",
                    "America/Mazatlan": "MX",
                    "America/Chihuahua": "MX",
                    "America/Ojinaga": "MX",
                    "America/Hermosillo": "MX",
                    "America/Tijuana": "MX",
                    "America/Santa_Isabel": "MX",
                    "America/Bahia_Banderas": "MX",
                    "Europe/Amsterdam": "NL",
                    "Arctic/Longyearbyen": "NO",
                    "Europe/Oslo": "NO",
                    "Europe/Warsaw": "PL",
                    "Europe/Lisbon": "PT",
                    "Atlantic/Madeira": "PT",
                    "Atlantic/Azores": "PT",
                    "Europe/Stockholm": "SE",
                    "Europe/Bratislava": "SK"
                },
                s = "klarnaosm_user_locale";
            class c {
                constructor(e) {
                    this.midLocales = e
                }
                static getCountryFromTimeZone() {
                    var e;
                    const {
                        timeZone: t
                    } = Intl.DateTimeFormat().resolvedOptions(), n = null !== (e = o[t]) && void 0 !== e ? e : null;
                    return n || (0, i.Xq)("[getCountryFromTimeZone] unsupported country or time zone", {
                        timeZone: t
                    }), n
                }
                static async getUsersCountry() {
                    let e = c.getCachedUsersCountry();
                    if (e) return (0, i.Xq)("Found users country in cache"), e;
                    try {
                        const t = new AbortController;
                        setTimeout((() => t.abort()), 1500);
                        const n = await fetch(r.GEOSERVICE_URL, {
                            signal: t.signal
                        });
                        if (!n.ok) throw new Error(n.statusText);
                        e = (await n.json()).country
                    } catch (e) {
                        return (0, i.Xq)("[getUsersCountry] Failed", e), (0, i.Xq)("[getUsersCountry] trying to parse from time zone"), this.getCountryFromTimeZone()
                    }
                    return e && c.setCachedUsersCountry(e), e
                }
                static getCachedUsersCountry() {
                    return localStorage.getItem(s) || null
                }
                static setCachedUsersCountry(e) {
                    (0, i.Xq)("Setting users country to cache", e), localStorage.setItem(s, e)
                }
                static findLocale(e, t, n) {
                    var a, r;
                    if (e) {
                        (0, i.Xq)("[getMatchingLocale] Valid locales for users country", e);
                        const o = null !== (a = e[0]) && void 0 !== a ? a : null;
                        let s = "";
                        if (t && "undefined" != typeof Shopify ? (s = Shopify.locale, (0, i.Xq)("[getMatchingLocale] Using Shopify.locale", s)) : navigator.language && (s = navigator.language.slice(0, 2), (0, i.Xq)("[getMatchingLocale] Using browser language", s)), s) {
                            const t = e.find((e => e.startsWith(s)));
                            if (t) return t
                        }
                        return n && null !== (r = e.find((e => e.startsWith("en")))) && void 0 !== r ? r : o
                    }
                    return null
                }
                getMatchingLocale(e, t, n) {
                    if (!e || !this.midLocales) return (0, i.Xq)("[getMatchingLocale] Invalid data", e, this.midLocales), null;
                    (0, i.Xq)("[getMatchingLocale] Available countries for merchant", n);
                    const a = this.getFilteredLocales(n);
                    (0, i.Xq)("[getMatchingLocale] Valid locales for merchant", a);
                    const r = null == a ? void 0 : a[e];
                    return c.findLocale(r, t, !0)
                }
                getFilteredLocales(e) {
                    if (!e) return this.midLocales;
                    const t = new Set(e);
                    return Object.keys(this.midLocales).reduce(((e, n) => (t.has(n) && (e[n] = this.midLocales[n]), e)), {})
                }
                getMatchingLocaleWithMidLocales(e, t) {
                    if (!e || !this.midLocales || 0 === Object.keys(this.midLocales).length) return (0, i.Xq)("[getMatchingLocale] Invalid data", e, this.midLocales), null;
                    const n = this.midLocales[e];
                    return c.findLocale(n, t, !1)
                }
            }
            const l = c;
            class d {
                constructor(e, t) {
                    this.store = e, this.productVariants = t, this.conflictingAppIds = [], this.eventHandler = () => {
                        this.updatePlacements()
                    }, this.localeService = new l(e.mid_locales)
                }
                static getVariantIdFromQueryString() {
                    const e = new URLSearchParams(window.location.search).get("variant");
                    return e ? Number.parseInt(e, 10) : null
                }
                async init() {
                    var e;
                    window.klarna_OSMP = window.klarna_OSMP || {}, window.klarna_OSMP.updaterId = null !== (e = window.klarna_OSMP.updaterId) && void 0 !== e ? e : 0, window.klarna_OSMP.rerenders = new Array(this.calculateRerendersLenBasedOnPlacementsCount()), this.conflictingAppIds = (0, i.CK)(), this.logIfConflictingAppsDetected(), this.injectOnSiteScripts(), await this.initPurchaseAmountIfCartOrProductPage(), this.listenForInputChange()
                }
                calculateRerendersLenBasedOnPlacementsCount() {
                    var e, t, n;
                    return 5 + 2 * (null !== (n = null === (t = null === (e = window.klarna_OSMP) || void 0 === e ? void 0 : e.placements) || void 0 === t ? void 0 : t.filter((e => e.placement_page === this.currentPageType)).length) && void 0 !== n ? n : 0)
                }
                logIfConflictingAppsDetected() {
                    this.conflictingAppIds.length > 0 && (0, i.Xq)(`Detected apps conflicting with Klarna placements: ${this.conflictingAppIds.join(", ")}. It may cause unwanted behaviour.`)
                }
                injectOnSiteScripts() {
                    if (null !== document.getElementById("klarna-osm-script-tag")) return;
                    const e = "us" === this.store.endpoint ? "na" : this.store.endpoint;
                    let t;
                    t = this.store.playground_active ? `https://${e}-library.playground.klarnaservices.com` : `https://${e}-library.klarnaservices.com`;
                    try {
                        const e = document.createElement("script");
                        e.id = "klarna-osm-script-tag", e.async = !0, e.src = `${t}/lib.js`, e.setAttribute("data-client-id", this.store.client_id);
                        const n = document.querySelector("body");
                        n.insertBefore(e, n.children[0])
                    } catch (e) {
                        (0, i.Xq)("Could not add script element", e)
                    }
                }
                async initPurchaseAmountIfCartOrProductPage() {
                    ["cart", "product"].includes(this.currentPageType) && await this.updatePurchaseAmount()
                }
                listenForInputChange() {
                    "cart" === this.currentPageType && (0 !== this.conflictingAppIds.length ? this.updatePlacementsOnInputEvents() : this.updatePlacementsOnDomMutations()), "product" === this.currentPageType && new MutationObserver((e => {
                        this.getKlarnaPlacements().forEach((e => {
                            var t, n;
                            const a = String(this.getDataPurchaseAmount() || 0),
                                r = e.getAttribute("data-purchase-amount");
                            a !== e.getAttribute("data-purchase-amount") && ((0, i.Xq)(`amount changed to ${a} from ${r}`), e.setAttribute("data-purchase-amount", a), (null === (n = null === (t = window.Klarna) || void 0 === t ? void 0 : t.OnsiteMessaging) || void 0 === n ? void 0 : n.refresh) ? window.Klarna.OnsiteMessaging.refresh() : window.KlarnaOnsiteService.push({
                                eventName: "refresh-placements"
                            }))
                        }))
                    })).observe(document.body, {
                        childList: !0,
                        subtree: !0
                    })
                }
                updatePlacementsOnDomMutations() {
                    const e = new MutationObserver((async t => {
                        window.klarna_OSMP.updaterId += 1;
                        const n = window.klarna_OSMP.updaterId,
                            a = [void 0, void 0, await this.getCartTotal()];
                        let r = 5;
                        if (d.addCurrentTimeToRerenders(), d.calculateMaxTimeBetweenRerenders() < 1e3) return (0, i.Xq)("Detected too frequent placement rerenders based on DOM modifications. Switching logic to input related one."), r = -1, e.disconnect(), void this.updatePlacementsOnInputEvents();
                        const o = async () => {
                            const e = await this.getCartTotal();
                            return (0, i.Xq)("Comparing amount and history", e, a), !!a.some((t => t !== e)) && (this.updatePurchaseAmount(e), a.shift(), a.push(e), !0)
                        };
                        for (; r > 0 && n === window.klarna_OSMP.updaterId;) r -= 1, await (0, i._v)(1e3), await o()
                    }));
                    e.observe(document.body, {
                        childList: !0,
                        subtree: !0
                    })
                }
                static addCurrentTimeToRerenders() {
                    const {
                        rerenders: e
                    } = window.klarna_OSMP;
                    e.shift(), e.push(new Date)
                }
                static calculateMaxTimeBetweenRerenders() {
                    var e, t;
                    const {
                        rerenders: n
                    } = window.klarna_OSMP;
                    return ((null === (e = n[n.length - 1]) || void 0 === e ? void 0 : e.getTime()) || 1 / 0) - ((null === (t = n[0]) || void 0 === t ? void 0 : t.getTime()) || -1 / 0)
                }
                updatePlacementsOnInputEvents() {
                    document.querySelectorAll("select, input").forEach((e => {
                        e.removeEventListener("change", this.eventHandler, !0), e.addEventListener("change", this.eventHandler, !0)
                    }))
                }
                async updatePlacements() {
                    await (0, i._v)(20), window.klarna_OSMP.updaterId += 1;
                    const e = window.klarna_OSMP.updaterId;
                    (0, i.Xq)("Updater started with id", e);
                    let t = await this.getCartTotal();
                    const n = async e => {
                        await (0, i._v)(e);
                        const n = await this.getCartTotal();
                        return n !== t && (this.updatePurchaseAmount(n), t = n, !0)
                    };
                    for (;;) {
                        let t = 10,
                            a = 50;
                        for (; t && !(e < window.klarna_OSMP.updaterId) && !await n(a);) a *= 1.5, t -= 1;
                        if (e < window.klarna_OSMP.updaterId) {
                            (0, i.Xq)("Updater terminated due to new one running", e);
                            break
                        }
                        if (!await n(1e3)) break
                    }
                    this.updatePlacementsOnInputEvents()
                }
                async updatePurchaseAmount(e = "") {
                    var t, n;
                    const a = this.getKlarnaPlacements();
                    let r = e;
                    r || ("cart" === this.currentPageType ? r = await this.getCartTotal() : "product" === this.currentPageType && (r = this.getDataPurchaseAmount())), (0, i.Xq)("Updating purchase amount", r), a.forEach((e => {
                        (0, i.Xq)("updating placement", e), e.setAttribute("data-purchase-amount", String(r))
                    })), (null === (n = null === (t = window.Klarna) || void 0 === t ? void 0 : t.OnsiteMessaging) || void 0 === n ? void 0 : n.refresh) ? window.Klarna.OnsiteMessaging.refresh() : window.KlarnaOnsiteService.push({
                        eventName: "refresh-placements"
                    }), 0 !== this.conflictingAppIds.length && this.listenForInputChange()
                }
                async getCartTotal() {
                    const e = await fetch("/cart.json");
                    if (!e.ok) throw new Error;
                    const t = await e.json();
                    return t.total_price ? t.total_price : 0
                }
            }
            var u = n(803);
            const p = [
                    ["/products/", "product"],
                    ["/collections", "collections"],
                    ["/pages/", "static"],
                    ["/cart", "cart"],
                    ["/checkouts", "checkout"]
                ],
                m = {
                    product: "product",
                    home: "home",
                    collection: "collections",
                    page: "static"
                };
            class h extends d {
                constructor() {
                    var e, t, n, a;
                    super(window.klarna_OSMP.store, null !== (a = null === (n = null === (t = null === (e = null === window || void 0 === window ? void 0 : window.ShopifyAnalytics) || void 0 === e ? void 0 : e.meta) || void 0 === t ? void 0 : t.product) || void 0 === n ? void 0 : n.variants) && void 0 !== a ? a : []), this.placements = window.klarna_OSMP.placements, this.detectedAfterpayElement = null, this.usersCountry = null, window.klarna_OSMP = window.klarna_OSMP || {}, window.KlarnaOnsiteService = window.KlarnaOnsiteService || [], window.Klarna = window.Klarna || {}, this.currentPageType = h.getCurrentPage()
                }
                static initObserver(e, t) {
                    return (0, i.Xq)("initObserver", {
                        rootNode: e,
                        element: t
                    }), new a.MutationSummary({
                        callback: e => {
                            if (void 0 === e) return;
                            const n = e[0];
                            if (0 === n.added.length) return;
                            const a = n.added[0];
                            a.classList.contains("afterpay-paragraph") && (a.previousSibling && a.previousSibling.innerHTML.includes("klarna") || ((0, i.Xq)("Detected competitor widget change in the DOM, inserting Ad position above it."), a.parentNode.insertBefore(t, a)))
                        },
                        rootNode: e,
                        observeOwnChanges: !0,
                        queries: [{
                            all: !0
                        }]
                    })
                }
                static getCurrentPage() {
                    if (this.isHomePage()) return "home";
                    const e = this.determineCurrentPageBasedOnPath(),
                        t = this.getCurrentPageFromShopifyAnalytics();
                    return e || t
                }
                static isHomePage() {
                    var e, t, n, a;
                    const i = (null === (a = null !== (t = null === (e = null === Shopify || void 0 === Shopify ? void 0 : Shopify.routes) || void 0 === e ? void 0 : e.root) && void 0 !== t ? t : null === (n = null === Shopify || void 0 === Shopify ? void 0 : Shopify.routes) || void 0 === n ? void 0 : n.root_url) || void 0 === a ? void 0 : a.slice(0, -1)) || "/";
                    return window.location.pathname === i
                }
                static determineCurrentPageBasedOnPath() {
                    for (const [e, t] of p)
                        if (window.location.pathname.includes(e)) return t;
                    return ""
                }
                static getCurrentPageFromShopifyAnalytics() {
                    var e, t, n;
                    const a = null === (n = null === (t = null === (e = null === window || void 0 === window ? void 0 : window.ShopifyAnalytics) || void 0 === e ? void 0 : e.meta) || void 0 === t ? void 0 : t.page) || void 0 === n ? void 0 : n.pageType;
                    return m[a] || ""
                }
                async init() {
                    var e;
                    if ((0, i.Xq)("init"), !this.placements || !this.store) return void(0, i.Xq)("Insufficient data. exiting...");
                    const {
                        Shopify: t
                    } = window, n = null !== (e = t.currency && t.currency.active) && void 0 !== e ? e : t.Checkout.currency;
                    void 0 !== t && ((0, i.Xq)(`Selected currency: ${n}`), (0, i.Xq)(`Shop currency: ${this.store.currency}`), this.store.currency && this.store.currency !== n) ? (0, i.Xq)(`Currency ${n} not supported. exiting...`) : (await this.checkForCompetitorAds(), this.placements.some((e => "geolocation" === e.locale_option)) && (this.usersCountry = await l.getUsersCountry(), (0, i.Xq)("Using geolocation, got users country:", this.usersCountry)), this.injectPlacements(), await super.init())
                }
                async checkForCompetitorAds() {
                    this.placements.filter((e => "below" === e.position)).length && (await (0, i._v)(1e3), this.detectedAfterpayElement = u.Z.getCompetitorElement("afterpay"), this.detectedAfterpayElement && (0, i.Xq)("got detectedAfterpayElement", this.detectedAfterpayElement))
                }
                findCurrentPage() {
                    let e = this.currentPageType;
                    return "static" === e && (e = window.location.pathname), (0, i.Xq)(`Page detected: ${e}`), e
                }
                injectPlacement(e, t, n) {
                    var a, r, o, s, c, l, d;
                    let u = e.placement_page;
                    if ("static" === this.currentPageType && (u = `${(null===(r=null===(a=window.Shopify)||void 0===a?void 0:a.routes)||void 0===r?void 0:r.root)||"/"}pages/${e.static_page}`), n === u) {
                        (0, i.Xq)("-----------------"), (0, i.Xq)(`Attempting to inject Ad position '${e.name?e.name:t}'.`, {
                            install_method: e.install_method ? e.install_method : "",
                            competitor_placement: "above" !== e.position
                        });
                        try {
                            const n = `margin: ${[e.padding_top,e.padding_right,e.padding_bottom,e.padding_left].map((e=>e?"1em":"0")).join(" ")}`;
                            let a = null;
                            "right" === e.justification ? a = "display: flex; justify-content: flex-end;" : "center" === e.justification && (a = "display: flex; justify-content: center;");
                            const r = document.createElement("div");
                            r.setAttribute("style", n);
                            let u = null;
                            if ("geolocation" === e.locale_option) {
                                if (e.countries && !e.countries.find((e => e === this.usersCountry)) || "EUR" !== this.store.currency && this.usersCountry !== e.country) return (0, i.Xq)(`Ad is not supported for this user's country: ${this.usersCountry}, countries for this placement: ${null!==(s=null===(o=e.countries)||void 0===o?void 0:o.join(", "))&&void 0!==s?s:e.country}`), !1;
                                u = this.localeService.getMatchingLocale(this.usersCountry, e.honor_storefront_locale, e.countries)
                            } else if ("auto" === e.locale_option && this.store.mid_locales) {
                                const t = null === Shopify || void 0 === Shopify ? void 0 : Shopify.locale,
                                    {
                                        country: n,
                                        data_locale: a
                                    } = e,
                                    r = this.store.mid_locales[n];
                                (0, i.Xq)("auto locale selection:", {
                                    locales: r,
                                    shopLocale: t,
                                    country: n,
                                    dataLocale: a,
                                    midLocales: this.store.mid_locales
                                }), r && (u = null !== (d = null !== (l = null !== (c = r.find((e => e.startsWith(t)))) && void 0 !== c ? c : r.find((e => a === e))) && void 0 !== l ? l : r[0]) && void 0 !== d ? d : null)
                            }
                            const p = u || e.data_locale;
                            (0, i.Xq)("Got matching locale:", u), (0, i.Xq)("Using locale:", p);
                            const m = document.createElement("klarna-placement");
                            "product" === this.currentPageType && 0 === (this.getDataPurchaseAmount() || 0) && "dynamic" === e.type ? ((0, i.Xq)("Using fallback placement", this.store.fallback_placement), m.setAttribute("data-key", this.store.fallback_placement)) : m.setAttribute("data-key", e.data_key), m.setAttribute("data-purchase-amount", String(this.getDataPurchaseAmount() || 0)), m.setAttribute("data-preloaded", "true"), m.setAttribute("data-locale", p), "dark" === e.theme && m.setAttribute("data-theme", "dark"), r.appendChild(m);
                            const g = document.querySelector(e.anchor_element);
                            if ("above" === e.position)(0, i.Xq)(`Ad position injected at element: ${e.anchor_element}`), g.parentNode.insertBefore(r, g);
                            else if ("below" === e.position) {
                                const t = g.nextSibling;
                                null !== t ? t.parentNode.insertBefore(r, t) : g.parentNode.append(r), (0, i.Xq)(`Ad position injected at element (competitor): ${e.anchor_element}`);
                                const n = this.detectedAfterpayElement === e.anchor_element;
                                this.detectedAfterpayElement && n && ((0, i.Xq)("Observing for competitor widget changes."), h.initObserver(g.parentNode, r))
                            }
                            return this.watchForRemoval(m, t), a && r.querySelector("klarna-placement") && r.querySelector("klarna-placement").setAttribute("style", a), m
                        } catch (t) {
                            (0, i.Xq)(`Failed to insert placement for placement id ${e.id}(${e.anchor_element})`, t)
                        }
                    }
                    return !1
                }
                injectPlacements() {
                    var e, t;
                    let n = 0,
                        a = 0;
                    const r = this.findCurrentPage();
                    this.placements.forEach(((e, t) => {
                        this.injectPlacement(e, t, r) ? n += 1 : a += 1
                    })), (0, i.Xq)(`Loaded: ${n}. Failed: ${a}`), (null === (t = null === (e = window.Klarna) || void 0 === e ? void 0 : e.OnsiteMessaging) || void 0 === t ? void 0 : t.refresh) ? window.Klarna.OnsiteMessaging.refresh() : window.KlarnaOnsiteService.push({
                        eventName: "refresh-placements"
                    })
                }
                getDataPurchaseAmount() {
                    var e, t, n, a, i, r;
                    let o = null;
                    const s = d.getVariantIdFromQueryString();
                    return s && (o = null === (e = this.productVariants) || void 0 === e ? void 0 : e.find((e => e.id === s))), o ? o.price : null !== (r = null === (i = null === (a = null === (n = null === (t = null === window || void 0 === window ? void 0 : window.ShopifyAnalytics) || void 0 === t ? void 0 : t.meta) || void 0 === n ? void 0 : n.product) || void 0 === a ? void 0 : a.variants[0]) || void 0 === i ? void 0 : i.price) && void 0 !== r ? r : 0
                }
                getKlarnaPlacements() {
                    const e = Array.from(document.getElementsByTagName("klarna-placement")).filter((e => !e.id));
                    return (0, i.Xq)("Got vintage placements", e), e
                }
                watchForRemoval(e, t) {
                    const n = new WeakSet;
                    let a = e;
                    do {
                        n.add(a), a = a.parentElement
                    } while (a);
                    const r = new MutationObserver((a => {
                        a.forEach((a => {
                            a.removedNodes.forEach((a => {
                                n.has(a) && !document.body.contains(e) && ((0, i.Xq)("placement was removed, reinserting..."), r.disconnect(), this.reinsertPlacement(t))
                            }))
                        }))
                    }));
                    document.body.contains(e) ? r.observe(document.body, {
                        childList: !0,
                        subtree: !0
                    }) : ((0, i.Xq)("Reinserting placement before observer attached"), this.reinsertPlacement(t))
                }
                reinsertPlacement(e) {
                    this.injectPlacement(this.placements[e], e, this.findCurrentPage()) ? (super.updatePurchaseAmount(), (0, i.Xq)("finished reinserting placement")) : (0, i.Xq)("failed to reinsert placement")
                }
            }
            const g = new h
        },
        991: e => {
            (() => {
                "use strict";
                var t, n = {};
                t = n, Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.SHOPIFY_API_KEY = t.DEVELOPMENT_PATH_PREFIX = t.GEOSERVICE_URL = t.APP_URL = t.NODE_ENV = void 0, t.NODE_ENV = "production", t.APP_URL = "https://skosm.klarna.com", t.GEOSERVICE_URL = `${t.APP_URL}/geolocation/v1`, t.DEVELOPMENT_PATH_PREFIX = "", t.SHOPIFY_API_KEY = "4439684aa13a71f0befb66b3a308e7d4", e.exports = n
            })()
        }
    }
]);