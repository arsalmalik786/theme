/*! jQuery v3.7.1 | (c) OpenJS Foundation and other contributors | jquery.org/license */
function isNotRichText(e) {
    var t = (new DOMParser).parseFromString(e, "text/html");
    return !Array.from(t.body.childNodes).some((e => e.nodeType === ELEMENT_NODE_TYPE))
}! function(e, t) {
    "use strict";
    "object" == typeof module && "object" == typeof module.exports ? module.exports = e.document ? t(e, !0) : function(e) {
        if (!e.document) throw new Error("SHGJQ requires a window with a document");
        return t(e)
    } : t(e)
}("undefined" != typeof window ? window : this, (function(e, t) {
    "use strict";

    function n(e, t, n) {
        var i, r, o = (n = n || de).createElement("script");
        if (o.text = e, t)
            for (i in fe)(r = t[i] || t.getAttribute && t.getAttribute(i)) && o.setAttribute(i, r);
        n.head.appendChild(o).parentNode.removeChild(o)
    }

    function i(e) {
        return null == e ? e + "" : "object" == typeof e || "function" == typeof e ? ie[re.call(e)] || "object" : typeof e
    }

    function r(e) {
        var t = !!e && "length" in e && e.length,
            n = i(e);
        return !ue(e) && !le(e) && ("array" === n || 0 === t || "number" == typeof t && 0 < t && t - 1 in e)
    }

    function o(e, t) {
        return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
    }

    function a(e, t) {
        return t ? "\0" === e ? "\ufffd" : e.slice(0, -1) + "\\" + e.charCodeAt(e.length - 1).toString(16) + " " : "\\" + e
    }

    function s(e, t, n) {
        return ue(t) ? ge.grep(e, (function(e, i) {
            return !!t.call(e, i, e) !== n
        })) : t.nodeType ? ge.grep(e, (function(e) {
            return e === t !== n
        })) : "string" != typeof t ? ge.grep(e, (function(e) {
            return -1 < ne.call(t, e) !== n
        })) : ge.filter(t, e, n)
    }

    function c(e, t) {
        for (;
            (e = e[t]) && 1 !== e.nodeType;);
        return e
    }

    function u(e) {
        return e
    }

    function l(e) {
        throw e
    }

    function d(e, t, n, i) {
        var r;
        try {
            e && ue(r = e.promise) ? r.call(e).done(t).fail(n) : e && ue(r = e.then) ? r.call(e, t, n) : t.apply(void 0, [e].slice(i))
        } catch (e) {
            n.apply(void 0, [e])
        }
    }

    function f() {
        de.removeEventListener("DOMContentLoaded", f), e.removeEventListener("load", f), ge.ready()
    }

    function h(e, t) {
        return t.toUpperCase()
    }

    function p(e) {
        return e.replace(je, "ms-").replace(Re, h)
    }

    function g() {
        this.expando = ge.expando + g.uid++
    }

    function m(e, t, n) {
        var i, r;
        if (void 0 === n && 1 === e.nodeType)
            if (i = "data-" + t.replace(Ge, "-$&").toLowerCase(), "string" == typeof(n = e.getAttribute(i))) {
                try {
                    n = "true" === (r = n) || "false" !== r && ("null" === r ? null : r === +r + "" ? +r : Ue.test(r) ? JSON.parse(r) : r)
                } catch (e) {}
                $e.set(e, t, n)
            } else n = void 0;
        return n
    }

    function v(e, t, n, i) {
        var r, o, a = 20,
            s = i ? function() {
                return i.cur()
            } : function() {
                return ge.css(e, t, "")
            },
            c = s(),
            u = n && n[3] || (ge.cssNumber[t] ? "" : "px"),
            l = e.nodeType && (ge.cssNumber[t] || "px" !== u && +c) && Fe.exec(ge.css(e, t));
        if (l && l[3] !== u) {
            for (c /= 2, u = u || l[3], l = +c || 1; a--;) ge.style(e, t, l + u), (1 - o) * (1 - (o = s() / c || .5)) <= 0 && (a = 0), l /= o;
            l *= 2, ge.style(e, t, l + u), n = n || []
        }
        return n && (l = +l || +c || 0, r = n[1] ? l + (n[1] + 1) * n[2] : +n[2], i && (i.unit = u, i.start = l, i.end = r)), r
    }

    function w(e, t) {
        for (var n, i, r, o, a, s, c, u = [], l = 0, d = e.length; l < d; l++)(i = e[l]).style && (n = i.style.display, t ? ("none" === n && (u[l] = qe.get(i, "display") || null, u[l] || (i.style.display = "")), "" === i.style.display && Je(i) && (u[l] = (c = a = o = void 0, a = (r = i).ownerDocument, s = r.nodeName, (c = Qe[s]) || (o = a.body.appendChild(a.createElement(s)), c = ge.css(o, "display"), o.parentNode.removeChild(o), "none" === c && (c = "block"), Qe[s] = c)))) : "none" !== n && (u[l] = "none", qe.set(i, "display", n)));
        for (l = 0; l < d; l++) null != u[l] && (e[l].style.display = u[l]);
        return e
    }

    function y(e, t) {
        var n;
        return n = void 0 !== e.getElementsByTagName ? e.getElementsByTagName(t || "*") : void 0 !== e.querySelectorAll ? e.querySelectorAll(t || "*") : [], void 0 === t || t && o(e, t) ? ge.merge([e], n) : n
    }

    function b(e, t) {
        for (var n = 0, i = e.length; n < i; n++) qe.set(e[n], "globalEval", !t || qe.get(t[n], "globalEval"))
    }

    function _(e, t, n, r, o) {
        for (var a, s, c, u, l, d, f = t.createDocumentFragment(), h = [], p = 0, g = e.length; p < g; p++)
            if ((a = e[p]) || 0 === a)
                if ("object" === i(a)) ge.merge(h, a.nodeType ? [a] : a);
                else if (it.test(a)) {
            for (s = s || f.appendChild(t.createElement("div")), c = (et.exec(a) || ["", ""])[1].toLowerCase(), u = nt[c] || nt._default, s.innerHTML = u[1] + ge.htmlPrefilter(a) + u[2], d = u[0]; d--;) s = s.lastChild;
            ge.merge(h, s.childNodes), (s = f.firstChild).textContent = ""
        } else h.push(t.createTextNode(a));
        for (f.textContent = "", p = 0; a = h[p++];)
            if (r && -1 < ge.inArray(a, r)) o && o.push(a);
            else if (l = ze(a), s = y(f.appendChild(a), "script"), l && b(s), n)
            for (d = 0; a = s[d++];) tt.test(a.type || "") && n.push(a);
        return f
    }

    function x() {
        return !0
    }

    function S() {
        return !1
    }

    function C(e, t, n, i, r, o) {
        var a, s;
        if ("object" == typeof t) {
            for (s in "string" != typeof n && (i = i || n, n = void 0), t) C(e, s, n, i, t[s], o);
            return e
        }
        if (null == i && null == r ? (r = n, i = n = void 0) : null == r && ("string" == typeof n ? (r = i, i = void 0) : (r = i, i = n, n = void 0)), !1 === r) r = S;
        else if (!r) return e;
        return 1 === o && (a = r, (r = function(e) {
            return ge().off(e), a.apply(this, arguments)
        }).guid = a.guid || (a.guid = ge.guid++)), e.each((function() {
            ge.event.add(this, t, r, i, n)
        }))
    }

    function E(e, t, n) {
        n ? (qe.set(e, t, !1), ge.event.add(e, t, {
            namespace: !1,
            handler: function(e) {
                var n, i = qe.get(this, t);
                if (1 & e.isTrigger && this[t]) {
                    if (i)(ge.event.special[t] || {}).delegateType && e.stopPropagation();
                    else if (i = K.call(arguments), qe.set(this, t, i), this[t](), n = qe.get(this, t), qe.set(this, t, !1), i !== n) return e.stopImmediatePropagation(), e.preventDefault(), n
                } else i && (qe.set(this, t, ge.event.trigger(i[0], i.slice(1), this)), e.stopPropagation(), e.isImmediatePropagationStopped = x)
            }
        })) : void 0 === qe.get(e, t) && ge.event.add(e, t, x)
    }

    function T(e, t) {
        return o(e, "table") && o(11 !== t.nodeType ? t : t.firstChild, "tr") && ge(e).children("tbody")[0] || e
    }

    function A(e) {
        return e.type = (null !== e.getAttribute("type")) + "/" + e.type, e
    }

    function O(e) {
        return "true/" === (e.type || "").slice(0, 5) ? e.type = e.type.slice(5) : e.removeAttribute("type"), e
    }

    function k(e, t) {
        var n, i, r, o, a, s;
        if (1 === t.nodeType) {
            if (qe.hasData(e) && (s = qe.get(e).events))
                for (r in qe.remove(t, "handle events"), s)
                    for (n = 0, i = s[r].length; n < i; n++) ge.event.add(t, r, s[r][n]);
            $e.hasData(e) && (o = $e.access(e), a = ge.extend({}, o), $e.set(t, a))
        }
    }

    function L(e, t, i, r) {
        t = ee(t);
        var o, a, s, c, u, l, d = 0,
            f = e.length,
            h = f - 1,
            p = t[0],
            g = ue(p);
        if (g || 1 < f && "string" == typeof p && !ce.checkClone && at.test(p)) return e.each((function(n) {
            var o = e.eq(n);
            g && (t[0] = p.call(this, n, o.html())), L(o, t, i, r)
        }));
        if (f && (a = (o = _(t, e[0].ownerDocument, !1, e, r)).firstChild, 1 === o.childNodes.length && (o = a), a || r)) {
            for (c = (s = ge.map(y(o, "script"), A)).length; d < f; d++) u = o, d !== h && (u = ge.clone(u, !0, !0), c && ge.merge(s, y(u, "script"))), i.call(e[d], u, d);
            if (c)
                for (l = s[s.length - 1].ownerDocument, ge.map(s, O), d = 0; d < c; d++) u = s[d], tt.test(u.type || "") && !qe.access(u, "globalEval") && ge.contains(l, u) && (u.src && "module" !== (u.type || "").toLowerCase() ? ge._evalUrl && !u.noModule && ge._evalUrl(u.src, {
                    nonce: u.nonce || u.getAttribute("nonce")
                }, l) : n(u.textContent.replace(st, ""), u, l))
        }
        return e
    }

    function P(e, t, n) {
        for (var i, r = t ? ge.filter(t, e) : e, o = 0; null != (i = r[o]); o++) n || 1 !== i.nodeType || ge.cleanData(y(i)), i.parentNode && (n && ze(i) && b(y(i, "script")), i.parentNode.removeChild(i));
        return e
    }

    function I(e, t, n) {
        var i, r, o, a, s = ut.test(t),
            c = e.style;
        return (n = n || lt(e)) && (a = n.getPropertyValue(t) || n[t], s && a && (a = a.replace(be, "$1") || void 0), "" !== a || ze(e) || (a = ge.style(e, t)), !ce.pixelBoxStyles() && ct.test(a) && ft.test(t) && (i = c.width, r = c.minWidth, o = c.maxWidth, c.minWidth = c.maxWidth = c.width = a, a = n.width, c.width = i, c.minWidth = r, c.maxWidth = o)), void 0 !== a ? a + "" : a
    }

    function N(e, t) {
        return {
            get: function() {
                if (!e()) return (this.get = t).apply(this, arguments);
                delete this.get
            }
        }
    }

    function D(e) {
        return ge.cssProps[e] || gt[e] || (e in pt ? e : gt[e] = function(e) {
            for (var t = e[0].toUpperCase() + e.slice(1), n = ht.length; n--;)
                if ((e = ht[n] + t) in pt) return e
        }(e) || e)
    }

    function H(e, t, n) {
        var i = Fe.exec(t);
        return i ? Math.max(0, i[2] - (n || 0)) + (i[3] || "px") : t
    }

    function j(e, t, n, i, r, o) {
        var a = "width" === t ? 1 : 0,
            s = 0,
            c = 0,
            u = 0;
        if (n === (i ? "border" : "content")) return 0;
        for (; a < 4; a += 2) "margin" === n && (u += ge.css(e, n + Be[a], !0, r)), i ? ("content" === n && (c -= ge.css(e, "padding" + Be[a], !0, r)), "margin" !== n && (c -= ge.css(e, "border" + Be[a] + "Width", !0, r))) : (c += ge.css(e, "padding" + Be[a], !0, r), "padding" !== n ? c += ge.css(e, "border" + Be[a] + "Width", !0, r) : s += ge.css(e, "border" + Be[a] + "Width", !0, r));
        return !i && 0 <= o && (c += Math.max(0, Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - o - c - s - .5)) || 0), c + u
    }

    function R(e, t, n) {
        var i = lt(e),
            r = (!ce.boxSizingReliable() || n) && "border-box" === ge.css(e, "boxSizing", !1, i),
            a = r,
            s = I(e, t, i),
            c = "offset" + t[0].toUpperCase() + t.slice(1);
        if (ct.test(s)) {
            if (!n) return s;
            s = "auto"
        }
        return (!ce.boxSizingReliable() && r || !ce.reliableTrDimensions() && o(e, "tr") || "auto" === s || !parseFloat(s) && "inline" === ge.css(e, "display", !1, i)) && e.getClientRects().length && (r = "border-box" === ge.css(e, "boxSizing", !1, i), (a = c in e) && (s = e[c])), (s = parseFloat(s) || 0) + j(e, t, n || (r ? "border" : "content"), a, i, s) + "px"
    }

    function M(e, t, n, i, r) {
        return new M.prototype.init(e, t, n, i, r)
    }

    function q() {
        bt && (!1 === de.hidden && e.requestAnimationFrame ? e.requestAnimationFrame(q) : e.setTimeout(q, ge.fx.interval), ge.fx.tick())
    }

    function $() {
        return e.setTimeout((function() {
            yt = void 0
        })), yt = Date.now()
    }

    function U(e, t) {
        var n, i = 0,
            r = {
                height: e
            };
        for (t = t ? 1 : 0; i < 4; i += 2 - t) r["margin" + (n = Be[i])] = r["padding" + n] = e;
        return t && (r.opacity = r.width = e), r
    }

    function G(e, t, n) {
        for (var i, r = (V.tweeners[t] || []).concat(V.tweeners["*"]), o = 0, a = r.length; o < a; o++)
            if (i = r[o].call(n, t, e)) return i
    }

    function V(e, t, n) {
        var i, r, o = 0,
            a = V.prefilters.length,
            s = ge.Deferred().always((function() {
                delete c.elem
            })),
            c = function() {
                if (r) return !1;
                for (var t = yt || $(), n = Math.max(0, u.startTime + u.duration - t), i = 1 - (n / u.duration || 0), o = 0, a = u.tweens.length; o < a; o++) u.tweens[o].run(i);
                return s.notifyWith(e, [u, i, n]), i < 1 && a ? n : (a || s.notifyWith(e, [u, 1, 0]), s.resolveWith(e, [u]), !1)
            },
            u = s.promise({
                elem: e,
                props: ge.extend({}, t),
                opts: ge.extend(!0, {
                    specialEasing: {},
                    easing: ge.easing._default
                }, n),
                originalProperties: t,
                originalOptions: n,
                startTime: yt || $(),
                duration: n.duration,
                tweens: [],
                createTween: function(t, n) {
                    var i = ge.Tween(e, u.opts, t, n, u.opts.specialEasing[t] || u.opts.easing);
                    return u.tweens.push(i), i
                },
                stop: function(t) {
                    var n = 0,
                        i = t ? u.tweens.length : 0;
                    if (r) return this;
                    for (r = !0; n < i; n++) u.tweens[n].run(1);
                    return t ? (s.notifyWith(e, [u, 1, 0]), s.resolveWith(e, [u, t])) : s.rejectWith(e, [u, t]), this
                }
            }),
            l = u.props;
        for (function(e, t) {
                var n, i, r, o, a;
                for (n in e)
                    if (r = t[i = p(n)], o = e[n], Array.isArray(o) && (r = o[1], o = e[n] = o[0]), n !== i && (e[i] = o, delete e[n]), (a = ge.cssHooks[i]) && "expand" in a)
                        for (n in o = a.expand(o), delete e[i], o) n in e || (e[n] = o[n], t[n] = r);
                    else t[i] = r
            }(l, u.opts.specialEasing); o < a; o++)
            if (i = V.prefilters[o].call(u, e, l, u.opts)) return ue(i.stop) && (ge._queueHooks(u.elem, u.opts.queue).stop = i.stop.bind(i)), i;
        return ge.map(l, G, u), ue(u.opts.start) && u.opts.start.call(e, u), u.progress(u.opts.progress).done(u.opts.done, u.opts.complete).fail(u.opts.fail).always(u.opts.always), ge.fx.timer(ge.extend(c, {
            elem: e,
            anim: u,
            queue: u.opts.queue
        })), u
    }

    function F(e) {
        return (e.match(Ie) || []).join(" ")
    }

    function B(e) {
        return e.getAttribute && e.getAttribute("class") || ""
    }

    function W(e) {
        return Array.isArray(e) ? e : "string" == typeof e && e.match(Ie) || []
    }

    function z(e, t, n, r) {
        var o;
        if (Array.isArray(t)) ge.each(t, (function(t, i) {
            n || Ht.test(e) ? r(e, i) : z(e + "[" + ("object" == typeof i && null != i ? t : "") + "]", i, n, r)
        }));
        else if (n || "object" !== i(t)) r(e, t);
        else
            for (o in t) z(e + "[" + o + "]", t[o], n, r)
    }

    function X(e) {
        return function(t, n) {
            "string" != typeof t && (n = t, t = "*");
            var i, r = 0,
                o = t.toLowerCase().match(Ie) || [];
            if (ue(n))
                for (; i = o[r++];) "+" === i[0] ? (i = i.slice(1) || "*", (e[i] = e[i] || []).unshift(n)) : (e[i] = e[i] || []).push(n)
        }
    }

    function J(e, t, n, i) {
        function r(s) {
            var c;
            return o[s] = !0, ge.each(e[s] || [], (function(e, s) {
                var u = s(t, n, i);
                return "string" != typeof u || a || o[u] ? a ? !(c = u) : void 0 : (t.dataTypes.unshift(u), r(u), !1)
            })), c
        }
        var o = {},
            a = e === Wt;
        return r(t.dataTypes[0]) || !o["*"] && r("*")
    }

    function Q(e, t) {
        var n, i, r = ge.ajaxSettings.flatOptions || {};
        for (n in t) void 0 !== t[n] && ((r[n] ? e : i || (i = {}))[n] = t[n]);
        return i && ge.extend(!0, e, i), e
    }
    var Y = [],
        Z = Object.getPrototypeOf,
        K = Y.slice,
        ee = Y.flat ? function(e) {
            return Y.flat.call(e)
        } : function(e) {
            return Y.concat.apply([], e)
        },
        te = Y.push,
        ne = Y.indexOf,
        ie = {},
        re = ie.toString,
        oe = ie.hasOwnProperty,
        ae = oe.toString,
        se = ae.call(Object),
        ce = {},
        ue = function(e) {
            return "function" == typeof e && "number" != typeof e.nodeType && "function" != typeof e.item
        },
        le = function(e) {
            return null != e && e === e.window
        },
        de = e.document,
        fe = {
            type: !0,
            src: !0,
            nonce: !0,
            noModule: !0
        },
        he = "3.7.1",
        pe = /HTML$/i,
        ge = function(e, t) {
            return new ge.fn.init(e, t)
        };
    ge.fn = ge.prototype = {
        jquery: he,
        constructor: ge,
        length: 0,
        toArray: function() {
            return K.call(this)
        },
        get: function(e) {
            return null == e ? K.call(this) : e < 0 ? this[e + this.length] : this[e]
        },
        pushStack: function(e) {
            var t = ge.merge(this.constructor(), e);
            return t.prevObject = this, t
        },
        each: function(e) {
            return ge.each(this, e)
        },
        map: function(e) {
            return this.pushStack(ge.map(this, (function(t, n) {
                return e.call(t, n, t)
            })))
        },
        slice: function() {
            return this.pushStack(K.apply(this, arguments))
        },
        first: function() {
            return this.eq(0)
        },
        last: function() {
            return this.eq(-1)
        },
        even: function() {
            return this.pushStack(ge.grep(this, (function(e, t) {
                return (t + 1) % 2
            })))
        },
        odd: function() {
            return this.pushStack(ge.grep(this, (function(e, t) {
                return t % 2
            })))
        },
        eq: function(e) {
            var t = this.length,
                n = +e + (e < 0 ? t : 0);
            return this.pushStack(0 <= n && n < t ? [this[n]] : [])
        },
        end: function() {
            return this.prevObject || this.constructor()
        },
        push: te,
        sort: Y.sort,
        splice: Y.splice
    }, ge.extend = ge.fn.extend = function() {
        var e, t, n, i, r, o, a = arguments[0] || {},
            s = 1,
            c = arguments.length,
            u = !1;
        for ("boolean" == typeof a && (u = a, a = arguments[s] || {}, s++), "object" == typeof a || ue(a) || (a = {}), s === c && (a = this, s--); s < c; s++)
            if (null != (e = arguments[s]))
                for (t in e) i = e[t], "__proto__" !== t && a !== i && (u && i && (ge.isPlainObject(i) || (r = Array.isArray(i))) ? (n = a[t], o = r && !Array.isArray(n) ? [] : r || ge.isPlainObject(n) ? n : {}, r = !1, a[t] = ge.extend(u, o, i)) : void 0 !== i && (a[t] = i));
        return a
    }, ge.extend({
        expando: "SHGJQ" + (he + Math.random()).replace(/\D/g, ""),
        isReady: !0,
        error: function(e) {
            throw new Error(e)
        },
        noop: function() {},
        isPlainObject: function(e) {
            var t, n;
            return !(!e || "[object Object]" !== re.call(e) || (t = Z(e)) && ("function" != typeof(n = oe.call(t, "constructor") && t.constructor) || ae.call(n) !== se))
        },
        isEmptyObject: function(e) {
            var t;
            for (t in e) return !1;
            return !0
        },
        globalEval: function(e, t, i) {
            n(e, {
                nonce: t && t.nonce
            }, i)
        },
        each: function(e, t) {
            var n, i = 0;
            if (r(e))
                for (n = e.length; i < n && !1 !== t.call(e[i], i, e[i]); i++);
            else
                for (i in e)
                    if (!1 === t.call(e[i], i, e[i])) break;
            return e
        },
        text: function(e) {
            var t, n = "",
                i = 0,
                r = e.nodeType;
            if (!r)
                for (; t = e[i++];) n += ge.text(t);
            return 1 === r || 11 === r ? e.textContent : 9 === r ? e.documentElement.textContent : 3 === r || 4 === r ? e.nodeValue : n
        },
        makeArray: function(e, t) {
            var n = t || [];
            return null != e && (r(Object(e)) ? ge.merge(n, "string" == typeof e ? [e] : e) : te.call(n, e)), n
        },
        inArray: function(e, t, n) {
            return null == t ? -1 : ne.call(t, e, n)
        },
        isXMLDoc: function(e) {
            var t = e && e.namespaceURI,
                n = e && (e.ownerDocument || e).documentElement;
            return !pe.test(t || n && n.nodeName || "HTML")
        },
        merge: function(e, t) {
            for (var n = +t.length, i = 0, r = e.length; i < n; i++) e[r++] = t[i];
            return e.length = r, e
        },
        grep: function(e, t, n) {
            for (var i = [], r = 0, o = e.length, a = !n; r < o; r++) !t(e[r], r) !== a && i.push(e[r]);
            return i
        },
        map: function(e, t, n) {
            var i, o, a = 0,
                s = [];
            if (r(e))
                for (i = e.length; a < i; a++) null != (o = t(e[a], a, n)) && s.push(o);
            else
                for (a in e) null != (o = t(e[a], a, n)) && s.push(o);
            return ee(s)
        },
        guid: 1,
        support: ce
    }), "function" == typeof Symbol && (ge.fn[Symbol.iterator] = Y[Symbol.iterator]), ge.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), (function(e, t) {
        ie["[object " + t + "]"] = t.toLowerCase()
    }));
    var me = Y.pop,
        ve = Y.sort,
        we = Y.splice,
        ye = "[\\x20\\t\\r\\n\\f]",
        be = new RegExp("^" + ye + "+|((?:^|[^\\\\])(?:\\\\.)*)" + ye + "+$", "g");
    ge.contains = function(e, t) {
        var n = t && t.parentNode;
        return e === n || !(!n || 1 !== n.nodeType || !(e.contains ? e.contains(n) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(n)))
    };
    var _e = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\x80-\uFFFF\w-]/g;
    ge.escapeSelector = function(e) {
        return (e + "").replace(_e, a)
    };
    var xe = de,
        Se = te;
    ! function() {
        function t(e, n, i, r) {
            var o, a, s, c, u, f, g, m = n && n.ownerDocument,
                v = n ? n.nodeType : 9;
            if (i = i || [], "string" != typeof e || !e || 1 !== v && 9 !== v && 11 !== v) return i;
            if (!r && (d(n), n = n || A, k)) {
                if (11 !== v && (u = ie.exec(e)))
                    if (o = u[1]) {
                        if (9 === v) {
                            if (!(s = n.getElementById(o))) return i;
                            if (s.id === o) return I.call(i, s), i
                        } else if (m && (s = m.getElementById(o)) && t.contains(n, s) && s.id === o) return I.call(i, s), i
                    } else {
                        if (u[2]) return I.apply(i, n.getElementsByTagName(e)), i;
                        if ((o = u[3]) && n.getElementsByClassName) return I.apply(i, n.getElementsByClassName(o)), i
                    }
                if (!(q[e + " "] || L && L.test(e))) {
                    if (g = e, m = n, 1 === v && (X.test(e) || z.test(e))) {
                        for ((m = re.test(e) && l(n.parentNode) || n) == n && ce.scope || ((c = n.getAttribute("id")) ? c = ge.escapeSelector(c) : n.setAttribute("id", c = N)), a = (f = h(e)).length; a--;) f[a] = (c ? "#" + c : ":scope") + " " + p(f[a]);
                        g = f.join(",")
                    }
                    try {
                        return I.apply(i, m.querySelectorAll(g)), i
                    } catch (n) {
                        q(e, !0)
                    } finally {
                        c === N && n.removeAttribute("id")
                    }
                }
            }
            return _(e.replace(be, "$1"), n, i, r)
        }

        function n() {
            var e = [];
            return function t(n, i) {
                return e.push(n + " ") > S.cacheLength && delete t[e.shift()], t[n + " "] = i
            }
        }

        function i(e) {
            return e[N] = !0, e
        }

        function r(e) {
            var t = A.createElement("fieldset");
            try {
                return !!e(t)
            } catch (e) {
                return !1
            } finally {
                t.parentNode && t.parentNode.removeChild(t), t = null
            }
        }

        function a(e) {
            return function(t) {
                return o(t, "input") && t.type === e
            }
        }

        function s(e) {
            return function(t) {
                return (o(t, "input") || o(t, "button")) && t.type === e
            }
        }

        function c(e) {
            return function(t) {
                return "form" in t ? t.parentNode && !1 === t.disabled ? "label" in t ? "label" in t.parentNode ? t.parentNode.disabled === e : t.disabled === e : t.isDisabled === e || t.isDisabled !== !e && le(t) === e : t.disabled === e : "label" in t && t.disabled === e
            }
        }

        function u(e) {
            return i((function(t) {
                return t = +t, i((function(n, i) {
                    for (var r, o = e([], n.length, t), a = o.length; a--;) n[r = o[a]] && (n[r] = !(i[r] = n[r]))
                }))
            }))
        }

        function l(e) {
            return e && void 0 !== e.getElementsByTagName && e
        }

        function d(e) {
            var n, i = e ? e.ownerDocument || e : xe;
            return i != A && 9 === i.nodeType && i.documentElement && (O = (A = i).documentElement, k = !ge.isXMLDoc(A), P = O.matches || O.webkitMatchesSelector || O.msMatchesSelector, O.msMatchesSelector && xe != A && (n = A.defaultView) && n.top !== n && n.addEventListener("unload", ue), ce.getById = r((function(e) {
                return O.appendChild(e).id = ge.expando, !A.getElementsByName || !A.getElementsByName(ge.expando).length
            })), ce.disconnectedMatch = r((function(e) {
                return P.call(e, "*")
            })), ce.scope = r((function() {
                return A.querySelectorAll(":scope")
            })), ce.cssHas = r((function() {
                try {
                    return A.querySelector(":has(*,:jqfake)"), !1
                } catch (e) {
                    return !0
                }
            })), ce.getById ? (S.filter.ID = function(e) {
                var t = e.replace(ae, se);
                return function(e) {
                    return e.getAttribute("id") === t
                }
            }, S.find.ID = function(e, t) {
                if (void 0 !== t.getElementById && k) {
                    var n = t.getElementById(e);
                    return n ? [n] : []
                }
            }) : (S.filter.ID = function(e) {
                var t = e.replace(ae, se);
                return function(e) {
                    var n = void 0 !== e.getAttributeNode && e.getAttributeNode("id");
                    return n && n.value === t
                }
            }, S.find.ID = function(e, t) {
                if (void 0 !== t.getElementById && k) {
                    var n, i, r, o = t.getElementById(e);
                    if (o) {
                        if ((n = o.getAttributeNode("id")) && n.value === e) return [o];
                        for (r = t.getElementsByName(e), i = 0; o = r[i++];)
                            if ((n = o.getAttributeNode("id")) && n.value === e) return [o]
                    }
                    return []
                }
            }), S.find.TAG = function(e, t) {
                return void 0 !== t.getElementsByTagName ? t.getElementsByTagName(e) : t.querySelectorAll(e)
            }, S.find.CLASS = function(e, t) {
                if (void 0 !== t.getElementsByClassName && k) return t.getElementsByClassName(e)
            }, L = [], r((function(e) {
                var t;
                O.appendChild(e).innerHTML = "<a id='" + N + "' href='' disabled='disabled'></a><select id='" + N + "-\r\\' disabled='disabled'><option selected=''></option></select>", e.querySelectorAll("[selected]").length || L.push("\\[" + ye + "*(?:value|" + U + ")"), e.querySelectorAll("[id~=" + N + "-]").length || L.push("~="), e.querySelectorAll("a#" + N + "+*").length || L.push(".#.+[+~]"), e.querySelectorAll(":checked").length || L.push(":checked"), (t = A.createElement("input")).setAttribute("type", "hidden"), e.appendChild(t).setAttribute("name", "D"), O.appendChild(e).disabled = !0, 2 !== e.querySelectorAll(":disabled").length && L.push(":enabled", ":disabled"), (t = A.createElement("input")).setAttribute("name", ""), e.appendChild(t), e.querySelectorAll("[name='']").length || L.push("\\[" + ye + "*name" + ye + "*=" + ye + "*(?:''|\"\")")
            })), ce.cssHas || L.push(":has"), L = L.length && new RegExp(L.join("|")), $ = function(e, n) {
                if (e === n) return T = !0, 0;
                var i = !e.compareDocumentPosition - !n.compareDocumentPosition;
                return i || (1 & (i = (e.ownerDocument || e) == (n.ownerDocument || n) ? e.compareDocumentPosition(n) : 1) || !ce.sortDetached && n.compareDocumentPosition(e) === i ? e === A || e.ownerDocument == xe && t.contains(xe, e) ? -1 : n === A || n.ownerDocument == xe && t.contains(xe, n) ? 1 : E ? ne.call(E, e) - ne.call(E, n) : 0 : 4 & i ? -1 : 1)
            }), A
        }

        function f() {}

        function h(e, n) {
            var i, r, o, a, s, c, u, l = R[e + " "];
            if (l) return n ? 0 : l.slice(0);
            for (s = e, c = [], u = S.preFilter; s;) {
                for (a in i && !(r = W.exec(s)) || (r && (s = s.slice(r[0].length) || s), c.push(o = [])), i = !1, (r = z.exec(s)) && (i = r.shift(), o.push({
                        value: i,
                        type: r[0].replace(be, " ")
                    }), s = s.slice(i.length)), S.filter) !(r = Z[a].exec(s)) || u[a] && !(r = u[a](r)) || (i = r.shift(), o.push({
                    value: i,
                    type: a,
                    matches: r
                }), s = s.slice(i.length));
                if (!i) break
            }
            return n ? s.length : s ? t.error(e) : R(e, c).slice(0)
        }

        function p(e) {
            for (var t = 0, n = e.length, i = ""; t < n; t++) i += e[t].value;
            return i
        }

        function g(e, t, n) {
            var i = t.dir,
                r = t.next,
                a = r || i,
                s = n && "parentNode" === a,
                c = H++;
            return t.first ? function(t, n, r) {
                for (; t = t[i];)
                    if (1 === t.nodeType || s) return e(t, n, r);
                return !1
            } : function(t, n, u) {
                var l, d, f = [D, c];
                if (u) {
                    for (; t = t[i];)
                        if ((1 === t.nodeType || s) && e(t, n, u)) return !0
                } else
                    for (; t = t[i];)
                        if (1 === t.nodeType || s)
                            if (d = t[N] || (t[N] = {}), r && o(t, r)) t = t[i] || t;
                            else {
                                if ((l = d[a]) && l[0] === D && l[1] === c) return f[2] = l[2];
                                if ((d[a] = f)[2] = e(t, n, u)) return !0
                            } return !1
            }
        }

        function m(e) {
            return 1 < e.length ? function(t, n, i) {
                for (var r = e.length; r--;)
                    if (!e[r](t, n, i)) return !1;
                return !0
            } : e[0]
        }

        function v(e, t, n, i, r) {
            for (var o, a = [], s = 0, c = e.length, u = null != t; s < c; s++)(o = e[s]) && (n && !n(o, i, r) || (a.push(o), u && t.push(s)));
            return a
        }

        function w(e, n, r, o, a, s) {
            return o && !o[N] && (o = w(o)), a && !a[N] && (a = w(a, s)), i((function(i, s, c, u) {
                var l, d, f, h, p = [],
                    g = [],
                    m = s.length,
                    w = i || function(e, n, i) {
                        for (var r = 0, o = n.length; r < o; r++) t(e, n[r], i);
                        return i
                    }(n || "*", c.nodeType ? [c] : c, []),
                    y = !e || !i && n ? w : v(w, p, e, c, u);
                if (r ? r(y, h = a || (i ? e : m || o) ? [] : s, c, u) : h = y, o)
                    for (l = v(h, g), o(l, [], c, u), d = l.length; d--;)(f = l[d]) && (h[g[d]] = !(y[g[d]] = f));
                if (i) {
                    if (a || e) {
                        if (a) {
                            for (l = [], d = h.length; d--;)(f = h[d]) && l.push(y[d] = f);
                            a(null, h = [], l, u)
                        }
                        for (d = h.length; d--;)(f = h[d]) && -1 < (l = a ? ne.call(i, f) : p[d]) && (i[l] = !(s[l] = f))
                    }
                } else h = v(h === s ? h.splice(m, h.length) : h), a ? a(null, s, h, u) : I.apply(s, h)
            }))
        }

        function y(e) {
            for (var t, n, i, r = e.length, o = S.relative[e[0].type], a = o || S.relative[" "], s = o ? 1 : 0, c = g((function(e) {
                    return e === t
                }), a, !0), u = g((function(e) {
                    return -1 < ne.call(t, e)
                }), a, !0), l = [function(e, n, i) {
                    var r = !o && (i || n != C) || ((t = n).nodeType ? c(e, n, i) : u(e, n, i));
                    return t = null, r
                }]; s < r; s++)
                if (n = S.relative[e[s].type]) l = [g(m(l), n)];
                else {
                    if ((n = S.filter[e[s].type].apply(null, e[s].matches))[N]) {
                        for (i = ++s; i < r && !S.relative[e[i].type]; i++);
                        return w(1 < s && m(l), 1 < s && p(e.slice(0, s - 1).concat({
                            value: " " === e[s - 2].type ? "*" : ""
                        })).replace(be, "$1"), n, s < i && y(e.slice(s, i)), i < r && y(e = e.slice(i)), i < r && p(e))
                    }
                    l.push(n)
                }
            return m(l)
        }

        function b(e, t) {
            var n, r, o, a, s, c, u = [],
                l = [],
                f = M[e + " "];
            if (!f) {
                for (t || (t = h(e)), n = t.length; n--;)(f = y(t[n]))[N] ? u.push(f) : l.push(f);
                (f = M(e, (r = l, a = 0 < (o = u).length, s = 0 < r.length, c = function(e, t, n, i, c) {
                    var u, l, f, h = 0,
                        p = "0",
                        g = e && [],
                        m = [],
                        w = C,
                        y = e || s && S.find.TAG("*", c),
                        b = D += null == w ? 1 : Math.random() || .1,
                        _ = y.length;
                    for (c && (C = t == A || t || c); p !== _ && null != (u = y[p]); p++) {
                        if (s && u) {
                            for (l = 0, t || u.ownerDocument == A || (d(u), n = !k); f = r[l++];)
                                if (f(u, t || A, n)) {
                                    I.call(i, u);
                                    break
                                }
                            c && (D = b)
                        }
                        a && ((u = !f && u) && h--, e && g.push(u))
                    }
                    if (h += p, a && p !== h) {
                        for (l = 0; f = o[l++];) f(g, m, t, n);
                        if (e) {
                            if (0 < h)
                                for (; p--;) g[p] || m[p] || (m[p] = me.call(i));
                            m = v(m)
                        }
                        I.apply(i, m), c && !e && 0 < m.length && 1 < h + o.length && ge.uniqueSort(i)
                    }
                    return c && (D = b, C = w), g
                }, a ? i(c) : c))).selector = e
            }
            return f
        }

        function _(e, t, n, i) {
            var r, o, a, s, c, u = "function" == typeof e && e,
                d = !i && h(e = u.selector || e);
            if (n = n || [], 1 === d.length) {
                if (2 < (o = d[0] = d[0].slice(0)).length && "ID" === (a = o[0]).type && 9 === t.nodeType && k && S.relative[o[1].type]) {
                    if (!(t = (S.find.ID(a.matches[0].replace(ae, se), t) || [])[0])) return n;
                    u && (t = t.parentNode), e = e.slice(o.shift().value.length)
                }
                for (r = Z.needsContext.test(e) ? 0 : o.length; r-- && (a = o[r], !S.relative[s = a.type]);)
                    if ((c = S.find[s]) && (i = c(a.matches[0].replace(ae, se), re.test(o[0].type) && l(t.parentNode) || t))) {
                        if (o.splice(r, 1), !(e = i.length && p(o))) return I.apply(n, i), n;
                        break
                    }
            }
            return (u || b(e, d))(i, t, !k, n, !t || re.test(e) && l(t.parentNode) || t), n
        }
        var x, S, C, E, T, A, O, k, L, P, I = Se,
            N = ge.expando,
            D = 0,
            H = 0,
            j = n(),
            R = n(),
            M = n(),
            q = n(),
            $ = function(e, t) {
                return e === t && (T = !0), 0
            },
            U = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
            G = "(?:\\\\[\\da-fA-F]{1,6}" + ye + "?|\\\\[^\\r\\n\\f]|[\\w-]|[^\0-\\x7f])+",
            V = "\\[" + ye + "*(" + G + ")(?:" + ye + "*([*^$|!~]?=)" + ye + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + G + "))|)" + ye + "*\\]",
            F = ":(" + G + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + V + ")*)|.*)\\)|)",
            B = new RegExp(ye + "+", "g"),
            W = new RegExp("^" + ye + "*," + ye + "*"),
            z = new RegExp("^" + ye + "*([>+~]|" + ye + ")" + ye + "*"),
            X = new RegExp(ye + "|>"),
            J = new RegExp(F),
            Q = new RegExp("^" + G + "$"),
            Z = {
                ID: new RegExp("^#(" + G + ")"),
                CLASS: new RegExp("^\\.(" + G + ")"),
                TAG: new RegExp("^(" + G + "|[*])"),
                ATTR: new RegExp("^" + V),
                PSEUDO: new RegExp("^" + F),
                CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + ye + "*(even|odd|(([+-]|)(\\d*)n|)" + ye + "*(?:([+-]|)" + ye + "*(\\d+)|))" + ye + "*\\)|)", "i"),
                bool: new RegExp("^(?:" + U + ")$", "i"),
                needsContext: new RegExp("^" + ye + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + ye + "*((?:-\\d)?\\d*)" + ye + "*\\)|)(?=[^-]|$)", "i")
            },
            ee = /^(?:input|select|textarea|button)$/i,
            te = /^h\d$/i,
            ie = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
            re = /[+~]/,
            ae = new RegExp("\\\\[\\da-fA-F]{1,6}" + ye + "?|\\\\([^\\r\\n\\f])", "g"),
            se = function(e, t) {
                var n = "0x" + e.slice(1) - 65536;
                return t || (n < 0 ? String.fromCharCode(n + 65536) : String.fromCharCode(n >> 10 | 55296, 1023 & n | 56320))
            },
            ue = function() {
                d()
            },
            le = g((function(e) {
                return !0 === e.disabled && o(e, "fieldset")
            }), {
                dir: "parentNode",
                next: "legend"
            });
        try {
            I.apply(Y = K.call(xe.childNodes), xe.childNodes), Y[xe.childNodes.length].nodeType
        } catch (x) {
            I = {
                apply: function(e, t) {
                    Se.apply(e, K.call(t))
                },
                call: function(e) {
                    Se.apply(e, K.call(arguments, 1))
                }
            }
        }
        for (x in t.matches = function(e, n) {
                return t(e, null, null, n)
            }, t.matchesSelector = function(e, n) {
                if (d(e), k && !q[n + " "] && (!L || !L.test(n))) try {
                    var i = P.call(e, n);
                    if (i || ce.disconnectedMatch || e.document && 11 !== e.document.nodeType) return i
                } catch (e) {
                    q(n, !0)
                }
                return 0 < t(n, A, null, [e]).length
            }, t.contains = function(e, t) {
                return (e.ownerDocument || e) != A && d(e), ge.contains(e, t)
            }, t.attr = function(e, t) {
                (e.ownerDocument || e) != A && d(e);
                var n = S.attrHandle[t.toLowerCase()],
                    i = n && oe.call(S.attrHandle, t.toLowerCase()) ? n(e, t, !k) : void 0;
                return void 0 !== i ? i : e.getAttribute(t)
            }, t.error = function(e) {
                throw new Error("Syntax error, unrecognized expression: " + e)
            }, ge.uniqueSort = function(e) {
                var t, n = [],
                    i = 0,
                    r = 0;
                if (T = !ce.sortStable, E = !ce.sortStable && K.call(e, 0), ve.call(e, $), T) {
                    for (; t = e[r++];) t === e[r] && (i = n.push(r));
                    for (; i--;) we.call(e, n[i], 1)
                }
                return E = null, e
            }, ge.fn.uniqueSort = function() {
                return this.pushStack(ge.uniqueSort(K.apply(this)))
            }, (S = ge.expr = {
                cacheLength: 50,
                createPseudo: i,
                match: Z,
                attrHandle: {},
                find: {},
                relative: {
                    ">": {
                        dir: "parentNode",
                        first: !0
                    },
                    " ": {
                        dir: "parentNode"
                    },
                    "+": {
                        dir: "previousSibling",
                        first: !0
                    },
                    "~": {
                        dir: "previousSibling"
                    }
                },
                preFilter: {
                    ATTR: function(e) {
                        return e[1] = e[1].replace(ae, se), e[3] = (e[3] || e[4] || e[5] || "").replace(ae, se), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4)
                    },
                    CHILD: function(e) {
                        return e[1] = e[1].toLowerCase(), "nth" === e[1].slice(0, 3) ? (e[3] || t.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && t.error(e[0]), e
                    },
                    PSEUDO: function(e) {
                        var t, n = !e[6] && e[2];
                        return Z.CHILD.test(e[0]) ? null : (e[3] ? e[2] = e[4] || e[5] || "" : n && J.test(n) && (t = h(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
                    }
                },
                filter: {
                    TAG: function(e) {
                        var t = e.replace(ae, se).toLowerCase();
                        return "*" === e ? function() {
                            return !0
                        } : function(e) {
                            return o(e, t)
                        }
                    },
                    CLASS: function(e) {
                        var t = j[e + " "];
                        return t || (t = new RegExp("(^|" + ye + ")" + e + "(" + ye + "|$)")) && j(e, (function(e) {
                            return t.test("string" == typeof e.className && e.className || void 0 !== e.getAttribute && e.getAttribute("class") || "")
                        }))
                    },
                    ATTR: function(e, n, i) {
                        return function(r) {
                            var o = t.attr(r, e);
                            return null == o ? "!=" === n : !n || (o += "", "=" === n ? o === i : "!=" === n ? o !== i : "^=" === n ? i && 0 === o.indexOf(i) : "*=" === n ? i && -1 < o.indexOf(i) : "$=" === n ? i && o.slice(-i.length) === i : "~=" === n ? -1 < (" " + o.replace(B, " ") + " ").indexOf(i) : "|=" === n && (o === i || o.slice(0, i.length + 1) === i + "-"))
                        }
                    },
                    CHILD: function(e, t, n, i, r) {
                        var a = "nth" !== e.slice(0, 3),
                            s = "last" !== e.slice(-4),
                            c = "of-type" === t;
                        return 1 === i && 0 === r ? function(e) {
                            return !!e.parentNode
                        } : function(t, n, u) {
                            var l, d, f, h, p, g = a !== s ? "nextSibling" : "previousSibling",
                                m = t.parentNode,
                                v = c && t.nodeName.toLowerCase(),
                                w = !u && !c,
                                y = !1;
                            if (m) {
                                if (a) {
                                    for (; g;) {
                                        for (f = t; f = f[g];)
                                            if (c ? o(f, v) : 1 === f.nodeType) return !1;
                                        p = g = "only" === e && !p && "nextSibling"
                                    }
                                    return !0
                                }
                                if (p = [s ? m.firstChild : m.lastChild], s && w) {
                                    for (y = (h = (l = (d = m[N] || (m[N] = {}))[e] || [])[0] === D && l[1]) && l[2], f = h && m.childNodes[h]; f = ++h && f && f[g] || (y = h = 0) || p.pop();)
                                        if (1 === f.nodeType && ++y && f === t) {
                                            d[e] = [D, h, y];
                                            break
                                        }
                                } else if (w && (y = h = (l = (d = t[N] || (t[N] = {}))[e] || [])[0] === D && l[1]), !1 === y)
                                    for (;
                                        (f = ++h && f && f[g] || (y = h = 0) || p.pop()) && (!(c ? o(f, v) : 1 === f.nodeType) || !++y || (w && ((d = f[N] || (f[N] = {}))[e] = [D, y]), f !== t)););
                                return (y -= r) === i || y % i == 0 && 0 <= y / i
                            }
                        }
                    },
                    PSEUDO: function(e, n) {
                        var r, o = S.pseudos[e] || S.setFilters[e.toLowerCase()] || t.error("unsupported pseudo: " + e);
                        return o[N] ? o(n) : 1 < o.length ? (r = [e, e, "", n], S.setFilters.hasOwnProperty(e.toLowerCase()) ? i((function(e, t) {
                            for (var i, r = o(e, n), a = r.length; a--;) e[i = ne.call(e, r[a])] = !(t[i] = r[a])
                        })) : function(e) {
                            return o(e, 0, r)
                        }) : o
                    }
                },
                pseudos: {
                    not: i((function(e) {
                        var t = [],
                            n = [],
                            r = b(e.replace(be, "$1"));
                        return r[N] ? i((function(e, t, n, i) {
                            for (var o, a = r(e, null, i, []), s = e.length; s--;)(o = a[s]) && (e[s] = !(t[s] = o))
                        })) : function(e, i, o) {
                            return t[0] = e, r(t, null, o, n), t[0] = null, !n.pop()
                        }
                    })),
                    has: i((function(e) {
                        return function(n) {
                            return 0 < t(e, n).length
                        }
                    })),
                    contains: i((function(e) {
                        return e = e.replace(ae, se),
                            function(t) {
                                return -1 < (t.textContent || ge.text(t)).indexOf(e)
                            }
                    })),
                    lang: i((function(e) {
                        return Q.test(e || "") || t.error("unsupported lang: " + e), e = e.replace(ae, se).toLowerCase(),
                            function(t) {
                                var n;
                                do {
                                    if (n = k ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang")) return (n = n.toLowerCase()) === e || 0 === n.indexOf(e + "-")
                                } while ((t = t.parentNode) && 1 === t.nodeType);
                                return !1
                            }
                    })),
                    target: function(t) {
                        var n = e.location && e.location.hash;
                        return n && n.slice(1) === t.id
                    },
                    root: function(e) {
                        return e === O
                    },
                    focus: function(e) {
                        return e === function() {
                            try {
                                return A.activeElement
                            } catch (e) {}
                        }() && A.hasFocus() && !!(e.type || e.href || ~e.tabIndex)
                    },
                    enabled: c(!1),
                    disabled: c(!0),
                    checked: function(e) {
                        return o(e, "input") && !!e.checked || o(e, "option") && !!e.selected
                    },
                    selected: function(e) {
                        return e.parentNode && e.parentNode.selectedIndex, !0 === e.selected
                    },
                    empty: function(e) {
                        for (e = e.firstChild; e; e = e.nextSibling)
                            if (e.nodeType < 6) return !1;
                        return !0
                    },
                    parent: function(e) {
                        return !S.pseudos.empty(e)
                    },
                    header: function(e) {
                        return te.test(e.nodeName)
                    },
                    input: function(e) {
                        return ee.test(e.nodeName)
                    },
                    button: function(e) {
                        return o(e, "input") && "button" === e.type || o(e, "button")
                    },
                    text: function(e) {
                        var t;
                        return o(e, "input") && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase())
                    },
                    first: u((function() {
                        return [0]
                    })),
                    last: u((function(e, t) {
                        return [t - 1]
                    })),
                    eq: u((function(e, t, n) {
                        return [n < 0 ? n + t : n]
                    })),
                    even: u((function(e, t) {
                        for (var n = 0; n < t; n += 2) e.push(n);
                        return e
                    })),
                    odd: u((function(e, t) {
                        for (var n = 1; n < t; n += 2) e.push(n);
                        return e
                    })),
                    lt: u((function(e, t, n) {
                        var i;
                        for (i = n < 0 ? n + t : t < n ? t : n; 0 <= --i;) e.push(i);
                        return e
                    })),
                    gt: u((function(e, t, n) {
                        for (var i = n < 0 ? n + t : n; ++i < t;) e.push(i);
                        return e
                    }))
                }
            }).pseudos.nth = S.pseudos.eq, {
                radio: !0,
                checkbox: !0,
                file: !0,
                password: !0,
                image: !0
            }) S.pseudos[x] = a(x);
        for (x in {
                submit: !0,
                reset: !0
            }) S.pseudos[x] = s(x);
        f.prototype = S.filters = S.pseudos, S.setFilters = new f, ce.sortStable = N.split("").sort($).join("") === N, d(), ce.sortDetached = r((function(e) {
            return 1 & e.compareDocumentPosition(A.createElement("fieldset"))
        })), ge.find = t, ge.expr[":"] = ge.expr.pseudos, ge.unique = ge.uniqueSort, t.compile = b, t.select = _, t.setDocument = d, t.tokenize = h, t.escape = ge.escapeSelector, t.getText = ge.text, t.isXML = ge.isXMLDoc, t.selectors = ge.expr, t.support = ge.support, t.uniqueSort = ge.uniqueSort
    }();
    var Ce = function(e, t, n) {
            for (var i = [], r = void 0 !== n;
                (e = e[t]) && 9 !== e.nodeType;)
                if (1 === e.nodeType) {
                    if (r && ge(e).is(n)) break;
                    i.push(e)
                }
            return i
        },
        Ee = function(e, t) {
            for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
            return n
        },
        Te = ge.expr.match.needsContext,
        Ae = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;
    ge.filter = function(e, t, n) {
        var i = t[0];
        return n && (e = ":not(" + e + ")"), 1 === t.length && 1 === i.nodeType ? ge.find.matchesSelector(i, e) ? [i] : [] : ge.find.matches(e, ge.grep(t, (function(e) {
            return 1 === e.nodeType
        })))
    }, ge.fn.extend({
        find: function(e) {
            var t, n, i = this.length,
                r = this;
            if ("string" != typeof e) return this.pushStack(ge(e).filter((function() {
                for (t = 0; t < i; t++)
                    if (ge.contains(r[t], this)) return !0
            })));
            for (n = this.pushStack([]), t = 0; t < i; t++) ge.find(e, r[t], n);
            return 1 < i ? ge.uniqueSort(n) : n
        },
        filter: function(e) {
            return this.pushStack(s(this, e || [], !1))
        },
        not: function(e) {
            return this.pushStack(s(this, e || [], !0))
        },
        is: function(e) {
            return !!s(this, "string" == typeof e && Te.test(e) ? ge(e) : e || [], !1).length
        }
    });
    var Oe, ke = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/;
    (ge.fn.init = function(e, t, n) {
        var i, r;
        if (!e) return this;
        if (n = n || Oe, "string" == typeof e) {
            if (!(i = "<" === e[0] && ">" === e[e.length - 1] && 3 <= e.length ? [null, e, null] : ke.exec(e)) || !i[1] && t) return !t || t.jquery ? (t || n).find(e) : this.constructor(t).find(e);
            if (i[1]) {
                if (t = t instanceof ge ? t[0] : t, ge.merge(this, ge.parseHTML(i[1], t && t.nodeType ? t.ownerDocument || t : de, !0)), Ae.test(i[1]) && ge.isPlainObject(t))
                    for (i in t) ue(this[i]) ? this[i](t[i]) : this.attr(i, t[i]);
                return this
            }
            return (r = de.getElementById(i[2])) && (this[0] = r, this.length = 1), this
        }
        return e.nodeType ? (this[0] = e, this.length = 1, this) : ue(e) ? void 0 !== n.ready ? n.ready(e) : e(ge) : ge.makeArray(e, this)
    }).prototype = ge.fn, Oe = ge(de);
    var Le = /^(?:parents|prev(?:Until|All))/,
        Pe = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };
    ge.fn.extend({
        has: function(e) {
            var t = ge(e, this),
                n = t.length;
            return this.filter((function() {
                for (var e = 0; e < n; e++)
                    if (ge.contains(this, t[e])) return !0
            }))
        },
        closest: function(e, t) {
            var n, i = 0,
                r = this.length,
                o = [],
                a = "string" != typeof e && ge(e);
            if (!Te.test(e))
                for (; i < r; i++)
                    for (n = this[i]; n && n !== t; n = n.parentNode)
                        if (n.nodeType < 11 && (a ? -1 < a.index(n) : 1 === n.nodeType && ge.find.matchesSelector(n, e))) {
                            o.push(n);
                            break
                        }
            return this.pushStack(1 < o.length ? ge.uniqueSort(o) : o)
        },
        index: function(e) {
            return e ? "string" == typeof e ? ne.call(ge(e), this[0]) : ne.call(this, e.jquery ? e[0] : e) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
        },
        add: function(e, t) {
            return this.pushStack(ge.uniqueSort(ge.merge(this.get(), ge(e, t))))
        },
        addBack: function(e) {
            return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
        }
    }), ge.each({
        parent: function(e) {
            var t = e.parentNode;
            return t && 11 !== t.nodeType ? t : null
        },
        parents: function(e) {
            return Ce(e, "parentNode")
        },
        parentsUntil: function(e, t, n) {
            return Ce(e, "parentNode", n)
        },
        next: function(e) {
            return c(e, "nextSibling")
        },
        prev: function(e) {
            return c(e, "previousSibling")
        },
        nextAll: function(e) {
            return Ce(e, "nextSibling")
        },
        prevAll: function(e) {
            return Ce(e, "previousSibling")
        },
        nextUntil: function(e, t, n) {
            return Ce(e, "nextSibling", n)
        },
        prevUntil: function(e, t, n) {
            return Ce(e, "previousSibling", n)
        },
        siblings: function(e) {
            return Ee((e.parentNode || {}).firstChild, e)
        },
        children: function(e) {
            return Ee(e.firstChild)
        },
        contents: function(e) {
            return null != e.contentDocument && Z(e.contentDocument) ? e.contentDocument : (o(e, "template") && (e = e.content || e), ge.merge([], e.childNodes))
        }
    }, (function(e, t) {
        ge.fn[e] = function(n, i) {
            var r = ge.map(this, t, n);
            return "Until" !== e.slice(-5) && (i = n), i && "string" == typeof i && (r = ge.filter(i, r)), 1 < this.length && (Pe[e] || ge.uniqueSort(r), Le.test(e) && r.reverse()), this.pushStack(r)
        }
    }));
    var Ie = /[^\x20\t\r\n\f]+/g;
    ge.Callbacks = function(e) {
        var t, n;
        e = "string" == typeof e ? (t = e, n = {}, ge.each(t.match(Ie) || [], (function(e, t) {
            n[t] = !0
        })), n) : ge.extend({}, e);
        var r, o, a, s, c = [],
            u = [],
            l = -1,
            d = function() {
                for (s = s || e.once, a = r = !0; u.length; l = -1)
                    for (o = u.shift(); ++l < c.length;) !1 === c[l].apply(o[0], o[1]) && e.stopOnFalse && (l = c.length, o = !1);
                e.memory || (o = !1), r = !1, s && (c = o ? [] : "")
            },
            f = {
                add: function() {
                    return c && (o && !r && (l = c.length - 1, u.push(o)), function t(n) {
                        ge.each(n, (function(n, r) {
                            ue(r) ? e.unique && f.has(r) || c.push(r) : r && r.length && "string" !== i(r) && t(r)
                        }))
                    }(arguments), o && !r && d()), this
                },
                remove: function() {
                    return ge.each(arguments, (function(e, t) {
                        for (var n; - 1 < (n = ge.inArray(t, c, n));) c.splice(n, 1), n <= l && l--
                    })), this
                },
                has: function(e) {
                    return e ? -1 < ge.inArray(e, c) : 0 < c.length
                },
                empty: function() {
                    return c && (c = []), this
                },
                disable: function() {
                    return s = u = [], c = o = "", this
                },
                disabled: function() {
                    return !c
                },
                lock: function() {
                    return s = u = [], o || r || (c = o = ""), this
                },
                locked: function() {
                    return !!s
                },
                fireWith: function(e, t) {
                    return s || (t = [e, (t = t || []).slice ? t.slice() : t], u.push(t), r || d()), this
                },
                fire: function() {
                    return f.fireWith(this, arguments), this
                },
                fired: function() {
                    return !!a
                }
            };
        return f
    }, ge.extend({
        Deferred: function(t) {
            var n = [
                    ["notify", "progress", ge.Callbacks("memory"), ge.Callbacks("memory"), 2],
                    ["resolve", "done", ge.Callbacks("once memory"), ge.Callbacks("once memory"), 0, "resolved"],
                    ["reject", "fail", ge.Callbacks("once memory"), ge.Callbacks("once memory"), 1, "rejected"]
                ],
                i = "pending",
                r = {
                    state: function() {
                        return i
                    },
                    always: function() {
                        return o.done(arguments).fail(arguments), this
                    },
                    catch: function(e) {
                        return r.then(null, e)
                    },
                    pipe: function() {
                        var e = arguments;
                        return ge.Deferred((function(t) {
                            ge.each(n, (function(n, i) {
                                var r = ue(e[i[4]]) && e[i[4]];
                                o[i[1]]((function() {
                                    var e = r && r.apply(this, arguments);
                                    e && ue(e.promise) ? e.promise().progress(t.notify).done(t.resolve).fail(t.reject) : t[i[0] + "With"](this, r ? [e] : arguments)
                                }))
                            })), e = null
                        })).promise()
                    },
                    then: function(t, i, r) {
                        function o(t, n, i, r) {
                            return function() {
                                var s = this,
                                    c = arguments,
                                    d = function() {
                                        var e, d;
                                        if (!(t < a)) {
                                            if ((e = i.apply(s, c)) === n.promise()) throw new TypeError("Thenable self-resolution");
                                            d = e && ("object" == typeof e || "function" == typeof e) && e.then, ue(d) ? r ? d.call(e, o(a, n, u, r), o(a, n, l, r)) : (a++, d.call(e, o(a, n, u, r), o(a, n, l, r), o(a, n, u, n.notifyWith))) : (i !== u && (s = void 0, c = [e]), (r || n.resolveWith)(s, c))
                                        }
                                    },
                                    f = r ? d : function() {
                                        try {
                                            d()
                                        } catch (e) {
                                            ge.Deferred.exceptionHook && ge.Deferred.exceptionHook(e, f.error), a <= t + 1 && (i !== l && (s = void 0, c = [e]), n.rejectWith(s, c))
                                        }
                                    };
                                t ? f() : (ge.Deferred.getErrorHook ? f.error = ge.Deferred.getErrorHook() : ge.Deferred.getStackHook && (f.error = ge.Deferred.getStackHook()), e.setTimeout(f))
                            }
                        }
                        var a = 0;
                        return ge.Deferred((function(e) {
                            n[0][3].add(o(0, e, ue(r) ? r : u, e.notifyWith)), n[1][3].add(o(0, e, ue(t) ? t : u)), n[2][3].add(o(0, e, ue(i) ? i : l))
                        })).promise()
                    },
                    promise: function(e) {
                        return null != e ? ge.extend(e, r) : r
                    }
                },
                o = {};
            return ge.each(n, (function(e, t) {
                var a = t[2],
                    s = t[5];
                r[t[1]] = a.add, s && a.add((function() {
                    i = s
                }), n[3 - e][2].disable, n[3 - e][3].disable, n[0][2].lock, n[0][3].lock), a.add(t[3].fire), o[t[0]] = function() {
                    return o[t[0] + "With"](this === o ? void 0 : this, arguments), this
                }, o[t[0] + "With"] = a.fireWith
            })), r.promise(o), t && t.call(o, o), o
        },
        when: function(e) {
            var t = arguments.length,
                n = t,
                i = Array(n),
                r = K.call(arguments),
                o = ge.Deferred(),
                a = function(e) {
                    return function(n) {
                        i[e] = this, r[e] = 1 < arguments.length ? K.call(arguments) : n, --t || o.resolveWith(i, r)
                    }
                };
            if (t <= 1 && (d(e, o.done(a(n)).resolve, o.reject, !t), "pending" === o.state() || ue(r[n] && r[n].then))) return o.then();
            for (; n--;) d(r[n], a(n), o.reject);
            return o.promise()
        }
    });
    var Ne = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
    ge.Deferred.exceptionHook = function(t, n) {
        e.console && e.console.warn && t && Ne.test(t.name) && e.console.warn("SHGJQ.Deferred exception: " + t.message, t.stack, n)
    }, ge.readyException = function(t) {
        e.setTimeout((function() {
            throw t
        }))
    };
    var De = ge.Deferred();
    ge.fn.ready = function(e) {
        return De.then(e).catch((function(e) {
            ge.readyException(e)
        })), this
    }, ge.extend({
        isReady: !1,
        readyWait: 1,
        ready: function(e) {
            (!0 === e ? --ge.readyWait : ge.isReady) || (ge.isReady = !0) !== e && 0 < --ge.readyWait || De.resolveWith(de, [ge])
        }
    }), ge.ready.then = De.then, "complete" === de.readyState || "loading" !== de.readyState && !de.documentElement.doScroll ? e.setTimeout(ge.ready) : (de.addEventListener("DOMContentLoaded", f), e.addEventListener("load", f));
    var He = function(e, t, n, r, o, a, s) {
            var c = 0,
                u = e.length,
                l = null == n;
            if ("object" === i(n))
                for (c in o = !0, n) He(e, t, c, n[c], !0, a, s);
            else if (void 0 !== r && (o = !0, ue(r) || (s = !0), l && (s ? (t.call(e, r), t = null) : (l = t, t = function(e, t, n) {
                    return l.call(ge(e), n)
                })), t))
                for (; c < u; c++) t(e[c], n, s ? r : r.call(e[c], c, t(e[c], n)));
            return o ? e : l ? t.call(e) : u ? t(e[0], n) : a
        },
        je = /^-ms-/,
        Re = /-([a-z])/g,
        Me = function(e) {
            return 1 === e.nodeType || 9 === e.nodeType || !+e.nodeType
        };
    g.uid = 1, g.prototype = {
        cache: function(e) {
            var t = e[this.expando];
            return t || (t = {}, Me(e) && (e.nodeType ? e[this.expando] = t : Object.defineProperty(e, this.expando, {
                value: t,
                configurable: !0
            }))), t
        },
        set: function(e, t, n) {
            var i, r = this.cache(e);
            if ("string" == typeof t) r[p(t)] = n;
            else
                for (i in t) r[p(i)] = t[i];
            return r
        },
        get: function(e, t) {
            return void 0 === t ? this.cache(e) : e[this.expando] && e[this.expando][p(t)]
        },
        access: function(e, t, n) {
            return void 0 === t || t && "string" == typeof t && void 0 === n ? this.get(e, t) : (this.set(e, t, n), void 0 !== n ? n : t)
        },
        remove: function(e, t) {
            var n, i = e[this.expando];
            if (void 0 !== i) {
                if (void 0 !== t) {
                    n = (t = Array.isArray(t) ? t.map(p) : (t = p(t)) in i ? [t] : t.match(Ie) || []).length;
                    for (; n--;) delete i[t[n]]
                }(void 0 === t || ge.isEmptyObject(i)) && (e.nodeType ? e[this.expando] = void 0 : delete e[this.expando])
            }
        },
        hasData: function(e) {
            var t = e[this.expando];
            return void 0 !== t && !ge.isEmptyObject(t)
        }
    };
    var qe = new g,
        $e = new g,
        Ue = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
        Ge = /[A-Z]/g;
    ge.extend({
        hasData: function(e) {
            return $e.hasData(e) || qe.hasData(e)
        },
        data: function(e, t, n) {
            return $e.access(e, t, n)
        },
        removeData: function(e, t) {
            $e.remove(e, t)
        },
        _data: function(e, t, n) {
            return qe.access(e, t, n)
        },
        _removeData: function(e, t) {
            qe.remove(e, t)
        }
    }), ge.fn.extend({
        data: function(e, t) {
            var n, i, r, o = this[0],
                a = o && o.attributes;
            if (void 0 === e) {
                if (this.length && (r = $e.get(o), 1 === o.nodeType && !qe.get(o, "hasDataAttrs"))) {
                    for (n = a.length; n--;) a[n] && 0 === (i = a[n].name).indexOf("data-") && (i = p(i.slice(5)), m(o, i, r[i]));
                    qe.set(o, "hasDataAttrs", !0)
                }
                return r
            }
            return "object" == typeof e ? this.each((function() {
                $e.set(this, e)
            })) : He(this, (function(t) {
                var n;
                if (o && void 0 === t) return void 0 !== (n = $e.get(o, e)) || void 0 !== (n = m(o, e)) ? n : void 0;
                this.each((function() {
                    $e.set(this, e, t)
                }))
            }), null, t, 1 < arguments.length, null, !0)
        },
        removeData: function(e) {
            return this.each((function() {
                $e.remove(this, e)
            }))
        }
    }), ge.extend({
        queue: function(e, t, n) {
            var i;
            if (e) return t = (t || "fx") + "queue", i = qe.get(e, t), n && (!i || Array.isArray(n) ? i = qe.access(e, t, ge.makeArray(n)) : i.push(n)), i || []
        },
        dequeue: function(e, t) {
            t = t || "fx";
            var n = ge.queue(e, t),
                i = n.length,
                r = n.shift(),
                o = ge._queueHooks(e, t);
            "inprogress" === r && (r = n.shift(), i--), r && ("fx" === t && n.unshift("inprogress"), delete o.stop, r.call(e, (function() {
                ge.dequeue(e, t)
            }), o)), !i && o && o.empty.fire()
        },
        _queueHooks: function(e, t) {
            var n = t + "queueHooks";
            return qe.get(e, n) || qe.access(e, n, {
                empty: ge.Callbacks("once memory").add((function() {
                    qe.remove(e, [t + "queue", n])
                }))
            })
        }
    }), ge.fn.extend({
        queue: function(e, t) {
            var n = 2;
            return "string" != typeof e && (t = e, e = "fx", n--), arguments.length < n ? ge.queue(this[0], e) : void 0 === t ? this : this.each((function() {
                var n = ge.queue(this, e, t);
                ge._queueHooks(this, e), "fx" === e && "inprogress" !== n[0] && ge.dequeue(this, e)
            }))
        },
        dequeue: function(e) {
            return this.each((function() {
                ge.dequeue(this, e)
            }))
        },
        clearQueue: function(e) {
            return this.queue(e || "fx", [])
        },
        promise: function(e, t) {
            var n, i = 1,
                r = ge.Deferred(),
                o = this,
                a = this.length,
                s = function() {
                    --i || r.resolveWith(o, [o])
                };
            for ("string" != typeof e && (t = e, e = void 0), e = e || "fx"; a--;)(n = qe.get(o[a], e + "queueHooks")) && n.empty && (i++, n.empty.add(s));
            return s(), r.promise(t)
        }
    });
    var Ve = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
        Fe = new RegExp("^(?:([+-])=|)(" + Ve + ")([a-z%]*)$", "i"),
        Be = ["Top", "Right", "Bottom", "Left"],
        We = de.documentElement,
        ze = function(e) {
            return ge.contains(e.ownerDocument, e)
        },
        Xe = {
            composed: !0
        };
    We.getRootNode && (ze = function(e) {
        return ge.contains(e.ownerDocument, e) || e.getRootNode(Xe) === e.ownerDocument
    });
    var Je = function(e, t) {
            return "none" === (e = t || e).style.display || "" === e.style.display && ze(e) && "none" === ge.css(e, "display")
        },
        Qe = {};
    ge.fn.extend({
        show: function() {
            return w(this, !0)
        },
        hide: function() {
            return w(this)
        },
        toggle: function(e) {
            return "boolean" == typeof e ? e ? this.show() : this.hide() : this.each((function() {
                Je(this) ? ge(this).show() : ge(this).hide()
            }))
        }
    });
    var Ye, Ze, Ke = /^(?:checkbox|radio)$/i,
        et = /<([a-z][^\/\0>\x20\t\r\n\f]*)/i,
        tt = /^$|^module$|\/(?:java|ecma)script/i;
    Ye = de.createDocumentFragment().appendChild(de.createElement("div")), (Ze = de.createElement("input")).setAttribute("type", "radio"), Ze.setAttribute("checked", "checked"), Ze.setAttribute("name", "t"), Ye.appendChild(Ze), ce.checkClone = Ye.cloneNode(!0).cloneNode(!0).lastChild.checked, Ye.innerHTML = "<textarea>x</textarea>", ce.noCloneChecked = !!Ye.cloneNode(!0).lastChild.defaultValue, Ye.innerHTML = "<option></option>", ce.option = !!Ye.lastChild;
    var nt = {
        thead: [1, "<table>", "</table>"],
        col: [2, "<table><colgroup>", "</colgroup></table>"],
        tr: [2, "<table><tbody>", "</tbody></table>"],
        td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
        _default: [0, "", ""]
    };
    nt.tbody = nt.tfoot = nt.colgroup = nt.caption = nt.thead, nt.th = nt.td, ce.option || (nt.optgroup = nt.option = [1, "<select multiple='multiple'>", "</select>"]);
    var it = /<|&#?\w+;/,
        rt = /^([^.]*)(?:\.(.+)|)/;
    ge.event = {
        global: {},
        add: function(e, t, n, i, r) {
            var o, a, s, c, u, l, d, f, h, p, g, m = qe.get(e);
            if (Me(e))
                for (n.handler && (n = (o = n).handler, r = o.selector), r && ge.find.matchesSelector(We, r), n.guid || (n.guid = ge.guid++), (c = m.events) || (c = m.events = Object.create(null)), (a = m.handle) || (a = m.handle = function(t) {
                        return void 0 !== ge && ge.event.triggered !== t.type ? ge.event.dispatch.apply(e, arguments) : void 0
                    }), u = (t = (t || "").match(Ie) || [""]).length; u--;) h = g = (s = rt.exec(t[u]) || [])[1], p = (s[2] || "").split(".").sort(), h && (d = ge.event.special[h] || {}, h = (r ? d.delegateType : d.bindType) || h, d = ge.event.special[h] || {}, l = ge.extend({
                    type: h,
                    origType: g,
                    data: i,
                    handler: n,
                    guid: n.guid,
                    selector: r,
                    needsContext: r && ge.expr.match.needsContext.test(r),
                    namespace: p.join(".")
                }, o), (f = c[h]) || ((f = c[h] = []).delegateCount = 0, d.setup && !1 !== d.setup.call(e, i, p, a) || e.addEventListener && e.addEventListener(h, a)), d.add && (d.add.call(e, l), l.handler.guid || (l.handler.guid = n.guid)), r ? f.splice(f.delegateCount++, 0, l) : f.push(l), ge.event.global[h] = !0)
        },
        remove: function(e, t, n, i, r) {
            var o, a, s, c, u, l, d, f, h, p, g, m = qe.hasData(e) && qe.get(e);
            if (m && (c = m.events)) {
                for (u = (t = (t || "").match(Ie) || [""]).length; u--;)
                    if (h = g = (s = rt.exec(t[u]) || [])[1], p = (s[2] || "").split(".").sort(), h) {
                        for (d = ge.event.special[h] || {}, f = c[h = (i ? d.delegateType : d.bindType) || h] || [], s = s[2] && new RegExp("(^|\\.)" + p.join("\\.(?:.*\\.|)") + "(\\.|$)"), a = o = f.length; o--;) l = f[o], !r && g !== l.origType || n && n.guid !== l.guid || s && !s.test(l.namespace) || i && i !== l.selector && ("**" !== i || !l.selector) || (f.splice(o, 1), l.selector && f.delegateCount--, d.remove && d.remove.call(e, l));
                        a && !f.length && (d.teardown && !1 !== d.teardown.call(e, p, m.handle) || ge.removeEvent(e, h, m.handle), delete c[h])
                    } else
                        for (h in c) ge.event.remove(e, h + t[u], n, i, !0);
                ge.isEmptyObject(c) && qe.remove(e, "handle events")
            }
        },
        dispatch: function(e) {
            var t, n, i, r, o, a, s = new Array(arguments.length),
                c = ge.event.fix(e),
                u = (qe.get(this, "events") || Object.create(null))[c.type] || [],
                l = ge.event.special[c.type] || {};
            for (s[0] = c, t = 1; t < arguments.length; t++) s[t] = arguments[t];
            if (c.delegateTarget = this, !l.preDispatch || !1 !== l.preDispatch.call(this, c)) {
                for (a = ge.event.handlers.call(this, c, u), t = 0;
                    (r = a[t++]) && !c.isPropagationStopped();)
                    for (c.currentTarget = r.elem, n = 0;
                        (o = r.handlers[n++]) && !c.isImmediatePropagationStopped();) c.rnamespace && !1 !== o.namespace && !c.rnamespace.test(o.namespace) || (c.handleObj = o, c.data = o.data, void 0 !== (i = ((ge.event.special[o.origType] || {}).handle || o.handler).apply(r.elem, s)) && !1 === (c.result = i) && (c.preventDefault(), c.stopPropagation()));
                return l.postDispatch && l.postDispatch.call(this, c), c.result
            }
        },
        handlers: function(e, t) {
            var n, i, r, o, a, s = [],
                c = t.delegateCount,
                u = e.target;
            if (c && u.nodeType && !("click" === e.type && 1 <= e.button))
                for (; u !== this; u = u.parentNode || this)
                    if (1 === u.nodeType && ("click" !== e.type || !0 !== u.disabled)) {
                        for (o = [], a = {}, n = 0; n < c; n++) void 0 === a[r = (i = t[n]).selector + " "] && (a[r] = i.needsContext ? -1 < ge(r, this).index(u) : ge.find(r, this, null, [u]).length), a[r] && o.push(i);
                        o.length && s.push({
                            elem: u,
                            handlers: o
                        })
                    }
            return u = this, c < t.length && s.push({
                elem: u,
                handlers: t.slice(c)
            }), s
        },
        addProp: function(e, t) {
            Object.defineProperty(ge.Event.prototype, e, {
                enumerable: !0,
                configurable: !0,
                get: ue(t) ? function() {
                    if (this.originalEvent) return t(this.originalEvent)
                } : function() {
                    if (this.originalEvent) return this.originalEvent[e]
                },
                set: function(t) {
                    Object.defineProperty(this, e, {
                        enumerable: !0,
                        configurable: !0,
                        writable: !0,
                        value: t
                    })
                }
            })
        },
        fix: function(e) {
            return e[ge.expando] ? e : new ge.Event(e)
        },
        special: {
            load: {
                noBubble: !0
            },
            click: {
                setup: function(e) {
                    var t = this || e;
                    return Ke.test(t.type) && t.click && o(t, "input") && E(t, "click", !0), !1
                },
                trigger: function(e) {
                    var t = this || e;
                    return Ke.test(t.type) && t.click && o(t, "input") && E(t, "click"), !0
                },
                _default: function(e) {
                    var t = e.target;
                    return Ke.test(t.type) && t.click && o(t, "input") && qe.get(t, "click") || o(t, "a")
                }
            },
            beforeunload: {
                postDispatch: function(e) {
                    void 0 !== e.result && e.originalEvent && (e.originalEvent.returnValue = e.result)
                }
            }
        }
    }, ge.removeEvent = function(e, t, n) {
        e.removeEventListener && e.removeEventListener(t, n)
    }, ge.Event = function(e, t) {
        if (!(this instanceof ge.Event)) return new ge.Event(e, t);
        e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || void 0 === e.defaultPrevented && !1 === e.returnValue ? x : S, this.target = e.target && 3 === e.target.nodeType ? e.target.parentNode : e.target, this.currentTarget = e.currentTarget, this.relatedTarget = e.relatedTarget) : this.type = e, t && ge.extend(this, t), this.timeStamp = e && e.timeStamp || Date.now(), this[ge.expando] = !0
    }, ge.Event.prototype = {
        constructor: ge.Event,
        isDefaultPrevented: S,
        isPropagationStopped: S,
        isImmediatePropagationStopped: S,
        isSimulated: !1,
        preventDefault: function() {
            var e = this.originalEvent;
            this.isDefaultPrevented = x, e && !this.isSimulated && e.preventDefault()
        },
        stopPropagation: function() {
            var e = this.originalEvent;
            this.isPropagationStopped = x, e && !this.isSimulated && e.stopPropagation()
        },
        stopImmediatePropagation: function() {
            var e = this.originalEvent;
            this.isImmediatePropagationStopped = x, e && !this.isSimulated && e.stopImmediatePropagation(), this.stopPropagation()
        }
    }, ge.each({
        altKey: !0,
        bubbles: !0,
        cancelable: !0,
        changedTouches: !0,
        ctrlKey: !0,
        detail: !0,
        eventPhase: !0,
        metaKey: !0,
        pageX: !0,
        pageY: !0,
        shiftKey: !0,
        view: !0,
        char: !0,
        code: !0,
        charCode: !0,
        key: !0,
        keyCode: !0,
        button: !0,
        buttons: !0,
        clientX: !0,
        clientY: !0,
        offsetX: !0,
        offsetY: !0,
        pointerId: !0,
        pointerType: !0,
        screenX: !0,
        screenY: !0,
        targetTouches: !0,
        toElement: !0,
        touches: !0,
        which: !0
    }, ge.event.addProp), ge.each({
        focus: "focusin",
        blur: "focusout"
    }, (function(e, t) {
        function n(e) {
            if (de.documentMode) {
                var n = qe.get(this, "handle"),
                    i = ge.event.fix(e);
                i.type = "focusin" === e.type ? "focus" : "blur", i.isSimulated = !0, n(e), i.target === i.currentTarget && n(i)
            } else ge.event.simulate(t, e.target, ge.event.fix(e))
        }
        ge.event.special[e] = {
            setup: function() {
                var i;
                if (E(this, e, !0), !de.documentMode) return !1;
                (i = qe.get(this, t)) || this.addEventListener(t, n), qe.set(this, t, (i || 0) + 1)
            },
            trigger: function() {
                return E(this, e), !0
            },
            teardown: function() {
                var e;
                if (!de.documentMode) return !1;
                (e = qe.get(this, t) - 1) ? qe.set(this, t, e): (this.removeEventListener(t, n), qe.remove(this, t))
            },
            _default: function(t) {
                return qe.get(t.target, e)
            },
            delegateType: t
        }, ge.event.special[t] = {
            setup: function() {
                var i = this.ownerDocument || this.document || this,
                    r = de.documentMode ? this : i,
                    o = qe.get(r, t);
                o || (de.documentMode ? this.addEventListener(t, n) : i.addEventListener(e, n, !0)), qe.set(r, t, (o || 0) + 1)
            },
            teardown: function() {
                var i = this.ownerDocument || this.document || this,
                    r = de.documentMode ? this : i,
                    o = qe.get(r, t) - 1;
                o ? qe.set(r, t, o) : (de.documentMode ? this.removeEventListener(t, n) : i.removeEventListener(e, n, !0), qe.remove(r, t))
            }
        }
    })), ge.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout",
        pointerenter: "pointerover",
        pointerleave: "pointerout"
    }, (function(e, t) {
        ge.event.special[e] = {
            delegateType: t,
            bindType: t,
            handle: function(e) {
                var n, i = e.relatedTarget,
                    r = e.handleObj;
                return i && (i === this || ge.contains(this, i)) || (e.type = r.origType, n = r.handler.apply(this, arguments), e.type = t), n
            }
        }
    })), ge.fn.extend({
        on: function(e, t, n, i) {
            return C(this, e, t, n, i)
        },
        one: function(e, t, n, i) {
            return C(this, e, t, n, i, 1)
        },
        off: function(e, t, n) {
            var i, r;
            if (e && e.preventDefault && e.handleObj) return i = e.handleObj, ge(e.delegateTarget).off(i.namespace ? i.origType + "." + i.namespace : i.origType, i.selector, i.handler), this;
            if ("object" == typeof e) {
                for (r in e) this.off(r, t, e[r]);
                return this
            }
            return !1 !== t && "function" != typeof t || (n = t, t = void 0), !1 === n && (n = S), this.each((function() {
                ge.event.remove(this, e, n, t)
            }))
        }
    });
    var ot = /<script|<style|<link/i,
        at = /checked\s*(?:[^=]|=\s*.checked.)/i,
        st = /^\s*<!\[CDATA\[|\]\]>\s*$/g;
    ge.extend({
        htmlPrefilter: function(e) {
            return e
        },
        clone: function(e, t, n) {
            var i, r, o, a, s, c, u, l = e.cloneNode(!0),
                d = ze(e);
            if (!(ce.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || ge.isXMLDoc(e)))
                for (a = y(l), i = 0, r = (o = y(e)).length; i < r; i++) s = o[i], "input" === (u = (c = a[i]).nodeName.toLowerCase()) && Ke.test(s.type) ? c.checked = s.checked : "input" !== u && "textarea" !== u || (c.defaultValue = s.defaultValue);
            if (t)
                if (n)
                    for (o = o || y(e), a = a || y(l), i = 0, r = o.length; i < r; i++) k(o[i], a[i]);
                else k(e, l);
            return 0 < (a = y(l, "script")).length && b(a, !d && y(e, "script")), l
        },
        cleanData: function(e) {
            for (var t, n, i, r = ge.event.special, o = 0; void 0 !== (n = e[o]); o++)
                if (Me(n)) {
                    if (t = n[qe.expando]) {
                        if (t.events)
                            for (i in t.events) r[i] ? ge.event.remove(n, i) : ge.removeEvent(n, i, t.handle);
                        n[qe.expando] = void 0
                    }
                    n[$e.expando] && (n[$e.expando] = void 0)
                }
        }
    }), ge.fn.extend({
        detach: function(e) {
            return P(this, e, !0)
        },
        remove: function(e) {
            return P(this, e)
        },
        text: function(e) {
            return He(this, (function(e) {
                return void 0 === e ? ge.text(this) : this.empty().each((function() {
                    1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || (this.textContent = e)
                }))
            }), null, e, arguments.length)
        },
        append: function() {
            return L(this, arguments, (function(e) {
                1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || T(this, e).appendChild(e)
            }))
        },
        prepend: function() {
            return L(this, arguments, (function(e) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var t = T(this, e);
                    t.insertBefore(e, t.firstChild)
                }
            }))
        },
        before: function() {
            return L(this, arguments, (function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this)
            }))
        },
        after: function() {
            return L(this, arguments, (function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
            }))
        },
        empty: function() {
            for (var e, t = 0; null != (e = this[t]); t++) 1 === e.nodeType && (ge.cleanData(y(e, !1)), e.textContent = "");
            return this
        },
        clone: function(e, t) {
            return e = null != e && e, t = null == t ? e : t, this.map((function() {
                return ge.clone(this, e, t)
            }))
        },
        html: function(e) {
            return He(this, (function(e) {
                var t = this[0] || {},
                    n = 0,
                    i = this.length;
                if (void 0 === e && 1 === t.nodeType) return t.innerHTML;
                if ("string" == typeof e && !ot.test(e) && !nt[(et.exec(e) || ["", ""])[1].toLowerCase()]) {
                    e = ge.htmlPrefilter(e);
                    try {
                        for (; n < i; n++) 1 === (t = this[n] || {}).nodeType && (ge.cleanData(y(t, !1)), t.innerHTML = e);
                        t = 0
                    } catch (e) {}
                }
                t && this.empty().append(e)
            }), null, e, arguments.length)
        },
        replaceWith: function() {
            var e = [];
            return L(this, arguments, (function(t) {
                var n = this.parentNode;
                ge.inArray(this, e) < 0 && (ge.cleanData(y(this)), n && n.replaceChild(t, this))
            }), e)
        }
    }), ge.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, (function(e, t) {
        ge.fn[e] = function(e) {
            for (var n, i = [], r = ge(e), o = r.length - 1, a = 0; a <= o; a++) n = a === o ? this : this.clone(!0), ge(r[a])[t](n), te.apply(i, n.get());
            return this.pushStack(i)
        }
    }));
    var ct = new RegExp("^(" + Ve + ")(?!px)[a-z%]+$", "i"),
        ut = /^--/,
        lt = function(t) {
            var n = t.ownerDocument.defaultView;
            return n && n.opener || (n = e), n.getComputedStyle(t)
        },
        dt = function(e, t, n) {
            var i, r, o = {};
            for (r in t) o[r] = e.style[r], e.style[r] = t[r];
            for (r in i = n.call(e), t) e.style[r] = o[r];
            return i
        },
        ft = new RegExp(Be.join("|"), "i");
    ! function() {
        function t() {
            if (l) {
                u.style.cssText = "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0", l.style.cssText = "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%", We.appendChild(u).appendChild(l);
                var t = e.getComputedStyle(l);
                i = "1%" !== t.top, c = 12 === n(t.marginLeft), l.style.right = "60%", a = 36 === n(t.right), r = 36 === n(t.width), l.style.position = "absolute", o = 12 === n(l.offsetWidth / 3), We.removeChild(u), l = null
            }
        }

        function n(e) {
            return Math.round(parseFloat(e))
        }
        var i, r, o, a, s, c, u = de.createElement("div"),
            l = de.createElement("div");
        l.style && (l.style.backgroundClip = "content-box", l.cloneNode(!0).style.backgroundClip = "", ce.clearCloneStyle = "content-box" === l.style.backgroundClip, ge.extend(ce, {
            boxSizingReliable: function() {
                return t(), r
            },
            pixelBoxStyles: function() {
                return t(), a
            },
            pixelPosition: function() {
                return t(), i
            },
            reliableMarginLeft: function() {
                return t(), c
            },
            scrollboxSize: function() {
                return t(), o
            },
            reliableTrDimensions: function() {
                var t, n, i, r;
                return null == s && (t = de.createElement("table"), n = de.createElement("tr"), i = de.createElement("div"), t.style.cssText = "position:absolute;left:-11111px;border-collapse:separate", n.style.cssText = "box-sizing:content-box;border:1px solid", n.style.height = "1px", i.style.height = "9px", i.style.display = "block", We.appendChild(t).appendChild(n).appendChild(i), r = e.getComputedStyle(n), s = parseInt(r.height, 10) + parseInt(r.borderTopWidth, 10) + parseInt(r.borderBottomWidth, 10) === n.offsetHeight, We.removeChild(t)), s
            }
        }))
    }();
    var ht = ["Webkit", "Moz", "ms"],
        pt = de.createElement("div").style,
        gt = {},
        mt = /^(none|table(?!-c[ea]).+)/,
        vt = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        },
        wt = {
            letterSpacing: "0",
            fontWeight: "400"
        };
    ge.extend({
        cssHooks: {
            opacity: {
                get: function(e, t) {
                    if (t) {
                        var n = I(e, "opacity");
                        return "" === n ? "1" : n
                    }
                }
            }
        },
        cssNumber: {
            animationIterationCount: !0,
            aspectRatio: !0,
            borderImageSlice: !0,
            columnCount: !0,
            flexGrow: !0,
            flexShrink: !0,
            fontWeight: !0,
            gridArea: !0,
            gridColumn: !0,
            gridColumnEnd: !0,
            gridColumnStart: !0,
            gridRow: !0,
            gridRowEnd: !0,
            gridRowStart: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            scale: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0,
            fillOpacity: !0,
            floodOpacity: !0,
            stopOpacity: !0,
            strokeMiterlimit: !0,
            strokeOpacity: !0
        },
        cssProps: {},
        style: function(e, t, n, i) {
            if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                var r, o, a, s = p(t),
                    c = ut.test(t),
                    u = e.style;
                if (c || (t = D(s)), a = ge.cssHooks[t] || ge.cssHooks[s], void 0 === n) return a && "get" in a && void 0 !== (r = a.get(e, !1, i)) ? r : u[t];
                "string" == (o = typeof n) && (r = Fe.exec(n)) && r[1] && (n = v(e, t, r), o = "number"), null != n && n == n && ("number" !== o || c || (n += r && r[3] || (ge.cssNumber[s] ? "" : "px")), ce.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (u[t] = "inherit"), a && "set" in a && void 0 === (n = a.set(e, n, i)) || (c ? u.setProperty(t, n) : u[t] = n))
            }
        },
        css: function(e, t, n, i) {
            var r, o, a, s = p(t);
            return ut.test(t) || (t = D(s)), (a = ge.cssHooks[t] || ge.cssHooks[s]) && "get" in a && (r = a.get(e, !0, n)), void 0 === r && (r = I(e, t, i)), "normal" === r && t in wt && (r = wt[t]), "" === n || n ? (o = parseFloat(r), !0 === n || isFinite(o) ? o || 0 : r) : r
        }
    }), ge.each(["height", "width"], (function(e, t) {
        ge.cssHooks[t] = {
            get: function(e, n, i) {
                if (n) return !mt.test(ge.css(e, "display")) || e.getClientRects().length && e.getBoundingClientRect().width ? R(e, t, i) : dt(e, vt, (function() {
                    return R(e, t, i)
                }))
            },
            set: function(e, n, i) {
                var r, o = lt(e),
                    a = !ce.scrollboxSize() && "absolute" === o.position,
                    s = (a || i) && "border-box" === ge.css(e, "boxSizing", !1, o),
                    c = i ? j(e, t, i, s, o) : 0;
                return s && a && (c -= Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - parseFloat(o[t]) - j(e, t, "border", !1, o) - .5)), c && (r = Fe.exec(n)) && "px" !== (r[3] || "px") && (e.style[t] = n, n = ge.css(e, t)), H(0, n, c)
            }
        }
    })), ge.cssHooks.marginLeft = N(ce.reliableMarginLeft, (function(e, t) {
        if (t) return (parseFloat(I(e, "marginLeft")) || e.getBoundingClientRect().left - dt(e, {
            marginLeft: 0
        }, (function() {
            return e.getBoundingClientRect().left
        }))) + "px"
    })), ge.each({
        margin: "",
        padding: "",
        border: "Width"
    }, (function(e, t) {
        ge.cssHooks[e + t] = {
            expand: function(n) {
                for (var i = 0, r = {}, o = "string" == typeof n ? n.split(" ") : [n]; i < 4; i++) r[e + Be[i] + t] = o[i] || o[i - 2] || o[0];
                return r
            }
        }, "margin" !== e && (ge.cssHooks[e + t].set = H)
    })), ge.fn.extend({
        css: function(e, t) {
            return He(this, (function(e, t, n) {
                var i, r, o = {},
                    a = 0;
                if (Array.isArray(t)) {
                    for (i = lt(e), r = t.length; a < r; a++) o[t[a]] = ge.css(e, t[a], !1, i);
                    return o
                }
                return void 0 !== n ? ge.style(e, t, n) : ge.css(e, t)
            }), e, t, 1 < arguments.length)
        }
    }), ((ge.Tween = M).prototype = {
        constructor: M,
        init: function(e, t, n, i, r, o) {
            this.elem = e, this.prop = n, this.easing = r || ge.easing._default, this.options = t, this.start = this.now = this.cur(), this.end = i, this.unit = o || (ge.cssNumber[n] ? "" : "px")
        },
        cur: function() {
            var e = M.propHooks[this.prop];
            return e && e.get ? e.get(this) : M.propHooks._default.get(this)
        },
        run: function(e) {
            var t, n = M.propHooks[this.prop];
            return this.options.duration ? this.pos = t = ge.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : M.propHooks._default.set(this), this
        }
    }).init.prototype = M.prototype, (M.propHooks = {
        _default: {
            get: function(e) {
                var t;
                return 1 !== e.elem.nodeType || null != e.elem[e.prop] && null == e.elem.style[e.prop] ? e.elem[e.prop] : (t = ge.css(e.elem, e.prop, "")) && "auto" !== t ? t : 0
            },
            set: function(e) {
                ge.fx.step[e.prop] ? ge.fx.step[e.prop](e) : 1 !== e.elem.nodeType || !ge.cssHooks[e.prop] && null == e.elem.style[D(e.prop)] ? e.elem[e.prop] = e.now : ge.style(e.elem, e.prop, e.now + e.unit)
            }
        }
    }).scrollTop = M.propHooks.scrollLeft = {
        set: function(e) {
            e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
        }
    }, ge.easing = {
        linear: function(e) {
            return e
        },
        swing: function(e) {
            return .5 - Math.cos(e * Math.PI) / 2
        },
        _default: "swing"
    }, ge.fx = M.prototype.init, ge.fx.step = {};
    var yt, bt, _t, xt, St = /^(?:toggle|show|hide)$/,
        Ct = /queueHooks$/;
    ge.Animation = ge.extend(V, {
        tweeners: {
            "*": [function(e, t) {
                var n = this.createTween(e, t);
                return v(n.elem, e, Fe.exec(t), n), n
            }]
        },
        tweener: function(e, t) {
            ue(e) ? (t = e, e = ["*"]) : e = e.match(Ie);
            for (var n, i = 0, r = e.length; i < r; i++) n = e[i], V.tweeners[n] = V.tweeners[n] || [], V.tweeners[n].unshift(t)
        },
        prefilters: [function(e, t, n) {
            var i, r, o, a, s, c, u, l, d = "width" in t || "height" in t,
                f = this,
                h = {},
                p = e.style,
                g = e.nodeType && Je(e),
                m = qe.get(e, "fxshow");
            for (i in n.queue || (null == (a = ge._queueHooks(e, "fx")).unqueued && (a.unqueued = 0, s = a.empty.fire, a.empty.fire = function() {
                    a.unqueued || s()
                }), a.unqueued++, f.always((function() {
                    f.always((function() {
                        a.unqueued--, ge.queue(e, "fx").length || a.empty.fire()
                    }))
                }))), t)
                if (r = t[i], St.test(r)) {
                    if (delete t[i], o = o || "toggle" === r, r === (g ? "hide" : "show")) {
                        if ("show" !== r || !m || void 0 === m[i]) continue;
                        g = !0
                    }
                    h[i] = m && m[i] || ge.style(e, i)
                }
            if ((c = !ge.isEmptyObject(t)) || !ge.isEmptyObject(h))
                for (i in d && 1 === e.nodeType && (n.overflow = [p.overflow, p.overflowX, p.overflowY], null == (u = m && m.display) && (u = qe.get(e, "display")), "none" === (l = ge.css(e, "display")) && (u ? l = u : (w([e], !0), u = e.style.display || u, l = ge.css(e, "display"), w([e]))), ("inline" === l || "inline-block" === l && null != u) && "none" === ge.css(e, "float") && (c || (f.done((function() {
                        p.display = u
                    })), null == u && (l = p.display, u = "none" === l ? "" : l)), p.display = "inline-block")), n.overflow && (p.overflow = "hidden", f.always((function() {
                        p.overflow = n.overflow[0], p.overflowX = n.overflow[1], p.overflowY = n.overflow[2]
                    }))), c = !1, h) c || (m ? "hidden" in m && (g = m.hidden) : m = qe.access(e, "fxshow", {
                    display: u
                }), o && (m.hidden = !g), g && w([e], !0), f.done((function() {
                    for (i in g || w([e]), qe.remove(e, "fxshow"), h) ge.style(e, i, h[i])
                }))), c = G(g ? m[i] : 0, i, f), i in m || (m[i] = c.start, g && (c.end = c.start, c.start = 0))
        }],
        prefilter: function(e, t) {
            t ? V.prefilters.unshift(e) : V.prefilters.push(e)
        }
    }), ge.speed = function(e, t, n) {
        var i = e && "object" == typeof e ? ge.extend({}, e) : {
            complete: n || !n && t || ue(e) && e,
            duration: e,
            easing: n && t || t && !ue(t) && t
        };
        return ge.fx.off ? i.duration = 0 : "number" != typeof i.duration && (i.duration in ge.fx.speeds ? i.duration = ge.fx.speeds[i.duration] : i.duration = ge.fx.speeds._default), null != i.queue && !0 !== i.queue || (i.queue = "fx"), i.old = i.complete, i.complete = function() {
            ue(i.old) && i.old.call(this), i.queue && ge.dequeue(this, i.queue)
        }, i
    }, ge.fn.extend({
        fadeTo: function(e, t, n, i) {
            return this.filter(Je).css("opacity", 0).show().end().animate({
                opacity: t
            }, e, n, i)
        },
        animate: function(e, t, n, i) {
            var r = ge.isEmptyObject(e),
                o = ge.speed(t, n, i),
                a = function() {
                    var t = V(this, ge.extend({}, e), o);
                    (r || qe.get(this, "finish")) && t.stop(!0)
                };
            return a.finish = a, r || !1 === o.queue ? this.each(a) : this.queue(o.queue, a)
        },
        stop: function(e, t, n) {
            var i = function(e) {
                var t = e.stop;
                delete e.stop, t(n)
            };
            return "string" != typeof e && (n = t, t = e, e = void 0), t && this.queue(e || "fx", []), this.each((function() {
                var t = !0,
                    r = null != e && e + "queueHooks",
                    o = ge.timers,
                    a = qe.get(this);
                if (r) a[r] && a[r].stop && i(a[r]);
                else
                    for (r in a) a[r] && a[r].stop && Ct.test(r) && i(a[r]);
                for (r = o.length; r--;) o[r].elem !== this || null != e && o[r].queue !== e || (o[r].anim.stop(n), t = !1, o.splice(r, 1));
                !t && n || ge.dequeue(this, e)
            }))
        },
        finish: function(e) {
            return !1 !== e && (e = e || "fx"), this.each((function() {
                var t, n = qe.get(this),
                    i = n[e + "queue"],
                    r = n[e + "queueHooks"],
                    o = ge.timers,
                    a = i ? i.length : 0;
                for (n.finish = !0, ge.queue(this, e, []), r && r.stop && r.stop.call(this, !0), t = o.length; t--;) o[t].elem === this && o[t].queue === e && (o[t].anim.stop(!0), o.splice(t, 1));
                for (t = 0; t < a; t++) i[t] && i[t].finish && i[t].finish.call(this);
                delete n.finish
            }))
        }
    }), ge.each(["toggle", "show", "hide"], (function(e, t) {
        var n = ge.fn[t];
        ge.fn[t] = function(e, i, r) {
            return null == e || "boolean" == typeof e ? n.apply(this, arguments) : this.animate(U(t, !0), e, i, r)
        }
    })), ge.each({
        slideDown: U("show"),
        slideUp: U("hide"),
        slideToggle: U("toggle"),
        fadeIn: {
            opacity: "show"
        },
        fadeOut: {
            opacity: "hide"
        },
        fadeToggle: {
            opacity: "toggle"
        }
    }, (function(e, t) {
        ge.fn[e] = function(e, n, i) {
            return this.animate(t, e, n, i)
        }
    })), ge.timers = [], ge.fx.tick = function() {
        var e, t = 0,
            n = ge.timers;
        for (yt = Date.now(); t < n.length; t++)(e = n[t])() || n[t] !== e || n.splice(t--, 1);
        n.length || ge.fx.stop(), yt = void 0
    }, ge.fx.timer = function(e) {
        ge.timers.push(e), ge.fx.start()
    }, ge.fx.interval = 13, ge.fx.start = function() {
        bt || (bt = !0, q())
    }, ge.fx.stop = function() {
        bt = null
    }, ge.fx.speeds = {
        slow: 600,
        fast: 200,
        _default: 400
    }, ge.fn.delay = function(t, n) {
        return t = ge.fx && ge.fx.speeds[t] || t, n = n || "fx", this.queue(n, (function(n, i) {
            var r = e.setTimeout(n, t);
            i.stop = function() {
                e.clearTimeout(r)
            }
        }))
    }, _t = de.createElement("input"), xt = de.createElement("select").appendChild(de.createElement("option")), _t.type = "checkbox", ce.checkOn = "" !== _t.value, ce.optSelected = xt.selected, (_t = de.createElement("input")).value = "t", _t.type = "radio", ce.radioValue = "t" === _t.value;
    var Et, Tt = ge.expr.attrHandle;
    ge.fn.extend({
        attr: function(e, t) {
            return He(this, ge.attr, e, t, 1 < arguments.length)
        },
        removeAttr: function(e) {
            return this.each((function() {
                ge.removeAttr(this, e)
            }))
        }
    }), ge.extend({
        attr: function(e, t, n) {
            var i, r, o = e.nodeType;
            if (3 !== o && 8 !== o && 2 !== o) return void 0 === e.getAttribute ? ge.prop(e, t, n) : (1 === o && ge.isXMLDoc(e) || (r = ge.attrHooks[t.toLowerCase()] || (ge.expr.match.bool.test(t) ? Et : void 0)), void 0 !== n ? null === n ? void ge.removeAttr(e, t) : r && "set" in r && void 0 !== (i = r.set(e, n, t)) ? i : (e.setAttribute(t, n + ""), n) : r && "get" in r && null !== (i = r.get(e, t)) ? i : null == (i = ge.find.attr(e, t)) ? void 0 : i)
        },
        attrHooks: {
            type: {
                set: function(e, t) {
                    if (!ce.radioValue && "radio" === t && o(e, "input")) {
                        var n = e.value;
                        return e.setAttribute("type", t), n && (e.value = n), t
                    }
                }
            }
        },
        removeAttr: function(e, t) {
            var n, i = 0,
                r = t && t.match(Ie);
            if (r && 1 === e.nodeType)
                for (; n = r[i++];) e.removeAttribute(n)
        }
    }), Et = {
        set: function(e, t, n) {
            return !1 === t ? ge.removeAttr(e, n) : e.setAttribute(n, n), n
        }
    }, ge.each(ge.expr.match.bool.source.match(/\w+/g), (function(e, t) {
        var n = Tt[t] || ge.find.attr;
        Tt[t] = function(e, t, i) {
            var r, o, a = t.toLowerCase();
            return i || (o = Tt[a], Tt[a] = r, r = null != n(e, t, i) ? a : null, Tt[a] = o), r
        }
    }));
    var At = /^(?:input|select|textarea|button)$/i,
        Ot = /^(?:a|area)$/i;
    ge.fn.extend({
        prop: function(e, t) {
            return He(this, ge.prop, e, t, 1 < arguments.length)
        },
        removeProp: function(e) {
            return this.each((function() {
                delete this[ge.propFix[e] || e]
            }))
        }
    }), ge.extend({
        prop: function(e, t, n) {
            var i, r, o = e.nodeType;
            if (3 !== o && 8 !== o && 2 !== o) return 1 === o && ge.isXMLDoc(e) || (t = ge.propFix[t] || t, r = ge.propHooks[t]), void 0 !== n ? r && "set" in r && void 0 !== (i = r.set(e, n, t)) ? i : e[t] = n : r && "get" in r && null !== (i = r.get(e, t)) ? i : e[t]
        },
        propHooks: {
            tabIndex: {
                get: function(e) {
                    var t = ge.find.attr(e, "tabindex");
                    return t ? parseInt(t, 10) : At.test(e.nodeName) || Ot.test(e.nodeName) && e.href ? 0 : -1
                }
            }
        },
        propFix: {
            for: "htmlFor",
            class: "className"
        }
    }), ce.optSelected || (ge.propHooks.selected = {
        get: function(e) {
            var t = e.parentNode;
            return t && t.parentNode && t.parentNode.selectedIndex, null
        },
        set: function(e) {
            var t = e.parentNode;
            t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex)
        }
    }), ge.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], (function() {
        ge.propFix[this.toLowerCase()] = this
    })), ge.fn.extend({
        addClass: function(e) {
            var t, n, i, r, o, a;
            return ue(e) ? this.each((function(t) {
                ge(this).addClass(e.call(this, t, B(this)))
            })) : (t = W(e)).length ? this.each((function() {
                if (i = B(this), n = 1 === this.nodeType && " " + F(i) + " ") {
                    for (o = 0; o < t.length; o++) r = t[o], n.indexOf(" " + r + " ") < 0 && (n += r + " ");
                    a = F(n), i !== a && this.setAttribute("class", a)
                }
            })) : this
        },
        removeClass: function(e) {
            var t, n, i, r, o, a;
            return ue(e) ? this.each((function(t) {
                ge(this).removeClass(e.call(this, t, B(this)))
            })) : arguments.length ? (t = W(e)).length ? this.each((function() {
                if (i = B(this), n = 1 === this.nodeType && " " + F(i) + " ") {
                    for (o = 0; o < t.length; o++)
                        for (r = t[o]; - 1 < n.indexOf(" " + r + " ");) n = n.replace(" " + r + " ", " ");
                    a = F(n), i !== a && this.setAttribute("class", a)
                }
            })) : this : this.attr("class", "")
        },
        toggleClass: function(e, t) {
            var n, i, r, o, a = typeof e,
                s = "string" === a || Array.isArray(e);
            return ue(e) ? this.each((function(n) {
                ge(this).toggleClass(e.call(this, n, B(this), t), t)
            })) : "boolean" == typeof t && s ? t ? this.addClass(e) : this.removeClass(e) : (n = W(e), this.each((function() {
                if (s)
                    for (o = ge(this), r = 0; r < n.length; r++) i = n[r], o.hasClass(i) ? o.removeClass(i) : o.addClass(i);
                else void 0 !== e && "boolean" !== a || ((i = B(this)) && qe.set(this, "__className__", i), this.setAttribute && this.setAttribute("class", i || !1 === e ? "" : qe.get(this, "__className__") || ""))
            })))
        },
        hasClass: function(e) {
            var t, n, i = 0;
            for (t = " " + e + " "; n = this[i++];)
                if (1 === n.nodeType && -1 < (" " + F(B(n)) + " ").indexOf(t)) return !0;
            return !1
        }
    });
    var kt = /\r/g;
    ge.fn.extend({
        val: function(e) {
            var t, n, i, r = this[0];
            return arguments.length ? (i = ue(e), this.each((function(n) {
                var r;
                1 === this.nodeType && (null == (r = i ? e.call(this, n, ge(this).val()) : e) ? r = "" : "number" == typeof r ? r += "" : Array.isArray(r) && (r = ge.map(r, (function(e) {
                    return null == e ? "" : e + ""
                }))), (t = ge.valHooks[this.type] || ge.valHooks[this.nodeName.toLowerCase()]) && "set" in t && void 0 !== t.set(this, r, "value") || (this.value = r))
            }))) : r ? (t = ge.valHooks[r.type] || ge.valHooks[r.nodeName.toLowerCase()]) && "get" in t && void 0 !== (n = t.get(r, "value")) ? n : "string" == typeof(n = r.value) ? n.replace(kt, "") : null == n ? "" : n : void 0
        }
    }), ge.extend({
        valHooks: {
            option: {
                get: function(e) {
                    var t = ge.find.attr(e, "value");
                    return null != t ? t : F(ge.text(e))
                }
            },
            select: {
                get: function(e) {
                    var t, n, i, r = e.options,
                        a = e.selectedIndex,
                        s = "select-one" === e.type,
                        c = s ? null : [],
                        u = s ? a + 1 : r.length;
                    for (i = a < 0 ? u : s ? a : 0; i < u; i++)
                        if (((n = r[i]).selected || i === a) && !n.disabled && (!n.parentNode.disabled || !o(n.parentNode, "optgroup"))) {
                            if (t = ge(n).val(), s) return t;
                            c.push(t)
                        }
                    return c
                },
                set: function(e, t) {
                    for (var n, i, r = e.options, o = ge.makeArray(t), a = r.length; a--;)((i = r[a]).selected = -1 < ge.inArray(ge.valHooks.option.get(i), o)) && (n = !0);
                    return n || (e.selectedIndex = -1), o
                }
            }
        }
    }), ge.each(["radio", "checkbox"], (function() {
        ge.valHooks[this] = {
            set: function(e, t) {
                if (Array.isArray(t)) return e.checked = -1 < ge.inArray(ge(e).val(), t)
            }
        }, ce.checkOn || (ge.valHooks[this].get = function(e) {
            return null === e.getAttribute("value") ? "on" : e.value
        })
    }));
    var Lt = e.location,
        Pt = {
            guid: Date.now()
        },
        It = /\?/;
    ge.parseXML = function(t) {
        var n, i;
        if (!t || "string" != typeof t) return null;
        try {
            n = (new e.DOMParser).parseFromString(t, "text/xml")
        } catch (t) {}
        return i = n && n.getElementsByTagName("parsererror")[0], n && !i || ge.error("Invalid XML: " + (i ? ge.map(i.childNodes, (function(e) {
            return e.textContent
        })).join("\n") : t)), n
    };
    var Nt = /^(?:focusinfocus|focusoutblur)$/,
        Dt = function(e) {
            e.stopPropagation()
        };
    ge.extend(ge.event, {
        trigger: function(t, n, i, r) {
            var o, a, s, c, u, l, d, f, h = [i || de],
                p = oe.call(t, "type") ? t.type : t,
                g = oe.call(t, "namespace") ? t.namespace.split(".") : [];
            if (a = f = s = i = i || de, 3 !== i.nodeType && 8 !== i.nodeType && !Nt.test(p + ge.event.triggered) && (-1 < p.indexOf(".") && (p = (g = p.split(".")).shift(), g.sort()), u = p.indexOf(":") < 0 && "on" + p, (t = t[ge.expando] ? t : new ge.Event(p, "object" == typeof t && t)).isTrigger = r ? 2 : 3, t.namespace = g.join("."), t.rnamespace = t.namespace ? new RegExp("(^|\\.)" + g.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, t.result = void 0, t.target || (t.target = i), n = null == n ? [t] : ge.makeArray(n, [t]), d = ge.event.special[p] || {}, r || !d.trigger || !1 !== d.trigger.apply(i, n))) {
                if (!r && !d.noBubble && !le(i)) {
                    for (c = d.delegateType || p, Nt.test(c + p) || (a = a.parentNode); a; a = a.parentNode) h.push(a), s = a;
                    s === (i.ownerDocument || de) && h.push(s.defaultView || s.parentWindow || e)
                }
                for (o = 0;
                    (a = h[o++]) && !t.isPropagationStopped();) f = a, t.type = 1 < o ? c : d.bindType || p, (l = (qe.get(a, "events") || Object.create(null))[t.type] && qe.get(a, "handle")) && l.apply(a, n), (l = u && a[u]) && l.apply && Me(a) && (t.result = l.apply(a, n), !1 === t.result && t.preventDefault());
                return t.type = p, r || t.isDefaultPrevented() || d._default && !1 !== d._default.apply(h.pop(), n) || !Me(i) || u && ue(i[p]) && !le(i) && ((s = i[u]) && (i[u] = null), ge.event.triggered = p, t.isPropagationStopped() && f.addEventListener(p, Dt), i[p](), t.isPropagationStopped() && f.removeEventListener(p, Dt), ge.event.triggered = void 0, s && (i[u] = s)), t.result
            }
        },
        simulate: function(e, t, n) {
            var i = ge.extend(new ge.Event, n, {
                type: e,
                isSimulated: !0
            });
            ge.event.trigger(i, null, t)
        }
    }), ge.fn.extend({
        trigger: function(e, t) {
            return this.each((function() {
                ge.event.trigger(e, t, this)
            }))
        },
        triggerHandler: function(e, t) {
            var n = this[0];
            if (n) return ge.event.trigger(e, t, n, !0)
        }
    });
    var Ht = /\[\]$/,
        jt = /\r?\n/g,
        Rt = /^(?:submit|button|image|reset|file)$/i,
        Mt = /^(?:input|select|textarea|keygen)/i;
    ge.param = function(e, t) {
        var n, i = [],
            r = function(e, t) {
                var n = ue(t) ? t() : t;
                i[i.length] = encodeURIComponent(e) + "=" + encodeURIComponent(null == n ? "" : n)
            };
        if (null == e) return "";
        if (Array.isArray(e) || e.jquery && !ge.isPlainObject(e)) ge.each(e, (function() {
            r(this.name, this.value)
        }));
        else
            for (n in e) z(n, e[n], t, r);
        return i.join("&")
    }, ge.fn.extend({
        serialize: function() {
            return ge.param(this.serializeArray())
        },
        serializeArray: function() {
            return this.map((function() {
                var e = ge.prop(this, "elements");
                return e ? ge.makeArray(e) : this
            })).filter((function() {
                var e = this.type;
                return this.name && !ge(this).is(":disabled") && Mt.test(this.nodeName) && !Rt.test(e) && (this.checked || !Ke.test(e))
            })).map((function(e, t) {
                var n = ge(this).val();
                return null == n ? null : Array.isArray(n) ? ge.map(n, (function(e) {
                    return {
                        name: t.name,
                        value: e.replace(jt, "\r\n")
                    }
                })) : {
                    name: t.name,
                    value: n.replace(jt, "\r\n")
                }
            })).get()
        }
    });
    var qt = /%20/g,
        $t = /#.*$/,
        Ut = /([?&])_=[^&]*/,
        Gt = /^(.*?):[ \t]*([^\r\n]*)$/gm,
        Vt = /^(?:GET|HEAD)$/,
        Ft = /^\/\//,
        Bt = {},
        Wt = {},
        zt = "*/".concat("*"),
        Xt = de.createElement("a");
    Xt.href = Lt.href, ge.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: Lt.href,
            type: "GET",
            isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(Lt.protocol),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": zt,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /\bxml\b/,
                html: /\bhtml/,
                json: /\bjson\b/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText",
                json: "responseJSON"
            },
            converters: {
                "* text": String,
                "text html": !0,
                "text json": JSON.parse,
                "text xml": ge.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function(e, t) {
            return t ? Q(Q(e, ge.ajaxSettings), t) : Q(ge.ajaxSettings, e)
        },
        ajaxPrefilter: X(Bt),
        ajaxTransport: X(Wt),
        ajax: function(t, n) {
            function i(t, n, i, s) {
                var u, f, h, b, _, x = n;
                l || (l = !0, c && e.clearTimeout(c), r = void 0, a = s || "", S.readyState = 0 < t ? 4 : 0, u = 200 <= t && t < 300 || 304 === t, i && (b = function(e, t, n) {
                    for (var i, r, o, a, s = e.contents, c = e.dataTypes;
                        "*" === c[0];) c.shift(), void 0 === i && (i = e.mimeType || t.getResponseHeader("Content-Type"));
                    if (i)
                        for (r in s)
                            if (s[r] && s[r].test(i)) {
                                c.unshift(r);
                                break
                            }
                    if (c[0] in n) o = c[0];
                    else {
                        for (r in n) {
                            if (!c[0] || e.converters[r + " " + c[0]]) {
                                o = r;
                                break
                            }
                            a || (a = r)
                        }
                        o = o || a
                    }
                    if (o) return o !== c[0] && c.unshift(o), n[o]
                }(p, S, i)), !u && -1 < ge.inArray("script", p.dataTypes) && ge.inArray("json", p.dataTypes) < 0 && (p.converters["text script"] = function() {}), b = function(e, t, n, i) {
                    var r, o, a, s, c, u = {},
                        l = e.dataTypes.slice();
                    if (l[1])
                        for (a in e.converters) u[a.toLowerCase()] = e.converters[a];
                    for (o = l.shift(); o;)
                        if (e.responseFields[o] && (n[e.responseFields[o]] = t), !c && i && e.dataFilter && (t = e.dataFilter(t, e.dataType)), c = o, o = l.shift())
                            if ("*" === o) o = c;
                            else if ("*" !== c && c !== o) {
                        if (!(a = u[c + " " + o] || u["* " + o]))
                            for (r in u)
                                if ((s = r.split(" "))[1] === o && (a = u[c + " " + s[0]] || u["* " + s[0]])) {
                                    !0 === a ? a = u[r] : !0 !== u[r] && (o = s[0], l.unshift(s[1]));
                                    break
                                }
                        if (!0 !== a)
                            if (a && e.throws) t = a(t);
                            else try {
                                t = a(t)
                            } catch (e) {
                                return {
                                    state: "parsererror",
                                    error: a ? e : "No conversion from " + c + " to " + o
                                }
                            }
                    }
                    return {
                        state: "success",
                        data: t
                    }
                }(p, b, S, u), u ? (p.ifModified && ((_ = S.getResponseHeader("Last-Modified")) && (ge.lastModified[o] = _), (_ = S.getResponseHeader("etag")) && (ge.etag[o] = _)), 204 === t || "HEAD" === p.type ? x = "nocontent" : 304 === t ? x = "notmodified" : (x = b.state, f = b.data, u = !(h = b.error))) : (h = x, !t && x || (x = "error", t < 0 && (t = 0))), S.status = t, S.statusText = (n || x) + "", u ? v.resolveWith(g, [f, x, S]) : v.rejectWith(g, [S, x, h]), S.statusCode(y), y = void 0, d && m.trigger(u ? "ajaxSuccess" : "ajaxError", [S, p, u ? f : h]), w.fireWith(g, [S, x]), d && (m.trigger("ajaxComplete", [S, p]), --ge.active || ge.event.trigger("ajaxStop")))
            }
            "object" == typeof t && (n = t, t = void 0), n = n || {};
            var r, o, a, s, c, u, l, d, f, h, p = ge.ajaxSetup({}, n),
                g = p.context || p,
                m = p.context && (g.nodeType || g.jquery) ? ge(g) : ge.event,
                v = ge.Deferred(),
                w = ge.Callbacks("once memory"),
                y = p.statusCode || {},
                b = {},
                _ = {},
                x = "canceled",
                S = {
                    readyState: 0,
                    getResponseHeader: function(e) {
                        var t;
                        if (l) {
                            if (!s)
                                for (s = {}; t = Gt.exec(a);) s[t[1].toLowerCase() + " "] = (s[t[1].toLowerCase() + " "] || []).concat(t[2]);
                            t = s[e.toLowerCase() + " "]
                        }
                        return null == t ? null : t.join(", ")
                    },
                    getAllResponseHeaders: function() {
                        return l ? a : null
                    },
                    setRequestHeader: function(e, t) {
                        return null == l && (e = _[e.toLowerCase()] = _[e.toLowerCase()] || e, b[e] = t), this
                    },
                    overrideMimeType: function(e) {
                        return null == l && (p.mimeType = e), this
                    },
                    statusCode: function(e) {
                        var t;
                        if (e)
                            if (l) S.always(e[S.status]);
                            else
                                for (t in e) y[t] = [y[t], e[t]];
                        return this
                    },
                    abort: function(e) {
                        var t = e || x;
                        return r && r.abort(t), i(0, t), this
                    }
                };
            if (v.promise(S), p.url = ((t || p.url || Lt.href) + "").replace(Ft, Lt.protocol + "//"), p.type = n.method || n.type || p.method || p.type, p.dataTypes = (p.dataType || "*").toLowerCase().match(Ie) || [""], null == p.crossDomain) {
                u = de.createElement("a");
                try {
                    u.href = p.url, u.href = u.href, p.crossDomain = Xt.protocol + "//" + Xt.host != u.protocol + "//" + u.host
                } catch (t) {
                    p.crossDomain = !0
                }
            }
            if (p.data && p.processData && "string" != typeof p.data && (p.data = ge.param(p.data, p.traditional)), J(Bt, p, n, S), l) return S;
            for (f in (d = ge.event && p.global) && 0 == ge.active++ && ge.event.trigger("ajaxStart"), p.type = p.type.toUpperCase(), p.hasContent = !Vt.test(p.type), o = p.url.replace($t, ""), p.hasContent ? p.data && p.processData && 0 === (p.contentType || "").indexOf("application/x-www-form-urlencoded") && (p.data = p.data.replace(qt, "+")) : (h = p.url.slice(o.length), p.data && (p.processData || "string" == typeof p.data) && (o += (It.test(o) ? "&" : "?") + p.data, delete p.data), !1 === p.cache && (o = o.replace(Ut, "$1"), h = (It.test(o) ? "&" : "?") + "_=" + Pt.guid++ + h), p.url = o + h), p.ifModified && (ge.lastModified[o] && S.setRequestHeader("If-Modified-Since", ge.lastModified[o]), ge.etag[o] && S.setRequestHeader("If-None-Match", ge.etag[o])), (p.data && p.hasContent && !1 !== p.contentType || n.contentType) && S.setRequestHeader("Content-Type", p.contentType), S.setRequestHeader("Accept", p.dataTypes[0] && p.accepts[p.dataTypes[0]] ? p.accepts[p.dataTypes[0]] + ("*" !== p.dataTypes[0] ? ", " + zt + "; q=0.01" : "") : p.accepts["*"]), p.headers) S.setRequestHeader(f, p.headers[f]);
            if (p.beforeSend && (!1 === p.beforeSend.call(g, S, p) || l)) return S.abort();
            if (x = "abort", w.add(p.complete), S.done(p.success), S.fail(p.error), r = J(Wt, p, n, S)) {
                if (S.readyState = 1, d && m.trigger("ajaxSend", [S, p]), l) return S;
                p.async && 0 < p.timeout && (c = e.setTimeout((function() {
                    S.abort("timeout")
                }), p.timeout));
                try {
                    l = !1, r.send(b, i)
                } catch (t) {
                    if (l) throw t;
                    i(-1, t)
                }
            } else i(-1, "No Transport");
            return S
        },
        getJSON: function(e, t, n) {
            return ge.get(e, t, n, "json")
        },
        getScript: function(e, t) {
            return ge.get(e, void 0, t, "script")
        }
    }), ge.each(["get", "post"], (function(e, t) {
        ge[t] = function(e, n, i, r) {
            return ue(n) && (r = r || i, i = n, n = void 0), ge.ajax(ge.extend({
                url: e,
                type: t,
                dataType: r,
                data: n,
                success: i
            }, ge.isPlainObject(e) && e))
        }
    })), ge.ajaxPrefilter((function(e) {
        var t;
        for (t in e.headers) "content-type" === t.toLowerCase() && (e.contentType = e.headers[t] || "")
    })), ge._evalUrl = function(e, t, n) {
        return ge.ajax({
            url: e,
            type: "GET",
            dataType: "script",
            cache: !0,
            async: !1,
            global: !1,
            converters: {
                "text script": function() {}
            },
            dataFilter: function(e) {
                ge.globalEval(e, t, n)
            }
        })
    }, ge.fn.extend({
        wrapAll: function(e) {
            var t;
            return this[0] && (ue(e) && (e = e.call(this[0])), t = ge(e, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && t.insertBefore(this[0]), t.map((function() {
                for (var e = this; e.firstElementChild;) e = e.firstElementChild;
                return e
            })).append(this)), this
        },
        wrapInner: function(e) {
            return ue(e) ? this.each((function(t) {
                ge(this).wrapInner(e.call(this, t))
            })) : this.each((function() {
                var t = ge(this),
                    n = t.contents();
                n.length ? n.wrapAll(e) : t.append(e)
            }))
        },
        wrap: function(e) {
            var t = ue(e);
            return this.each((function(n) {
                ge(this).wrapAll(t ? e.call(this, n) : e)
            }))
        },
        unwrap: function(e) {
            return this.parent(e).not("body").each((function() {
                ge(this).replaceWith(this.childNodes)
            })), this
        }
    }), ge.expr.pseudos.hidden = function(e) {
        return !ge.expr.pseudos.visible(e)
    }, ge.expr.pseudos.visible = function(e) {
        return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)
    }, ge.ajaxSettings.xhr = function() {
        try {
            return new e.XMLHttpRequest
        } catch (e) {}
    };
    var Jt = {
            0: 200,
            1223: 204
        },
        Qt = ge.ajaxSettings.xhr();
    ce.cors = !!Qt && "withCredentials" in Qt, ce.ajax = Qt = !!Qt, ge.ajaxTransport((function(t) {
        var n, i;
        if (ce.cors || Qt && !t.crossDomain) return {
            send: function(r, o) {
                var a, s = t.xhr();
                if (s.open(t.type, t.url, t.async, t.username, t.password), t.xhrFields)
                    for (a in t.xhrFields) s[a] = t.xhrFields[a];
                for (a in t.mimeType && s.overrideMimeType && s.overrideMimeType(t.mimeType), t.crossDomain || r["X-Requested-With"] || (r["X-Requested-With"] = "XMLHttpRequest"), r) s.setRequestHeader(a, r[a]);
                n = function(e) {
                    return function() {
                        n && (n = i = s.onload = s.onerror = s.onabort = s.ontimeout = s.onreadystatechange = null, "abort" === e ? s.abort() : "error" === e ? "number" != typeof s.status ? o(0, "error") : o(s.status, s.statusText) : o(Jt[s.status] || s.status, s.statusText, "text" !== (s.responseType || "text") || "string" != typeof s.responseText ? {
                            binary: s.response
                        } : {
                            text: s.responseText
                        }, s.getAllResponseHeaders()))
                    }
                }, s.onload = n(), i = s.onerror = s.ontimeout = n("error"), void 0 !== s.onabort ? s.onabort = i : s.onreadystatechange = function() {
                    4 === s.readyState && e.setTimeout((function() {
                        n && i()
                    }))
                }, n = n("abort");
                try {
                    s.send(t.hasContent && t.data || null)
                } catch (r) {
                    if (n) throw r
                }
            },
            abort: function() {
                n && n()
            }
        }
    })), ge.ajaxPrefilter((function(e) {
        e.crossDomain && (e.contents.script = !1)
    })), ge.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /\b(?:java|ecma)script\b/
        },
        converters: {
            "text script": function(e) {
                return ge.globalEval(e), e
            }
        }
    }), ge.ajaxPrefilter("script", (function(e) {
        void 0 === e.cache && (e.cache = !1), e.crossDomain && (e.type = "GET")
    })), ge.ajaxTransport("script", (function(e) {
        var t, n;
        if (e.crossDomain || e.scriptAttrs) return {
            send: function(i, r) {
                t = ge("<script>").attr(e.scriptAttrs || {}).prop({
                    charset: e.scriptCharset,
                    src: e.url
                }).on("load error", n = function(e) {
                    t.remove(), n = null, e && r("error" === e.type ? 404 : 200, e.type)
                }), de.head.appendChild(t[0])
            },
            abort: function() {
                n && n()
            }
        }
    }));
    var Yt, Zt = [],
        Kt = /(=)\?(?=&|$)|\?\?/;
    ge.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function() {
            var e = Zt.pop() || ge.expando + "_" + Pt.guid++;
            return this[e] = !0, e
        }
    }), ge.ajaxPrefilter("json jsonp", (function(t, n, i) {
        var r, o, a, s = !1 !== t.jsonp && (Kt.test(t.url) ? "url" : "string" == typeof t.data && 0 === (t.contentType || "").indexOf("application/x-www-form-urlencoded") && Kt.test(t.data) && "data");
        if (s || "jsonp" === t.dataTypes[0]) return r = t.jsonpCallback = ue(t.jsonpCallback) ? t.jsonpCallback() : t.jsonpCallback, s ? t[s] = t[s].replace(Kt, "$1" + r) : !1 !== t.jsonp && (t.url += (It.test(t.url) ? "&" : "?") + t.jsonp + "=" + r), t.converters["script json"] = function() {
            return a || ge.error(r + " was not called"), a[0]
        }, t.dataTypes[0] = "json", o = e[r], e[r] = function() {
            a = arguments
        }, i.always((function() {
            void 0 === o ? ge(e).removeProp(r) : e[r] = o, t[r] && (t.jsonpCallback = n.jsonpCallback, Zt.push(r)), a && ue(o) && o(a[0]), a = o = void 0
        })), "script"
    })), ce.createHTMLDocument = ((Yt = de.implementation.createHTMLDocument("").body).innerHTML = "<form></form><form></form>", 2 === Yt.childNodes.length), ge.parseHTML = function(e, t, n) {
        return "string" != typeof e ? [] : ("boolean" == typeof t && (n = t, t = !1), t || (ce.createHTMLDocument ? ((i = (t = de.implementation.createHTMLDocument("")).createElement("base")).href = de.location.href, t.head.appendChild(i)) : t = de), o = !n && [], (r = Ae.exec(e)) ? [t.createElement(r[1])] : (r = _([e], t, o), o && o.length && ge(o).remove(), ge.merge([], r.childNodes)));
        var i, r, o
    }, ge.fn.load = function(e, t, n) {
        var i, r, o, a = this,
            s = e.indexOf(" ");
        return -1 < s && (i = F(e.slice(s)), e = e.slice(0, s)), ue(t) ? (n = t, t = void 0) : t && "object" == typeof t && (r = "POST"), 0 < a.length && ge.ajax({
            url: e,
            type: r || "GET",
            dataType: "html",
            data: t
        }).done((function(e) {
            o = arguments, a.html(i ? ge("<div>").append(ge.parseHTML(e)).find(i) : e)
        })).always(n && function(e, t) {
            a.each((function() {
                n.apply(this, o || [e.responseText, t, e])
            }))
        }), this
    }, ge.expr.pseudos.animated = function(e) {
        return ge.grep(ge.timers, (function(t) {
            return e === t.elem
        })).length
    }, ge.offset = {
        setOffset: function(e, t, n) {
            var i, r, o, a, s, c, u = ge.css(e, "position"),
                l = ge(e),
                d = {};
            "static" === u && (e.style.position = "relative"), s = l.offset(), o = ge.css(e, "top"), c = ge.css(e, "left"), ("absolute" === u || "fixed" === u) && -1 < (o + c).indexOf("auto") ? (a = (i = l.position()).top, r = i.left) : (a = parseFloat(o) || 0, r = parseFloat(c) || 0), ue(t) && (t = t.call(e, n, ge.extend({}, s))), null != t.top && (d.top = t.top - s.top + a), null != t.left && (d.left = t.left - s.left + r), "using" in t ? t.using.call(e, d) : l.css(d)
        }
    }, ge.fn.extend({
        offset: function(e) {
            if (arguments.length) return void 0 === e ? this : this.each((function(t) {
                ge.offset.setOffset(this, e, t)
            }));
            var t, n, i = this[0];
            return i ? i.getClientRects().length ? (t = i.getBoundingClientRect(), n = i.ownerDocument.defaultView, {
                top: t.top + n.pageYOffset,
                left: t.left + n.pageXOffset
            }) : {
                top: 0,
                left: 0
            } : void 0
        },
        position: function() {
            if (this[0]) {
                var e, t, n, i = this[0],
                    r = {
                        top: 0,
                        left: 0
                    };
                if ("fixed" === ge.css(i, "position")) t = i.getBoundingClientRect();
                else {
                    for (t = this.offset(), n = i.ownerDocument, e = i.offsetParent || n.documentElement; e && (e === n.body || e === n.documentElement) && "static" === ge.css(e, "position");) e = e.parentNode;
                    e && e !== i && 1 === e.nodeType && ((r = ge(e).offset()).top += ge.css(e, "borderTopWidth", !0), r.left += ge.css(e, "borderLeftWidth", !0))
                }
                return {
                    top: t.top - r.top - ge.css(i, "marginTop", !0),
                    left: t.left - r.left - ge.css(i, "marginLeft", !0)
                }
            }
        },
        offsetParent: function() {
            return this.map((function() {
                for (var e = this.offsetParent; e && "static" === ge.css(e, "position");) e = e.offsetParent;
                return e || We
            }))
        }
    }), ge.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    }, (function(e, t) {
        var n = "pageYOffset" === t;
        ge.fn[e] = function(i) {
            return He(this, (function(e, i, r) {
                var o;
                if (le(e) ? o = e : 9 === e.nodeType && (o = e.defaultView), void 0 === r) return o ? o[t] : e[i];
                o ? o.scrollTo(n ? o.pageXOffset : r, n ? r : o.pageYOffset) : e[i] = r
            }), e, i, arguments.length)
        }
    })), ge.each(["top", "left"], (function(e, t) {
        ge.cssHooks[t] = N(ce.pixelPosition, (function(e, n) {
            if (n) return n = I(e, t), ct.test(n) ? ge(e).position()[t] + "px" : n
        }))
    })), ge.each({
        Height: "height",
        Width: "width"
    }, (function(e, t) {
        ge.each({
            padding: "inner" + e,
            content: t,
            "": "outer" + e
        }, (function(n, i) {
            ge.fn[i] = function(r, o) {
                var a = arguments.length && (n || "boolean" != typeof r),
                    s = n || (!0 === r || !0 === o ? "margin" : "border");
                return He(this, (function(t, n, r) {
                    var o;
                    return le(t) ? 0 === i.indexOf("outer") ? t["inner" + e] : t.document.documentElement["client" + e] : 9 === t.nodeType ? (o = t.documentElement, Math.max(t.body["scroll" + e], o["scroll" + e], t.body["offset" + e], o["offset" + e], o["client" + e])) : void 0 === r ? ge.css(t, n, s) : ge.style(t, n, r, s)
                }), t, a ? r : void 0, a)
            }
        }))
    })), ge.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], (function(e, t) {
        ge.fn[t] = function(e) {
            return this.on(t, e)
        }
    })), ge.fn.extend({
        bind: function(e, t, n) {
            return this.on(e, null, t, n)
        },
        unbind: function(e, t) {
            return this.off(e, null, t)
        },
        delegate: function(e, t, n, i) {
            return this.on(t, e, n, i)
        },
        undelegate: function(e, t, n) {
            return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
        },
        hover: function(e, t) {
            return this.on("mouseenter", e).on("mouseleave", t || e)
        }
    }), ge.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), (function(e, t) {
        ge.fn[t] = function(e, n) {
            return 0 < arguments.length ? this.on(t, null, e, n) : this.trigger(t)
        }
    }));
    var en = /^[\s\uFEFF\xA0]+|([^\s\uFEFF\xA0])[\s\uFEFF\xA0]+$/g;
    ge.proxy = function(e, t) {
        var n, i, r;
        if ("string" == typeof t && (n = e[t], t = e, e = n), ue(e)) return i = K.call(arguments, 2), (r = function() {
            return e.apply(t || this, i.concat(K.call(arguments)))
        }).guid = e.guid = e.guid || ge.guid++, r
    }, ge.holdReady = function(e) {
        e ? ge.readyWait++ : ge.ready(!0)
    }, ge.isArray = Array.isArray, ge.parseJSON = JSON.parse, ge.nodeName = o, ge.isFunction = ue, ge.isWindow = le, ge.camelCase = p, ge.type = i, ge.now = Date.now, ge.isNumeric = function(e) {
        var t = ge.type(e);
        return ("number" === t || "string" === t) && !isNaN(e - parseFloat(e))
    }, ge.trim = function(e) {
        return null == e ? "" : (e + "").replace(en, "$1")
    }, "function" == typeof define && define.amd && define("SHGJQ", [], (function() {
        return ge
    }));
    var tn = e.SHGJQ,
        nn = e.$;
    return ge.noConflict = function(t) {
        return e.$ === ge && (e.$ = nn), t && e.SHGJQ === ge && (e.SHGJQ = tn), ge
    }, void 0 === t && (e.SHGJQ = e.$ = ge), ge
})), SHGJQ.noConflict(),
    function() {
        function e(e) {
            var t = /(\/\/\s*<!\[CDATA\[)|(\/\/\s*\]\]>)/gm;
            return e = e.replace(t, ""), JSON.parse(e)
        }
        "performance" in window && "mark" in performance && performance.mark("beforeHydrate");
        var t = document.getElementsByClassName("__SHG_DATA__");
        console.debug("hydrating " + t.length + " sections");
        for (var n = 0, i = t.length; n < i; n++) {
            var r = t[n];
            if (r.text) {
                var o;
                try {
                    o = e(r.text)
                } catch (e) {
                    console.error("Failed to parse hydration data - invalid JSON", e, r);
                    continue
                }
                try {
                    e: if ("__shgProductCallback" in o) {
                        if (window.__shgProductCallbacks = window.__shgProductCallbacks || {}, !o.__shgProductCallback.id || !o.__shgProductCallback.callback) {
                            console.warn("Invalid product callback", o.__shgProductCallback);
                            break e
                        }
                        o.__shgProductCallback.id in window.__shgProductCallbacks || (window.__shgProductCallbacks[o.__shgProductCallback.id] = []), window.__shgProductCallbacks[o.__shgProductCallback.id].push(o.__shgProductCallback.callback)
                    }
                    "__shgProductInit" in o && (window.__shgProductInits = window.__shgProductInits || [], window.__shgProductComponent = window.__shgProductComponent || {}, window.__shgProductInits.push(o.__shgProductInit)),
                    "__shgCategoryInit" in o && (window.__shgCategoryInits = window.__shgCategoryInits || [], window.__shgCategoryInits.push(o.__shgCategoryInit)),
                    "__shgBox" in o && (window.SHOGUN_BOX = window.SHOGUN_BOX || [], window.SHOGUN_BOX.push(o.__shgBox)),
                    "__shgBoxV2" in o && (window.SHOGUN_BOX_V2 = window.SHOGUN_BOX_V2 || [], window.SHOGUN_BOX_V2.push(o.__shgBoxV2)),
                    "__shgVideoParallax" in o && (window.SHOGUN_VIDEO_PARALLAX = window.SHOGUN_VIDEO_PARALLAX || [], window.SHOGUN_VIDEO_PARALLAX.push(o.__shgVideoParallax)),
                    "__shgVideoParallaxV2" in o && (window.SHOGUN_VIDEO_PARALLAX_V2 = window.SHOGUN_VIDEO_PARALLAX_V2 || [], window.SHOGUN_VIDEO_PARALLAX_V2.push(o.__shgVideoParallaxV2)),
                    "__shgCountdown" in o && (window.SHOGUN_COUNTDOWNS = window.SHOGUN_COUNTDOWNS || [], window.SHOGUN_COUNTDOWNS.push(o.__shgCountdown)),
                    "__shgFormBox" in o && (window.SHOGUN_FORM_BOX = window.SHOGUN_FORM_BOX || [], window.SHOGUN_FORM_BOX.push(o.__shgFormBox)),
                    "__shgFormTextAreaElements" in o && (window.SHOGUN_FORM_TEXTAREA_ELEMENTS = window.SHOGUN_FORM_TEXTAREA_ELEMENTS || [], window.SHOGUN_FORM_TEXTAREA_ELEMENTS.push(o.__shgFormTextAreaElements)),
                    "__shgImageElements" in o && (window.SHOGUN_IMAGE_ELEMENTS = window.SHOGUN_IMAGE_ELEMENTS || [], window.SHOGUN_IMAGE_ELEMENTS.push(o.__shgImageElements)),
                    "__shgImageV2Elements" in o && (window.SHOGUN_IMAGE_V2_ELEMENTS = window.SHOGUN_IMAGE_ELEMENTS || [], window.SHOGUN_IMAGE_V2_ELEMENTS.push(o.__shgImageV2Elements)),
                    "__shgSlider" in o && (window.SHOGUN_SLIDERS = window.SHOGUN_SLIDERS || [], window.SHOGUN_SLIDERS.push(o.__shgSlider)),
                    "__shgMoneyFormat" in o && (window.__shgMoneyFormat = window.__shgMoneyFormat || o.__shgMoneyFormat),
                    "__shgSelectedOptions" in o && (window.__shgSelectedOptions = window.__shgSelectedOptions || {}, window.__shgSelectedOptions[o.__shgSelectedOptions.id] = new Array),
                    "__shgVariantOptionValues" in o && (window.__shgVariantOptionValues = window.__shgVariantOptionValues || {}, window.__shgVariantOptionValues[o.__shgVariantOptionValues.id] = {}),
                    "__shgCustomSwatches" in o && (document.customColorSwatch = o.__shgCustomSwatches.data)
                }
                catch (e) {
                    console.error("Failed to hydrate", e, r);
                    continue
                }
            }
        }
        "performance" in window && "mark" in performance && performance.mark("afterHydrate")
    }(), window.requestIdleCallback || (window.requestIdleCallback = function(e, t) {
        var n = 1,
            i = (t = t || {}).timeout || n,
            r = performance.now();
        return setTimeout((function() {
            e({
                get didTimeout() {
                    return !t.timeout && performance.now() - r - n > i
                },
                timeRemaining: function() {
                    return Math.max(0, n + (performance.now() - r))
                }
            })
        }), n)
    }), window.cancelIdleCallback || (window.cancelIdleCallback = function(e) {
        clearTimeout(e)
    }),
    function() {
        function e(e) {
            var t = e.event === o.ENTER_VIEWPORT,
                n = -1 !== e.name.indexOf("fadeIn"),
                i = -1 !== e.name.indexOf("zoomIn");
            return !(!t || !n && !i)
        }

        function t(e) {
            return ["animate__animated", "animate__" + e.name, s[e.delay], c[e.duration], u[e.iterationCount]].filter((function(e) {
                return !!e
            }))
        }

        function n(e) {
            try {
                return JSON.parse(e.dataset.animations).filter((function(e) {
                    return e.event && e.name
                })).map((function(e) {
                    return e.classes = t(e), e.touched = !1, e.endTime = null, e
                }))
            } catch (e) {
                return console.warn("Something went wrong while parsing the animations!", e), []
            }
        }

        function i(e) {
            this.animations = n(e), this.element = e, this.status = a.UNTOUCHED
        }

        function r() {
            document.querySelectorAll("[data-animations]").forEach((function(e) {
                new i(e).initialize()
            }))
        }
        var o = {
                ENTER_VIEWPORT: "enterviewport",
                MOUSE_ENTER: "mouseenter"
            },
            a = {
                FINISHED: "finished",
                PROGRESS: "progress",
                UNTOUCHED: "untouched"
            },
            s = {
                "1s": "animate__delay-1s",
                "2s": "animate__delay-2s",
                "3s": "animate__delay-3s",
                "4s": "animate__delay-4s",
                "5s": "animate__delay-5s"
            },
            c = {
                slower: "animate__slower",
                slow: "animate__slow",
                fast: "animate__fast",
                faster: "animate__faster"
            },
            u = {
                twice: "animate__repeat-2",
                thrice: "animate__repeat-3",
                infinite: "animate__infinite"
            };
        i.prototype.addClasses = function(e) {
            var t = this;
            e.forEach((function(e) {
                t.element.classList.add(e)
            }))
        }, i.prototype.removeClasses = function(e) {
            var t = this;
            e.forEach((function(e) {
                t.element.classList.remove(e)
            }))
        }, i.prototype.start = function(t) {
            (new Date).getTime() - t.endTime < 250 || (this.status === a.UNTOUCHED && e(t) && this.element.style.setProperty("opacity", "1"), this.status === a.PROGRESS || t.shouldBeTriggeredOnce && t.touched || (t.touched = !0, this.addClasses(t.classes), this.status = a.PROGRESS))
        }, i.prototype.end = function(e) {
            this.removeClasses(e.classes), this.status = a.FINISHED, e.endTime = (new Date).getTime()
        }, i.prototype.initialize = function() {
            var e = this;
            e.animations.forEach((function(t) {
                t.event === o.ENTER_VIEWPORT && (new IntersectionObserver((function(n) {
                    n[0].isIntersecting && e.start(t)
                })).observe(e.element), e.element.addEventListener("animationend", (function(n) {
                    n.preventDefault(), e.end(t)
                }))), t.event === o.MOUSE_ENTER && (e.element.addEventListener(t.event, (function() {
                    e.start(t)
                })), e.element.addEventListener("animationend", (function(n) {
                    n.preventDefault(), e.end(t)
                })))
            }))
        }, "complete" === document.readyState ? r() : window.addEventListener("load", r)
    }(),
    function(e) {
        "use strict";

        function t() {
            this.polyfills = new Set
        }
        var n = (navigator && navigator.userAgent || "").toLowerCase(),
            i = /safari/,
            r = "https://polyfill.io/v3/polyfill.min.js?features=IntersectionObserver%2CIntersectionObserverEntry",
            o = "https://cdnjs.cloudflare.com/ajax/libs/object-fit-images/3.2.4/ofi.js",
            a = "https://cdnjs.cloudflare.com/ajax/libs/picturefill/3.0.3/picturefill.min.js",
            s = function(t) {
                e('head > script[src="' + t + '"]').length || e("head").append(e("<script />").attr("src", t))
            },
            c = {
                ie: /msie|trident|edge/.test(n),
                safari: function() {
                    if (!i.test(n)) return !1;
                    var e = n.match(/version\/(\d+).+?safari/);
                    return {
                        version: e && e[1]
                    }
                }(),
                objectFitPolyfill: function() {
                    var e = this.safari && this.safari.version < 10;
                    this.ie && e && s(o)
                },
                picturePolyfill: function() {
                    this.ie && (s(a), setTimeout((function() {
                        window.picturefill && window.picturefill({
                            reevaluate: !0
                        })
                    })))
                },
                intersectionPolyfill: function() {
                    "IntersectionObserver" in window && "IntersectionObserverEntry" in window || s(r)
                }
            };
        t.prototype.isPolyfill = function(e) {
            return !!c[e + "Polyfill"]
        }, t.prototype.push = function(e) {
            this.isPolyfill(e) && (this.polyfills.has(e) || (this.polyfills.add(e), c[e + "Polyfill"]()))
        }, window.SHOGUN_POLYFILLS = new t, window.SHOGUN_BROWSER = {
            supportOnlyTouch: matchMedia("(hover: none)").matches
        }
    }(SHGJQ),
    function() {
        "use strict";

        function e(e) {
            const t = e.getAttribute("data-srcset"),
                n = e.getAttribute("data-src"),
                i = e.getAttribute("data-bgset");
            t && (e.getAttribute("srcset") || e.setAttribute("srcset", t)), n ? e.getAttribute("src") || e.setAttribute("src", n) : i && (e.style.backgroundImage = `url(${i})`), e.classList.replace("shogun-lazyload", "shogun-lazyloaded"), e.classList.remove("shogun-lazyload-bg-image")
        }

        function t(t, n, i) {
            for (let r = 0, o = n.length; r < o; r++) {
                const o = n[r];
                if (!o.isIntersecting) continue;
                const a = t.get(o.target);
                if (a && a.size)
                    for (const t of a) try {
                        t && e(t)
                    } catch (e) {
                        console.error(`failed to load asset - ${e}`, t, e)
                    }
                t.delete(o.target), i.unobserve(o.target)
            }
        }

        function n(e) {
            return new IntersectionObserver(t.bind(void 0, e), {
                root: null,
                rootMargin: a,
                threshold: s
            })
        }

        function i(e) {
            for (; !e.offsetParent;) {
                if (!(e = e.parentElement)) return;
                if (e.classList.contains("shg-c") && "none" === window.getComputedStyle(e).display) return
            }
            return e
        }

        function r(e, t) {
            let n, i = 0;
            return function(...r) {
                const o = Date.now();
                o - i < t ? (cancelIdleCallback(n), n = requestIdleCallback((() => {
                    i = o, e.apply(this, r)
                }), {
                    timeout: t
                })) : (i = o, e.apply(this, r))
            }
        }

        function o() {
            performance.mark("beforeObserveLazyAssets");
            const e = Array.prototype.slice.call(document.getElementsByClassName("shogun-lazyload"));
            if (e.length) {
                for (let t = 0, n = e.length; t < n; t++) {
                    const n = i(e[t]);
                    n && (c.has(n) ? c.get(n).add(e[t]) : (c.set(n, new Set([e[t]])), u.observe(n)))
                }
                performance.mark("afterObserveLazyAssets")
            }
        }
        window.SHOGUN_POLYFILLS = window.SHOGUN_POLYFILLS || [], window.SHOGUN_POLYFILLS.push("objectFit"), window.SHOGUN_POLYFILLS.push("intersection");
        const a = "200px",
            s = .01,
            c = new WeakMap,
            u = n(c),
            l = ["resize", "scroll", "hashchange"],
            d = ["focus", "mouseover", "click", "load", "transitionend", "animationend"],
            f = r(o, 100);
        "complete" === document.readyState ? f() : window.addEventListener("load", f), "MutationObserver" in window ? new MutationObserver(f).observe(document.documentElement, {
            childList: !0,
            subtree: !0,
            attributes: !0
        }) : setInterval(f, 1e3);
        for (const e of l) window.addEventListener(e, f, !0);
        for (const e of d) document.addEventListener(e, f, !0)
    }(),
    function(e) {
        function t(e) {
            return [].slice.call(e)
        }

        function n(e) {
            return "." + e
        }

        function i(e) {
            return "[" + e + "]"
        }

        function r() {
            this.imageSources = [], this.selectedImageIndex = 0, this.visible = !1, this.lightboxContainer = document.body, this.lightboxElement = null, this.init()
        }
        window.SHOGUN_POLYFILLS = window.SHOGUN_POLYFILLS || [], window.SHOGUN_POLYFILLS.push("objectFit");
        var o = "shg-lightbox",
            a = "shg-lightbox-image",
            s = "shg-lightbox-nav",
            c = "shg-nav-right",
            u = "data-shg-lightbox-switch",
            l = "data-shg-lightbox-image",
            d = "data-shg-lightbox-trigger",
            f = "hidden",
            h = "Escape";
        r.lightboxTemplate = '<span class="shg-lightbox-close">&times;</span><div class="shg-lightbox-nav shg-nav-left hidden"></div><div class="shg-lightbox-content">   <div class="shg-lightbox-image-container">     <img class="shg-lightbox-image" alt="Shogun lightbox"/>   </div></div><div class="shg-lightbox-nav shg-nav-right hidden"></div>', r.prototype.init = function() {
            var e = this.lightboxContainer.querySelector(n(o));
            e ? this.lightboxElement = e : (this.lightboxElement = this.createModalElement(), this.lightboxContainer.appendChild(this.lightboxElement), this.attachEvents())
        }, r.prototype.showNavigation = function() {
            t(document.querySelectorAll(n(s))).forEach((function(e) {
                e.classList.contains(f) && e.classList.remove(f)
            }))
        }, r.prototype.hideNavigation = function() {
            t(document.querySelectorAll(n(s))).forEach((function(e) {
                e.classList.contains(f) || e.classList.add(f)
            }))
        }, r.prototype.show = function(e) {
            if (e.preventDefault(), !this.visible) {
                var n = e.target,
                    r = n.hasAttribute(l),
                    o = this.getClosestLightboxItem(n).querySelectorAll(i(l)),
                    s = this.getElement(a),
                    c = t(o).map((function(e) {
                        return e.getAttribute("src")
                    })),
                    u = r ? c.indexOf(n.getAttribute("src")) : 0,
                    d = c[u];
                this.imageSources = c, this.selectedImageIndex = u, c.length > 1 && this.showNavigation(), s.setAttribute("src", d), this.lightboxElement.classList.remove(f), this.visible = !0
            }
        }, r.prototype.hide = function() {
            this.getElement(a).setAttribute("src", ""), this.lightboxElement.classList.add(f), this.hideNavigation(), this.visible = !1
        }, r.prototype.navigate = function(e) {
            return e.classList.contains(c) ? this.next() : this.previous()
        }, r.prototype.next = function() {
            var e = this.getElement(a),
                t = this.imageSources,
                n = this.selectedImageIndex + 1,
                i = 0,
                r = n > t.length - 1 ? i : n,
                o = t[r];
            this.selectedImageIndex = r, e.setAttribute("src", o)
        }, r.prototype.previous = function() {
            var e = this.getElement(a),
                t = this.imageSources,
                n = this.selectedImageIndex - 1,
                i = 0,
                r = t.length - 1,
                o = n < i ? r : n,
                s = t[o];
            this.selectedImageIndex = o, e.setAttribute("src", s)
        }, r.prototype.createModalElement = function() {
            var e = r.lightboxTemplate,
                t = document.createElement("div");
            return t.classList.add(f), t.classList.add(o), t.innerHTML = e, t
        }, r.prototype.attachEvents = function() {
            this.lightboxContainer.addEventListener("click", function(e) {
                return this.canElementShow(e.target) ? this.show(e) : this.canElementNavigate(e.target) ? this.navigate(e.target) : this.canElementHide(e.target) ? this.hide() : void 0
            }.bind(this)), this.lightboxContainer.ownerDocument.defaultView.addEventListener("keydown", function(e) {
                var t = e.code || e.key || e.keyIdentifier;
                this.visible && t === h && (e.preventDefault(), this.hide())
            }.bind(this), !0)
        }, r.prototype.canElementShow = function(e) {
            return e.hasAttribute(l) || e.hasAttribute(d)
        }, r.prototype.canElementHide = function(e) {
            return this.lightboxElement.contains(e) && !e.classList.contains(a) && !e.classList.contains(s)
        }, r.prototype.canElementNavigate = function(e) {
            return e.classList.contains(s)
        }, r.prototype.getElement = function(e) {
            return this.lightboxElement.querySelector(n(e))
        }, r.prototype.getClosestLightboxItem = function(e) {
            for (var t = e; t && !t.hasAttribute(u) && t !== this.lightboxContainer;) t = t.parentNode;
            return t === this.lightboxContainer ? null : t
        }, new r, e.__shgLightbox = r
    }("object" == typeof exports ? exports : window, window),
    function() {
        if (window.Shopify ? .routes ? .root && "/" !== window.Shopify.routes.root) {
            var e = window.Shopify.routes.root.replaceAll("/", "");
            window.document.querySelectorAll("a.shg-btn").forEach((function(t) {
                var n = t.getAttribute("href");
                if (n) {
                    var i = new URL(document.baseURI),
                        r = new URL(n, document.baseURI);
                    if (i.origin == r.origin) {
                        var o = r.toString().split("/").slice(3);
                        e !== o[0] && (o.unshift(e), t.href = o.join("/"))
                    }
                }
            }))
        }
    }(),
    function(e) {
        "use strict";
        window.SHOGUN_LOADED || (window.SHOGUN_LOADED = !0, e((function() {
            const e = new Event("pagebuilder:load", {
                bubbles: !0,
                cancelable: !0
            });
            document.dispatchEvent(e)
        })))
    }(SHGJQ),
    function(e) {
        "use strict";

        function t(e) {
            var t = e.parents(".shogun-root, .shg-fw").first(),
                n = t.offset(),
                i = (document.documentElement.clientWidth || document.body.clientWidth) - n.left - t.outerWidth(),
                r = n.left,
                o = Math.min(-i, 0),
                a = Math.min(-r, 0),
                s = {
                    marginRight: o.toString() + "px",
                    marginLeft: a.toString() + "px",
                    width: "calc(100% + " + Math.abs(a + o) + "px)"
                };
            e.css(s)
        }
        e(".shg-fw").each((function(n, i) {
            t(e(i))
        })), document.addEventListener("pagebuilder:load", (function() {
            for (var n = ["ms", "moz", "webkit", "o"], i = window.requestAnimationFrame, r = 0; r < n.length && !i; ++r) i = window[n[r] + "RequestAnimationFrame"];
            i || (i = function(e) {
                window.setImmediate(e)
            });
            var o = e(".shg-fw"),
                a = function() {
                    i((function() {
                        o.each((function(n, i) {
                            t(e(i))
                        }))
                    }))
                };
            e(window).on("resize orientationchange shg-fw:resize", a), a()
        }))
    }(SHGJQ),
    function(e, t) {
        e.SHGMoney = t()
    }(this || exports || global || window, (function() {
        function e(e, t) {
            var n = {
                template: "${{amount}}",
                default: {
                    currency: "USD",
                    currency_symbol: "$",
                    decimal_separator: ".",
                    thousands_separator: ",",
                    decimal_places: 2,
                    currency_symbol_location: "left"
                }
            };
            this.formatType = e, this.config = t || n[e] || n.default
        }
        return e.prototype.parseCents = function(e) {
            var t = /\./g,
                n = /,/g;
            e = (e = e.toString()).lastIndexOf(",") > e.lastIndexOf(".") ? e.replace(t, "").replace(n, ".") : e.replace(n, "");
            var i = parseFloat(e);
            return isNaN(i) || null == i ? 0 : i
        }, e.prototype.formatMoney = function(e, t) {
            var n = this;
            e = n.parseCents(e);
            var i = {
                template: function(e, t) {
                    function i(e, t) {
                        return void 0 === e ? t : e
                    }

                    function r(e, t, n, r) {
                        t = i(t, 2), n = i(n, ","), r = i(r, ".");
                        var o = (e = e.toFixed(t)).split(".");
                        return o[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1" + n) + (o[1] ? r + o[1] : "")
                    }
                    var o = "",
                        a = /\{\{\s*(\w+)\s*\}\}/,
                        s = t || n.config;
                    switch (s.match(a)[1]) {
                        case "amount":
                        default:
                            o = r(e, 2);
                            break;
                        case "amount_no_decimals":
                            o = r(e, 0);
                            break;
                        case "amount_with_comma_separator":
                            o = r(e, 2, ".", ",");
                            break;
                        case "amount_no_decimals_with_comma_separator":
                            o = r(e, 0, ".", ",");
                            break;
                        case "amount_with_apostrophe_separator":
                            o = r(e, 2, "'")
                    }
                    return s.replace(a, o)
                },
                default: function(e, t) {
                    function i(e) {
                        return t ? t[e] : n.config[e]
                    }
                    var r = "",
                        o = e.toString().split("."),
                        a = o[0],
                        s = o[1] || "";
                    if (a = a.split("").reverse().map((function(e, t) {
                            var n = t + 1;
                            return n % 3 == 0 && a.length !== n ? i("thousands_separator") + e : e
                        })).reverse().join(""), r = a, 0 !== i("decimal_places")) {
                        var c = s.slice(0, i("decimal_places"));
                        s = "";
                        for (var u = 0; u < i("decimal_places"); u++) s += c[u] || "0";
                        r = r + i("decimal_separator") + s
                    }
                    return r = "left" === i("currency_symbol_location") ? i("currency_symbol") + r : r + i("currency_symbol")
                }
            };
            return (i[n.formatType] || i.default)(e, t)
        }, e
    })),
    function(e) {
        function t(e, t) {
            r.push({
                selector: e,
                fn: t
            }), i || (i = new a(n)).observe(o.documentElement, {
                childList: !0,
                subtree: !0
            }), n()
        }

        function n() {
            for (var e, t, n = 0, i = r.length; n < i; n++) {
                e = r[n];
                for (var a, s = 0, c = (t = o.querySelectorAll(e.selector)).length; s < c; s++)(a = t[s]).ready || (a.ready = !0, e.fn.call(a, a))
            }
        }
        var i, r = [],
            o = e.document,
            a = e.MutationObserver || e.WebKitMutationObserver || e.MozMutationObserver;
        e.__shgElementReady = a ? t : function() {
            console.error("Browser does not support MutationObserver")
        }
    }(window),
    function(e) {
        "use strict";

        function t() {
            e("ul.shogun-tabs").each((function(t, n) {
                var i = e(n).data("vthemes");
                if (i) {
                    var r = null;
                    (r = e(window).width() < 768 ? i.xs : e(window).width() < 992 ? i.sm : e(window).width() < 1200 ? i.md : i.lg) || (r = i.default);
                    var o = "shogun-rounded" == r;
                    e(n).hasClass(r) || (o ? e(n).find(".shogun-tab-border").show() : e(n).find(".shogun-tab-border").hide(), e(n).attr("class", "shogun-tabs " + r), e(n).siblings(".shogun-tabs-body").attr("class", "shogun-tabs-body " + r))
                }
            }))
        }
        e(document).attr("shg-tabs-v2") || (e(document).attr("shg-tabs-v2", 1), e(document).on("click", ".shogun-tabs > li", (function() {
            var t = e(this);
            if (!t.hasClass("shogun-tab-active")) {
                var n = e(this).parent(),
                    i = n.hasClass("shogun-rounded");
                i && n.find(".shogun-tab-border").remove(), n.find("li").removeClass("shogun-tab-active"), n.find("li").attr("aria-selected", "false"), t.addClass("shogun-tab-active"), t.attr("aria-selected", "true"), i && t.append('<div class="shogun-tab-border" />');
                var r = t.parent().parent().children().last().children(".shogun-tab-content");
                r.removeClass("shogun-tab-active"), e(r[t.index()]).addClass("shogun-tab-active"), window.SHOGUN_MAP_RESIZER && window.SHOGUN_MAP_RESIZER()
            }
        })), document.addEventListener("pagebuilder:load", (function() {
            t(), e(window).resize(t)
        })))
    }(SHGJQ),
    function(e) {
        "use strict";
        e(document).attr("shg-tabs") || (e(document).attr("shg-tabs", 1), e(document).on("click", ".shogun-nav-tabs > li > a", (function(t) {
            t.preventDefault();
            var n = "active";
            if (!e(this).parent().hasClass(n)) {
                var i = e(this).parent(),
                    r = i.index();
                i.siblings().removeClass(n), i.addClass(n);
                var o = i.parent().parent().children().last().children(".shogun-tab-pane");
                return o.removeClass(n), e(o[r]).addClass(n), window.SHOGUN_MAP_RESIZER && window.SHOGUN_MAP_RESIZER(), !1
            }
        })))
    }(SHGJQ),
    function(e) {
        "use strict";

        function t(t, r, a) {
            var s = r.data("link"),
                c = r.data("icon"),
                u = t.data("color"),
                l = o[t.data("size")],
                d = t.data("in-new-tab") ? '_blank" ' : '_self" ';
            const f = `Open ${i(c)} profile`;
            if (!s) return r.remove();
            r.attr("target", d).attr("href", s).attr("aria-label", f).css(n(t, a));
            var h = e("<i />").addClass("shg-fa shg-fa-" + c + " " + l).css({
                color: u
            });
            r.append(h)
        }

        function n(e, t) {
            var n = "vertical" === e.data("orientation") ? "margin-bottom" : "margin-right",
                i = t ? "0px" : e.data("gutter"),
                r = {};
            return r[n] = i, r
        }

        function i(e) {
            switch (e) {
                case "facebook-square":
                    return "Facebook";
                case "twitter-square":
                    return "Twitter";
                case "youtube-square":
                    return "YouTube";
                case "instagram":
                    return "Instagram";
                case "pinterest-square":
                    return "Pinterest";
                case "linkedin-square":
                    return "LinkedIn";
                case "vimeo-square":
                    return "Vimeo";
                case "snapchat-square":
                    return "Snapchat";
                default:
                    return "Social"
            }
        }

        function r(e) {
            e.css({
                "flex-direction": a[e.data("orientation")]
            })
        }
        var o = {
                small: "shg-fa-2x",
                medium: "shg-fa-3x",
                large: "shg-fa-4x"
            },
            a = {
                horizontal: "row",
                vertical: "column"
            };
        document.addEventListener("pagebuilder:load", (function() {
            e(".shg-social-container").each((function() {
                var n = e(this),
                    i = n.find(".shg-social-element");
                i.each((function(r) {
                    var o = e(this),
                        a = r + 1 === i.length;
                    t(n, o, a)
                })), r(n)
            }))
        }))
    }(SHGJQ),
    function(e) {
        "use strict";

        function t(t) {
            return "#" + e(t).closest(".shg-sld").attr("id")
        }

        function n(e) {
            var t = parseInt(e.intervalTime) || 1;
            return t = 1e3 * Math.max(t, 1), setInterval((function() {
                i(e.id, 1)
            }), t)
        }

        function i(t, n, i) {
            const o = e(t).parent().attr("id"),
                a = window.SHOGUN_SLIDERS.find((e => e.id === "#slider-" + o)),
                s = a && a.transition || "animate__noAnimation";
            var c = e(t).children(".shg-sld-content").children(".shg-sld-slides"),
                u = c.children(".shg-sld-item.shg-sld-active"),
                l = u.next(".shg-sld-item"),
                d = u.prev(".shg-sld-item"),
                f = c.children(".shg-sld-item");
            if (0 === n || e(f[0]).hasClass(s) || e(f[0]).addClass(s), u.removeClass("shg-sld-active"), i) return e(f[n]).addClass("shg-sld-active"), void r(t, n);
            n < 0 ? (d.length || (d = e(f[f.length - 1])), r(t, f.index(d)), d.addClass("shg-sld-active")) : (l.length || (l = e(f[0])), r(t, f.index(l)), l.addClass("shg-sld-active"))
        }

        function r(t, n) {
            var i = e(t).children(".shg-sld-dots").children(".shg-sld-dot");
            i.removeClass("shg-sld-active"), e(i[n]).addClass("shg-sld-active")
        }

        function o(e, t) {
            var n, i, r, o, a, s = 100,
                c = 100,
                u = 300;
            e.addEventListener("touchstart", (function(e) {
                var t = e.changedTouches[0];
                n = t.pageX, i = t.pageY, a = (new Date).getTime()
            }), !1), e.addEventListener("touchend", (function(e) {
                var l = e.changedTouches[0];
                r = l.pageX - n, o = l.pageY - i, (new Date).getTime() - a <= u && Math.abs(r) >= s && Math.abs(o) <= c && t(r < 0 ? "left" : "right")
            }), !1)
        }
        window.SHOGUN_SLIDERS && (e(document).attr("shg-sliders") || (e(document).attr("shg-sliders", 1), e(document).on("click", ".shg-sld-nav-button", (function() {
            var n = t(this);
            e(this).hasClass("shg-sld-right") ? i(n, 1) : i(n, -1)
        })), e(document).on("click", ".shg-sld-dot", (function() {
            i(t(this), e(this).parent().find(".shg-sld-dot").index(this), !0)
        }))), document.addEventListener("pagebuilder:load", (function() {
            function t(e) {
                const t = [],
                    n = new Set;
                for (const i of e) n.has(i.id) || (t.push(i), n.add(i.id));
                return t
            }
            window.__shgSliderLoaded || (t(window.SHOGUN_SLIDERS).forEach((function(t) {
                if (t.autoplay) {
                    var r = !1;
                    if (t.interval = n(t), e(t.id).find("> .shg-sld-content > .shg-sld-nav-button, > .shg-sld-dots > .shg-sld-dot").click((function() {
                            clearInterval(t.interval), t.interval = n(t)
                        })), t.pauseOnHover) {
                        var a = e(t.id).find(".shg-sld-slides")[0];
                        a.addEventListener("mouseenter", (function() {
                            r = !0, clearInterval(t.interval)
                        })), a.addEventListener("mouseleave", (function() {
                            r && (t.interval = n(t), r = !1)
                        }))
                    }
                }
                o(e(t.id).find(".shg-sld-slides").get(0), (function(e) {
                    switch (e) {
                        case "left":
                            return i(t.id, 1);
                        case "right":
                            return i(t.id, -1)
                    }
                }))
            })), window.__shgSliderLoaded = !0)
        })))
    }(SHGJQ),
    function(e) {
        "use strict";

        function t(e) {
            return e.replace(/(['"])/g, "\\$1")
        }

        function n(e) {
            return e.replace(/\\/g, "")
        }

        function i(t) {
            "separately" === t.meta.groupBy && (window.__shgVariantOptionValues[t.meta.uuid] = t.product.options.reduce((function(n, i, r) {
                return n[i] = e.unique(t.product.variants.map((function(e) {
                    return e["option" + (r + 1)]
                }))), n
            }), {}))
        }

        function r(t) {
            let n = ["shg-variant-btn"];
            return t.inactive && n.push(t.unavailableVariantDisplay), t.selected && n.push("active"), e("<a>").addClass("shg-c shg-btn-wrapper").attr("id", t.id).attr("href", "#").addClass(n.join(" ")).attr("data-option", t.optionKey).attr("data-option-value", t.text).text(t.text)
        }

        function o(e, t) {
            return !(!e.detectColorSwatches || "default" !== e.groupBy) || e.detectColorSwatches && ["color", "colour", "material"].includes(t.toLowerCase())
        }

        function a(t, n, i) {
            if (o(n, i)) return e("<span>").addClass("shg-product-swatches-title").addClass("js-shg-product-swatches-title").text(t.selectedValue).data("selected-value", t.selectedValue)
        }

        function s(e, t) {
            return "hidden" !== t ? e : e.filter((function(e) {
                return e.available
            }))
        }

        function c(t, n, i) {
            if (!o(n.meta, i)) return;
            let r = s(t.options, t.unavailableVariantDisplay),
                a = [],
                c = e("<div>").addClass("shg-product-swatches-wrapper").append(r.map((function(i) {
                    let r = window.__shgColorMaper(i.value),
                        o = e("<div>").addClass("shg-product-swatch").addClass("js-shg-product-swatch").data("variant-title", i.value).css("background-color", r),
                        s = "separately" === n.meta.groupBy && n.product.options.length > 1;
                    return i.available || s ? (t.selectedValue === i.value && o.addClass("selected"), o) : (o.addClass("not-available"), o.addClass("js-not-available"), a.push(o), null)
                })));
            return a.forEach((function(e) {
                c.append(e)
            })), c
        }

        function u(n, i, r) {
            let a = s(n.options, n.unavailableVariantDisplay),
                c = e("<select>").attr("id", n.id).addClass(["shg-product-variant-select", n.class].join(" ")).attr("data-option", n.optionKey).attr("data-option-label", n.optionLabel).prop("disabled", n.disabled).append(a.map((function(i) {
                    return e("<option>").prop("disabled", "disabled" === n.unavailableVariantDisplay && !i.available).attr("value", t(i.value)).prop("selected", n.selectedValue === i.value).text(i.label)
                })));
            return (o(i, r) || "buttons" === i.displayType) && c.css("display", "none"), c
        }

        function l(e, t, n) {
            if (t.staticVariant) {
                const i = n ? .find((function(e) {
                        return Number.parseInt(e.id, 10) === t.productVariantId
                    })),
                    r = e ? .find((function(e) {
                        return e.value === i.title
                    }));
                return r ? [r] : []
            }
            return e
        }

        function d(t, n, i) {
            if ("buttons" !== t.displayType || o(n, t.optionLabel)) return;
            const a = e("<div>").addClass("shg-btn-container"),
                s = l(t.options, n, i).map((function(e) {
                    return r({
                        text: e.label,
                        optionKey: t.optionKey,
                        selected: e.label === t.selectedValue,
                        inactive: !e.available,
                        unavailableVariantDisplay: t.unavailableVariantDisplay
                    })
                }));
            return a.append(s)
        }

        function f(t, n, i) {
            return e("<div>").addClass("shg-product-selector-inline-wrapper").append(t.meta.showVariantLabels ? e("<label>").attr("for", "Shg-Product-Option-" + i + "-" + t.meta.uuid).text(n) : "")
        }

        function h(t, n, i, r) {
            var o = "option" + (n + 1),
                a = [],
                s = [];
            return t.filter((function(e) {
                if (0 === n) return !0;
                var t = i.slice(0, n).join(" / ");
                return e.title.startsWith(t) && ("hidden" !== r || e.available)
            })).map((function(e) {
                var t = e[o];
                e.available ? a.push(t) : s.push(t)
            })), {
                active: e.unique(a),
                inactive: e.unique(s).filter((function(e) {
                    return !a.includes(e)
                }))
            }
        }
        if (window.__shgVariantDefaultGroupingUI = function(e) {
                var t = e.product.options,
                    n = e.product.variants;
                const i = {
                        displayType: e.meta.displayType,
                        optionKey: "option1",
                        disabled: e.meta.staticVariant,
                        unavailableVariantDisplay: e.meta.unavailableVariantDisplay,
                        selectedValue: e.variant.title,
                        options: n.map((function(e) {
                            return {
                                value: e.title,
                                label: e.title,
                                available: e.available,
                                id: `${e.id}`
                            }
                        }))
                    },
                    r = { ...i,
                        id: "Shg-Product-Option-0-" + e.meta.uuid
                    };
                let o = t.join(" / ");
                return f(e, o, "0").append(u(r, e.meta, o)).append(c(i, e, o)).append(a(i, e.meta, o)).append(d(i, e.meta, e.product.variants))
            }, window.__shgVariantSeparateGroupingUI = function(e) {
                var t = e.product.options,
                    n = e.product.variants;
                return t.map((function(t, i) {
                    var r = "option" + (i + 1),
                        o = e.variant[r],
                        s = e.variant.title.split(" / "),
                        l = h(n, i, s, e.unavailableVariantDisplay),
                        p = {
                            displayType: e.meta.displayType,
                            optionKey: r,
                            optionLabel: t,
                            showColorSwatches: e.meta.colorSwatches,
                            disabled: e.meta.staticVariant,
                            unavailableVariantDisplay: e.meta.unavailableVariantDisplay,
                            selectedValue: o,
                            options: window.__shgVariantOptionValues[e.meta.uuid][t].filter((function(e, t, n) {
                                return void 0 !== e && n.indexOf(e) === t
                            })).map((function(e) {
                                return {
                                    value: e,
                                    label: e,
                                    available: l.active.includes(e)
                                }
                            }))
                        };
                    const g = { ...p,
                        id: "Shg-Product-Option-" + r + "-" + e.meta.uuid
                    };
                    return f(e, t, r).append(u(g, e.meta, t)).append(c(p, e, t)).append(a(e.meta, t)).append(d(p, e.meta, e.product.variants))
                }))
            }, window.__shgUpdateSeparateGroupingUI = function(n, i, r) {
                r("variant-mount").find("select").filter((function() {
                    return parseInt(e(this).data("option").replace("option", "")) > n
                })).each((function(r, o) {
                    var a = h(i.product.variants, n + r, window.__shgSelectedOptions[i.meta.uuid], i.meta.unavailableVariantDisplay),
                        s = e(o).val();
                    e(o).empty().append(window.__shgVariantOptionValues[i.meta.uuid][e(o).data("option-label")].filter((function(e, t, n) {
                        return void 0 !== e && n.indexOf(e) === t && ("hidden" !== i.meta.unavailableVariantDisplay || a.active.includes(e))
                    })).map((function(n) {
                        return e("<option>").attr("value", t(n)).prop("selected", t(n) === s).prop("disabled", a.inactive.includes(n)).text(n)
                    }))), "buttons" === i.meta.displayType && window.__shgVariantOptionValues[i.meta.uuid][e(o).data("option-label")].filter((function(e, t, n) {
                        return void 0 !== e && n.indexOf(e) === t
                    })).map((function(t) {
                        var n = e(o).parent().find("a.shg-variant-btn[data-option-value='" + t + "']");
                        n.removeClass("active"), s === n.html() && n.addClass("active"), a.active.includes(t) ? n.removeClass(i.meta.unavailableVariantDisplay) : n.addClass(i.meta.unavailableVariantDisplay)
                    }))
                }))
            }, !window.__shgProductComponent) return;
        const p = {
                aliceblue: "#f0f8ff",
                antiquewhite: "#faebd7",
                aqua: "#00ffff",
                aquamarine: "#7fffd4",
                azure: "#f0ffff",
                beige: "#f5f5dc",
                bisque: "#ffe4c4",
                black: "#000000",
                blanchedalmond: "#ffebcd",
                blue: "#0000ff",
                blueviolet: "#8a2be2",
                brown: "#a52a2a",
                burlywood: "#deb887",
                cadetblue: "#5f9ea0",
                chartreuse: "#7fff00",
                chocolate: "#d2691e",
                coral: "#ff7f50",
                cornflowerblue: "#6495ed",
                cornsilk: "#fff8dc",
                crimson: "#dc143c",
                cyan: "#00ffff",
                darkblue: "#00008b",
                darkcyan: "#008b8b",
                darkgoldenrod: "#b8860b",
                darkgray: "#a9a9a9",
                darkgreen: "#006400",
                darkkhaki: "#bdb76b",
                darkmagenta: "#8b008b",
                darkolivegreen: "#556b2f",
                darkorange: "#ff8c00",
                darkorchid: "#9932cc",
                darkred: "#8b0000",
                darksalmon: "#e9967a",
                darkseagreen: "#8fbc8f",
                darkslateblue: "#483d8b",
                darkslategray: "#2f4f4f",
                darkturquoise: "#00ced1",
                darkviolet: "#9400d3",
                deeppink: "#ff1493",
                deepskyblue: "#00bfff",
                dimgray: "#696969",
                dodgerblue: "#1e90ff",
                firebrick: "#b22222",
                floralwhite: "#fffaf0",
                forestgreen: "#228b22",
                fuchsia: "#ff00ff",
                gainsboro: "#dcdcdc",
                ghostwhite: "#f8f8ff",
                gold: "#ffd700",
                goldenrod: "#daa520",
                gray: "#808080",
                green: "#008000",
                greenyellow: "#adff2f",
                honeydew: "#f0fff0",
                hotpink: "#ff69b4",
                indianred: "#cd5c5c",
                indigo: "#4b0082",
                ivory: "#fffff0",
                khaki: "#f0e68c",
                lavender: "#e6e6fa",
                lavender: "#e6e6fa",
                lavenderblush: "#fff0f5",
                lawngreen: "#7cfc00",
                lemonchiffon: "#fffacd",
                lightblue: "#add8e6",
                lightcoral: "#f08080",
                lightcyan: "#e0ffff",
                lightgoldenrodyellow: "#fafad2",
                lightgray: "#d3d3d3",
                lightgreen: "#90ee90",
                lightpink: "#ffb6c1",
                lightsalmon: "#ffa07a",
                lightseagreen: "#20b2aa",
                lightskyblue: "#87cefa",
                lightslategray: "#778899",
                lightsteelblue: "#b0c4de",
                lightyellow: "#ffffe0",
                lime: "#00ff00",
                limegreen: "#32cd32",
                linen: "#faf0e6",
                magenta: "#ff00ff",
                maroon: "#800000",
                mediumaquamarine: "#66cdaa",
                mediumblue: "#0000cd",
                mediumorchid: "#ba55d3",
                mediumpurple: "#9370db",
                mediumseagreen: "#3cb371",
                mediumslateblue: "#7b68ee",
                mediumspringgreen: "#00fa9a",
                mediumturquoise: "#48d1cc",
                mediumvioletred: "#c71585",
                midnightblue: "#191970",
                mintcream: "#f5fffa",
                mistyrose: "#ffe4e1",
                moccasin: "#ffe4b5",
                navajowhite: "#ffdead",
                navy: "#000080",
                oldlace: "#fdf5e6",
                olive: "#808000",
                olivedrab: "#6b8e23",
                orange: "#ffa500",
                orangered: "#ff4500",
                orchid: "#da70d6",
                palegoldenrod: "#eee8aa",
                palegreen: "#98fb98",
                paleturquoise: "#afeeee",
                palevioletred: "#db7093",
                papayawhip: "#ffefd5",
                peachpuff: "#ffdab9",
                peru: "#cd853f",
                pink: "#ffc0cb",
                plum: "#dda0dd",
                powderblue: "#b0e0e6",
                purple: "#800080",
                red: "#ff0000",
                rosybrown: "#bc8f8f",
                royalblue: "#4169e1",
                saddlebrown: "#8b4513",
                salmon: "#fa8072",
                sandybrown: "#f4a460",
                seagreen: "#2e8b57",
                seashell: "#fff5ee",
                sienna: "#a0522d",
                silver: "#c0c0c0",
                skyblue: "#87ceeb",
                slateblue: "#6a5acd",
                slategray: "#708090",
                snow: "#fffafa",
                springgreen: "#00ff7f",
                steelblue: "#4682b4",
                tan: "#d2b48c",
                teal: "#008080",
                thistle: "#d8bfd8",
                tomato: "#ff6347",
                turquoise: "#40e0d0",
                violet: "#ee82ee",
                wheat: "#f5deb3",
                white: "#ffffff",
                whitesmoke: "#f5f5f5",
                yellow: "#ffff00",
                yellowgreen: "#9acd32"
            },
            g = " (Sold Out)";
        window.__shgColorMaper = function(e) {
            let t = (e = e.toLowerCase()).replace(/[^a-zA-Z0-9]/g, ""),
                n = e.replace(/[^a-zA-Z]/g, ""),
                i = document.customColorSwatch[t];
            return i || (i = p[n]), i
        }, window.initColorSwatchListeners = function() {
            e(document).on("mouseenter", ".js-shg-product-swatch", (function(t) {
                let n = e(t.currentTarget),
                    i = n.data("variant-title");
                n.hasClass("js-not-available") && (i += g), n.parent().parent().find(".js-shg-product-swatches-title").text(i)
            })), e(document).on("mouseleave", ".js-shg-product-swatch", (function(t) {
                let n = e(t.currentTarget).parent().parent().find(".js-shg-product-swatches-title");
                n.text(n.data("selected-value"))
            })), e(document).on("click touchend", ".shg-product-selector-wrapper .js-shg-product-swatch", (function(t) {
                t.stopImmediatePropagation();
                let n = e(t.currentTarget);
                if (n.hasClass("js-not-available")) return;
                n.parent().parent().find(".js-shg-product-swatch").removeClass("selected"), n.addClass("selected");
                let i = n.data("variant-title");
                n.parent().parent().find(".js-shg-product-swatches-title").data("selected-value", i), n.parent().parent().find("select").val(n.data("variant-title")).trigger("change"), setTimeout((function() {
                    document.querySelector(".js-shg-product-swatches-title").innerText = i
                }), 50)
            }))
        }, window.initVariantButtonListeners = function(t) {
            t.find("a.shg-variant-btn").on("click", (function(n) {
                n.preventDefault();
                var i = e(this);
                let r = i.data("option");
                t.find("a.shg-variant-btn[data-option='" + r + "']").removeClass("active"), i.addClass("active"), i.parent().parent().find("select.shg-product-variant-select").val(i.html()).trigger("change")
            }))
        }, window.__shgProductComponent.variant = function(t, r) {
            var o = r("variant-mount"),
                a = t.meta.unavailableVariantDisplay;
            t.variant && (i(t), o.html("").append("default" === t.meta.groupBy ? window.__shgVariantDefaultGroupingUI(t) : window.__shgVariantSeparateGroupingUI(t)));
            var s = o.find("select");
            s.on("change", (function() {
                if ("separately" === t.meta.groupBy && ["hidden", "disabled"].includes(a)) {
                    var i = e(this).data("option"),
                        o = parseInt(i.replace("option", ""));
                    window.__shgSelectedOptions[t.meta.uuid][o - 1] = e(this).val(), window.__shgSelectedOptions[t.meta.uuid].splice(o), window.__shgUpdateSeparateGroupingUI(o, t, r)
                }
                var c = s.map((function() {
                    return e(this).val()
                })).toArray().map((function(e) {
                    return n(e)
                })).join(" / ");
                window.__shgProductsUpdatePropsFns.forEach((function(n) {
                    n((n => {
                        var i = n.product.id === t.product.id && !n.meta.staticVariant && n.product.variants.find((function(e) {
                            return e.title === c
                        }));
                        if (i) {
                            if (n.meta.uuid === t.meta.parentGroupUUID && "shopify" === t.meta.platform) {
                                try {
                                    var r = window.location.pathname + "?variant=" + i.id;
                                    history.pushState(null, "", r)
                                } catch (e) {
                                    console.error(e)
                                }
                                if (window.ReChargeWidget) {
                                    const e = t.meta.uuid,
                                        n = document.getElementById(e) ? .closest(".shg-product");
                                    if (!n) return;
                                    const r = n.getElementsByClassName("shg-product-variant-selector-for-recharge-hidden");
                                    for (const e of r) {
                                        e.setAttribute("data-value", i.id.toString());
                                        const t = new Event("change", {
                                            bubbles: !0
                                        });
                                        t.value = i.id.toString(), e.dispatchEvent(t)
                                    }
                                }
                            }
                            var o = {
                                variant: i || !1,
                                selectedImage: i && i.featured_image && i.featured_image.src || !1
                            };
                            return e.extend({}, n, o)
                        }
                        return n
                    }))
                }))
            })), "buttons" === t.meta.displayType && window.initVariantButtonListeners(r("variant-mount"), t), t.meta.detectColorSwatches && window.initColorSwatchListeners()
        }
    }(SHGJQ),
    function() {
        "use strict";
        window.__shgProductComponent && (window.__shgProductComponent.title = function(e, t) {
            t("title").html(e.product.title), t("url").attr("href", e.getProductUrl(e.product.handle, e.variant))
        })
    }(SHGJQ),
    function(e) {
        function t(e, t) {
            this.productId = (t.product.id || t.product.external_id).toString(), this.showCollectionPageStars = t.meta.showCollectionPageStars, this.reviewsApiUrl = t.meta.reviewsApiUrl, this.reviewsQueryParams = t.meta.reviewsQueryParams, this.reviewsPerPage = t.meta.reviewsPerPage, this.reviews = [], this.totalReviews = 0, this.totalPages = 0, this.averageScore = 0;
            var n = e.find(".shg-product-reviews-container");
            this.$container = n, this.$loading = n.find(".shg-product-reviews-loading"), this.$content = n.find(".shg-product-reviews-content"), this.$form = n.find(".shg-product-reviews-form"), this.$paginationContainer = n.find(".shg-product-reviews-pagination-items"), this.REVIEWS_ITEM_TEMPLATE = n.find(".shg-product-reviews-list-item-template").html(), this.STAR_SVG = n.find(".shg-product-reviews-stars-svg-content").html(), this.CARET_LEFT_SVG = n.find(".shg-product-reviews-caret-left-svg-content").html()
        }

        function n(e) {
            return e[0]
        }

        function i(e) {
            return e[e.length - 1]
        }

        function r(e) {
            return "." + e
        }

        function o(e) {
            return "[data-shg-reviews='" + e + "']"
        }

        function a(e) {
            return "[name='" + e + "']"
        }
        if (window.__shgProductComponent) {
            window.__shgProductComponent.reviews = function(e, n, i) {
                "use strict";
                new t(i, e).init()
            };
            var s = 2,
                c = 1,
                u = "list",
                l = "write",
                d = "success",
                f = "fail",
                h = "empty",
                p = "shg-product-reviews-view",
                g = "shg-product-reviews-form-field",
                m = "shg-product-reviews-star";
            t.prototype.init = function() {
                var e = this;
                this.loadReviews(c, (function() {
                    e.render(), !e.showCollectionPageStars && e.attachEvents()
                }))
            }, t.prototype.loadReviews = function(t, n) {
                var i = this;
                e.ajax({
                    method: "GET",
                    url: this.reviewsApiUrl + "/product",
                    dataType: "json",
                    data: e.extend({}, this.reviewsQueryParams, {
                        external_product_id: this.productId,
                        page: t,
                        per_page: this.reviewsPerPage
                    }),
                    success: function(e) {
                        i.setReviews(e), n()
                    },
                    fail: function() {
                        console.error("failed to fetch review...")
                    }
                })
            }, t.prototype.setReviews = function(e) {
                this.reviews = e.items, this.totalReviews = e.total_count, this.totalPages = e.total_pages, this.averageScore = e.average_score
            }, t.prototype.getPaginationPages = function(e) {
                function t(e, t) {
                    return e = e < 0 ? 0 : e, t = t > r ? r : t, o.slice(e, t)
                }
                var r = this.totalPages,
                    o = Array.apply(null, Array(this.totalPages)).map((function(e, t) {
                        return t + 1
                    })),
                    a = t(e - s - 1, e + s);
                return {
                    before: t(0, n(a) - 1 <= s ? n(a) - 1 : s),
                    middle: a,
                    after: t(r - (r - i(a) <= s ? r - i(a) : s), r)
                }
            }, t.prototype.getRoundedAverageScore = function() {
                var e = this.averageScore;
                return e % 1 >= .5 ? Math.ceil(e) : Math.floor(e)
            }, t.prototype.getReviewsView = function() {
                return this.totalReviews > 0 ? u : h
            }, t.prototype.validateForm = function() {
                var e = this;
                return this.$form.find(r(g)).removeClass(g + "-error"), this.$form.serializeArray().reduce((function(t, n) {
                    var i = e.$form.find(a(n.name));
                    if (n.value && !i.is(":invalid")) return t;
                    i.closest(r(g)).addClass(g + "-error")
                }), !0)
            }, t.prototype.handlePaginate = function(e) {
                this.loadReviews(e, this.renderReviews.bind(this, e))
            }, t.prototype.handleFormSubmit = function() {
                var t = this;
                if (this.validateForm()) {
                    var n = {
                        external_product_id: this.productId
                    };
                    this.$form.serializeArray().reduce((function(e, t) {
                        var n = "score" === t.name || "page" === t.name || "per_page" === t.name;
                        return e[t.name] = n ? Number(t.value) : t.value, e
                    }), n), this.renderLoading(), e.ajax({
                        method: "POST",
                        url: this.reviewsApiUrl + "/reviews",
                        contentType: "application/json",
                        dataType: "json",
                        data: JSON.stringify(e.extend({}, this.reviewsQueryParams, n))
                    }).done((function() {
                        t.$form.trigger("reset"), t.showView(d), t.renderLoaded(), setTimeout((function() {
                            t.loadReviews(c, (function() {
                                t.renderReviews(c), t.showView(t.getReviewsView())
                            }))
                        }), 3e3)
                    })).fail((function() {
                        t.showView(f), t.renderLoaded(), setTimeout(t.showView.bind(t, l), 3e3)
                    }))
                }
            }, t.prototype.attachStarEvents = function() {
                var t = this,
                    n = this.$container.find(".shg-product-reviews-stars-hoverable"),
                    i = n.parent(r(g)).find(a("score"));
                n.find(r(m)).on("mouseover", (function() {
                    var n = e(this).index();
                    t.renderSelectedStars(n + 1)
                })).on("click", (function() {
                    var t = e(this).index();
                    i.val(t + 1)
                })), n.on("mouseleave", (function() {
                    var e = i.val();
                    t.renderSelectedStars(e)
                }))
            }, t.prototype.attachEvents = function() {
                var t = this,
                    n = this.$container.find(".shg-product-reviews-button-write"),
                    i = this.$container.find(".shg-product-reviews-button-cancel"),
                    r = this.$container.find(".shg-product-reviews-button-submit");
                n.on("click", (function() {
                    e(this).hide(), t.showView(l)
                })), i.on("click", (function() {
                    n.show(), t.showView(t.getReviewsView())
                })), r.on("click", (function() {
                    t.$form.submit()
                })), this.$form.on("submit", (function(e) {
                    e.preventDefault(), t.handleFormSubmit()
                })), this.attachStarEvents()
            }, t.prototype.renderReviewsSize = function() {
                this.$container.find(o("total-reviews")).text(this.totalReviews)
            }, t.prototype.renderStars = function(t, n) {
                for (var i = t.find(r(m)).length; i < 5; i++) {
                    var o = "number" == typeof n ? i < n ? "full" : "empty" : "disabled",
                        a = e("<div>").addClass(m).addClass(m + "-" + o).html(this.STAR_SVG);
                    t.append(a)
                }
            }, t.prototype.renderSelectedStars = function(e) {
                this.$container.find(".shg-product-reviews-stars-hoverable").find(r(m)).addClass(m + "-empty").removeClass(m + "-full").slice(0, e).removeClass(m + "-empty").addClass(m + "-full")
            }, t.prototype.renderAverageStars = function() {
                var e = this.$container.find(o("average-stars"));
                e.empty(), this.renderStars(e, this.getRoundedAverageScore() || null)
            }, t.prototype.renderFormStars = function() {
                var e = this.$container.find(o("form-stars"));
                this.renderStars(e, 0)
            }, t.prototype.renderReviews = function(t) {
                var n = this;
                this.renderReviewsSize(), this.renderAverageStars();
                var i = this.$container.find(".shg-product-reviews-view-list-container");
                i.empty(), this.reviews.forEach((function(t) {
                    var r = e(n.REVIEWS_ITEM_TEMPLATE).appendTo(i);
                    n.renderStars(r.find(o("review-stars")), t.score);
                    var a = new Date(1e3 * t.created_at),
                        s = r.find(o("review-date-container"));
                    a.getTime() <= 0 ? s.hide() : (s.show(), r.find(o("review-date")).text(a.toLocaleDateString())), t.author_name && t.author_name.trim().length > 0 && r.find(o("review-author")).text(t.author_name), r.find(o("review-title")).text(t.title), r.find(o("review-content")).text(t.body)
                })), 1 !== this.totalPages && this.renderPagination(t)
            }, t.prototype.renderPaginationItem = function(t, n) {
                var i = e("<div>").addClass("shg-product-reviews-pagination-item");
                t === n && i.addClass("shg-product-reviews-pagination-item-active"), i.on("click", this.handlePaginate.bind(this, n)), this.$paginationContainer.append(i.text(n))
            }, t.prototype.renderPaginationLeftCaret = function(t) {
                var n = t - 1,
                    i = e("<div>").addClass("shg-product-reviews-pagination-item").html(this.CARET_LEFT_SVG).on("click", this.handlePaginate.bind(this, n));
                t <= c && i.hide(), this.$paginationContainer.prepend(i)
            }, t.prototype.renderPaginationRightCaret = function(t) {
                var n = t + 1,
                    i = e("<div>").addClass("shg-product-reviews-pagination-item").html(this.CARET_LEFT_SVG).on("click", this.handlePaginate.bind(this, n));
                i.children().addClass("shg-product-reviews-pagination-item-flip"), t >= this.totalPages && i.hide(), this.$paginationContainer.append(i)
            }, t.prototype.renderPagination = function(e) {
                var t = "<span>...</span>",
                    r = this.getPaginationPages(e),
                    o = r.before,
                    a = r.middle,
                    s = r.after;
                this.$paginationContainer.empty(), this.renderPaginationLeftCaret(e), o.forEach(this.renderPaginationItem.bind(this, e)), o.length > 0 && i(o) + 1 !== n(a) && this.$paginationContainer.append(t), a.forEach(this.renderPaginationItem.bind(this, e)), s.length > 0 && i(a) + 1 !== n(s) && this.$paginationContainer.append(t), s.forEach(this.renderPaginationItem.bind(this, e)), this.renderPaginationRightCaret(e)
            }, t.prototype.showView = function(e) {
                this.$container.find(r(p)).hide(), this.$container.find(r(p) + "-" + e).show()
            }, t.prototype.renderLoading = function() {
                this.$loading.show(), this.$content.hide()
            }, t.prototype.renderLoaded = function() {
                this.$loading.hide(), this.$content.show()
            }, t.prototype.render = function() {
                this.showCollectionPageStars ? (this.renderAverageStars(), this.renderLoaded()) : (this.showView(this.getReviewsView()), this.renderFormStars(), this.renderReviews(c), this.renderLoaded())
            }
        }
    }(SHGJQ),
    function(e) {
        "use strict";
        if (!window.__shgProductComponent) return;
        const t = /\/previews\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\/sections\//,
            n = () => t.test(window.location.pathname),
            i = 1e4,
            r = e => `Product #${e} is not configured for subscription in ReCharge`;
        window.__shgProductComponent.rechargeWidget = function(t) {
            function o() {
                const n = (t, n) => {
                        const i = e.extend({}, t.rechargeWidgets, {
                            [s]: n
                        });
                        return e.extend({}, t, {
                            rechargeWidgets: i
                        })
                    },
                    o = e => {
                        t.updateProps((t => n(t, e)))
                    },
                    a = e => {
                        const t = e.closest(".shg-product");
                        if (!t) return;
                        const n = t.getElementsByClassName("shg-product-atc-btn-wrapper");
                        Array.from(n).forEach((t => {
                            t.querySelectorAll("input[name*=selling_plan]").forEach((e => {
                                e.remove()
                            }));
                            for (const [n, i] of new FormData(e)) {
                                const e = document.createElement("input");
                                e.setAttribute("type", "hidden"), e.setAttribute("name", n), e.setAttribute("value", i), t.append(e)
                            }
                        }))
                    },
                    l = () => {
                        const e = setInterval((() => {
                            window.ReChargeWidget && (clearInterval(e), window.ReChargeWidget.api.fetchProduct(c).then((e => {
                                if (!e ? .in_recharge) throw new Error(r(c));
                                const t = e => {
                                    e ? .config ? .injectionTarget === f && (window.ReChargeWidget.eventService.removeEventListener("widget:build", t), o("success"))
                                };
                                window.ReChargeWidget.eventService.addEventListener("widget:build", t), window.ReChargeWidget.createWidget({
                                    productId: c,
                                    injectionParent: f,
                                    selectors: {
                                        variant: [`#${s} .shg-product-variant-selector-for-recharge-hidden`]
                                    }
                                })
                            })).catch((e => {
                                h && (h.style.display = "none"), e = "RechargeRequestError" === e ? .name ? new Error(r(c)) : e, console.error(e), o("error")
                            })))
                        }), 300);
                        setTimeout((() => {
                            if (!window.ReChargeWidget) {
                                if (window.__shgRechargeInitFailureReported) return;
                                window.__shgRechargeInitFailureReported = !0, console.error(`ReCharge script did not run within ${i/1e3} sec. Make sure ReCharge widget is set up properly in your Shopify theme and the theme is loaded on your page`), clearInterval(e)
                            }
                            t.updateProps((e => "loading" === e.rechargeWidgets[s] ? n(e, "timeout") : e), !0)
                        }), [i])
                    },
                    d = () => {
                        const e = setInterval((() => {
                            if (!h) return;
                            new FormData(h).entries().next().done || (clearInterval(e), a(h))
                        }), 300)
                    };
                return {
                    init: () => {
                        window[`__shgRechargeInitialized-${s}`] || (window[`__shgRechargeInitialized-${s}`] = !0, window.addEventListener("runProductCallbacksComplete", (() => o("loading")), {
                            once: !0
                        }), l(), d(), h ? .addEventListener("change", (e => {
                            a(e.currentTarget)
                        })))
                    },
                    initForPreview: function() {
                        if (window[`__shgRechargeInitialized-${s}`]) return;
                        window[`__shgRechargeInitialized-${s}`] = !0, window.addEventListener("runProductCallbacksComplete", (() => o("loading")), {
                            once: !0
                        });
                        const e = document.querySelector("head");
                        if (!e) return;
                        window.Shopify = { ...window.Shopify || {},
                            shop: u
                        };
                        const t = document.createElement("script");
                        t.setAttribute("src", `https://static.rechargecdn.com/assets/js/widget.min.js?shop=${u}`), t.onload = () => {
                            setTimeout((() => {
                                this.init()
                            }), 100)
                        }, e.appendChild(t)
                    }
                }
            }

            function a() {
                const e = () => {
                        const e = document.querySelector('script[src*="https://app-data-prod.rechargeadapter.com/v2-prod/"]');
                        e ? .remove()
                    },
                    t = ({
                        onLoad: e
                    }) => {
                        const t = document.createElement("script");
                        t.setAttribute("src", "https://app-data-prod.rechargeadapter.com/v2-prod/static/js/bc.js"), t.onload = e, document.getElementsByTagName("head")[0].append(t)
                    },
                    n = () => {
                        const n = setInterval((() => {
                            if (!window.RCA_DATA ? .RCA_PRODUCT_DATA) return;
                            e(), clearInterval(n);
                            const i = window.RCA_DATA.RCA_PRODUCT_DATA.find((e => e.id === Number.parseInt(c, 10)));
                            if (i) {
                                const {
                                    subscriptionModifier: {
                                        id: e,
                                        frequencies: n
                                    }
                                } = i, r = document.getElementById(`${s}-widget`), o = document.createElement("div");
                                o.classList.add("form-field"), o.setAttribute("data-product-attribute", "set-select");
                                const a = document.createElement("select");
                                a.setAttribute("name", `attribute[${e}]`), a.classList.add("form-select", "form-select--small"), a.setAttribute("id", `attribute_select_${e}`), Object.keys(n).forEach((e => {
                                    const t = n[e],
                                        i = document.createElement("option");
                                    i.value = e, i.setAttribute("data-product-attribute-value", e), i.text = `Delivery every ${t} day`, a.appendChild(i)
                                })), o.appendChild(a), r.appendChild(o), t({
                                    onLoad: () => {
                                        window.__shgRechargeInitialized = !0
                                    }
                                })
                            }
                        }), 100)
                    };
                return {
                    init: () => {
                        window.__shgRechargeInitialized || (window.RCA_store_objects.page_type = "Product", window.RCA_store_objects.product.id = Number.parseInt(c, 10), window.RCA_store_objects.product.price = {
                            without_tax: {
                                value: d ? Number.parseFloat(d) : 0
                            }
                        }, n())
                    }
                }
            }
            const s = t.meta.uuid,
                c = "number" == typeof t.product.id ? t.product.id : Number.parseInt(t.product.external_id, 10);
            if (Number.isNaN(c)) return;
            const u = t.meta.shopUrl,
                l = t.meta.platform,
                d = t.variant ? .price,
                f = `#${`${s}-widget`}`,
                h = document.getElementById(s);
            "shopify" === l ? n() ? o().initForPreview() : o().init() : "big_commerce" === l && a().init()
        }
    }(SHGJQ),
    function(e) {
        "use strict";
        window.__shgProductComponent && (window.__shgProductComponent.quantity = function(t, n, i) {
            function r(n) {
                t.updateProps((t => e.extend({}, t, {
                    quantity: n
                })))
            }
            var o = n("quantity"),
                a = t.hasOwnProperty("quantity") ? t.quantity : t.meta.defaultQuantity;
            o.val(a), o.on("change input", (function() {
                var t = e(this).val().replace(/[^0-9]/g, "");
                t.length > 1 && "0" === t[0] && (t = t.substring(1)), r(t)
            })), o.on("blur", (function() {
                !t.hasOwnProperty("quantity") || "" !== a && "0" !== a || r("1")
            })), i.find("button").on("click", (function() {
                var t = e(this).text(),
                    n = Number(o.val()) + ("+" === t ? 1 : -1);
                n >= 1 && r(n)
            })), !t.quantity && t.meta.defaultQuantity && window.addEventListener("runProductCallbacksComplete", (() => r(t.meta.defaultQuantity)), {
                once: !0
            })
        })
    }(SHGJQ),
    function() {
        "use strict";
        var e = Number.isInteger || function(e) {
            return "number" == typeof e && isFinite(e) && Math.floor(e) === e
        };
        window.__shgProductComponent && (window.__shgProductComponent.price = function(t, n) {
            function i(t) {
                if (null == t) return "";
                var n = e(t) ? (t / 100).toFixed(2) : t;
                return new window.SHGMoney(s.type, s.config).formatMoney(n)
            }

            function r(e, n) {
                Object.values(t.rechargeWidgets || {}).some((e => "success" === e)) || e.html(n)
            }
            var o = !!t.variant,
                a = o && !t.variant.available,
                s = t.moneyFormat,
                c = t.variant && t.variant.price_currency && t.variant.price_currency.toUpperCase();
            c && s.currencies && s.currencies[c] && (s.config = s.currencies[c]), a ? (n("sold-out").show(), n("price").hide(), n("compare-price").hide()) : o ? (n("sold-out").hide(), r(n("price"), i(t.variant.price)), n("price").show(), t.meta.hasComparePrice && t.variant.compare_at_price ? (r(n("compare-price"), i(t.variant.compare_at_price)), n("compare-price").show()) : (r(n("compare-price"), i(t.variant.compare_at_price)), n("compare-price").hide())) : (n("sold-out").hide(), n("price").hide(), n("compare-price").hide())
        })
    }(window.SHGJQ, window.SHGMoney);
var ZERO_WIDTH_SPACE = "&#8203;";
! function() {
    "use strict";
    window.__shgProductComponent && (window.__shgProductComponent.metafield = function(e, t) {
        const {
            product: {
                metafields: n
            },
            meta: {
                metafieldKey: i,
                metafieldNamespace: r
            }
        } = e, o = n.find((e => e.key === i && e.namespace === r));
        o ? (t("key").html(o.key + ": "), t("value").html(o.value)) : (t("key").html(""), t("value").html(""))
    })
}(SHGJQ),
function() {
    "use strict";
    if (!window.__shgProductComponent) return;
    const e = (e, t, n) => {
            const i = async () => {
                if (!e) return;
                const i = setInterval((async () => {
                    if (window.LOOX) {
                        window.LOOX.productId = `${e}`;
                        const {
                            clientId: r
                        } = window.LOOX;
                        fetch(`https://loox.io/widget/${r}/ratings?products_ids=${e}`).then((e => e.json())).then((e => {
                            const {
                                ratings: i
                            } = e, r = t.find("div.shg-product-loox-widget"), o = r[0] ? .firstElementChild;
                            if ("reviews_rating" === n && 0 === i.length) {
                                const e = o ? .firstElementChild;
                                e ? .classList.add("show-empty"), e ? .setAttribute("data-rating", "1"), e ? .setAttribute("data-raters", "1"), e ? .setAttribute("data-pattern", "(0)")
                            }
                        })), clearInterval(i)
                    }
                }), 300)
            };
            return {
                init: () => {
                    i()
                }
            }
        },
        t = async (e, t, n) => {
            const i = t.find("div.shg-product-loox-widget"),
                r = i[0] ? .firstElementChild;
            if ("reviews_rating" === n) {
                r ? .setAttribute("href", "#looxReviews");
                const t = r ? .firstElementChild;
                t ? .setAttribute("data-id", e), t ? .setAttribute("data-fetch", "true"), t ? .classList ? .add("loox-rating")
            } else r ? .setAttribute("id", "looxReviews"), r ? .setAttribute("data-product-id", e)
        };
    window.__shgProductComponent.looxWidget = async function(n, i, r) {
        const o = n.meta.platform,
            a = n.product.external_id || n.product.id,
            s = n.meta.widgetType;
        a ? (await t(a, r, s), "shopify" === o && e(a, r, s).init()) : console.error("Loox widget: Product id is missing")
    }
}(SHGJQ),
function() {
    "use strict";
    if (!window.__shgProductComponent) return;
    const e = (e, t, n, i, r) => ({
        init: () => {
            fetch(`https://judge.me/api/v1/widgets/settings?api_token=${n}&shop_domain=${e}`).then((e => e.json())).then((e => {
                const t = /<script[^>]*>([^<]+)<\/script>/i.exec(e ? .settings);
                if (t) {
                    const n = t[1],
                        i = /window\.jdgmSettings=(.*?);/.exec(n);
                    if (i) {
                        window.jdgmSettings = JSON.parse(i[1]);
                        const t = document.createElement("div");
                        t.innerHTML = e ? .settings || "", document.body.appendChild(t)
                    }
                }
            }));
            const o = document.createElement("script");
            o.src = "https://cdn.judge.me/loader.js";
            const a = document.createElement("link");
            a.rel = "stylesheet", a.href = "https://cdn.judge.me/widget_v3/base.css";
            const s = document.createElement("script");
            s.src = `https://cdn1.judge.me/assets/installed.js?${e}`, document.getElementsByTagName("head")[0].append(s), document.getElementsByTagName("head")[0].append(o);
            document.querySelector('link[href="https://cdn.judge.me/widget_v3/base.css"]') || document.getElementsByTagName("head")[0].append(a), fetch(`https://judge.me/api/v1/widgets/settings?api_token=${n}&shop_domain=${e}`).then((e => e.json())).then((e => {
                const t = document.createElement("div");
                t.innerHTML = e ? .settings, document.getElementById(`jdgm-widget-settings-${r}`).appendChild(t)
            })), fetch(`https://judge.me/api/v1/widgets/html_miracle?api_token=${n}&shop_domain=${e}`).then((e => e.json())).then((e => {
                const t = document.createElement("div");
                t.innerHTML = e ? .html_miracle, document.getElementById(`jdgm-widget-miracle-${r}`).appendChild(t)
            })), "review-widget" === i ? fetch(`https://judge.me/api/v1/widgets/product_review?api_token=${n}&shop_domain=${e}&external_id=${t}`).then((e => e.json())).then((e => {
                document.getElementById(`jdgm-widget-${r}`).innerHTML = e ? .widget
            })) : "all-reviews-widget" === i ? fetch(`https://judge.me/api/v1/widgets/all_reviews_page?api_token=${n}&shop_domain=${e}`).then((e => e.json())).then((e => {
                document.getElementById(`jdgm-widget-all-header-${r}`).innerHTML = e ? .all_reviews_header, document.getElementById(`jdgm-widget-all-${r}`).innerHTML = e ? .all_reviews
            })) : "preview-badge" === i && fetch(`https://judge.me/api/v1/widgets/preview_badge?api_token=${n}&shop_domain=${e}&external_id=${t}`).then((e => e.json())).then((e => {
                let t = e ? .badge ? .replace(/display:none/g, "display:block");
                t = t ? .replace(/jdgm-prev-badge/g, "jdgm-preview-badge-show"), document.getElementById(`jdgm-widget-preview-badge-${r}`).innerHTML = t
            }))
        }
    });
    window.__shgProductComponent.judgemeWidget = function(t) {
        const n = t.meta.platform,
            i = t.meta.site_domain,
            r = t.meta.apiKey,
            o = t.meta.widgetType,
            a = t.meta.uuid,
            s = t.meta.productId;
        "shopify" === n && e(i, s, r, o, a).init()
    }
}(SHGJQ),
function(e, t, n) {
    "use strict";

    function i(e, t, n) {
        return n ? 0 : (Math.ceil(e / t) - 1) * t + 1
    }

    function r(e, t) {
        switch (t) {
            case "shopify":
                return e.replace(a, (function(e) {
                    return "_500x500_crop_center" + e
                }));
            case "big_commerce":
                var n = new RegExp("(.+)/products/(\\d+)/images/(\\d+)/([\\w\\.]+)" + o, "i"),
                    i = e.match(n);
                return i ? i[1] + "/images/stencil/500x500/products/" + i[2] + "/" + i[3] + "/" + i[4] + i[5] : e;
            default:
                return e
        }
    }
    var o = "(\\.(gif|jpe?g|tiff|png|psd|bmp|svg|heic|webp))",
        a = new RegExp(o, "i");
    e.__shgProductComponent = e.__shgProductComponent || {}, e.__shgProductComponent.image_gallery = function(e, t) {
        function o(e, t) {
            var o = t("image-gallery-root"),
                a = o.data("shg-carousel_mode"),
                s = o[0].hasAttribute("data-shg-lightbox-switch"),
                c = e.product.images,
                u = parseInt(o.data("shg-column_count"), 10),
                l = o.data("shg-square_thumbnails"),
                d = i(c.length, u, a);
            c.map((function(t, i) {
                var o = "string" == typeof t ? t : t.src,
                    a = o,
                    c = n("<div>").addClass("shg-gallery-thumb-image-wrapper");
                i + 1 >= d && c.css("padding-bottom", "0"), l && (c.addClass("shg-gallery-thumb-image-square"), o = r(o, e.meta.platform));
                var u = e.meta.LAZY_LOAD_ENABLED && e.meta.imageGalleryOffsetTop && e.meta.LAZY_LOAD_OFFSET_TOP && e.meta.imageGalleryOffsetTop > e.meta.LAZY_LOAD_OFFSET_TOP,
                    f = n("<img>").addClass("shg-gallery-thumb-image").attr("src", o).attr("loading", u ? "lazy" : "eager").attr("alt", t.alt).data("original-src", a);
                return s && f.attr("data-shg-lightbox-image", !0), c.append(f)
            })).reduce((function(e, t) {
                return e.append(t), e
            }), o.find(".shg-gallery-thumb-list"))
        }

        function a(e, t) {
            var i = t("image-gallery-root"),
                r = i.data("shg-show_dots"),
                o = i.find(".shg-gallery-dots-container"),
                a = i.data("shg-carousel_column_count"),
                s = e.product.images,
                c = Math.ceil(s.length / a);
            if (r)
                for (var u = 0; u < c; u++) {
                    var l = n("<div>").addClass("shg-gallery-dot").data("shg-dot_index", u);
                    o.append(l)
                }
        }

        function s(e, t) {
            var i = t("image-gallery-root");
            i.find("img").on("click", (function(t) {
                i[0].hasAttribute("data-shg-lightbox-switch") || e.updateProps((e => n.extend({}, e, {
                    selectedImage: n(t.target).data("original-src")
                })))
            })).on("mouseenter", (function(t) {
                e.updateProps((i => n.extend({}, i, {
                    productImagesToPreload: e.productImagesToPreload ? e.productImagesToPreload.add(n(t.target).data("original-src")) : new Set([n(t.target).data("original-src")])
                })))
            })), i.find(".shg-gallery-scroll-button.shg-left").on("click", (function() {
                var n = 0 | i.data("shg-current_position");
                i.data("shg-current_position", Math.max(0, n - 1)), l(e, t), u(e, t)
            })), i.find(".shg-gallery-scroll-button.shg-right").on("click", (function() {
                var n = 0 | i.data("shg-current_position"),
                    r = i.data("shg-carousel_column_count");
                i.data("shg-current_position", Math.min(Math.floor((e.product.images.length - 1) / r), n + 1)), l(e, t), u(e, t)
            }))
        }

        function c(e) {
            "connection" in navigator && !0 === navigator.connection.saveData || "requestIdleCallback" in window && window.requestIdleCallback((function() {
                var t = e.productImagesToPreload instanceof Set ? e.productImagesToPreload : new Set;
                for (var i of d.find("img")) t.add(n(i).data("original-src"));
                e.updateProps((e => n.extend({}, e, {
                    productImagesToPreload: t
                })))
            }))
        }

        function u(e, t) {
            var n = t("image-gallery-root"),
                i = n.data("shg-carousel_mode"),
                r = n.data("shg-carousel_column_count"),
                o = 0 | n.data("shg-current_position"),
                a = e.product.images.length,
                s = o * r,
                c = (o + 1) * r,
                u = 0 === o ? 0 : Math.min(0, a - c);
            if (i) {
                var l = n.find(".shg-gallery-thumb-image-wrapper");
                l.addClass("shg-gallery-image-hidden"), l.filter((function(e) {
                    return e >= s + u && e < c + u
                })).removeClass("shg-gallery-image-hidden")
            }
        }

        function l(e, t) {
            var n = t("image-gallery-root"),
                i = n.find(".shg-gallery-dot"),
                r = 0 | n.data("shg-current_position");
            i.on("click", (function(i) {
                var r = n.find(".shg-gallery-dot").filter((function(e, t) {
                    return i.target === t
                })).data("shg-dot_index");
                n.data("shg-current_position", r), l(e, t), u(e, t)
            })), i.removeClass("shg-selected"), i.filter((function(e) {
                return e === r
            })).addClass("shg-selected")
        }
        var d = t("image-gallery-root");
        d.data("shg-is-gallery-initialized") || (o(e, t), a(e, t), c(e, t), d.data("shg-is-gallery-initialized", !0)), l(e, t), u(e, t), s(e, t)
    }
}("object" == typeof exports ? exports : window, window, SHGJQ),
function(e, t, n) {
    "use strict";

    function i(e) {
        return "shg-product-img-" + encodeURIComponent(e)
    }

    function r(e) {
        return "shg-product-zoom-img-" + encodeURIComponent(e)
    }

    function o() {
        var e = P.variant,
            t = e && e.featured_image && e.featured_image.src,
            n = P.selectedImage || t || P.product.featured_image,
            r = P.product.images.some((e => "object" == typeof e)) ? P.product.images : P.product.media || [],
            o = P.product.handle,
            s = P.getProductUrl(o, e),
            c = d(n),
            u = S.attr("src");
        if ((c.src || c.srcSet) && u !== c.src) {
            if (h(s), c.src === A && T.addClass("shg-product-img-placeholder"), u) {
                var l = T.find('[data-id="' + i(n) + '"]');
                l.length || (l = a(n, !0)), S.is("[data-shg-lightbox-image]") && (l.attr("data-shg-lightbox-image", !0), S.removeAttr("data-shg-lightbox-image")), l.addClass("shogun-image").attr("data-shg-product-target", "product-image").show(), S.removeClass().removeAttr("data-shg-product-target").hide(), S = l
            } else {
                var g = P.meta.LAZY_LOAD_ENABLED && P.meta.imageOffsetTop && P.meta.LAZY_LOAD_OFFSET_TOP && P.meta.imageOffsetTop > P.meta.LAZY_LOAD_OFFSET_TOP;
                f(S, c, g), S.attr("data-id", i(n))
            }
            return p(r, n), S
        }
    }

    function a(e, t) {
        if (T) {
            var r = new Image;
            r.decoding = "async", r.style.display = t ? "" : "none", r.dataset.id = i(e);
            var o = d(e),
                a = !1,
                s = n(r);
            f(s, o, a);
            var c = T.find("a");
            return c.length ? c.append(r) : T.append(r), s
        }
        console.debug("Cannot create image - $imageWrapper is not defined")
    }

    function s(e) {
        T.find('[data-id="' + i(e) + '"]').length || a(e, !1)
    }

    function c() {
        P.productImagesToPreload instanceof Set && P.productImagesToPreload.forEach(s)
    }

    function u(e) {
        try {
            var t = new Blob([e], {
                type: "image/svg+xml"
            });
            return URL.createObjectURL(t)
        } catch (e) {
            return ""
        }
    }

    function l(e, t) {
        var n = "";
        return t.width && (n += "_" + t.width + "x"), e.substring(0, e.lastIndexOf(".")) + n + e.substring(e.lastIndexOf("."), e.length)
    }

    function d(e) {
        var t = P.meta.platform,
            n = A,
            i = null;
        return e ? (t === O ? (n = e, i = k.map((function(t) {
            return l(e, {
                width: t
            }) + " " + t + "w"
        })).join(", ")) : n = e, {
            src: n,
            srcSet: i
        }) : {
            src: n,
            srcSet: i
        }
    }

    function f(e, t, n) {
        var i = t.src,
            r = t.srcSet,
            o = P.meta.platform;
        i && (o === O && (e.attr("srcset", r), window.SHOGUN_POLYFILLS.push("picture")), e.attr("src", i), e.attr("loading", n ? "lazy" : "eager"))
    }

    function h(e) {
        E.attr("href", e)
    }

    function p(e, t) {
        var n = e.find((function(e) {
            return e.src === t
        }));
        n && S.attr("alt", n.alt || "")
    }

    function g() {
        var e = P.variant,
            t = e && e.featured_image && e.featured_image.src,
            n = P.selectedImage || t || P.product.featured_image;
        m(C, {
            image: n
        }), T[0].hasAttribute("data-shg-lightbox-switch") && C.children(".shg-image-zoom-background").attr("data-shg-lightbox-trigger", !0)
    }

    function m(e, t) {
        function n() {
            o.style.maxWidth = a.width + "px", o.style.maxHeight = a.height + "px"
        }

        function i(e, t) {
            function n() {
                v.style.transform = "scale(" + u + ")"
            }
            var i = 0,
                r = null;
            o.addEventListener(e.start, (function(e) {
                if (!t) return e.cancelable && e.preventDefault(), void n();
                switch (i) {
                    case 0:
                        i = 1, r = setTimeout((function() {
                            i = 0
                        }), 500);
                        break;
                    case 1:
                        i = 2, clearTimeout(r), e.cancelable && e.preventDefault(), n()
                }
            })), o.addEventListener(e.move, (function(e) {
                if (!t || 2 === i) {
                    clearTimeout(r), e.preventDefault();
                    var n = e.currentTarget.getBoundingClientRect(),
                        o = e.pageX || (e.changedTouches ? e.changedTouches[0].pageX : 0),
                        a = e.pageY || (e.changedTouches ? e.changedTouches[0].pageY : 0),
                        u = y((o - n.left) / n.width * 100, s, c),
                        l = y((a - n.top) / n.height * 100, s, c);
                    v.style.transformOrigin = u + "% " + l + "%"
                }
            })), o.addEventListener(e.end, (function(e) {
                1 !== i && (clearTimeout(r), i = 0), e.cancelable && e.preventDefault(), v.style.transform = ""
            }))
        }
        if (e[0] && S[0]) {
            var o = e[0],
                a = S[0].getBoundingClientRect();
            if (a.width && a.height) {
                for (var s = 0, c = 100, u = t.scale || L, l = t.src || t.image, d = r(l), f = "shg-image-zoom-background", h = o.getElementsByClassName(f), p = !1, g = 0, m = h.length; g < m; g++) h[g].dataset.id === d ? (h[g].style.display = "", n(), p = !0) : h[g].style.display = "none";
                if (!p) {
                    var v = document.createElement("div");
                    v.className = f, v.dataset.id = d, v.style.backgroundImage = "url(" + l + ")", o.dataset.shgZoomInitialized = "true", n(), o.append(v), w(i)
                }
            }
        }
    }

    function v(e) {
        if (_(e), g(), "true" !== C.attr("data-shg-zoom-initialized")) {
            var t = new IntersectionObserver((function(n) {
                var i = n[0],
                    r = 0 === i.intersectionRatio;
                if ("true" === i.target.getAttribute("data-shg-zoom-initialized")) return t.disconnect();
                r || (_(e), g())
            }));
            t.observe(C[0])
        }
    }

    function w(e) {
        function t(r) {
            window.removeEventListener(n.start, t, !1), window.removeEventListener(i.start, t, !1), r.type === n.start ? e(n, !1) : e(i, !0)
        }
        var n = {
                start: "mouseover",
                move: "mousemove",
                end: "mouseleave"
            },
            i = {
                start: "touchstart",
                move: "touchmove",
                end: "touchend"
            };
        window.addEventListener(n.start, t, !1), window.addEventListener(i.start, t, !1)
    }

    function y(e, t, n) {
        return Math.min(Math.max(e, t), n)
    }

    function b() {
        T.css({
            display: "inline-block"
        })
    }

    function _(e) {
        S = e.$image, C = e.$imageZoom, E = e.$imageLink, T = e.$imageWrapper, P = e.props
    }

    function x(e, t) {
        var n = {
            $image: t("image"),
            $imageZoom: t("image-zoom"),
            $imageLink: t("url"),
            $imageWrapper: t("image-wrapper"),
            props: e
        };
        _(n), o(), c(), b(), !C.length || E.length && window.SHOGUN_BROWSER && window.SHOGUN_BROWSER.supportOnlyTouch || (n.$image = t("image"), _(n), v(n), S.prop("completed") || S.on("load", (function() {
            v(n)
        })))
    }
    window.SHOGUN_POLYFILLS = window.SHOGUN_POLYFILLS || [], window.SHOGUN_POLYFILLS.push("objectFit"), window.SHOGUN_POLYFILLS.push("intersection");
    var S, C, E, T, A = u('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52"><path fill="rgba(0, 0, 0, 0.25)" opacity="0.45" d="M45.04 12v28H7v-4h30.04c2.21 0 4-1.79 4-4V12h4z"/><path fill="none" stroke="rgba(0, 0, 0, 0.25)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="M49 46H3c-1.1 0-2-.9-2-2V8c0-1.1.9-2 2-2h46c1.1 0 2 .9 2 2v36c0 1.1-.9 2-2 2z" style="&#10;    background: rgba(0, 0, 0, 0.2);&#10;"/><path fill="none" stroke="rgba(0, 0, 0, 0.25)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="M6 11h40v30H6z"/><path fill="none" stroke="rgba(0, 0, 0, 0.25)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="M32.91 18.55h-6.86c-.4 0-.78.16-1.06.44l-8.05 8.05a.996.996 0 0 0 0 1.41l7.07 7.07c.39.39 1.02.39 1.41 0l8.05-8.05c.28-.28.44-.66.44-1.06v-6.86c0-.55-.45-1-1-1z"/><circle fill="rgba(0, 0, 0, 0.25)" cx="30.02" cy="22.44" r="1"/></svg>'),
        O = "shopify",
        k = [180, 370, 540, 740, 900, 1080, 1296, 1512, 1728, 2048],
        L = 2,
        P = {};
    x.PLACEHOLDER_IMAGE_SRC = A, e.__shgProductComponent = window.__shgProductComponent || {}, e.__shgProductComponent.image = x
}("object" == typeof exports ? exports : window, window, SHGJQ);
var ELEMENT_NODE_TYPE = 1;
ZERO_WIDTH_SPACE = "&#8203;";
! function() {
    "use strict";
    window.__shgProductComponent && (window.__shgProductComponent.description = function(e, t) {
        var n = e.product.description || e.product.body_html || ZERO_WIDTH_SPACE;
        isNotRichText(n) && (n = "<p>" + n + "</p>"), t("description").html(n)
    })
}(SHGJQ),
function(e) {
    "use strict";

    function t(e) {
        e = Array.isArray(e) ? e.join("") : e;
        var t = a.exec(e);
        return function(n) {
            var i = {
                query: e
            };
            (n && (i.variables = JSON.stringify(n)), t && t.length) && (t[2] && (i.operationName = t[2]));
            return JSON.stringify(i)
        }
    }

    function n(e) {
        var t = window.location.href;
        e = e.replace(/[[\]]/g, "\\$&");
        var n = new RegExp("[?&]" + e + "(=([^&#]*)|&|#|$)").exec(t);
        return n ? n[2] ? decodeURIComponent(n[2].replace(/\+/g, " ")) : "" : null
    }

    function i(e, t) {
        function n(t, n) {
            t = "function" == typeof t ? t(o) : t, n && t === o || (o = t, r(e.uuid, t))
        }
        if (e.hideIfDraft && "draft" === t.status) return;
        var i = f[e.platform];
        let o = {};
        n({
            meta: e,
            product: t,
            variant: i.getInitialVariant(t, e),
            updateProps: n,
            getDefaultVariant: i.getDefaultVariant,
            getProductUrl: i.getProductUrl,
            moneyFormat: i.moneyFormatConfig(e),
            getMetafields: i.getMetafields
        }), window.__shgProductsUpdatePropsFns = window.__shgProductsUpdatePropsFns || [], window.__shgProductsUpdatePropsFns.push(n)
    }

    function r(t, n) {
        function i(e) {
            return e.not("#" + t + " .shg-product").not("#" + t + " .shg-product *")
        }
        var r = e("#" + t).not("#" + t + " .shg-product");
        i(r.unbind().find("*")).unbind(), window.__shgProductCallbacks && window.__shgProductCallbacks[t] && window.__shgProductCallbacks[t].forEach((function(t) {
            var o = "box" === t.cb ? r : r.find("#" + t.data.uuid),
                a = function(e) {
                    return i(o.find('[data-shg-product-target="product-' + e + '"]'))
                },
                s = e.extend({}, n, {
                    meta: e.extend({}, n.meta, t.data)
                });
            window.__shgProductComponent && window.__shgProductComponent[t.cb] && window.__shgProductComponent[t.cb](s, a, o, r)
        })), null === h && (h = setTimeout((() => {
            h = null, window.dispatchEvent(new CustomEvent("runProductCallbacksComplete"))
        })))
    }

    function o(e, t) {
        function n() {
            return t.featured_image ? t.featured_image : t.image && t.image.src ? t.image.src : t.images && t.images.length ? t.images[0].src || t.images[0] : void 0
        }

        function i(e) {
            return e.featured_image ? e.featured_image : e.image_id && t.images && t.images.length ? t.images.find((function(t) {
                return t.id === e.image_id
            })) : void 0
        }

        function r(e) {
            return "boolean" == typeof e.available ? e.available : s.isVariantAvailable(e)
        }

        function o(e) {
            return e.available = r(e), e.featured_image = i(e), e
        }

        function a(e) {
            return e.name || e
        }
        var s = f[e.platform];
        return t.featured_image = n(), t.variants = t.variants.map(o), t.options = t.options && t.options.filter(Boolean).map(a), t
    }
    const a = /(query|mutation) ?([\w\d-_]+)? ?\(.*?\)? \{/,
        s = async ({
            url: e,
            method: t,
            headers: n,
            body: i
        }) => (await fetch(e, {
            method: t,
            headers: n,
            body: i
        })).json(),
        c = ({
            storefrontDomain: e,
            storefrontAccessToken: n,
            storefrontApiVersion: i
        }) => async ({
            query: r,
            variables: o
        }) => {
            if (!e || !n || !i) return Promise.reject(new Error("Can not perform storefront request. Missing storefrontDomain, storefrontAccessToken or storefrontApiVersion"));
            if (!r) return Promise.reject(new Error("Can not perform storefront request. Missing query"));
            return s({
                url: `https://${e}/api/${i}/graphql`,
                method: "POST",
                headers: {
                    "X-Shopify-Storefront-Access-Token": n || "",
                    "Content-Type": "application/json",
                    Accept: "application/json"
                },
                body: t(r)(o)
            })
        };
    window.__shgProductComponent = window.__shgProductComponent || {}, window.__shgProductComponent.box = function(e, t, n, i) {
        i.show()
    }, window.__shgProductsInit = function(e) {
        window.__shgProductInits && window.__shgProductInits.forEach((function(t) {
            var n = null != e,
                r = void 0 !== t.manual && null !== t.manual;
            if (!n || !r || t.manual === e) {
                var a = f[t.platform];
                a.getProduct(t, (function(e) {
                    if (e) {
                        var n = [];
                        a.getMetafields(t, (function(r) {
                            const a = r ? .product;
                            n = a ? Object.keys(a).map((e => "id" === e ? null : a[e])).filter((e => !!e)) : [];
                            var s = o(t, e);
                            s.metafields = n, i(t, s)
                        }))
                    }
                }))
            }
        }))
    };
    var u = {
            getProduct: function(t, n) {
                var i = t.productUrl + "?external_id=" + t.productId,
                    r = {
                        "SHOGUN-AUTH-TOKEN": t.authToken
                    };
                e.ajax({
                    url: i,
                    method: "GET",
                    dataType: "json",
                    headers: r
                }).then((function(e) {
                    n(e.product)
                }))
            },
            getMetafields: function(e, t) {
                t()
            },
            getProductUrl: function(e) {
                return "/" + e
            },
            isVariantAvailable: function(e) {
                return !e.inventory_tracking || "none" === e.inventory_tracking || e.inventory_quantity > 0
            },
            getDefaultVariant: function(e, t) {
                return e.variants.find((function(e) {
                    return e.id === t.productVariantId
                })) || e.variants[0]
            },
            getInitialVariant: function(e, t) {
                return this.getDefaultVariant(e, t)
            },
            moneyFormatConfig: function(e) {
                return {
                    type: "default",
                    config: e.moneyFormat[e.currency]
                }
            }
        },
        l = e.extend({}, u, {
            getProduct: function(t, n) {
                if (window.__shgProducts && window.__shgProducts.hasOwnProperty(t.productHandle)) return n(window.__shgProducts[t.productHandle]);
                if (t.guestCodeEnabled) return l.getProductWithPasswordProtection(t, n);
                var i = (t.shopUrl ? "https://" + t.shopUrl : "") + "/products/" + t.productHandle + ".js";
                e.ajax({
                    url: i,
                    method: "GET",
                    dataType: "json"
                }).done((function(e) {
                    n(e)
                })).fail((function(e) {
                    0 === e.status && l.getProductCORSFallback(t, n)
                }))
            },
            getMetafields: function(e, t) {
                const {
                    storefrontAccessToken: n,
                    storefrontApiVersion: i,
                    storefrontDomain: r,
                    metafieldsQuery: o
                } = e;
                c({
                    storefrontDomain: r,
                    storefrontAccessToken: n,
                    storefrontApiVersion: i
                })({
                    query: o
                }).then((e => t(e.data))).catch((() => {
                    t()
                }))
            },
            getProductCORSFallback: function(t, n) {
                var i = document.getElementsByTagName("base")[0],
                    r = window.location.origin;
                i && i.attributes.href && (r = i.attributes.href.value);
                var o = r + "/products/" + t.productHandle + ".json";
                e.ajax({
                    url: o,
                    method: "GET",
                    dataType: "json"
                }).then((function(e) {
                    n(e.product)
                }))
            },
            getProductWithPasswordProtection: function(t, n) {
                var i = t.externalProductUrl,
                    r = {
                        "SHOGUN-AUTH-TOKEN": t.authToken
                    };
                e.ajax({
                    url: i,
                    method: "GET",
                    dataType: "json",
                    headers: r
                }).then((function(e) {
                    n(e)
                }))
            },
            getProductUrl: function(e, t) {
                var n = "/products/" + e;
                return t ? n + "?variant=" + t.id : n
            },
            isVariantAvailable: function(e) {
                return !e.inventory_policy || !("shopify" === e.inventory_management && "deny" === e.inventory_policy && e.inventory_quantity < 1)
            },
            getInitialVariant: function(e, t) {
                return t.staticVariant ? this.getDefaultVariant(e, t) : e.variants.find((function(e) {
                    return String(e.id) === n("variant")
                })) || this.getDefaultVariant(e, t)
            },
            moneyFormatConfig: function(e) {
                var t = window.__shgMoneyFormat;
                if ("string" == typeof t) return {
                    type: "template",
                    config: t
                };
                var n = window.__shgCurrentCurrencyCode;
                return {
                    type: "default",
                    config: n && n.currency && t && t[n.currency] ? t[n.currency] : n || t[e.currency]
                }
            }
        }),
        d = e.extend({}, u, {
            moneyFormatConfig: function(e) {
                return {
                    type: "default",
                    config: e.moneyFormat[e.currency],
                    currencies: e.moneyFormat
                }
            }
        }),
        f = {
            shopify: l,
            big_commerce: u,
            commerce_cloud: d
        };
    let h = null;
    document.addEventListener("pagebuilder:load", (function() {
        window.__shgProductsInit(!1)
    }))
}(SHGJQ),
function(e) {
    "use strict";
    window.__shgProductComponent && (window.__shgProductComponent.addToCart = function(t, n, i) {
        function r() {
            var n = {
                payload: {
                    id: t.variant.id,
                    quantity: t.quantity || t.meta.defaultQuantity || 1
                }
            };
            if ("stay" === t.meta.behavior) {
                var i = [];
                e(e.find("[data-shogun-cart-items-count]")).each((function(t, n) {
                    const r = e(n).closest('[id^="shopify-section-"]');
                    if (r) {
                        const e = r.attr("id").replace("shopify-section-", "");
                        i.includes(e) || i.push(e)
                    } else console.error("There is an element with attribute 'data-shogun-cart-items-count' that is not inside a Shopify section.");
                    return ""
                })), n.payload.sections = i.join(",")
            }
            return n
        }

        function o(n) {
            const i = t.product.id,
                r = {
                    action: "add",
                    product_id: i,
                    "qty[]": t.quantity || t.meta.defaultQuantity || 1
                };
            if (n) {
                const e = () => {
                    const e = document.getElementsByClassName("rca-subscription-form__button--selected");
                    return !!e.length && e[0].classList.contains("rca-subscription-form__button--otp")
                };
                if (window.RCA_DATA ? .RCA_PRODUCT_DATA) {
                    const t = window.RCA_DATA.RCA_PRODUCT_DATA.find((e => e.id === Number.parseInt(i, 10)));
                    if (t ? .subscriptionModifier && !e()) {
                        const {
                            id: e
                        } = t.subscriptionModifier, n = document.getElementById(`attribute_select_${e}`);
                        if (n) {
                            const t = n.value;
                            r[`attribute[${e}]`] = t
                        }
                    }
                }
            }
            return {
                payload: e.extend(r, t.variant.option_values.reduce((function(e, t) {
                    return e["attribute[" + t.option_id + "]"] = t.id, e
                }), {})),
                headers: {
                    "x-xsrf-token": window.BCData && window.BCData.csrf_token ? window.BCData.csrf_token : ""
                }
            }
        }

        function a() {
            return {
                payload: e.extend({
                    pid: t.variant.id,
                    quantity: t.quantity || t.meta.defaultQuantity || 1,
                    format: "stay" === t.meta.behavior ? "ajax" : "html"
                }, t.variant.option_values.reduce((function(e, t) {
                    return e["options[" + t.option_id + "]"] = t.id, e
                }), {}))
            }
        }

        function s(e) {
            var n = {
                shopify: r,
                big_commerce: o,
                commerce_cloud: a
            }[t.meta.platform];
            return n && n(e)
        }

        function c() {
            return i.removeClass("shg-product-atc-success").removeClass("shg-product-atc-error").removeClass("shg-product-atc-disabled").off("click").on("click", b).text(t.meta.buttonText)
        }

        function u() {
            return c().off("click").addClass("shg-product-atc-disabled")
        }

        function l() {
            return u().addClass("shg-product-atc-error").text(t.meta.soldOutText)
        }

        function d(e) {
            window.location = e
        }

        function f() {
            return u().addClass("shg-product-atc-error").text("Please try again later.")
        }

        function h() {
            return u().text(t.meta.unavailableText)
        }

        function p() {
            return u().addClass("shg-product-atc-success").text(t.meta.successText)
        }

        function g() {
            return u().text("Loading...")
        }

        function m(t) {
            var n = i.parent("form");
            for (var r in n.not(':has(input[type="submit"])').append('<input type="submit" />'), n.find(":submit").hide(), t.payload) {
                n.find('input[name="' + r + '"]').remove();
                var o = e("<input>").attr({
                    type: "hidden",
                    name: r,
                    value: t.payload[r]
                });
                n.append(o)
            }
            return n
        }

        function v() {
            window.stencilUtils.api.cart.getContent({}, ((e, t) => {
                const n = (new DOMParser).parseFromString(t, "text/html"),
                    i = n.querySelector("[data-cart-quantity]") ? .getAttribute("data-cart-quantity") || 0,
                    r = document.querySelector("[data-cart-preview]");
                if (r) {
                    const e = r.getAttribute("aria-label");
                    r.setAttribute("aria-label", e ? e.replace(/\d+/, i) : `Cart with ${i} items`), i ? r.classList.remove("navUser-item--cart__hidden-s") : r.classList.add("navUser-item--cart__hidden-s")
                }
                const o = document.querySelector(".cart-quantity");
                if (o) {
                    const e = o.innerText;
                    o.innerText = e ? e.replace(/\d+/, i) : i, i > 0 ? o.classList.add("countPill--positive") : o.classList.remove("countPill--positive")
                }
                window.stencilUtils.tools.storage ? .localStorageAvailable ? .() && localStorage.setItem("cart-quantity", i)
            }))
        }

        function w({
            hasBCReChargeEnabled: e,
            behavior: t,
            response: n
        }) {
            "go" !== t ? "direct" !== t || (window.location = `${window.location.origin}/checkout`) : window.location = `${window.location.origin}/cart.php`
        }

        function y() {
            var e = !!t.variant;
            e && !t.variant.available ? l() : e ? c() : h()
        }

        function b() {
            const n = !!document.getElementById(t.meta.uuid).closest(".shg-product").querySelector(".rca-subscription-form");
            var i = s(n),
                r = m(i);
            if (x && "go" === t.meta.behavior) {
                const e = [window.Shopify ? .routes ? .root, window.Shopify ? .routes ? .root_url, "/"].find((e => null != e)),
                    t = "/" === e ? r.attr("action") : `${e}${r.attr("action")}`;
                return r.attr("action", t), void r.find(":submit").click()
            }
            if (x && "direct" === t.meta.behavior) return u(), void(window.location.href = `${location.origin}/cart/${i.payload.id}:${i.payload.quantity}`);
            u(), e.ajax({
                method: "POST",
                dataType: "json",
                url: t.meta.action,
                data: r.serialize(),
                headers: i.headers
            }).done((function(i) {
                if (i && i.data && i.data.error) {
                    let e = i.data ? .data ? .url;
                    e && _ ? d(e) : f()
                } else if (p(), x) Object.entries(i.sections).forEach((function([t, n]) {
                    var i = e.parseHTML(n),
                        r = e.find(`#shopify-section-${t}`);
                    e(r).each((function() {
                        var t = e(this).find("[data-shogun-cart-items-count]");
                        e(t).each((function(t) {
                            var n = e(i).find("[data-shogun-cart-items-count]")[t];
                            n && e(this).replaceWith(n)
                        }))
                    }))
                }));
                else if (_) try {
                    window.stencilUtils ? ("stay" === t.meta.behavior && v(), w({
                        hasBCReChargeEnabled: n,
                        behavior: t.meta.behavior,
                        response: i
                    })) : console.warn("Stencil Utils object is not found. It is required for full AJAX cart support, without it, the cart counter will not be updating")
                } catch (e) {
                    console.warn(e)
                }
            })).fail((function() {
                l()
            })).always((function() {
                setTimeout((function() {
                    c()
                }), 4e3)
            }))
        }
        const _ = "big_commerce" === t.meta.platform,
            x = "shopify" === t.meta.platform,
            S = t.rechargeWidgets || {},
            C = Object.keys(S);
        if (x && C.length > 0) {
            let e = !1;
            for (const t of C) {
                if ("loading" === S[t]) {
                    e = !0;
                    break
                }
            }
            e ? g() : y()
        } else y()
    })
}(SHGJQ),
function(e) {
    "use strict";
    document.addEventListener("pagebuilder:load", (function() {
        const t = e(".shg-map-container");
        if (t.length) {
            window.SHOGUN_MAPS = [];
            var n = "https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=geometry,drawing,places&key=AIzaSyCOsHBRVUQdLjaak3_FcHPbAMOggnekCHc";
            window.SHOGUN_MAP_RESIZER = function() {
                window.SHOGUN_MAPS.forEach((function(e) {
                    var t = e.getCenter();
                    window.google.maps.event.trigger(e.getDiv(), "resize"), e.setCenter(t)
                }))
            }, e.getScript(n, (function() {
                function n(e) {
                    var t = e.data("zoom"),
                        n = e.data("title"),
                        i = e.data("description"),
                        r = e.find(".shg-map")[0],
                        o = {
                            lat: e.data("latitude"),
                            lng: e.data("longitude")
                        },
                        a = {
                            center: o,
                            zoom: 12,
                            zoomControl: t,
                            draggable: t,
                            scrollwheel: t,
                            gestureHandling: t ? "auto" : "none"
                        };
                    if (o.lat && o.lng) {
                        var s, c = new window.google.maps.Map(r, a);
                        if (window.SHOGUN_MAPS.push(c), o.lat && o.lng && (s = new window.google.maps.Marker({
                                position: o,
                                map: c
                            })), s && (n || i)) {
                            var u = '<div class="shg-map-info-window-container"><h3>' + n + "</h3><span>" + i + "</span></div>",
                                l = new window.google.maps.InfoWindow({
                                    content: u
                                });
                            s.addListener("click", (function() {
                                l.open(c, s)
                            }))
                        }
                    }
                }
                t.each((function() {
                    n(e(this))
                }))
            }))
        }
    }))
}(SHGJQ),
function(e, t) {
    "use strict";

    function n(e) {
        var n = t(e).attr("data-initialized", "true"),
            r = n.data("api-path");
        s[r] ? i(s[r], n) : t.get(r, (function(e) {
            s[r] = e.posts, i(e.posts, n)
        }))
    }

    function i(e, n) {
        var i = n.data("in-new-window"),
            a = n.data("hide-text"),
            s = n.data("vertical-gutter") || "10px",
            c = i ? "_blank" : "_self",
            u = n.data("square-thumbnails"),
            l = u ? "shg-ig-posts-image-square" : "shg-ig-posts-image",
            d = u && "shg-ig-square-wrapper";
        e.forEach((function(e) {
            n.append(t("<div>").addClass("shg-ig-posts").css({
                marginBottom: s
            }).append(t("<a>").attr({
                href: e.link,
                target: c
            }).addClass("shg-ig-posts-link").append(t("<div>").addClass(d).css({
                marginBottom: 0
            }).append(t("<img>").attr("src", e.image).addClass(l))))), a || n.find(".shg-ig-posts:last").append(t("<div>").addClass("shg-ig-details-container").append(t("<p>").addClass("shg-ig-posts-caption").text(o(e.caption))).append(t("<div>").addClass("shg-ig-user-details").append(t("<img>").addClass("shg-ig-user-image").attr("src", e.from.profile_picture)).append(t("<div>").addClass("shg-ig-username-container").append(t("<p>").addClass("shg-ig-user-full-name").text(e.from.full_name)).append(t("<p>").addClass("shg-ig-user-createdat").text(r(e.created_at))))))
        }))
    }

    function r(e) {
        var t = new Date(1e3 * parseInt(e, 10));
        return t.getFullYear() + "-" + (t.getMonth() + 1) + "-" + t.getDate()
    }

    function o(e) {
        return !e || e.length < 150 ? e : e.slice(0, 150).concat(" ...")
    }
    var a = ".shg-ig-posts-container:not([data-initialized='true'])",
        s = {};
    document.addEventListener("pagebuilder:load", (function() {
        t(a).each((function() {
            n(this)
        })), e.__shgElementReady && e.__shgElementReady(a, n)
    }))
}(window, SHGJQ),
function(e) {
    "use strict";

    function t() {
        if (e(".shogun-image-lightbox-content").length) {
            var t = e(".shogun-image-lightbox-content");
            t.attr("data-shg-lightbox-switch", !0), t.children("div").children("img").attr("data-shg-lightbox-image", !0), t.children(".shogun-image-overlay").attr("data-shg-lightbox-trigger", !0)
        }
    }
    window.SHOGUN_POLYFILLS.push("intersection"), e(window).on("load", (function() {
        t()
    }))
}(SHGJQ),
function(e) {
    "use strict";

    function t() {
        if (e(".shogun-image-lightbox-content").length) {
            var t = e(".shogun-image-lightbox-content");
            t.attr("data-shg-lightbox-switch", !0), t.children("img").attr("data-shg-lightbox-image", !0), t.children(".shogun-image-overlay").attr("data-shg-lightbox-trigger", !0)
        }
    }
    window.SHOGUN_POLYFILLS.push("intersection"), e(window).on("load", (function() {
        t()
    }))
}(SHGJQ),
function(e) {
    "use strict";

    function t(e, t) {
        e.style.height = "0", e.style.height = e.scrollHeight + t + "px"
    }
    var n = 13,
        i = 50;
    n = 13, i = 50;
    e(window).on("load", (function() {
        window.SHOGUN_FORM_TEXTAREA_ELEMENTS && window.SHOGUN_FORM_TEXTAREA_ELEMENTS.forEach((function(r) {
            var o = document.getElementById("form-textarea-" + r.uuid);
            if (o) {
                var a = parseInt(e(o).css("lineHeight"), 10);
                o.addEventListener("keydown", (function(r) {
                    r.keyCode == n && e(o).height() > i && t(o, a)
                })), o.addEventListener("keyup", (function() {
                    t(o, 0)
                })), o.addEventListener("paste", (function() {
                    t(o, 0)
                }))
            }
        }))
    }))
}(SHGJQ),
function(e) {
    "use strict";

    function t() {
        var t = e(this);
        "" === t.val() ? t.addClass("is-placeholder-selected") : t.removeClass("is-placeholder-selected")
    }
    var n = e(".shogun-form-dropdown select");
    n.each(t), n.on("change", t)
}(SHGJQ),
function(e) {
    "use strict";

    function t(e) {
        e.isValid ? e.el.next(".shogun-form-field-error-msg-container").hide() : e.el.next(".shogun-form-field-error-msg-container").show()
    }

    function n(e, t) {
        var n = e.attr("name"),
            i = e.val(),
            r = !e.attr("required") || !!i;
        return r && "email" === t && !s.test(i) && (r = !1), {
            label: n,
            value: i,
            type: t,
            isValid: r,
            el: e
        }
    }

    function i(t) {
        var n = [];
        return t.each((function() {
            var t = e(this).find("input"),
                i = e(this).find("input:checked"),
                r = e(t[0]).attr("name"),
                o = e(t[0]).attr("required"),
                a = i && e(i).val();
            n.push({
                label: r,
                type: "radio",
                value: a,
                isValid: !o || !!a,
                el: e(t[t.length - 1]).parent()
            })
        })), n
    }

    function r(t) {
        var n = [];
        return t.each((function() {
            var t = e(this).find("input"),
                i = e(this).find("input:checked"),
                r = e(t[0]).attr("name"),
                o = e(t[0]).attr("required"),
                a = "";
            i.each((function() {
                a.length && (a += ","), a += e(this).val()
            })), n.push({
                label: r,
                type: "checkbox",
                value: a,
                isValid: !o || !!a,
                el: e(t[t.length - 1]).parent()
            })
        })), n
    }

    function o(o) {
        if (!o.disabled) {
            var a = e("#" + o.uuid),
                s = [];
            a.find("div[data-field-type]").each((function() {
                var t = e(this).data("field-type");
                switch (t) {
                    case "text":
                        var o = e(this).find("input[type='text']");
                        o && s.push(n(o, t));
                        break;
                    case "email":
                        var a = e(this).find("input[type='email']");
                        a && s.push(n(a, t));
                        break;
                    case "textarea":
                        var c = e(this).find("textarea");
                        c && s.push(n(c, t));
                        break;
                    case "select":
                        var u = e(this).find("select");
                        u && s.push(n(u, t));
                        break;
                    case "checkbox":
                        s = s.concat(r(e(this)));
                        break;
                    case "radio":
                        s = s.concat(i(e(this)))
                }
            })), s.forEach((function(e) {
                t(e)
            }));
            var c = a.find(".g-recaptcha-response");
            if (c.length && s.push({
                    label: "g-recaptcha-response",
                    value: c.val(),
                    type: "g-recaptcha-response",
                    isValid: !0
                }), s.some((function(e) {
                    return !e.isValid
                }))) return !1;
            var u = {
                site_id: o.site_id,
                form_submission_email: o.form_submission_email,
                form_submission_klaviyo_list_id: o.form_submission_klaviyo_list_id,
                form_submission_destination: o.form_submission_destination,
                form_name: o.form_name,
                fields: s.map((function(e) {
                    return {
                        label: e.label,
                        value: e.value,
                        type: e.type
                    }
                }))
            };
            e.ajax({
                type: "POST",
                url: o.domain + "/api/forms/contact/submit",
                data: JSON.stringify(u),
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function() {
                    a.find(".shogun-form-success-msg").css("visibility", "visible"), a.find(".shogun-form-error-msg").text(""), a.find(".shogun-form-field-error-msg").text(""), a.find(".shogun-form-error-msg-container").hide(), a.find(".shogun-form-field-error-msg-container").hide(), a.find(".shogun-form-box-submit").prop("disabled", !0), o.disabled = !0, o.form_href && window.open(o.form_href, o.form_same_window ? "_self" : "_blank")
                },
                error: function(e, t) {
                    e.responseJSON.errors.includes("add_ons.google_recaptcha.verification_failed") ? a.find(".shogun-recaptcha-error-msg").css("visibility", "visible") : (a.find(".shogun-form-error-msg").text(t), a.find(".shogun-form-error-msg-container").show())
                }
            })
        }
    }
    var a = 13,
        s = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    e(window).on("load", (function() {
        window.SHOGUN_FORM_BOX && window.SHOGUN_FORM_BOX.forEach((function(t) {
            var n = e("#" + t.uuid),
                i = n.find(".shogun-form-box-submit");
            if (i.click((function() {
                    o(t)
                })), 0 === i.length) {
                var r = function(e) {
                    e.which === a && o(t)
                };
                n.find("select").keypress(r), n.find("input").keypress(r), n.find("textarea").keypress(r)
            }
        }))
    }))
}(SHGJQ),
function(e) {
    "use strict";

    function t() {
        var t = e(this).parents(".shogun-form"),
            i = t.data("domain") + "/api/forms/contact/submit",
            r = t.data("site-id"),
            o = t.data("reply-email"),
            a = t.data("form-name"),
            s = !0,
            c = [];
        if (t.find(".shogun-form-field").each((function() {
                var t = e(this).data("type"),
                    i = e(this).val();
                c.push({
                    label: e(this).attr("name"),
                    value: i,
                    type: t
                }), e(this).data("required") && 0 === i.length ? (s = !1, e(this).next().text("This field is required").show()) : "email" === t && i.length && !n.test(i) ? (s = !1, e(this).next().text("This must be a valid email address").show()) : e(this).next().hide()
            })), !s) return !1;
        var u = {
            site_id: r,
            reply_email: o,
            form_name: a,
            fields: c
        };
        e.ajax({
            type: "POST",
            url: i,
            data: JSON.stringify(u),
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function() {
                t.parent().find(".shogun-success-alert").show(), t.hide()
            }
        })
    }
    var n = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    e(document).on("click", ".shogun-form-submit", t), e(document).on("keypress", "input.shogun-form-field", (function(e) {
        if (13 === e.which) return t.call(this), !1
    }))
}(SHGJQ),
function(e) {
    "use strict";

    function t(e) {
        var t = Date.parse(e) - Date.parse(new Date),
            n = Math.floor(t / 1e3 % 60),
            i = Math.floor(t / 1e3 / 60 % 60),
            r = Math.floor(t / 36e5 % 24);
        return {
            total: t,
            days: Math.floor(t / 864e5),
            hours: r,
            minutes: i,
            seconds: n
        }
    }

    function n(e) {
        return e.toString().length > 2 ? e : ("0" + e).slice(-2)
    }

    function i(i, r) {
        function o() {
            var e = t(r);
            if (e.total <= 0) return clearInterval(d);
            s.html(n(e.days)), c.html(("0" + e.hours).slice(-2)), u.html(("0" + e.minutes).slice(-2)), l.html(("0" + e.seconds).slice(-2))
        }
        var a = e(i),
            s = a.find(".days"),
            c = a.find(".hours"),
            u = a.find(".minutes"),
            l = a.find(".seconds");
        o();
        var d = setInterval(o, 1e3)
    }
    document.addEventListener("pagebuilder:load", (function() {
        if (window.SHOGUN_COUNTDOWNS)
            for (var e = 0; e < window.SHOGUN_COUNTDOWNS.length; e++) {
                var t, n = window.SHOGUN_COUNTDOWNS[e],
                    r = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/;
                t = n.date && !r.test(n.date) && parseInt(n.date) > 0 ? new Date(parseInt(n.date)) : new Date(n.date), "true" === n.isStatic && ((t = new Date).setDate(t.getDate() + n.days), t.setHours(t.getHours() + n.hours), t.setMinutes(t.getMinutes() + n.minutes), t.setSeconds(t.getSeconds() + n.seconds)), isNaN(Date.parse(t)) || i(n.id, new Date(t))
            }
    }))
}(SHGJQ),
function(e) {
    "use strict";

    function t(e) {
        return e.is(":not([data-col-grid-mode-on=''])")
    }

    function n() {
        u.each((function(t, n) {
            i(e(n))
        }))
    }

    function i(n) {
        try {
            if (!t(n)) return;
            var i, o = n.children(),
                a = {},
                s = {},
                c = !0;
            o.each((function(t, n) {
                const o = e(n).offset().top;
                i === o && (c = !1), i = o, r(e(n)).each((function(t, n) {
                    var i = e(n);
                    a[t] ? a[t].push(i) : a[t] = [i], s[t] = Math.max(s[t] || 0, i.outerHeight(!0))
                }))
            })), Object.keys(a).forEach((function(e) {
                a[e].forEach((function(t) {
                    if (c || t.hasClass("shogun-image-container")) t.css({
                        height: "",
                        "min-height": ""
                    });
                    else if (s[e]) {
                        var n = t.outerHeight(!0) - t.outerHeight(),
                            i = parseInt(s[e] - n);
                        t.css({
                            "min-height": i,
                            "box-sizing": "border-box"
                        })
                    }
                }))
            }))
        } catch (e) {
            console.error("failed to adjust columns", e)
        }
    }

    function r(e) {
        var t = e.children();
        return (t.first() && t.first().data("is-product-box") ? t.first().children() : t).filter((function(e, t) {
            return o(t) && "script" !== t.tagName.toLowerCase()
        }))
    }

    function o(e) {
        return !(null === e.offsetParent)
    }

    function a(t) {
        i(t), e(window).trigger("shg-fw:resize")
    }

    function s() {
        n(), e(window).trigger("shg-fw:resize")
    }

    function c() {
        if ("IntersectionObserver" in window) {
            var t = new IntersectionObserver((function(t) {
                for (const n of t) n.isIntersecting && a(e(n.target))
            }), {
                root: null,
                rootMargin: "-300px 0px -300px 0px",
                threshold: 0
            });
            for (let e = 0; e < u.length; e++) t.observe(u.get(e))
        }
    }
    window.SHOGUN_POLYFILLS = window.SHOGUN_POLYFILLS || [], window.SHOGUN_POLYFILLS.push("intersection");
    var u = e(".shg-row");
    document.addEventListener("load", (function(t) {
        t.target.matches(".shg-row img") && a(e(this).closest(".shg-row"))
    }), !0), document.addEventListener("click", (function(e) {
        e.target.matches(".shg-sld-dot, .shg-sld-nav-button, .shogun-tab, .shogun-accordion") && s()
    })), window.addEventListener("load", (function() {
        u = e(".shg-row"), c()
    })), document.addEventListener("pagebuilder:load", s), e(window).resize(s)
}(SHGJQ),
function(e) {
    "use strict";

    function t(e) {
        return (g[e.platform] || p).getCollection(e, n)
    }

    function n(t, n) {
        var i = e("#" + n.uuid).find(".shg-product").filter((function(t, i) {
            return e(i).parents(".shg-category").first().attr("id") === n.uuid
        })).map((function(e, t) {
            return t.id
        })).toArray();
        window.__shgProductInits.filter((function(t) {
            return t.manual && e.inArray(t.uuid, i) > -1
        })).forEach((function(e) {
            var i = t.find((t => t.id.toString() === e.productId.toString()));
            if (i) {
                var a = o(i.handle) || i;
                e.productVariantId = r(a, parseInt(n.selectedVariants[a.id], 10)), e.productHandle = a.handle, e.product = a
            }
        })), f(n, t), n.hideOutOfStock && d(n, t)
    }

    function i(e, t) {
        return e.variants.filter((function(e) {
            return e.id === t
        }))[0]
    }

    function r(e, t) {
        var n = e.variants[0].id;
        return t && t !== n && i(e, t) ? t : n
    }

    function o(e) {
        return window.__shgProducts && window.__shgProducts.hasOwnProperty(e) ? window.__shgProducts[e] : null
    }

    function a(e) {
        const t = new Set;
        for (const n of e) {
            const e = window.__shgProductInits.find((function(e) {
                return e.productId.toString() === n.id.toString()
            }));
            e && (e.staticVariant ? (variant = n.variants.find((t => t.id === e.productVariantId)), (variant.inventory_quantity > 0 || variant.available) && t.add(e.uuid)) : n.variants.some((e => e.inventory_quantity > 0 || e.available)) && t.add(e.uuid))
        }
        return t
    }

    function s(e) {
        return e.firstElementChild ? e.firstElementChild.id : ""
    }

    function c(e, t) {
        for (; e.firstChild;) e.removeChild(e.firstChild);
        e.appendChild(t)
    }

    function u(e, t, n) {
        let i = document.createDocumentFragment();
        const r = e.length * n;
        for (let o = 0; o < r; o++) {
            const r = Math.floor(o / n);
            let a = t[o];
            a || (a = document.createElement("div"), a.className = "shg-category-col"), i.appendChild(a), i.children.length === n && (c(e[r], i), i = document.createDocumentFragment())
        }
    }

    function l(e) {
        if (!e.length) return 0;
        const t = e[0];
        let n = 0;
        for (const e of t.children) {
            if (!e.className.includes("shg-category-col")) continue;
            const t = e.className.match(/shg-category-col-(\d+)/);
            if (t) {
                let e;
                try {
                    e = Number.parseInt(t[1])
                } catch {
                    e = 1
                }
                Number.isNaN(e) && (e = 1), n += e
            } else n++
        }
        return n
    }

    function d(e, t) {
        const n = document.getElementById(e.uuid),
            i = Array.from(n.getElementsByClassName("shg-category-col"));
        if (!i.length) return;
        const r = a(t),
            o = i.filter((e => {
                const t = s(e);
                return !!t && r.has(t)
            }));
        if (i.length === o.length) return;
        const c = Array.from(n.getElementsByClassName("shg-category-row"));
        u(c, o, l(c))
    }

    function f(e, t) {
        const n = document.getElementById(e.uuid),
            i = Array.from(n.getElementsByClassName("shg-category-col"));
        if (!i.length) return;
        const r = t.map((e => e.id.toString())),
            o = i.filter((e => {
                const t = s(e);
                return !!t && r.includes(window.__shgProductInits.find((e => e.uuid === t)).productId.toString())
            }));
        if (i.length === o.length) return;
        const a = Array.from(n.getElementsByClassName("shg-category-row"));
        u(a, o, l(a))
    }
    var h = {
            getCollection: async function(t, n) {
                const i = t.shopUrl ? "https://" + t.shopUrl : "",
                    r = i + "/collections/" + t.handle + "/products.json?limit=250",
                    o = async () => {
                        if (t.guestCodeEnabled) return !0;
                        const n = i + "/collections/" + t.handle + ".json";
                        e.get(n).then((e => e.collection.products_count > 250)).catch((() => !0))
                    };
                return await o() ? p.getCollection(t, n) : e.get(r).then((e => n(e.products, t)))
            }
        },
        p = {
            getCollection: function(t, n) {
                var i = {
                    "SHOGUN-AUTH-TOKEN": t.authToken
                };
                return e.ajax({
                    url: t.apiUrl,
                    method: "GET",
                    dataType: "json",
                    headers: i
                }).then((function(e) {
                    n(e.products, t)
                }))
            }
        },
        g = {
            shopify: h,
            big_commerce: p
        };
    document.addEventListener("pagebuilder:load", (function() {
        if (window.__shgCategoryInits) {
            var n = window.__shgCategoryInits.reduce((function(e, n) {
                return e.concat(t(n))
            }), []);
            e.when.apply(e, n).then((function() {
                window.__shgProductsInit(!0)
            }))
        }
    }))
}(SHGJQ),
function(e) {
    "use strict";

    function t() {
        var e = document.createElement("bootstrap"),
            t = {
                WebkitTransition: "webkitTransitionEnd",
                MozTransition: "transitionend",
                OTransition: "oTransitionEnd otransitionend",
                transition: "transitionend"
            };
        for (var n in t)
            if (void 0 !== e.style[n]) return {
                end: t[n]
            };
        return !1
    }
    e.fn.emulateTransitionEnd = function(t) {
        var n = !1,
            i = this;
        return e(this).one("bsTransitionEnd", (function() {
            n = !0
        })), setTimeout((function() {
            n || e(i).trigger(e.support.transition.end)
        }), t), this
    }, document.addEventListener("pagebuilder:load", (function() {
        e.support.transition = t(), e.support.transition && (e.event.special.bsTransitionEnd = {
            bindType: e.support.transition.end,
            delegateType: e.support.transition.end,
            handle: function(t) {
                if (e(t.target).is(this)) return t.handleObj.handler.apply(this, arguments)
            }
        })
    }))
}(SHGJQ),
function(e) {
    "use strict";

    function t(t) {
        return this.each((function() {
            var i = e(this),
                r = i.data("shg.bs.carousel"),
                o = e.extend({}, n.DEFAULTS, i.data(), "object" == typeof t && t),
                a = "string" == typeof t ? t : o.shgSlide;
            r || i.data("shg.bs.carousel", r = new n(this, o)), "number" == typeof t ? r.to(t) : a ? r[a]() : o.interval && r.pause().cycle()
        }))
    }
    var n = function(t, n) {
        this.$element = e(t), this.$indicators = this.$element.find(".shg-car-indicators"), this.options = n, this.paused = null, this.sliding = null, this.interval = null, this.$active = null, this.$items = null, this.options.keyboard && this.$element.on("keydown.shg.bs.carousel", e.proxy(this.keydown, this)), "hover" === this.options.pause && !("ontouchstart" in document.documentElement) && this.$element.on("mouseenter.shg.bs.carousel", e.proxy(this.pause, this)).on("mouseleave.shg.bs.carousel", e.proxy(this.cycle, this))
    };
    n.VERSION = "3.3.7", n.TRANSITION_DURATION = 600, n.DEFAULTS = {
        interval: 5e3,
        pause: "hover",
        wrap: !0,
        keyboard: !0
    }, n.prototype.keydown = function(e) {
        if (!/input|textarea/i.test(e.target.tagName)) {
            switch (e.which) {
                case 37:
                    this.prev();
                    break;
                case 39:
                    this.next();
                    break;
                default:
                    return
            }
            e.preventDefault()
        }
    }, n.prototype.cycle = function(t) {
        return t || (this.paused = !1), this.interval && clearInterval(this.interval), this.options.interval && !this.paused && (this.interval = setInterval(e.proxy(this.next, this), this.options.interval)), this
    }, n.prototype.getItemIndex = function(e) {
        return this.$items = e.parent().children(".shg-car-item"), this.$items.index(e || this.$active)
    }, n.prototype.getItemForDirection = function(e, t) {
        var n = this.getItemIndex(t);
        if (("prev" === e && 0 === n || "next" === e && n === this.$items.length - 1) && !this.options.wrap) return t;
        var i = (n + ("prev" === e ? -1 : 1)) % this.$items.length;
        return this.$items.eq(i)
    }, n.prototype.to = function(e) {
        var t = this,
            n = this.getItemIndex(this.$active = this.$element.find(".shg-car-item.shg-active"));
        if (!(e > this.$items.length - 1 || e < 0)) return this.sliding ? this.$element.one("slid.shg.bs.carousel", (function() {
            t.to(e)
        })) : n === e ? this.pause().cycle() : this.slide(e > n ? "next" : "prev", this.$items.eq(e))
    }, n.prototype.pause = function(t) {
        return t || (this.paused = !0), this.$element.find(".next, .prev").length && e.support.transition && (this.$element.trigger(e.support.transition.end), this.cycle(!0)), this.interval = clearInterval(this.interval), this
    }, n.prototype.next = function() {
        if (!this.sliding) return this.slide("next")
    }, n.prototype.prev = function() {
        if (!this.sliding) return this.slide("prev")
    }, n.prototype.slide = function(t, i) {
        var r = this.$element.find(".shg-car-item.shg-active"),
            o = i || this.getItemForDirection(t, r),
            a = this.interval,
            s = "next" === t ? "shg-car-left" : "shg-car-right",
            c = this;
        if (o.hasClass("shg-active")) return this.sliding = !1;
        var u = o[0],
            l = e.Event("slide.shg.bs.carousel", {
                relatedTarget: u,
                direction: s
            });
        if (this.$element.trigger(l), !l.isDefaultPrevented()) {
            if (this.sliding = !0, a && this.pause(), this.$indicators.length) {
                this.$indicators.find(".shg-active").removeClass("shg-active");
                var d = e(this.$indicators.children()[this.getItemIndex(o)]);
                d && d.addClass("shg-active")
            }
            var f = e.Event("slid.shg.bs.carousel", {
                relatedTarget: u,
                direction: s
            });
            return e.support.transition && this.$element.hasClass("shg-slide") ? (o.addClass(t), r.addClass(s), o.addClass(s), r.one("bsTransitionEnd", (function() {
                o.removeClass([t, s].join(" ")).addClass("shg-active"), r.removeClass(["shg-active", s].join(" ")), c.sliding = !1, setTimeout((function() {
                    c.$element.trigger(f)
                }), 0)
            })).emulateTransitionEnd(n.TRANSITION_DURATION)) : (r.removeClass("shg-active"), o.addClass("shg-active"), this.sliding = !1, this.$element.trigger(f)), a && this.cycle(), this
        }
    };
    var i = e.fn.carousel;
    e.fn.carousel = t, e.fn.carousel.Constructor = n, e.fn.carousel.noConflict = function() {
        return e.fn.carousel = i, this
    };
    var r = function(n) {
        var i, r = e(this),
            o = e(r.attr("data-shg-target") || (i = r.attr("href")) && i.replace(/.*(?=#[^\s]+$)/, ""));
        if (o.hasClass("shg-car")) {
            var a = e.extend({}, o.data(), r.data()),
                s = r.attr("data-shg-slide-to");
            s && (a.interval = !1), t.call(o, a), s && o.data("shg.bs.carousel").to(s), n.preventDefault()
        }
    };
    e(document).on("click.shg.bs.carousel.data-api", "[data-shg-slide]", r).on("click.shg.bs.carousel.data-api", "[data-shg-slide-to]", r), e(window).on("load", (function() {
        e('[data-shg-ride="shg-carousel"]').each((function() {
            var n = e(this);
            t.call(n, n.data())
        }))
    }))
}(SHGJQ),
function() {
    "use strict";

    function e() {
        window.SHOGUN_BOX_V2 && window.SHOGUN_BOX_V2.forEach((function(e) {
            e.url && document.querySelectorAll(`#${e.uuid} a`).forEach((e => {
                e.addEventListener("click", (e => e.stopPropagation()))
            }))
        })), window.SHOGUN_VIDEO_PARALLAX_V2 && window.SHOGUN_VIDEO_PARALLAX_V2.forEach((e => {
            const t = document.querySelector(`#${e.uuid}`).querySelector(".shg-box-video-wrapper");
            window.jarallax(t, {
                speed: e.speed,
                videoSrc: e.url,
                videoLoop: !0,
                videoVolume: e.sound ? 50 : 0,
                imgSrc: e.backupImage,
                onInit: function() {
                    const e = t.closest("div");
                    e && (e.style.zIndex = "1");
                    const n = t.closest("iframe");
                    n && (n.style.zIndex = "1")
                },
                disableVideo: function() {
                    return !1
                },
                onError: function() {
                    e.backupImage && window.jarallax(t, "destroy")
                }
            })
        }))
    }
    window.addEventListener("load", e)
}(),
function(e) {
    "use strict";

    function t() {
        if (window.SHOGUN_BOX && window.SHOGUN_BOX.forEach((function(t) {
                if (t.url) {
                    var n = "#" + t.id,
                        i = e(n);
                    e(n + " a").click((function(e) {
                        e.stopPropagation()
                    })), i.click((function(e) {
                        "undefined" != typeof Weglot ? window.open(i.data("shg-href"), t.new_window ? "_blank" : "_self") : window.open(t.url, t.new_window ? "_blank" : "_self"), e.stopPropagation()
                    }))
                }
            })), window.SHOGUN_VIDEO_PARALLAX)
            for (var t = 0; t < window.SHOGUN_VIDEO_PARALLAX.length; t++) {
                var n = window.SHOGUN_VIDEO_PARALLAX[t],
                    i = e(n.id).children(".shg-box-video-wrapper").first();
                window.jarallax(i, {
                    speed: n.speed,
                    videoSrc: n.url,
                    videoLoop: !0,
                    videoVolume: n.sound ? 50 : 0,
                    imgSrc: n.backupImage,
                    onInit: function() {
                        i.closest("div").css("z-index", 1), i.closest("iframe").css("z-index", 1)
                    },
                    disableVideo: function() {
                        return !1
                    },
                    onError: function() {
                        n.backupImage && window.jarallax(i, "destroy")
                    }
                })
            }
    }
    window.__shogunBoxesOnLoad = t, e(window).on("load", t)
}(SHGJQ),
function(e) {
    "use strict";

    function t(t) {
        t.addClass("shogun-accordion-active"), t.children(".shogun-accordion-body").slideDown("fast", (function() {
            e(this).addClass("shogun-accordion-active")
        }))
    }

    function n(t) {
        t.removeClass("shogun-accordion-active"), t.children(".shogun-accordion-body").slideUp("fast", (function() {
            e(this).removeClass("shogun-accordion-active")
        }))
    }
    e(document).attr("shg-accordion-v2") || (e(document).attr("shg-accordion-v2", 1), e(document).on("click", ".shogun-accordion-heading", (function(i) {
        i.stopPropagation();
        var r = e(this),
            o = r.next(".shogun-accordion-body"),
            a = r.parent(),
            s = r.closest(".shogun-accordion-wrapper"),
            c = o.hasClass("shogun-accordion-active");
        s.data("multi") || n(s.children(".shogun-accordion-active")), c ? n(a) : t(a), window.SHOGUN_MAP_RESIZER && window.SHOGUN_MAP_RESIZER()
    })))
}(SHGJQ),
function(e) {
    "use strict";
    e(document).attr("shg-accordion") || (e(document).attr("shg-accordion", 1), e(document).on("click", ".shogun-panel-heading, .shogun-panel-title, .shogun-panel-title a", (function(t) {
        t.stopPropagation();
        var n = e(this).closest(".shogun-panel-group"),
            i = e(this).closest(".shogun-panel").children(".shogun-panel-body");
        if (n.data("multi")) return i.slideToggle("fast").toggleClass("in"), !1;
        var r = i.hasClass("in");
        return n.children(".shogun-panel").each((function() {
            e(this).children(".shogun-panel-body.in").each((function() {
                var t = e(this);
                t.slideToggle("fast", (function() {
                    t.removeClass("in")
                }))
            }))
        })), r || i.slideToggle("fast", (function() {
            i.addClass("in")
        })), window.SHOGUN_MAP_RESIZER && window.SHOGUN_MAP_RESIZER(), !1
    })))
}(SHGJQ);