window[window["TiktokAnalyticsObject"]]._env = {
    "env": "external",
    "key": ""
};
window[window["TiktokAnalyticsObject"]]._variation_id = 'test_3';
window[window["TiktokAnalyticsObject"]]._cc = 'PK';;
if (!window[window["TiktokAnalyticsObject"]]._server_unique_id) window[window["TiktokAnalyticsObject"]]._server_unique_id = 'e682b179-a7c9-11ee-bdec-08c0eb4a4cee';
window[window["TiktokAnalyticsObject"]]._plugins = {
    "AdvancedMatching": true,
    "AutoAdvancedMatching": true,
    "AutoConfig": true,
    "Callback": true,
    "DiagnosticsConsole": true,
    "Identify": true,
    "Monitor": false,
    "PangleCookieMatching": true,
    "PerformanceInteraction": false,
    "Shopify": true,
    "WebFL": false
};
window[window["TiktokAnalyticsObject"]]._auto_config = {
    "open_graph": ["audience"],
    "microdata": ["audience"],
    "json_ld": ["audience"],
    "meta": null
};
! function() {
    function t() {
        return window && window.TiktokAnalyticsObject || "ttq"
    }

    function i() {
        return window && window[t()]
    }
    var o, n, e, c, a, r = [{
            id: "MWNkZmM2YTcxMA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MWNkZmM2YTcxMQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MWNkZmM2YTcxMg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MWNkZmM2YTcxMw",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MWNkZmM2YTcxNA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MWNkZmM2YTcxNQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MWNkZmM2YTcxNg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MWNkZmM2YTcxNw",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MWNkZmM2YTcxOA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MWNkZmM2YTcxOQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MWNkZmM2YTcxMTA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MWNkZmM2YTcxMTE",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MWNkZmM2YTcxMTI",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }, {
            id: "MWNkZmM2YTcxMTM",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }, {
            id: "MWNkZmM2YTcxMTQ",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }, {
            id: "MWNkZmM2YTcxMTU",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }],
        d = {
            "info": {
                "pixelCode": "CK3OUDRC77U7PQISHIN0",
                "name": "Nine West - MF",
                "status": 0,
                "setupMode": 0,
                "partner": "",
                "advertiserID": "7270195579035189249",
                "is_onsite": false,
                "firstPartyCookieEnabled": true
            },
            "plugins": {
                "Shopify": false,
                "AdvancedMatching": {
                    "email": true,
                    "phone_number": true
                },
                "AutoAdvancedMatching": null,
                "Callback": true,
                "Identify": true,
                "Monitor": true,
                "PerformanceInteraction": true,
                "WebFL": true,
                "AutoConfig": {
                    "form_rules": null,
                    "vc_rules": {
                        "ninewest.com": [{
                            "version": "stable",
                            "rule_key": "ninewest.com",
                            "valueXpath": "//strong[@class='_19gi7yt0 _19gi7ytl _1fragemfs _19gi7yt1 notranslate']",
                            "currency": {
                                "val": "USD"
                            }
                        }]
                    }
                },
                "DiagnosticsConsole": true,
                "PangleCookieMatching": false,
                "CompetitorInsight": true
            },
            "rules": []
        },
        M = "https://analytics.tiktok.com/i18n/pixel/static/",
        p = i();
    p || (p = [], window && (window[t()] = p)), Object.assign(d, {
            options: (o = d.info.pixelCode, (n = i()._o) && n[o] || {})
        }),
        function(t) {
            p._i || (p._i = {});
            var i = t.info.pixelCode;
            i && (p._i[i] || (p._i[i] = []), Object.assign(p._i[i], t), p._i[i]._load = +new Date)
        }(d), e = function(t, i, o) {
            var n = 0 < arguments.length && void 0 !== t ? t : {},
                e = 1 < arguments.length ? i : void 0,
                i = 2 < arguments.length ? o : void 0,
                o = function(t, i) {
                    for (var o = 0; o < t.length; o++)
                        if (i.call(null, t[o], o)) return t[o]
                }(r, function(t) {
                    var i = t.map;
                    return function(t, i) {
                        for (var o = 0; o < t.length; o++)
                            if (!i.call(null, t[o], o)) return !1;
                        return !0
                    }(Object.keys(i), function(t) {
                        return !(!n[t] || !e[t]) === i[t]
                    })
                });
            return o ? i + "main.".concat(o.id, ".js") : i + "main.".concat(r[0].id, ".js")
        }(p._plugins, d.plugins, M), c = d.info.pixelCode, (void 0 !== self.DedicatedWorkerGlobalScope ? self instanceof self.DedicatedWorkerGlobalScope : "DedicatedWorkerGlobalScope" === self.constructor.name) ? self.importScripts && self.importScripts(e) : ((a = document.createElement("script")).type = "text/javascript", a.async = !0, a.src = e, a.setAttribute("data-id", c), (c = document.getElementsByTagName("script")[0]) && c.parentNode && c.parentNode.insertBefore(a, c))
}();